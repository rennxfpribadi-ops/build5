// theme.dart
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

// ═════════════════════════════════════════════════════════════════════
//  THEME MODE (3 pilihan)
// ═════════════════════════════════════════════════════════════════════
enum AppThemeMode { normal, comic3d, monochrome }

class AppThemeModeInfo {
  final AppThemeMode mode;
  final String name;
  final String subtitle;
  final IconData icon;

  const AppThemeModeInfo({
    required this.mode,
    required this.name,
    required this.subtitle,
    required this.icon,
  });
}

const List<AppThemeModeInfo> kThemeModes = [
  AppThemeModeInfo(
    mode: AppThemeMode.normal,
    name: 'Purple Luxury',
    subtitle: 'Violet Premium Glass',
    icon: Icons.auto_awesome_rounded,
  ),
  AppThemeModeInfo(
    mode: AppThemeMode.comic3d,
    name: 'Komik 3D Tebal',
    subtitle: 'Border Hitam + Shadow Padat',
    icon: Icons.auto_stories_rounded,
  ),
  AppThemeModeInfo(
    mode: AppThemeMode.monochrome,
    name: 'Putih Biru',
    subtitle: 'Clean Light Mode',
    icon: Icons.wb_sunny_rounded,
  ),
];

// ═════════════════════════════════════════════════════════════════════
//  THEME MANAGER
// ═════════════════════════════════════════════════════════════════════
class ThemeModeManager {
  static const _prefsKey = 'app_theme_mode';

  static final ValueNotifier<AppThemeMode> current =
      ValueNotifier<AppThemeMode>(AppThemeMode.normal);

  static AppThemeMode get mode => current.value;

  static Future<void> setMode(AppThemeMode m) async {
    current.value = m;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_prefsKey, m.name);
  }

  static Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getString(_prefsKey);
    if (saved != null) {
      final found = AppThemeMode.values.firstWhere(
        (e) => e.name == saved,
        orElse: () => AppThemeMode.normal,
      );
      current.value = found;
    }
  }

  static Future<void> reset() async {
    current.value = AppThemeMode.normal;
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_prefsKey);
  }

  static bool get isNormal     => mode == AppThemeMode.normal;
  static bool get isComic3d    => mode == AppThemeMode.comic3d;
  static bool get isMonochrome => mode == AppThemeMode.monochrome; // Bertindak sebagai Light Mode sekarang
}

// ═════════════════════════════════════════════════════════════════════
//  APP COLORS
//  RULE:
//  • comic3d    → HANYA menebalkan border + sisi hitam padat (shadow).
//                 Warna lain SAMA dengan Purple Luxury.
//  • monochrome → Putih Biru (Light Mode) sesuai gambar referensi.
//  • normal     → default.
// ═════════════════════════════════════════════════════════════════════
class AppColors {
  // ── BACKGROUND ──
  static Color get bg {
    if (ThemeModeManager.isMonochrome) return const Color(0xFFF4F8FB); // Latar belakang putih kebiruan
    return const Color(0xFF0B0614);
  }

  static Color get card {
    if (ThemeModeManager.isMonochrome) return const Color(0xFFFFFFFF); // Kartu putih bersih
    return const Color(0xFF1A0F2E);
  }

  static Color get card2 {
    if (ThemeModeManager.isMonochrome) return const Color(0xFFF1F5F9); // Sedikit abu-abu kebiruan
    return const Color(0xFF241538);
  }

  // ── BORDER ──
  static Color get border {
    if (ThemeModeManager.isComic3d)    return const Color(0xFF000000);
    if (ThemeModeManager.isMonochrome) return const Color(0xFFD0E1F9); // Border biru muda
    return const Color(0xFF3D2A5C);
  }

  static Color get borderLit {
    if (ThemeModeManager.isComic3d)    return const Color(0xFF000000);
    if (ThemeModeManager.isMonochrome) return const Color(0xFFA0C0E8); // Border biru agak gelap
    return const Color(0xFF5A3F82);
  }

  // ── TEXT ──
  static Color get text {
    if (ThemeModeManager.isMonochrome) return const Color(0xFF1A2B4C); // Biru gelap / Navy
    return const Color(0xFFF5EBFF);
  }

  static Color get textSub {
    if (ThemeModeManager.isMonochrome) return const Color(0xFF5A7184); // Abu-abu kebiruan
    return const Color(0xFFC4A8E0);
  }

  static Color get textHint {
    if (ThemeModeManager.isMonochrome) return const Color(0xFF8CA1B5); // Abu-abu terang
    return const Color(0xFF8A6BA8);
  }

  // ── ACCENT ──
  static Color get accent {
    if (ThemeModeManager.isMonochrome) return const Color(0xFF2B7DE9); // Biru utama (tombol)
    return const Color(0xFFB45CFF);
  }

  static Color get accentMid {
    if (ThemeModeManager.isMonochrome) return const Color(0xFF1E5BBA); // Biru agak gelap
    return const Color(0xFF9333EA);
  }

  static Color get accentLight {
    if (ThemeModeManager.isMonochrome) return const Color(0xFF60A5FA); // Biru muda
    return const Color(0xFFD8B4FE);
  }

  static Color get accentDark {
    if (ThemeModeManager.isMonochrome) return const Color(0xFF1A4B9C); // Biru sangat gelap
    return const Color(0xFF6D28D9);
  }

  static Color get dark {
    if (ThemeModeManager.isMonochrome) return const Color(0xFFE2E8F0); 
    return const Color(0xFF0F0819);
  }

  // ── OVERLAY ──
  static Color get overlay40 => const Color(0x66000000);
  static Color get overlay60 => const Color(0x99000000);
  static Color get overlay80 => const Color(0xCC000000);

  // ── STATUS ──
  static Color get online {
    if (ThemeModeManager.isMonochrome) return const Color(0xFF10B981); // Hijau
    return const Color(0xFF00E676);
  }

  static Color get batteryLow {
    if (ThemeModeManager.isMonochrome) return const Color(0xFFEF4444); // Merah
    return const Color(0xFFFF1744);
  }

  static Color get batteryMid {
    if (ThemeModeManager.isMonochrome) return const Color(0xFFF59E0B); // Oranye
    return const Color(0xFFFFB300);
  }

  static Color get batteryHigh {
    if (ThemeModeManager.isMonochrome) return const Color(0xFF10B981); // Hijau
    return const Color(0xFF00E676);
  }

  // ── CHAT BUBBLE ──
  static Color get bubbleMine {
    if (ThemeModeManager.isMonochrome) return const Color(0xFFE0F2FE); // Biru sangat muda
    return const Color(0x26B45CFF);
  }

  static Color get bubbleOther {
    if (ThemeModeManager.isMonochrome) return const Color(0xFFF1F5F9); // Abu-abu terang
    return const Color(0xFF1A0F2E);
  }

  // ── GRADIENT ──
  static LinearGradient get btnGrad {
    if (ThemeModeManager.isMonochrome) {
      return const LinearGradient(
        colors: [Color(0xFF3B82F6), Color(0xFF2563EB)], // Gradien biru cerah ke biru
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      );
    }
    return const LinearGradient(
      colors: [Color(0xFFB45CFF), Color(0xFF6D28D9)],
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
    );
  }

  static LinearGradient get glassGrad {
    if (ThemeModeManager.isMonochrome) {
      return LinearGradient(
        colors: [
          Colors.white.withOpacity(0.9),
          Colors.white.withOpacity(0.6),
        ],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      );
    }
    return LinearGradient(
      colors: [
        Colors.white.withOpacity(0.06),
        Colors.white.withOpacity(0.02),
      ],
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
    );
  }

  static Color get glassBorder {
    if (ThemeModeManager.isComic3d) return const Color(0xFF000000);
    if (ThemeModeManager.isMonochrome) return const Color(0xFFE2E8F0); // Border tipis abu/biru
    return const Color(0x1AFFFFFF);
  }

  // ── SHADOW ──
  static List<BoxShadow> get glassShadow {
    if (ThemeModeManager.isComic3d) {
      return const [
        BoxShadow(
          color: Color(0xFF000000),
          offset: Offset(6, 6),
          blurRadius: 0,
          spreadRadius: 0,
        ),
      ];
    }
    if (ThemeModeManager.isMonochrome) {
      return [
        BoxShadow(
          color: const Color(0xFF1A2B4C).withOpacity(0.06), // Shadow biru sangat tipis
          blurRadius: 16,
          offset: const Offset(0, 4),
        ),
      ];
    }
    return [
      BoxShadow(
        color: Colors.black.withOpacity(0.35),
        blurRadius: 30,
        offset: const Offset(0, 8),
      ),
    ];
  }

  static List<BoxShadow> get softShadow {
    if (ThemeModeManager.isComic3d) {
      return const [
        BoxShadow(
          color: Color(0xFF000000),
          offset: Offset(4, 4),
          blurRadius: 0,
          spreadRadius: 0,
        ),
      ];
    }
    if (ThemeModeManager.isMonochrome) {
      return [
        BoxShadow(
          color: const Color(0xFF1A2B4C).withOpacity(0.04),
          blurRadius: 8,
          offset: const Offset(0, 2),
        ),
      ];
    }
    return [
      BoxShadow(
        color: Colors.black.withOpacity(0.15),
        blurRadius: 16,
        offset: const Offset(0, 4),
      ),
    ];
  }

  // ── GEOMETRY ──
  static double get cardRadius {
    if (ThemeModeManager.isComic3d) return 8;
    return 16;
  }

  static double get sheetRadius {
    if (ThemeModeManager.isComic3d) return 10;
    return 20;
  }

  static double get borderWidth {
    if (ThemeModeManager.isComic3d) return 4;
    return 1;
  }

  // ── EXTRA ACCENTS ──
  static Color get amber => const Color(0xFFF59E0B);
  static Color get gold  => const Color(0xFFFBBF24);
  static Color get purple => ThemeModeManager.isMonochrome
      ? const Color(0xFF6366F1) : const Color(0xFFB388FF);
  static Color get pink => ThemeModeManager.isMonochrome
      ? const Color(0xFFEC4899) : const Color(0xFFFF5CC8);
  static Color get teal => ThemeModeManager.isMonochrome
      ? const Color(0xFF06B6D4) : const Color(0xFF00D4FF);
  static Color get green => ThemeModeManager.isMonochrome
      ? const Color(0xFF10B981) : const Color(0xFF00E676);
  static Color get red => ThemeModeManager.isMonochrome
      ? const Color(0xFFEF4444) : const Color(0xFFFF1744);
}

// ═════════════════════════════════════════════════════════════════════
//  THEME SCOPE
// ═════════════════════════════════════════════════════════════════════
class ThemeScope extends StatelessWidget {
  final Widget child;
  const ThemeScope({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppThemeMode>(
      valueListenable: ThemeModeManager.current,
      builder: (context, _, __) => child,
    );
  }
}

// ═════════════════════════════════════════════════════════════════════
//  ANIMATED GRID BACKGROUND
// ═════════════════════════════════════════════════════════════════════
class AnimatedGridBackground extends StatelessWidget {
  final AnimationController controller;
  const AnimatedGridBackground({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (_, __) => CustomPaint(
        painter: _GridPainter(controller.value),
      ),
    );
  }
}

class _GridPainter extends CustomPainter {
  final double t;
  _GridPainter(this.t);

  @override
  void paint(Canvas canvas, Size size) {
    final grid = Paint()
      ..color = AppColors.border.withOpacity(0.06)
      ..strokeWidth = 0.5;
    const step = 40.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), grid);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }
  }

  @override
  bool shouldRepaint(covariant _GridPainter old) => old.t != t;
}

// ═════════════════════════════════════════════════════════════════════
//  APP BACKGROUND
// ═════════════════════════════════════════════════════════════════════
class AppBackground extends StatelessWidget {
  final AnimationController? controller;
  final String? imagePath;
  final Widget child;

  const AppBackground({
    super.key,
    this.controller,
    this.imagePath,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Positioned.fill(child: _buildBaseBg()),
        Positioned.fill(
          child: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: ThemeModeManager.isMonochrome
                    ? [
                        // Gradien sangat tipis untuk light mode agar tidak flat
                        Colors.white.withOpacity(0.4),
                        AppColors.bg.withOpacity(0.8),
                      ]
                    : [
                        AppColors.bg.withOpacity(0.75),
                        AppColors.bg.withOpacity(0.85),
                        AppColors.bg.withOpacity(0.95),
                      ],
              ),
            ),
          ),
        ),
        Positioned.fill(child: child),
      ],
    );
  }

  Widget _buildBaseBg() {
    if (ThemeModeManager.isMonochrome) {
      return ColoredBox(color: AppColors.bg);
    }
    if (imagePath != null) {
      return Image.asset(
        imagePath!,
        fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => controller != null
            ? AnimatedGridBackground(controller: controller!)
            : ColoredBox(color: AppColors.bg),
      );
    }
    if (controller != null) {
      return AnimatedGridBackground(controller: controller!);
    }
    return ColoredBox(color: AppColors.bg);
  }
}