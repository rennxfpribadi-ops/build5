import 'dart:async';
import 'dart:convert';
import 'dart:ui' show ImageFilter;
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'theme.dart';

const String baseUrl = 'http://cp.zyrostore.id:3448';

// ═════════════════════════════════════════════════════════════════════
//  ROLE HELPERS
// ═════════════════════════════════════════════════════════════════════
const _roleOrder = ['developer', 'owner', 'reseller', 'fullup', 'member'];

int _roleRank(String r) {
  final idx = _roleOrder.indexOf(r.toLowerCase());
  return idx == -1 ? 99 : idx;
}

Color _roleColor(String role) {
  switch (role.toLowerCase()) {
    case 'developer': return const Color(0xFFB45CFF);
    case 'owner':     return const Color(0xFFFF5252);
    case 'reseller':  return const Color(0xFF00D4FF);
    case 'fullup':    return const Color(0xFFFFB300);
    case 'member':    return const Color(0xFF9E9E9E);
    default:          return const Color(0xFF9E9E9E);
  }
}

IconData _roleIcon(String role) {
  switch (role.toLowerCase()) {
    case 'developer': return Icons.code_rounded;
    case 'owner':     return Icons.workspace_premium_rounded;
    case 'reseller':  return Icons.storefront_rounded;
    case 'fullup':    return Icons.star_rounded;
    case 'member':    return Icons.person_rounded;
    default:          return Icons.person_rounded;
  }
}

bool _canManageRoles(String role) {
  final r = role.toLowerCase();
  return r == 'developer' || r == 'owner';
}

bool _isUpgradeable(String role) {
  final r = role.toLowerCase();
  return r == 'fullup' || r == 'member';
}

/// Aturan grant: developer → semua role lebih tinggi dari target.
/// owner → hanya role di bawah owner (reseller / fullup / member).
List<String> _upgradeTargets(String myRole, String targetCurrentRole) {
  final myRank = _roleRank(myRole);
  final targetRank = _roleRank(targetCurrentRole);
  return _roleOrder.where((r) {
    final rRank = _roleRank(r);
    if (rRank >= targetRank) return false;
    if (myRank == 0) return true;   // developer: semua
    if (myRank == 1) return rRank >= 2; // owner: hanya < owner
    return false;
  }).toList();
}

// ═════════════════════════════════════════════════════════════════════
//  PAGE
// ═════════════════════════════════════════════════════════════════════
class UserManagementPage extends StatefulWidget {
  final String sessionKey;
  final String currentRole;
  const UserManagementPage({
    super.key,
    required this.sessionKey,
    required this.currentRole,
  });

  @override
  State<UserManagementPage> createState() => _UserManagementPageState();
}

class _UserManagementPageState extends State<UserManagementPage> {
  List<Map<String, dynamic>> _allUsers = [];
  List<Map<String, dynamic>> _filtered = [];
  Map<String, int> _roleSummary = {};
  int _totalUsers = 0;
  bool _loading = true;
  String? _error;
  String _searchQuery = '';
  String _filterRole = 'all';
  Timer? _autoRefreshTimer;

  final TextEditingController _searchCtrl = TextEditingController();
  final Set<String> _selectedUsernames = {};
  bool _selectMode = false;

  // ── Init ────────────────────────────────────────────────────────────
  @override
  void initState() {
    super.initState();
    _fetchUsers();
    _autoRefreshTimer = Timer.periodic(const Duration(seconds: 15), (_) {
      if (mounted) _fetchUsers(silent: true);
    });
  }

  @override
  void dispose() {
    _autoRefreshTimer?.cancel();
    _searchCtrl.dispose();
    super.dispose();
  }

  // ── API ─────────────────────────────────────────────────────────────
  Future<void> _fetchUsers({bool silent = false}) async {
    if (!silent) setState(() { _loading = true; _error = null; });
    try {
      final res = await http
          .get(Uri.parse('$baseUrl/listUsers?key=${Uri.encodeComponent(widget.sessionKey)}'))
          .timeout(const Duration(seconds: 10));
      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['authorized'] == true) {
        final users = List<Map<String, dynamic>>.from(data['users'] ?? []);
        users.sort((a, b) =>
            _roleRank(a['role'] ?? 'member').compareTo(_roleRank(b['role'] ?? 'member')));
        if (mounted) {
          setState(() {
            _allUsers = users;
            _roleSummary = Map<String, int>.from(
                (data['roleSummary'] ?? {}).map((k, v) => MapEntry(k.toString(), v as int)));
            _totalUsers = data['total'] ?? users.length;
            _loading = false;
          });
          _applyFilter();
        }
      } else {
        if (mounted) setState(() {
          _error = data['message'] ?? 'Tidak terotorisasi';
          _loading = false;
        });
      }
    } catch (e) {
      if (mounted) setState(() {
        _error = 'Gagal terhubung: $e';
        _loading = false;
      });
    }
  }

  void _applyFilter() {
    setState(() {
      _filtered = _allUsers.where((u) {
        final uname = (u['username'] ?? '').toString().toLowerCase();
        final role = (u['role'] ?? 'member').toString().toLowerCase();
        final matchSearch = _searchQuery.isEmpty || uname.contains(_searchQuery.toLowerCase());
        final matchRole = _filterRole == 'all' || role == _filterRole;
        return matchSearch && matchRole;
      }).toList();
    });
  }

  Future<void> _deleteUser(String username) async {
    final confirmed = await _showConfirmDialog(username);
    if (!confirmed) return;
    try {
      final res = await http.get(Uri.parse(
          '$baseUrl/deleteUser?key=${Uri.encodeComponent(widget.sessionKey)}'
          '&username=${Uri.encodeComponent(username)}'))
          .timeout(const Duration(seconds: 10));
      final data = jsonDecode(res.body);
      if (data['deleted'] == true) {
        _showSnack('✅ @$username berhasil dihapus', AppColors.green);
        _fetchUsers(silent: true);
      } else {
        _showSnack('❌ ${data["message"] ?? "Gagal menghapus"}', AppColors.red);
      }
    } catch (e) {
      _showSnack('❌ Error: $e', AppColors.red);
    }
  }

  // ── Add Days ────────────────────────────────────────────────────────
  Future<void> _showAddDaysDialog(String username, String currentExpDate) async {
    final ctrl = TextEditingController();
    await showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.6),
      builder: (_) => _glassDialog(
        Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
              Icon(Icons.add_alarm_rounded, color: AppColors.green, size: 22),
              const SizedBox(width: 10),
              Expanded(child: Text('Tambah Waktu',
                  style: TextStyle(color: AppColors.text, fontSize: 16, fontWeight: FontWeight.bold))),
            ]),
            const SizedBox(height: 6),
            Text('@$username · Expired: $currentExpDate',
                style: TextStyle(color: AppColors.textSub, fontSize: 12),
                maxLines: 1, overflow: TextOverflow.ellipsis),
            const SizedBox(height: 16),
            TextField(
              controller: ctrl,
              keyboardType: TextInputType.number,
              style: TextStyle(color: AppColors.text),
              decoration: InputDecoration(
                hintText: 'Tambah berapa hari?',
                hintStyle: TextStyle(color: AppColors.textHint, fontSize: 13),
                filled: true,
                fillColor: Colors.white.withOpacity(0.05),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide.none),
                suffixText: 'hari',
                suffixStyle: TextStyle(color: AppColors.textSub),
              ),
            ),
            const SizedBox(height: 18),
            Row(mainAxisAlignment: MainAxisAlignment.end, children: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: Text('Batal', style: TextStyle(color: AppColors.textHint))),
              const SizedBox(width: 8),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.green,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
                onPressed: () async {
                  final days = int.tryParse(ctrl.text.trim());
                  if (days == null || days <= 0) return;
                  Navigator.pop(context);
                  await _addDaysToUser(username, days);
                },
                child: const Text('Tambah',
                    style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold))),
            ]),
          ],
        ),
      ),
    );
  }

  Future<void> _addDaysToUser(String username, int days) async {
    try {
      final res = await http.get(Uri.parse(
          '$baseUrl/editUser?key=${Uri.encodeComponent(widget.sessionKey)}'
          '&username=${Uri.encodeComponent(username)}&addDays=$days'))
          .timeout(const Duration(seconds: 10));
      final data = jsonDecode(res.body);
      if (data['edited'] == true) {
        _showSnack('✅ +$days hari ditambahkan ke @$username', AppColors.green);
        _fetchUsers(silent: true);
      } else {
        _showSnack('❌ ${data["message"] ?? "Gagal tambah hari"}', AppColors.red);
      }
    } catch (e) {
      _showSnack('❌ Error: $e', AppColors.red);
    }
  }

  // ═════════════════════════════════════════════════════════════════════
  //  UPGRADE ROLE — endpoint khusus: /upgradeRole
  //  GET /upgradeRole?key=<sessionKey>&username=<target>&role=<newRole>
  //  Response: { upgraded: true, message: "..." } (atau edited/success)
  // ═════════════════════════════════════════════════════════════════════
  Future<void> _showUpgradeDialog(String username, String currentRole) async {
    final targets = _upgradeTargets(widget.currentRole, currentRole);
    if (targets.isEmpty) {
      _showSnack('Tidak ada role yang bisa dituju untuk @$username', AppColors.amber);
      return;
    }

    String? selected;

    await showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.6),
      builder: (_) => _glassDialog(
        StatefulBuilder(
          builder: (ctx, setS) => Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(children: [
                const Icon(Icons.upgrade_rounded, color: Color(0xFFFFB300), size: 22),
                const SizedBox(width: 10),
                Expanded(child: Text('Upgrade Role',
                    style: TextStyle(color: AppColors.text, fontSize: 16, fontWeight: FontWeight.bold))),
              ]),
              const SizedBox(height: 6),
              Text('@$username · sekarang ${currentRole.toUpperCase()}',
                  style: TextStyle(color: AppColors.textSub, fontSize: 12)),
              const SizedBox(height: 16),
              Wrap(spacing: 8, runSpacing: 8, children: targets.map((r) {
                final c = _roleColor(r);
                final sel = selected == r;
                return GestureDetector(
                  onTap: () => setS(() => selected = r),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 180),
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
                    decoration: BoxDecoration(
                      color: sel ? c.withOpacity(0.28) : Colors.white.withOpacity(0.05),
                      borderRadius: BorderRadius.circular(50),
                      border: Border.all(
                        color: sel ? c : Colors.white.withOpacity(0.18),
                        width: sel ? 1.6 : 1),
                      boxShadow: sel
                          ? [BoxShadow(color: c.withOpacity(0.35), blurRadius: 12)]
                          : [],
                    ),
                    child: Row(mainAxisSize: MainAxisSize.min, children: [
                      Icon(_roleIcon(r), color: c, size: 14),
                      const SizedBox(width: 6),
                      Text(r.toUpperCase(),
                          style: TextStyle(
                              color: sel ? c : AppColors.textSub,
                              fontSize: 11,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 0.5)),
                    ]),
                  ),
                );
              }).toList()),
              const SizedBox(height: 20),
              Row(mainAxisAlignment: MainAxisAlignment.end, children: [
                TextButton(
                  onPressed: () => Navigator.pop(ctx),
                  child: Text('Batal', style: TextStyle(color: AppColors.textHint))),
                const SizedBox(width: 8),
                ElevatedButton(
                  onPressed: selected == null
                      ? null
                      : () {
                          Navigator.pop(ctx);
                          _upgradeRole(username, selected!);
                        },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFFFB300),
                    disabledBackgroundColor: Colors.white.withOpacity(0.08),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
                  child: Text('Upgrade',
                      style: TextStyle(
                          color: selected != null ? Colors.black : AppColors.textHint,
                          fontWeight: FontWeight.bold)),
                ),
              ]),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _upgradeRole(String username, String newRole) async {
    try {
      final res = await http.get(Uri.parse(
          '$baseUrl/upgradeRole?key=${Uri.encodeComponent(widget.sessionKey)}'
          '&username=${Uri.encodeComponent(username)}'
          '&role=${Uri.encodeComponent(newRole)}'))
          .timeout(const Duration(seconds: 10));
      final data = jsonDecode(res.body);
      final ok = data['upgraded'] == true ||
          data['edited'] == true ||
          data['success'] == true;
      if (ok) {
        _showSnack('✅ @$username diupgrade ke ${newRole.toUpperCase()}', AppColors.green);
        _fetchUsers(silent: true);
      } else {
        _showSnack('❌ ${data["message"] ?? "Gagal upgrade role"}', AppColors.red);
      }
    } catch (e) {
      _showSnack('❌ Error: $e', AppColors.red);
    }
  }

  // ── Confirm Dialog ──────────────────────────────────────────────────
  Future<bool> _showConfirmDialog(String username) async {
    return await showDialog<bool>(
          context: context,
          barrierColor: Colors.black.withOpacity(0.6),
          builder: (_) => _glassDialog(
            Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(children: [
                  Icon(Icons.warning_amber_rounded, color: AppColors.red, size: 22),
                  const SizedBox(width: 10),
                  Text('Hapus Akun',
                      style: TextStyle(color: AppColors.text, fontSize: 16, fontWeight: FontWeight.bold)),
                ]),
                const SizedBox(height: 12),
                Text('Yakin ingin menghapus akun @$username?\nTindakan ini tidak bisa dibatalkan.',
                    style: TextStyle(color: AppColors.textSub, fontSize: 13)),
                const SizedBox(height: 18),
                Row(mainAxisAlignment: MainAxisAlignment.end, children: [
                  TextButton(
                    onPressed: () => Navigator.pop(context, false),
                    child: Text('Batal', style: TextStyle(color: AppColors.textHint))),
                  const SizedBox(width: 8),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.red,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
                    onPressed: () => Navigator.pop(context, true),
                    child: const Text('Hapus',
                        style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold))),
                ]),
              ],
            ),
          ),
        ) ??
        false;
  }

  void _showSnack(String msg, Color color) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg, style: const TextStyle(color: Colors.white, fontSize: 13)),
      backgroundColor: color,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      margin: const EdgeInsets.all(14),
      duration: const Duration(seconds: 3),
    ));
  }

  // ═════════════════════════════════════════════════════════════════════
  //  BUILD
  // ═════════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    final isDev = widget.currentRole.toLowerCase() == 'developer';
    return Scaffold(
      backgroundColor: AppColors.bg,
      floatingActionButton: (isDev && _selectMode && _selectedUsernames.isNotEmpty)
          ? FloatingActionButton.extended(
              backgroundColor: AppColors.red,
              icon: const Icon(Icons.delete_rounded, color: Colors.white),
              label: Text('Hapus ${_selectedUsernames.length} akun',
                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
              onPressed: () async {
                for (final u in _selectedUsernames.toList()) {
                  await _deleteUser(u);
                }
                setState(() { _selectedUsernames.clear(); _selectMode = false; });
              },
            )
          : null,
      body: _LiquidBg(
        child: SafeArea(
          bottom: false,
          child: Column(
            children: [
              _buildHeader(),
              if (!_loading && _error == null) ...[
                _buildRoleSummaryBar(),
                _buildSearchAndFilter(),
              ],
              Expanded(child: _buildBody()),
            ],
          ),
        ),
      ),
    );
  }

  // ── Header ──────────────────────────────────────────────────────────
  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 14, 14, 8),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: _glassBox(radius: 20, accent: AppColors.accent, elevated: true),
        child: Row(children: [
          Container(
            width: 42, height: 42,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: AppColors.accent.withOpacity(0.18),
              border: Border.all(color: AppColors.accent.withOpacity(0.5), width: 1.5),
              boxShadow: [BoxShadow(color: AppColors.accent.withOpacity(0.3), blurRadius: 14)],
            ),
            child: Icon(Icons.manage_accounts_rounded, color: AppColors.accent, size: 22),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('USER MANAGEMENT',
                  style: TextStyle(
                    color: AppColors.text,
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                    letterSpacing: 1.5,
                  )),
              Text(
                _loading ? 'Memuat...' : 'Total: $_totalUsers akun',
                style: TextStyle(color: AppColors.textSub, fontSize: 11),
              ),
            ]),
          ),
          _GlassIconButton(
            icon: Icons.refresh_rounded,
            color: AppColors.accent,
            size: 40,
            onTap: () => _fetchUsers(),
          ),
        ]),
      ),
    );
  }

  // ── Role Summary ────────────────────────────────────────────────────
  Widget _buildRoleSummaryBar() {
    final roles = _roleOrder.where((r) => (_roleSummary[r] ?? 0) > 0).toList();
    if (roles.isEmpty) return const SizedBox.shrink();
    return SizedBox(
      height: 60,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.fromLTRB(14, 4, 14, 4),
        itemCount: roles.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (_, i) {
          final r = roles[i];
          final count = _roleSummary[r] ?? 0;
          final color = _roleColor(r);
          final selected = _filterRole == r;
          return GestureDetector(
            onTap: () {
              setState(() => _filterRole = selected ? 'all' : r);
              _applyFilter();
            },
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
              decoration: BoxDecoration(
                color: selected ? color.withOpacity(0.22) : Colors.white.withOpacity(0.06),
                borderRadius: BorderRadius.circular(50),
                border: Border.all(
                    color: selected ? color : Colors.white.withOpacity(0.14),
                    width: selected ? 1.5 : 1),
                boxShadow: selected
                    ? [BoxShadow(color: color.withOpacity(0.35), blurRadius: 14)]
                    : [],
              ),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                Icon(_roleIcon(r), color: color, size: 14),
                const SizedBox(width: 6),
                Text(r.toUpperCase(),
                    style: TextStyle(
                        color: selected ? color : AppColors.textSub,
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1)),
                const SizedBox(width: 6),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                  decoration: BoxDecoration(
                    color: color.withOpacity(0.25),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text('$count',
                      style: TextStyle(color: color, fontSize: 10, fontWeight: FontWeight.bold)),
                ),
              ]),
            ),
          );
        },
      ),
    );
  }

  // ── Search + Filter ─────────────────────────────────────────────────
  Widget _buildSearchAndFilter() {
    final isDev = widget.currentRole.toLowerCase() == 'developer';
    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 4, 14, 10),
      child: Row(children: [
        Expanded(
          child: Container(
            height: 46,
            decoration: _glassBox(radius: 14),
            child: Row(children: [
              const SizedBox(width: 12),
              Icon(Icons.search_rounded, color: AppColors.textHint, size: 18),
              const SizedBox(width: 8),
              Expanded(
                child: TextField(
                  controller: _searchCtrl,
                  style: TextStyle(color: AppColors.text, fontSize: 13),
                  decoration: InputDecoration(
                    hintText: 'Cari username / telegram / creator...',
                    hintStyle: TextStyle(color: AppColors.textHint, fontSize: 12),
                    border: InputBorder.none, isDense: true,
                  ),
                  onChanged: (v) { _searchQuery = v; _applyFilter(); },
                ),
              ),
              if (_searchQuery.isNotEmpty)
                GestureDetector(
                  onTap: () { _searchCtrl.clear(); _searchQuery = ''; _applyFilter(); },
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 10),
                    child: Icon(Icons.close_rounded, color: AppColors.textHint, size: 16),
                  ),
                ),
            ]),
          ),
        ),
        if (isDev) ...[
          const SizedBox(width: 8),
          _GlassIconButton(
            icon: _selectMode
                ? Icons.check_box_rounded
                : Icons.check_box_outline_blank_rounded,
            color: _selectMode ? AppColors.red : AppColors.textSub,
            size: 46,
            active: _selectMode,
            onTap: () => setState(() {
              _selectMode = !_selectMode;
              if (!_selectMode) _selectedUsernames.clear();
            }),
          ),
          const SizedBox(width: 6),
          _GlassIconButton(
            icon: Icons.delete_sweep_rounded,
            color: AppColors.red,
            size: 46,
            onTap: () => _showBulkDeleteDialog(),
          ),
        ],
      ]),
    );
  }

  // ── Bulk Delete ─────────────────────────────────────────────────────
  Future<void> _showBulkDeleteDialog() async {
    if (widget.currentRole.toLowerCase() != 'developer') return;
    String selectedRole = 'all';
    final TextEditingController countCtrl = TextEditingController();
    const roleOptions = ['all', 'member', 'fullup', 'reseller', 'owner'];

    await showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.6),
      builder: (_) => _glassDialog(
        StatefulBuilder(
          builder: (ctx, setS) => Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(children: [
                Icon(Icons.delete_sweep_rounded, color: AppColors.red, size: 22),
                const SizedBox(width: 10),
                Text('Hapus Massal',
                    style: TextStyle(color: AppColors.text, fontSize: 16, fontWeight: FontWeight.bold)),
              ]),
              const SizedBox(height: 12),
              Text('Pilih kategori yang akan dihapus:',
                  style: TextStyle(color: AppColors.textSub, fontSize: 13)),
              const SizedBox(height: 12),
              Wrap(spacing: 8, runSpacing: 8, children: roleOptions.map((opt) {
                final c = opt == 'all' ? AppColors.red : _roleColor(opt);
                final sel = selectedRole == opt;
                return GestureDetector(
                  onTap: () => setS(() => selectedRole = opt),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                    decoration: BoxDecoration(
                      color: sel ? c.withOpacity(0.25) : Colors.white.withOpacity(0.05),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                          color: sel ? c : Colors.white.withOpacity(0.15),
                          width: sel ? 1.5 : 1),
                    ),
                    child: Text(opt.toUpperCase(),
                        style: TextStyle(
                            color: sel ? c : AppColors.textSub,
                            fontSize: 11, fontWeight: FontWeight.bold)),
                  ),
                );
              }).toList()),
              const SizedBox(height: 16),
              Divider(color: Colors.white.withOpacity(0.1)),
              const SizedBox(height: 8),
              Text('Atau masukkan jumlah (kosongkan = semua):',
                  style: TextStyle(color: AppColors.textSub, fontSize: 12)),
              const SizedBox(height: 8),
              TextField(
                controller: countCtrl,
                keyboardType: TextInputType.number,
                style: TextStyle(color: AppColors.text, fontSize: 14),
                decoration: InputDecoration(
                  hintText: 'contoh: 5',
                  hintStyle: TextStyle(color: AppColors.textHint, fontSize: 12),
                  filled: true,
                  fillColor: Colors.white.withOpacity(0.05),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide.none),
                ),
              ),
              const SizedBox(height: 18),
              Row(mainAxisAlignment: MainAxisAlignment.end, children: [
                TextButton(
                  onPressed: () => Navigator.pop(ctx),
                  child: Text('Batal', style: TextStyle(color: AppColors.textHint))),
                const SizedBox(width: 8),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.red,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
                  onPressed: () async {
                    Navigator.pop(ctx);
                    await _bulkDelete(
                        role: selectedRole,
                        maxCount: int.tryParse(countCtrl.text.trim()));
                  },
                  child: const Text('Hapus',
                      style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold))),
              ]),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _bulkDelete({required String role, int? maxCount}) async {
    final toDelete = _allUsers.where((u) {
      final r = (u['role'] ?? '').toString().toLowerCase();
      if (r == 'developer') return false;
      if (role == 'all') return true;
      return r == role;
    }).toList();

    final targets = maxCount != null ? toDelete.take(maxCount).toList() : toDelete;
    if (targets.isEmpty) {
      _showSnack('Tidak ada user yang bisa dihapus', AppColors.amber);
      return;
    }

    int deleted = 0;
    for (final u in targets) {
      final username = u['username']?.toString() ?? '';
      if (username.isEmpty) continue;
      try {
        final res = await http.get(Uri.parse(
            '$baseUrl/deleteUser?key=${Uri.encodeComponent(widget.sessionKey)}'
            '&username=${Uri.encodeComponent(username)}'))
            .timeout(const Duration(seconds: 8));
        final data = jsonDecode(res.body);
        if (data['deleted'] == true) deleted++;
      } catch (_) {}
    }
    _showSnack('✅ $deleted akun berhasil dihapus', AppColors.green);
    _fetchUsers(silent: true);
  }

  // ── Body ────────────────────────────────────────────────────────────
  Widget _buildBody() {
    if (_loading) {
      return Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
        CircularProgressIndicator(color: AppColors.accent, strokeWidth: 2),
        const SizedBox(height: 16),
        Text('Memuat data user...', style: TextStyle(color: AppColors.textSub, fontSize: 13)),
      ]));
    }
    if (_error != null) {
      return Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
        Icon(Icons.error_outline_rounded, color: AppColors.red, size: 48),
        const SizedBox(height: 12),
        Text(_error!, style: TextStyle(color: AppColors.textSub, fontSize: 13)),
        const SizedBox(height: 16),
        ElevatedButton.icon(
          onPressed: _fetchUsers,
          icon: const Icon(Icons.refresh_rounded, size: 16),
          label: const Text('Coba Lagi'),
          style: ElevatedButton.styleFrom(
            backgroundColor: AppColors.accent,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
        ),
      ]));
    }
    if (_filtered.isEmpty) {
      return Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
        Icon(Icons.person_search_rounded, color: AppColors.textHint, size: 48),
        const SizedBox(height: 12),
        Text(
          _searchQuery.isNotEmpty ? 'User tidak ditemukan' : 'Tidak ada user',
          style: TextStyle(color: AppColors.textHint, fontSize: 13),
        ),
      ]));
    }

    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(14, 4, 14, 20),
      physics: const BouncingScrollPhysics(),
      itemCount: _filtered.length,
      itemBuilder: (_, i) => _buildUserCard(_filtered[i]),
    );
  }

  // ── User Card ───────────────────────────────────────────────────────
  Widget _buildUserCard(Map<String, dynamic> user) {
    final username = user['username']?.toString() ?? '—';
    final role = (user['role'] ?? 'member').toString().toLowerCase();
    final expDate = user['expiredDate']?.toString() ?? '';
    final color = _roleColor(role);

    String expDisplay;
    Color expColor;
    try {
      final exp = DateTime.tryParse(expDate);
      if (exp == null) {
        expDisplay = expDate.isEmpty ? 'Tidak diketahui' : expDate;
        expColor = AppColors.textHint;
      } else {
        final diff = exp.difference(DateTime.now()).inDays;
        if (diff > 9999) {
          expDisplay = 'PERMANENT';
          expColor = AppColors.green;
        } else if (diff < 0) {
          expDisplay = 'EXPIRED';
          expColor = AppColors.red;
        } else {
          expDisplay = '$diff Hari';
          expColor = diff < 7 ? AppColors.amber : AppColors.textSub;
        }
      }
    } catch (_) {
      expDisplay = expDate;
      expColor = AppColors.textHint;
    }

    final isDev = widget.currentRole.toLowerCase() == 'developer';
    final canManage = _canManageRoles(widget.currentRole);
    final canUpgrade = canManage && _isUpgradeable(role);
    final isSelected = _selectedUsernames.contains(username);
    final createdBy = user['createdBy']?.toString() ?? '';
    final telegramUser = user['telegram']?.toString() ?? '';

    return _GlassCard(
      margin: const EdgeInsets.only(bottom: 10),
      accent: color,
      selected: isSelected,
      onTap: _selectMode && isDev
          ? () => setState(() {
                if (isSelected) _selectedUsernames.remove(username);
                else _selectedUsernames.add(username);
              })
          : null,
      onLongPress: isDev
          ? () => setState(() {
                _selectMode = true;
                if (isSelected) _selectedUsernames.remove(username);
                else _selectedUsernames.add(username);
              })
          : null,
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          if (_selectMode && isDev) ...[
            Icon(
              isSelected ? Icons.check_circle_rounded : Icons.radio_button_unchecked_rounded,
              color: isSelected ? AppColors.red : AppColors.textHint,
              size: 20),
            const SizedBox(width: 10),
          ],
          Container(
            width: 44, height: 44,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: color.withOpacity(0.15),
              border: Border.all(color: color.withOpacity(0.55), width: 1.5),
              boxShadow: [BoxShadow(color: color.withOpacity(0.25), blurRadius: 12)],
            ),
            child: Center(child: Icon(_roleIcon(role), color: color, size: 20)),
          ),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Wrap(spacing: 6, runSpacing: 4, crossAxisAlignment: WrapCrossAlignment.center, children: [
              Text('@$username',
                  style: TextStyle(color: AppColors.text, fontWeight: FontWeight.bold, fontSize: 13)),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                decoration: BoxDecoration(
                  color: color.withOpacity(0.18),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: color.withOpacity(0.45)),
                ),
                child: Text(role.toUpperCase(),
                    style: TextStyle(
                        color: color, fontSize: 9, fontWeight: FontWeight.bold, letterSpacing: 1)),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                decoration: BoxDecoration(
                  color: expColor.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(expDisplay,
                    style: TextStyle(color: expColor, fontSize: 9, fontWeight: FontWeight.bold)),
              ),
            ]),
            const SizedBox(height: 4),
            Wrap(spacing: 8, runSpacing: 2, crossAxisAlignment: WrapCrossAlignment.center, children: [
              if (telegramUser.isNotEmpty)
                Row(mainAxisSize: MainAxisSize.min, children: [
                  const Icon(Icons.telegram_rounded, color: Color(0xFF29B6F6), size: 11),
                  const SizedBox(width: 3),
                  Text('@$telegramUser',
                      style: const TextStyle(color: Color(0xFF29B6F6), fontSize: 10)),
                ]),
              if (createdBy.isNotEmpty)
                Row(mainAxisSize: MainAxisSize.min, children: [
                  Icon(Icons.person_outline_rounded, color: AppColors.textHint, size: 11),
                  const SizedBox(width: 3),
                  Text('by @$createdBy',
                      style: TextStyle(color: AppColors.textHint, fontSize: 10)),
                ]),
            ]),
          ])),
          const SizedBox(width: 6),
          if (canManage) Row(mainAxisSize: MainAxisSize.min, children: [
            if (canUpgrade) ...[
              _GlassIconButton(
                icon: Icons.upgrade_rounded,
                color: AppColors.amber,
                size: 34,
                onTap: () => _showUpgradeDialog(username, role),
              ),
              const SizedBox(width: 6),
            ],
            _GlassIconButton(
              icon: Icons.add_alarm_rounded,
              color: AppColors.green,
              size: 34,
              onTap: () => _showAddDaysDialog(username, expDate),
            ),
            const SizedBox(width: 6),
            _GlassIconButton(
              icon: Icons.delete_outline_rounded,
              color: AppColors.red,
              size: 34,
              onTap: () => _deleteUser(username),
            ),
          ]),
        ]),
        Padding(
          padding: const EdgeInsets.only(top: 8, left: 56),
          child: Row(children: [
            Icon(Icons.calendar_today_rounded, color: AppColors.textHint, size: 10),
            const SizedBox(width: 4),
            Text('EXP $expDate',
                style: TextStyle(color: AppColors.textHint, fontSize: 10)),
          ]),
        ),
      ]),
    );
  }
}

// ═════════════════════════════════════════════════════════════════════
//  LIQUID GLASS — HELPERS & WIDGETS
// ═════════════════════════════════════════════════════════════════════

/// Kotak glass reusable (fill + border + sheen + shadow).
BoxDecoration _glassBox({
  double radius = 16,
  Color? accent,
  bool elevated = false,
}) {
  final acc = accent ?? AppColors.accent;
  return BoxDecoration(
    color: AppColors.card.withOpacity(elevated ? 0.7 : 0.55),
    borderRadius: BorderRadius.circular(radius),
    border: Border.all(
      color: Colors.white.withOpacity(elevated ? 0.18 : 0.12),
      width: 1,
    ),
    boxShadow: [
      BoxShadow(
        color: Colors.black.withOpacity(0.28),
        blurRadius: 24,
        offset: const Offset(0, 8),
      ),
      BoxShadow(
        color: acc.withOpacity(elevated ? 0.10 : 0.05),
        blurRadius: 30,
        offset: Offset.zero,
      ),
    ],
  );
}

/// Card glass dengan ink ripple + sheen di tepi atas.
class _GlassCard extends StatelessWidget {
  final Widget child;
  final EdgeInsets? padding;
  final EdgeInsets? margin;
  final double radius;
  final Color? accent;
  final VoidCallback? onTap;
  final VoidCallback? onLongPress;
  final bool selected;

  const _GlassCard({
    required this.child,
    this.padding,
    this.margin,
    this.radius = 18,
    this.accent,
    this.onTap,
    this.onLongPress,
    this.selected = false,
  });

  @override
  Widget build(BuildContext context) {
    final acc = accent ?? AppColors.accent;
    return Container(
      margin: margin,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.3),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(radius),
        child: Material(
          color: AppColors.card.withOpacity(0.6),
          child: InkWell(
            onTap: onTap,
            onLongPress: onLongPress,
            splashColor: acc.withOpacity(0.15),
            highlightColor: acc.withOpacity(0.08),
            child: Stack(children: [
              Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(radius),
                  border: Border.all(
                    color: selected
                        ? acc.withOpacity(0.75)
                        : Colors.white.withOpacity(0.12),
                    width: selected ? 1.6 : 1,
                  ),
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      Colors.white.withOpacity(0.06),
                      Colors.transparent,
                    ],
                  ),
                ),
                child: Padding(
                  padding: padding ?? const EdgeInsets.all(14),
                  child: child,
                ),
              ),
              // Specular sheen (liquid glass highlight)
              Positioned(
                top: 0, left: 24, right: 24,
                child: Container(
                  height: 1,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        Colors.white.withOpacity(0),
                        Colors.white.withOpacity(0.35),
                        Colors.white.withOpacity(0),
                      ],
                    ),
                  ),
                ),
              ),
            ]),
          ),
        ),
      ),
    );
  }
}

/// Icon button bulat semi-transparan (glass style).
class _GlassIconButton extends StatelessWidget {
  final IconData icon;
  final Color color;
  final VoidCallback? onTap;
  final double size;
  final bool active;

  const _GlassIconButton({
    required this.icon,
    required this.color,
    this.onTap,
    this.size = 40,
    this.active = false,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: size, height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: active ? color.withOpacity(0.22) : Colors.white.withOpacity(0.07),
          border: Border.all(
            color: active ? color.withOpacity(0.65) : Colors.white.withOpacity(0.15),
            width: active ? 1.5 : 1,
          ),
          boxShadow: [
            BoxShadow(
              color: (active ? color : Colors.black).withOpacity(active ? 0.35 : 0.2),
              blurRadius: 12,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        child: Icon(icon, color: color, size: size * 0.45),
      ),
    );
  }
}

/// Dialog glass dengan BackdropFilter blur.
Widget _glassDialog(Widget content) {
  return Dialog(
    backgroundColor: Colors.transparent,
    elevation: 0,
    insetPadding: const EdgeInsets.symmetric(horizontal: 20),
    child: ClipRRect(
      borderRadius: BorderRadius.circular(22),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 30, sigmaY: 30),
        child: Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: AppColors.card.withOpacity(0.85),
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: Colors.white.withOpacity(0.15)),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.4),
                blurRadius: 30,
                offset: const Offset(0, 12),
              ),
            ],
          ),
          child: content,
        ),
      ),
    ),
  );
}

// ═════════════════════════════════════════════════════════════════════
//  LIQUID BACKGROUND
// ═════════════════════════════════════════════════════════════════════
class _LiquidBg extends StatefulWidget {
  final Widget child;
  const _LiquidBg({required this.child});
  @override
  State<_LiquidBg> createState() => _LiquidBgState();
}

class _LiquidBgState extends State<_LiquidBg> with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 22),
    )..repeat();
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(children: [
      Positioned.fill(
        child: AnimatedBuilder(
          animation: _ctrl,
          builder: (_, __) => CustomPaint(
            painter: _LiquidBlobPainter(_ctrl.value),
          ),
        ),
      ),
      Positioned.fill(child: widget.child),
    ]);
  }
}

class _LiquidBlobPainter extends CustomPainter {
  final double t;
  _LiquidBlobPainter(this.t);

  Offset _align(Alignment a, Size s) =>
      Offset((a.x + 1) / 2 * s.width, (a.y + 1) / 2 * s.height);

  @override
  void paint(Canvas canvas, Size size) {
    // Base color
    canvas.drawRect(Offset.zero & size, Paint()..color = AppColors.bg);

    final blob = Paint()
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 70);

    final a1 = Alignment(
      -0.8 + 0.5 * _sin(t * 2),
      -0.7 + 0.4 * _cos(t * 2),
    );
    blob.color = AppColors.accent.withOpacity(0.35);
    canvas.drawCircle(_align(a1, size), size.width * 0.42, blob);

    final a2 = Alignment(
      0.7 + 0.4 * _cos(t * 2 + 1.3),
      0.6 + 0.3 * _sin(t * 2 + 2.1),
    );
    blob.color = AppColors.accentMid.withOpacity(0.28);
    canvas.drawCircle(_align(a2, size), size.width * 0.48, blob);

    final a3 = Alignment(
      0.3 * _sin(t * 4 + 1.5),
      -0.4 + 0.4 * _cos(t * 4),
    );
    blob.color = AppColors.accentLight.withOpacity(0.20);
    canvas.drawCircle(_align(a3, size), size.width * 0.36, blob);
  }

  static double _sin(double x) => _taylorSin(x);
  static double _cos(double x) => _taylorSin(x + 1.5707963267948966);
  static double _taylorSin(double x) {
    // Normalize to [-π, π]
    const twoPi = 6.283185307179586;
    x = x % twoPi;
    if (x > 3.141592653589793) x -= twoPi;
    if (x < -3.141592653589793) x += twoPi;
    // Taylor: x - x^3/6 + x^5/120 - x^7/5040
    final x2 = x * x;
    final x3 = x2 * x;
    final x5 = x3 * x2;
    final x7 = x5 * x2;
    return x - x3 / 6 + x5 / 120 - x7 / 5040;
  }

  @override
  bool shouldRepaint(covariant _LiquidBlobPainter old) => old.t != t;
}