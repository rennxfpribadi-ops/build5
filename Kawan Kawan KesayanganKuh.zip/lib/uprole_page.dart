// uprole_page.dart
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_gallery_saver_plus/image_gallery_saver_plus.dart';
import 'package:permission_handler/permission_handler.dart';

import 'theme.dart';

// ═══════════════════════════════════════════════════════════════════════
//  KONFIGURASI
// ═══════════════════════════════════════════════════════════════════════
const String kFont = 'Pek';
const String baseUrl = 'http://cp.zyrostore.id:3448';

const List<String> kRoleOrder = [
  'member', 'fullup', 'reseller', 'owner',
];

const Map<String, int> kRolePrice = {
  'member': 25000,
  'fullup': 35000,
  'reseller': 70000,
  'owner': 120000,
};

const int kMinUpgradeFee = 15000;

int calculateUpgradePrice(String from, String to) {
  final fromP = kRolePrice[from.toLowerCase()] ?? 0;
  final toP = kRolePrice[to.toLowerCase()] ?? 0;
  final diff = toP - fromP;
  if (diff <= 0) return 0;
  return diff < kMinUpgradeFee ? kMinUpgradeFee : diff;
}

Color roleColorOf(String role) {
  switch (role.toLowerCase()) {
    case 'owner':    return ThemeModeManager.isMonochrome
        ? const Color(0xFF7C3AED)
        : const Color(0xFF7C3AED);
    case 'reseller': return const Color(0xFFEC4899);
    case 'fullup':   return const Color(0xFF06B6D4);
    case 'member':
    default:         return AppColors.accent;
  }
}

IconData roleIconOf(String role) {
  switch (role.toLowerCase()) {
    case 'owner':    return Icons.workspace_premium_rounded;
    case 'reseller': return Icons.storefront_rounded;
    case 'fullup':   return Icons.stars_rounded;
    case 'member':
    default:         return Icons.person_rounded;
  }
}

String _formatHarga(int harga) {
  if (harga >= 1000) {
    final k = harga / 1000;
    return k == k.toInt() ? '${k.toInt()}k' : '${k.toStringAsFixed(1)}k';
  }
  return '$harga';
}

String _formatRupiah(int harga) {
  final str = harga.toString();
  final buffer = StringBuffer();
  int count = 0;
  for (int i = str.length - 1; i >= 0; i--) {
    buffer.write(str[i]);
    count++;
    if (count == 3 && i != 0) {
      buffer.write('.');
      count = 0;
    }
  }
  return 'Rp ${buffer.toString().split('').reversed.join()}';
}

// ═══════════════════════════════════════════════════════════════════════
class UpRolePage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String currentRole;
  final ValueChanged<String>? onRoleUpdated;

  const UpRolePage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.currentRole,
    this.onRoleUpdated,
  });

  @override
  State<UpRolePage> createState() => _UpRolePageState();
}

class _UpRolePageState extends State<UpRolePage> {
  late String _currentRole;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _currentRole = widget.currentRole.toLowerCase();
    _fetchRole();
  }

  Future<void> _fetchRole() async {
    try {
      final res = await http
          .get(Uri.parse('$baseUrl/myRole?key=${widget.sessionKey}'))
          .timeout(const Duration(seconds: 10));

      final data = jsonDecode(res.body);

      if (data['success'] == true && mounted) {
        setState(() {
          _currentRole = (data['role'] ?? 'member').toLowerCase();
          _loading = false;
        });
      } else if (mounted) {
        setState(() => _loading = false);
      }
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  List<String> get _targets {
    final idx = kRoleOrder.indexOf(_currentRole);
    if (idx < 0) return [];
    return kRoleOrder.sublist(idx + 1);
  }

  bool _isPermanentUpgrade(String targetRole) {
    return _currentRole.toLowerCase() == 'member' &&
        (targetRole.toLowerCase() == 'fullup' ||
            targetRole.toLowerCase() == 'reseller' ||
            targetRole.toLowerCase() == 'owner');
  }

  bool _isCurrentRolePermanent() {
    return _currentRole.toLowerCase() == 'fullup' ||
        _currentRole.toLowerCase() == 'reseller' ||
        _currentRole.toLowerCase() == 'owner';
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppThemeMode>(
      valueListenable: ThemeModeManager.current,
      builder: (context, _, __) {
        return Scaffold(
          backgroundColor: AppColors.bg,
          body: SafeArea(
            top: true,
            bottom: true,
            left: true,
            right: true,
            child: Column(
              children: [
                _buildTopBar(),
                Expanded(
                  child: _loading
                      ? Center(
                          child: CircularProgressIndicator(
                            color: AppColors.accent,
                          ),
                        )
                      : _targets.isEmpty
                          ? _buildTopRoleEmpty()
                          : SingleChildScrollView(
                              physics: const BouncingScrollPhysics(),
                              padding: const EdgeInsets.fromLTRB(16, 10, 16, 24),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  _buildHeaderCard(),
                                  const SizedBox(height: 16),
                                  _buildAccountSection(),
                                  const SizedBox(height: 16),
                                  _buildMainPricingSection(),
                                  const SizedBox(height: 16),
                                  _buildCurrentRoleSection(),
                                  const SizedBox(height: 16),
                                  _buildTargetList(),
                                ],
                              ),
                            ),
                ),
                if (!_loading && _targets.isNotEmpty) _buildBottomBar(),
              ],
            ),
          ),
        );
      },
    );
  }

  // ═════════════════════════════════════════════════════════════════════
  //  TOP BAR
  // ═════════════════════════════════════════════════════════════════════
  Widget _buildTopBar() {
    final isComic = ThemeModeManager.isComic3d;
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 12),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.maybePop(context),
            child: Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                color: AppColors.card,
                shape: BoxShape.circle,
                border: Border.all(
                  color: AppColors.border,
                  width: isComic ? 3 : 1,
                ),
                boxShadow: AppColors.softShadow,
              ),
              child: Icon(
                Icons.arrow_back_ios_new_rounded,
                color: AppColors.accent,
                size: 18,
              ),
            ),
          ),
          Expanded(
            child: Text(
              'Upgrade Akun',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: AppColors.accent,
                fontSize: 18,
                fontWeight: FontWeight.w800,
                fontFamily: kFont,
              ),
            ),
          ),
          const SizedBox(width: 44),
        ],
      ),
    );
  }

  // ═════════════════════════════════════════════════════════════════════
  //  TOP ROLE EMPTY STATE (teks tengah, tanpa box)
  // ═════════════════════════════════════════════════════════════════════
  Widget _buildTopRoleEmpty() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Icon(
              Icons.emoji_events_rounded,
              color: AppColors.gold,
              size: 72,
            ),
            const SizedBox(height: 20),
            Text(
              'Role Anda sudah paling tinggi',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: AppColors.text,
                fontSize: 18,
                fontWeight: FontWeight.w800,
                fontFamily: kFont,
                letterSpacing: 0.5,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Tidak ada role lagi yang bisa di-upgrade.',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: AppColors.textSub,
                fontSize: 12,
                fontFamily: kFont,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═════════════════════════════════════════════════════════════════════
  //  HEADER CARD
  // ═════════════════════════════════════════════════════════════════════
  Widget _buildHeaderCard() {
    final isComic = ThemeModeManager.isComic3d;
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: AppColors.btnGrad,
        borderRadius: BorderRadius.circular(AppColors.cardRadius),
        border: Border.all(
          color: isComic ? Colors.black : Colors.transparent,
          width: isComic ? 3 : 0,
        ),
        boxShadow: [
          BoxShadow(
            color: AppColors.accent.withOpacity(0.3),
            blurRadius: 15,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 60,
            height: 60,
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.2),
              shape: BoxShape.circle,
              border: Border.all(
                color: Colors.white.withOpacity(0.4),
                width: 1.5,
              ),
            ),
            child: const Icon(
              Icons.arrow_upward_rounded,
              color: Colors.white,
              size: 30,
            ),
          ),
          const SizedBox(width: 16),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Upgrade Akun',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    fontFamily: kFont,
                  ),
                ),
                SizedBox(height: 6),
                Text(
                  'Pilih target role, selesaikan pembayaran - akun langsung diperbarui otomatis.',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 12,
                    height: 1.4,
                    fontFamily: kFont,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ═════════════════════════════════════════════════════════════════════
  //  ACCOUNT SECTION
  // ═════════════════════════════════════════════════════════════════════
  Widget _buildAccountSection() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(AppColors.cardRadius),
        border: Border.all(
          color: AppColors.border,
          width: ThemeModeManager.isComic3d ? 3 : 1.5,
        ),
        boxShadow: AppColors.softShadow,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                Icons.person_outline_rounded,
                color: AppColors.accent,
                size: 18,
              ),
              const SizedBox(width: 8),
              Text(
                'AKUN AKTIF',
                style: TextStyle(
                  color: AppColors.accent,
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                  fontFamily: kFont,
                  letterSpacing: 0.5,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: AppColors.card2,
              borderRadius: BorderRadius.circular(14),
            ),
            child: Row(
              children: [
                Container(
                  width: 44,
                  height: 44,
                  decoration: BoxDecoration(
                    color: AppColors.accent,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Icon(
                    Icons.person_rounded,
                    color: Colors.white,
                    size: 24,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        widget.username,
                        style: TextStyle(
                          color: AppColors.text,
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          fontFamily: kFont,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        'Pilih target role untuk melanjutkan',
                        style: TextStyle(
                          color: AppColors.textSub,
                          fontSize: 11,
                          fontFamily: kFont,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ═════════════════════════════════════════════════════════════════════
  //  MAIN PRICING
  // ═════════════════════════════════════════════════════════════════════
  Widget _buildMainPricingSection() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(AppColors.cardRadius),
        border: Border.all(
          color: AppColors.border,
          width: ThemeModeManager.isComic3d ? 3 : 1.5,
        ),
        boxShadow: AppColors.softShadow,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                Icons.auto_awesome_rounded,
                color: AppColors.gold,
                size: 18,
              ),
              const SizedBox(width: 8),
              Text(
                'HARGA UTAMA',
                style: TextStyle(
                  color: AppColors.gold,
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                  fontFamily: kFont,
                  letterSpacing: 0.5,
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Row(
            children: ['fullup', 'reseller', 'owner'].map((role) {
              final price = kRolePrice[role] ?? 0;
              return Expanded(
                child: Container(
                  margin: const EdgeInsets.symmetric(horizontal: 4),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  decoration: BoxDecoration(
                    color: AppColors.card2,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: AppColors.border,
                      width: 1.2,
                    ),
                  ),
                  child: Column(
                    children: [
                      Text(
                        role[0].toUpperCase() + role.substring(1),
                        style: TextStyle(
                          color: AppColors.textSub,
                          fontSize: 12,
                          fontFamily: kFont,
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        _formatRupiah(price),
                        style: TextStyle(
                          color: AppColors.accent,
                          fontSize: 14,
                          fontWeight: FontWeight.w800,
                          fontFamily: kFont,
                        ),
                      ),
                    ],
                  ),
                ),
              );
            }).toList(),
          ),
          const SizedBox(height: 12),
          Text(
            'Sisa hari aktif member dihitung sebagai potongan biaya.',
            style: TextStyle(
              color: AppColors.textSub,
              fontSize: 11,
              fontFamily: kFont,
            ),
          ),
        ],
      ),
    );
  }

  // ═════════════════════════════════════════════════════════════════════
  //  CURRENT ROLE
  // ═════════════════════════════════════════════════════════════════════
  Widget _buildCurrentRoleSection() {
    final isPermanent = _isCurrentRolePermanent();
    final masaBerlaku = isPermanent
        ? 'Berlaku PERMANEN (tanpa batas waktu)'
        : 'Berlaku hingga 31/12/2099, 23:59:59';

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.accent.withOpacity(0.08),
        borderRadius: BorderRadius.circular(AppColors.cardRadius),
        border: Border.all(
          color: AppColors.accent.withOpacity(0.35),
          width: ThemeModeManager.isComic3d ? 3 : 1.5,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: AppColors.accent,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  _currentRole.toUpperCase(),
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 12,
                    fontWeight: FontWeight.w800,
                    fontFamily: kFont,
                    letterSpacing: 0.5,
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Text(
                'Role saat ini',
                style: TextStyle(
                  color: AppColors.text,
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  fontFamily: kFont,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            masaBerlaku,
            style: TextStyle(
              color: isPermanent ? AppColors.green : AppColors.textSub,
              fontSize: 12,
              fontWeight: isPermanent ? FontWeight.w700 : FontWeight.normal,
              fontFamily: kFont,
            ),
          ),
        ],
      ),
    );
  }

  // ═════════════════════════════════════════════════════════════════════
  //  TARGET LIST
  // ═════════════════════════════════════════════════════════════════════
  Widget _buildTargetList() {
    return Column(
      children: _targets.map((t) {
        final price = calculateUpgradePrice(_currentRole, t);
        final isSelected = t == _targets.first;
        return Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: _buildTargetCard(t, price, isSelected),
        );
      }).toList(),
    );
  }

  Widget _buildTargetCard(String target, int price, bool isSelected) {
    final isPermanent = _isPermanentUpgrade(target);
    final isComic = ThemeModeManager.isComic3d;

    return GestureDetector(
      onTap: () => _onTargetTap(target, price),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: AppColors.card,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isSelected ? AppColors.accent : AppColors.border,
            width: isSelected ? 2 : (isComic ? 3 : 1.5),
          ),
          boxShadow: AppColors.softShadow,
        ),
        child: Row(
          children: [
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                color: isSelected ? AppColors.accent : AppColors.card2,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(
                Icons.arrow_upward_rounded,
                color: isSelected ? Colors.white : AppColors.accent,
                size: 24,
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    '${_currentRole[0].toUpperCase() + _currentRole.substring(1)} → ${target[0].toUpperCase() + target.substring(1)}',
                    style: TextStyle(
                      color: AppColors.text,
                      fontSize: 14,
                      fontWeight: FontWeight.w800,
                      fontFamily: kFont,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    'Selisih harga asli (${_formatRupiah(kRolePrice[target] ?? 0)} - ${_formatRupiah(kRolePrice[_currentRole] ?? 0)})',
                    style: TextStyle(
                      color: AppColors.textSub,
                      fontSize: 11,
                      fontFamily: kFont,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    isPermanent
                        ? '⏳ Masa berlaku: PERMANEN'
                        : '⏳ Masa berlaku: standar',
                    style: TextStyle(
                      color: isPermanent ? AppColors.green : AppColors.textSub,
                      fontSize: 10.5,
                      fontWeight:
                          isPermanent ? FontWeight.w700 : FontWeight.normal,
                      fontFamily: kFont,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 8),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  _formatRupiah(price),
                  style: TextStyle(
                    color: AppColors.accent,
                    fontSize: 14,
                    fontWeight: FontWeight.w800,
                    fontFamily: kFont,
                  ),
                ),
                const SizedBox(height: 6),
                if (isSelected)
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 4,
                    ),
                    decoration: BoxDecoration(
                      color: AppColors.accent,
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: const Text(
                      'Dipilih',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 10,
                        fontWeight: FontWeight.w700,
                        fontFamily: kFont,
                      ),
                    ),
                  )
                else
                  const SizedBox(height: 20),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // ═════════════════════════════════════════════════════════════════════
  //  BOTTOM BAR
  // ═════════════════════════════════════════════════════════════════════
  Widget _buildBottomBar() {
    final isComic = ThemeModeManager.isComic3d;
    int selectedPrice = 0;
    if (_targets.isNotEmpty) {
      selectedPrice = calculateUpgradePrice(_currentRole, _targets.first);
    }

    return Container(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 16),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
        border: Border(
          top: BorderSide(
            color: AppColors.border,
            width: isComic ? 3 : 1,
          ),
        ),
        boxShadow: AppColors.softShadow,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Total pembayaran',
                style: TextStyle(
                  color: AppColors.textSub,
                  fontSize: 13,
                  fontFamily: kFont,
                ),
              ),
              Text(
                _formatRupiah(selectedPrice),
                style: TextStyle(
                  color: AppColors.accent,
                  fontSize: 18,
                  fontWeight: FontWeight.w900,
                  fontFamily: kFont,
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          SizedBox(
            width: double.infinity,
            height: 54,
            child: ElevatedButton(
              onPressed: () {
                if (_targets.isNotEmpty) {
                  _onTargetTap(_targets.first, selectedPrice);
                }
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.accent,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                  side: isComic
                      ? const BorderSide(color: Colors.black, width: 3)
                      : BorderSide.none,
                ),
                elevation: 0,
              ),
              child: Text(
                'BAYAR ${_formatRupiah(selectedPrice)}',
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 15,
                  fontWeight: FontWeight.w800,
                  fontFamily: kFont,
                  letterSpacing: 0.5,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _onTargetTap(String target, int price) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => _UpgradeFlowSheet(
        sessionKey: widget.sessionKey,
        fromRole: _currentRole,
        toRole: target,
        price: price,
        onSuccess: () {
          widget.onRoleUpdated?.call(target);
          _fetchRole();
        },
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════
//  FLOW PEMBAYARAN
// ═══════════════════════════════════════════════════════════════════════
class _UpgradeFlowSheet extends StatefulWidget {
  final String sessionKey;
  final String fromRole;
  final String toRole;
  final int price;
  final VoidCallback? onSuccess;

  const _UpgradeFlowSheet({
    required this.sessionKey,
    required this.fromRole,
    required this.toRole,
    required this.price,
    this.onSuccess,
  });

  @override
  State<_UpgradeFlowSheet> createState() => _UpgradeFlowSheetState();
}

class _UpgradeFlowSheetState extends State<_UpgradeFlowSheet> {
  int _step = 0;
  String? _depositId;
  String? _qrUrl;
  int _totalPayment = 0;
  int _expiredAt = 0;
  bool _loading = false;
  bool _savingQr = false;
  Timer? _pollTimer;

  bool get _isPermanent =>
      widget.fromRole.toLowerCase() == 'member' &&
      (widget.toRole.toLowerCase() == 'fullup' ||
          widget.toRole.toLowerCase() == 'reseller' ||
          widget.toRole.toLowerCase() == 'owner');

  @override
  void dispose() {
    _pollTimer?.cancel();
    super.dispose();
  }

  Future<void> _createInvoice() async {
    setState(() => _loading = true);

    try {
      final res = await http
          .post(
            Uri.parse('$baseUrl/buy/upgrade'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'sessionKey': widget.sessionKey,
              'targetRole': widget.toRole,
            }),
          )
          .timeout(const Duration(seconds: 30));

      final data = jsonDecode(res.body);

      if (data['success'] != true) {
        _toast(data['message'] ?? 'Gagal buat invoice', AppColors.red);
        setState(() => _loading = false);
        return;
      }

      setState(() {
        _depositId = data['depositId'];
        _qrUrl = data['qrUrl'];
        _totalPayment = data['totalPayment'] ?? widget.price;
        _expiredAt = data['expiredAt'] ?? 0;
        _step = 1;
        _loading = false;
      });

      _startPolling();
    } catch (e) {
      _toast('Error: $e', AppColors.red);
      setState(() => _loading = false);
    }
  }

  void _startPolling() {
    _pollTimer?.cancel();
    _pollTimer = Timer.periodic(const Duration(seconds: 5), (_) async {
      if (!mounted || _depositId == null) return;
      try {
        final res = await http
            .post(
              Uri.parse('$baseUrl/buy/upgrade/status'),
              headers: {'Content-Type': 'application/json'},
              body: jsonEncode({'depositId': _depositId}),
            )
            .timeout(const Duration(seconds: 15));

        final data = jsonDecode(res.body);
        final status = data['status'];

        if (status == 'success') {
          _pollTimer?.cancel();
          if (mounted) {
            setState(() => _step = 2);
            widget.onSuccess?.call();
          }
        } else if (status == 'expired') {
          _pollTimer?.cancel();
          if (mounted) {
            _toast('Invoice expired', AppColors.red);
            Navigator.pop(context);
          }
        }
      } catch (_) {}
    });
  }

  Future<void> _saveQris() async {
    if (_qrUrl == null || _qrUrl!.isEmpty) {
      _toast('QRIS belum tersedia', AppColors.amber);
      return;
    }
    setState(() => _savingQr = true);
    try {
      var status = await Permission.photos.status;
      if (!status.isGranted) {
        status = await Permission.photos.request();
      }
      if (!status.isGranted) {
        status = await Permission.storage.request();
      }

      final res = await http
          .get(Uri.parse(_qrUrl!))
          .timeout(const Duration(seconds: 30));
      if (res.statusCode != 200 || res.bodyBytes.isEmpty) {
        _toast('Gagal download QRIS', AppColors.red);
        return;
      }

      final name =
          'UPGRADE_${widget.toRole}_${DateTime.now().millisecondsSinceEpoch}';
      final result = await ImageGallerySaverPlus.saveImage(
        res.bodyBytes,
        quality: 100,
        name: name,
      );

      if (result['isSuccess'] == true) {
        _toast('QRIS tersimpan di galeri ✅', AppColors.green);
      } else {
        _toast('Gagal simpan QRIS', AppColors.red);
      }
    } catch (e) {
      _toast('Error simpan: $e', AppColors.red);
    } finally {
      if (mounted) setState(() => _savingQr = false);
    }
  }

  Future<void> _cancelInvoice() async {
    _pollTimer?.cancel();
    if (_depositId != null) {
      try {
        await http
            .post(
              Uri.parse('$baseUrl/buy/upgrade/cancel'),
              headers: {'Content-Type': 'application/json'},
              body: jsonEncode({'depositId': _depositId}),
            )
            .timeout(const Duration(seconds: 10));
      } catch (_) {}
    }
    if (mounted) Navigator.pop(context);
  }

  void _toast(String msg, Color color) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          msg,
          style: const TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w600,
            fontFamily: kFont,
          ),
        ),
        backgroundColor: color,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        margin: const EdgeInsets.all(16),
        duration: const Duration(seconds: 3),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isComic = ThemeModeManager.isComic3d;
    return SafeArea(
      top: false,
      child: Container(
        margin: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: AppColors.card,
          borderRadius: BorderRadius.circular(24),
          border: Border.all(
            color: isComic ? Colors.black : Colors.transparent,
            width: isComic ? 3 : 0,
          ),
          boxShadow: AppColors.softShadow,
        ),
        child: Padding(
          padding: EdgeInsets.fromLTRB(
            20,
            20,
            20,
            MediaQuery.of(context).viewInsets.bottom + 20,
          ),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: AppColors.border,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                const SizedBox(height: 20),
                _buildStepIndicator(),
                const SizedBox(height: 24),
                if (_step == 0) _buildConfirmStep(),
                if (_step == 1) _buildQrisStep(),
                if (_step == 2) _buildSuccessStep(),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildStepIndicator() {
    final steps = ['Konfirmasi', 'Bayar', 'Selesai'];
    return Row(
      children: List.generate(steps.length, (i) {
        final active = i <= _step;
        final current = i == _step;
        return Expanded(
          child: Row(
            children: [
              Container(
                width: 28,
                height: 28,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: active ? AppColors.accent : AppColors.card2,
                  border: Border.all(
                    color: active ? AppColors.accent : AppColors.border,
                    width: 1.5,
                  ),
                ),
                alignment: Alignment.center,
                child: current && _loading
                    ? const SizedBox(
                        width: 12,
                        height: 12,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: Colors.white,
                        ),
                      )
                    : Text(
                        '${i + 1}',
                        style: TextStyle(
                          color:
                              active ? Colors.white : AppColors.textSub,
                          fontSize: 12,
                          fontWeight: FontWeight.w800,
                          fontFamily: kFont,
                        ),
                      ),
              ),
              if (i < steps.length - 1)
                Expanded(
                  child: Container(
                    height: 2,
                    margin: const EdgeInsets.symmetric(horizontal: 6),
                    color:
                        i < _step ? AppColors.accent : AppColors.border,
                  ),
                ),
            ],
          ),
        );
      }),
    );
  }

  Widget _buildConfirmStep() {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            _buildRoleBadge(widget.fromRole, dim: true),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Icon(
                Icons.arrow_forward_rounded,
                color: AppColors.accent,
                size: 20,
              ),
            ),
            _buildRoleBadge(widget.toRole, dim: false),
          ],
        ),
        const SizedBox(height: 24),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: AppColors.accent.withOpacity(0.08),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: AppColors.accent.withOpacity(0.3)),
          ),
          child: Column(
            children: [
              Text(
                'BIAYA UPGRADE',
                style: TextStyle(
                  color: AppColors.textSub,
                  fontSize: 11,
                  fontFamily: kFont,
                  letterSpacing: 1,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                _formatRupiah(widget.price),
                style: TextStyle(
                  color: AppColors.accent,
                  fontSize: 26,
                  fontWeight: FontWeight.w900,
                  fontFamily: kFont,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                'Dibayar sekali, langsung up',
                style: TextStyle(
                  color: AppColors.textSub,
                  fontSize: 11,
                  fontFamily: kFont,
                ),
              ),
              if (_isPermanent) ...[
                const SizedBox(height: 8),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 10,
                    vertical: 4,
                  ),
                  decoration: BoxDecoration(
                    color: AppColors.green.withOpacity(0.10),
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(
                      color: AppColors.green.withOpacity(0.4),
                    ),
                  ),
                  child: Text(
                    '✓ Masa berlaku PERMANEN',
                    style: TextStyle(
                      color: AppColors.green,
                      fontSize: 10.5,
                      fontWeight: FontWeight.w700,
                      fontFamily: kFont,
                    ),
                  ),
                ),
              ],
            ],
          ),
        ),
        const SizedBox(height: 20),
        Text(
          '⚠️ Setelah bayar, role kamu otomatis berubah jadi ${widget.toRole.toUpperCase()}. Tidak bisa di-refund.',
          textAlign: TextAlign.center,
          style: TextStyle(
            color: AppColors.amber,
            fontSize: 11,
            fontFamily: kFont,
            height: 1.4,
          ),
        ),
        const SizedBox(height: 24),
        SizedBox(
          width: double.infinity,
          height: 52,
          child: ElevatedButton(
            onPressed: _loading ? null : _createInvoice,
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.accent,
              disabledBackgroundColor: AppColors.border,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14),
              ),
            ),
            child: _loading
                ? const SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(
                      color: Colors.white,
                      strokeWidth: 2,
                    ),
                  )
                : const Text(
                    'BAYAR SEKARANG',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 14,
                      fontWeight: FontWeight.w800,
                      fontFamily: kFont,
                      letterSpacing: 1,
                    ),
                  ),
          ),
        ),
      ],
    );
  }

  Widget _buildRoleBadge(String role, {required bool dim}) {
    return Column(
      children: [
        Container(
          width: 56,
          height: 56,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: dim ? AppColors.card2 : AppColors.accent,
            border: Border.all(
              color: dim ? AppColors.border : AppColors.accent,
              width: 2,
            ),
          ),
          child: Icon(
            roleIconOf(role),
            color: dim ? AppColors.textSub : Colors.white,
            size: 26,
          ),
        ),
        const SizedBox(height: 8),
        Text(
          role.toUpperCase(),
          style: TextStyle(
            color: dim ? AppColors.textSub : AppColors.accent,
            fontSize: 11,
            fontWeight: FontWeight.w700,
            fontFamily: kFont,
            letterSpacing: 0.5,
          ),
        ),
      ],
    );
  }

  Widget _buildQrisStep() {
    final sisaWaktu = _expiredAt > 0
        ? ((_expiredAt - DateTime.now().millisecondsSinceEpoch) / 1000)
            .clamp(0, 3600)
            .toInt()
        : 0;

    return Column(
      children: [
        Text(
          'SCAN QRIS UNTUK BAYAR',
          style: TextStyle(
            color: AppColors.text,
            fontSize: 14,
            fontWeight: FontWeight.w800,
            fontFamily: kFont,
            letterSpacing: 0.5,
          ),
        ),
        const SizedBox(height: 6),
        Text(
          'Bayar sesuai nominal, role otomatis berubah',
          textAlign: TextAlign.center,
          style: TextStyle(
            color: AppColors.textSub,
            fontSize: 11,
            fontFamily: kFont,
          ),
        ),
        const SizedBox(height: 16),
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: AppColors.card2,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: AppColors.accent.withOpacity(0.5),
              width: 2,
            ),
            boxShadow: AppColors.softShadow,
          ),
          child: _qrUrl != null
              ? Image.network(
                  _qrUrl!,
                  width: 220,
                  height: 220,
                  fit: BoxFit.contain,
                  loadingBuilder: (_, child, p) {
                    if (p == null) return child;
                    return SizedBox(
                      width: 220,
                      height: 220,
                      child: Center(
                        child: CircularProgressIndicator(
                          color: AppColors.accent,
                        ),
                      ),
                    );
                  },
                  errorBuilder: (_, __, ___) => SizedBox(
                    width: 220,
                    height: 220,
                    child: Center(
                      child: Icon(
                        Icons.broken_image,
                        size: 60,
                        color: AppColors.textSub,
                      ),
                    ),
                  ),
                )
              : SizedBox(
                  width: 220,
                  height: 220,
                  child: Center(
                    child: CircularProgressIndicator(
                      color: AppColors.accent,
                    ),
                  ),
                ),
        ),
        const SizedBox(height: 16),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          decoration: BoxDecoration(
            color: AppColors.accent.withOpacity(0.08),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppColors.accent.withOpacity(0.3)),
          ),
          child: Column(
            children: [
              Text(
                'TOTAL BAYAR',
                style: TextStyle(
                  color: AppColors.textSub,
                  fontSize: 10,
                  fontFamily: kFont,
                  letterSpacing: 1,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                _formatRupiah(_totalPayment),
                style: TextStyle(
                  color: AppColors.accent,
                  fontSize: 22,
                  fontWeight: FontWeight.w900,
                  fontFamily: kFont,
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(
              width: 14,
              height: 14,
              child: CircularProgressIndicator(
                strokeWidth: 2,
                color: AppColors.accent,
              ),
            ),
            const SizedBox(width: 10),
            Text(
              'Menunggu pembayaran...',
              style: TextStyle(
                color: AppColors.textSub,
                fontSize: 12,
                fontFamily: kFont,
              ),
            ),
          ],
        ),
        if (sisaWaktu > 0)
          Padding(
            padding: const EdgeInsets.only(top: 4),
            child: Text(
              'Kedaluwarsa dalam ${sisaWaktu}s',
              style: TextStyle(
                color: AppColors.textSub,
                fontSize: 10,
                fontFamily: kFont,
              ),
            ),
          ),
        const SizedBox(height: 20),
        SizedBox(
          width: double.infinity,
          height: 46,
          child: OutlinedButton(
            onPressed: _savingQr ? null : _saveQris,
            style: OutlinedButton.styleFrom(
              side: BorderSide(color: AppColors.accent, width: 1.5),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14),
              ),
            ),
            child: _savingQr
                ? SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      color: AppColors.accent,
                    ),
                  )
                : Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        Icons.download_rounded,
                        color: AppColors.accent,
                        size: 18,
                      ),
                      const SizedBox(width: 8),
                      Text(
                        'SIMPAN QRIS',
                        style: TextStyle(
                          color: AppColors.accent,
                          fontSize: 13,
                          fontWeight: FontWeight.w700,
                          fontFamily: kFont,
                          letterSpacing: 1,
                        ),
                      ),
                    ],
                  ),
          ),
        ),
        const SizedBox(height: 10),
        SizedBox(
          width: double.infinity,
          height: 46,
          child: OutlinedButton(
            onPressed: _cancelInvoice,
            style: OutlinedButton.styleFrom(
              side: BorderSide(color: AppColors.red, width: 1.5),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14),
              ),
            ),
            child: Text(
              'BATAL',
              style: TextStyle(
                color: AppColors.red,
                fontSize: 13,
                fontWeight: FontWeight.w700,
                fontFamily: kFont,
                letterSpacing: 1,
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildSuccessStep() {
    return Column(
      children: [
        Container(
          width: 80,
          height: 80,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: AppColors.green,
          ),
          child: const Icon(
            Icons.check_rounded,
            color: Colors.white,
            size: 48,
          ),
        ),
        const SizedBox(height: 20),
        Text(
          'UPGRADE SUKSES',
          style: TextStyle(
            color: AppColors.text,
            fontSize: 16,
            fontWeight: FontWeight.w800,
            fontFamily: kFont,
            letterSpacing: 1,
          ),
        ),
        const SizedBox(height: 8),
        Text(
          'Role kamu sekarang: ${widget.toRole.toUpperCase()}',
          style: TextStyle(
            color: AppColors.textSub,
            fontSize: 12,
            fontFamily: kFont,
          ),
        ),
        if (_isPermanent) ...[
          const SizedBox(height: 4),
          Text(
            'Masa berlaku: PERMANEN ✨',
            style: TextStyle(
              color: AppColors.green,
              fontSize: 12,
              fontWeight: FontWeight.w700,
              fontFamily: kFont,
            ),
          ),
        ],
        const SizedBox(height: 24),
        SizedBox(
          width: double.infinity,
          height: 50,
          child: ElevatedButton(
            onPressed: () => Navigator.pop(context),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.accent,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14),
              ),
            ),
            child: const Text(
              'SELESAI',
              style: TextStyle(
                color: Colors.white,
                fontSize: 14,
                fontWeight: FontWeight.w800,
                fontFamily: kFont,
                letterSpacing: 1,
              ),
            ),
          ),
        ),
      ],
    );
  }
}