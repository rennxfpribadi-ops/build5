import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

// ═══════════════════════════════════════════════════════════════
// 🔧 GANTI INI DENGAN DOMAIN KAMU
// ═══════════════════════════════════════════════════════════════
const String baseUrl = "http://cp.zyrostore.id:3448";

// ─── Model Particle Bintang ──────────────────────────────────────
class _Star {
  final double x;        // 0..1 posisi horizontal awal
  final double y;        // 0..1 posisi vertikal awal
  final double speed;    // kecepatan jatuh
  final double size;     // ukuran sparkle
  final double opacity;  // opacity dasar
  final double sway;     // amplitudo geser kiri-kanan
  final double swaySpeed;
  final double phase;

  _Star({
    required this.x,
    required this.y,
    required this.speed,
    required this.size,
    required this.opacity,
    required this.sway,
    required this.swaySpeed,
    required this.phase,
  });
}

// ─── Painter Bintang Berjatuhan ──────────────────────────────────
class _FallingStarsPainter extends CustomPainter {
  final double progress;
  final List<_Star> stars;

  _FallingStarsPainter({required this.progress, required this.stars});

  Path _sparkle(Offset c, double s) {
    final p = Path();
    p.moveTo(c.dx, c.dy - s);
    p.quadraticBezierTo(c.dx + s * 0.18, c.dy - s * 0.18, c.dx + s, c.dy);
    p.quadraticBezierTo(c.dx + s * 0.18, c.dy + s * 0.18, c.dx, c.dy + s);
    p.quadraticBezierTo(c.dx - s * 0.18, c.dy + s * 0.18, c.dx - s, c.dy);
    p.quadraticBezierTo(c.dx - s * 0.18, c.dy - s * 0.18, c.dx, c.dy - s);
    return p;
  }

  @override
  void paint(Canvas canvas, Size size) {
    for (final star in stars) {
      // Gerak jatuh (loop)
      final y = ((star.y + progress * star.speed) % 1.0) * size.height;

      // Sway kiri-kanan
      final swayX =
          math.sin(progress * math.pi * 2 * star.swaySpeed + star.phase) *
              star.sway *
              size.width;
      final x = (star.x * size.width) + swayX;
      final center = Offset(x, y);

      // Glow luar
      canvas.drawCircle(
        center,
        star.size * 2.2,
        Paint()
          ..color = Colors.white.withOpacity(star.opacity * 0.12)
          ..maskFilter = MaskFilter.blur(BlurStyle.normal, star.size * 2),
      );

      // Sparkle ✨ core
      canvas.drawPath(
        _sparkle(center, star.size),
        Paint()..color = Colors.white.withOpacity(star.opacity),
      );

      // Titik terang tengah
      canvas.drawCircle(
        center,
        star.size * 0.35,
        Paint()..color = Colors.white.withOpacity(star.opacity),
      );
    }
  }

  @override
  bool shouldRepaint(covariant _FallingStarsPainter old) =>
      old.progress != progress;
}

// ─── Painter Grid Background ─────────────────────────────────────
class _GridPainter extends CustomPainter {
  final double progress;

  _GridPainter({required this.progress});

  @override
  void paint(Canvas canvas, Size size) {
    const spacing = 44.0;
    final center = size.center(Offset.zero);
    final maxDist = size.longestSide * 0.6;
    final paint = Paint()..strokeWidth = 0.9;

    // Garis vertikal
    for (double x = 0; x <= size.width; x += spacing) {
      final d = (Offset(x, center.dy) - center).distance;
      final a = (0.14 * (1 - d / maxDist)).clamp(0.0, 0.14);
      paint.color = Colors.purpleAccent.withOpacity(a);
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }

    // Garis horizontal
    for (double y = 0; y <= size.height; y += spacing) {
      final d = (Offset(center.dx, y) - center).distance;
      final a = (0.14 * (1 - d / maxDist)).clamp(0.0, 0.14);
      paint.color = Colors.purpleAccent.withOpacity(a);
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }

    // Titik-titik pulsing di persilangan (grid nodes)
    final pulse = (math.sin(progress * math.pi * 2) + 1) / 2;
    for (double x = 0; x <= size.width; x += spacing) {
      for (double y = 0; y <= size.height; y += spacing) {
        final d = (Offset(x, y) - center).distance;
        if (d < maxDist) {
          final a = (0.55 *
                  (1 - d / maxDist) *
                  (0.25 + pulse * 0.75))
              .clamp(0.0, 1.0);
          canvas.drawCircle(
            Offset(x, y),
            1.3,
            Paint()..color = Colors.purpleAccent.withOpacity(a),
          );
        }
      }
    }
  }

  @override
  bool shouldRepaint(covariant _GridPainter old) => old.progress != progress;
}

// ═══════════════════════════════════════════════════════════════
// PAGE
// ═══════════════════════════════════════════════════════════════
class RoleUpgradePage extends StatefulWidget {
  final String sessionKey;
  const RoleUpgradePage({Key? key, required this.sessionKey}) : super(key: key);

  @override
  State<RoleUpgradePage> createState() => _RoleUpgradePageState();
}

class _RoleUpgradePageState extends State<RoleUpgradePage>
    with TickerProviderStateMixin {
  // ── Animasi ─────────────────────────────────────────────────
  late AnimationController _bgController;
  late List<_Star> _stars;

  // ── State ───────────────────────────────────────────────────
  bool _isLoading = true;
  bool _isUpgrading = false;
  List<dynamic> _users = [];

  String? _selectedUsername;
  String? _currentRole;
  String? _selectedNewRole;

  // ── Role metadata ───────────────────────────────────────────
  static const Map<String, List<String>> _roleHierarchy = {
    'member':    ['fullup', 'reseller', 'owner', 'developer'],
    'fullup':    ['reseller', 'owner', 'developer'],
    'reseller':  ['owner', 'developer'],
    'owner':     ['developer'],
    'developer': [],
  };

  static const Map<String, IconData> _roleIcons = {
    'member':    Icons.person_outline,
    'fullup':    Icons.star_outline,
    'reseller':  Icons.storefront_outlined,
    'owner':     Icons.workspace_premium,
    'developer': Icons.code,
  };

  static const Map<String, Color> _roleColors = {
    'member':    Color(0xFF90A4AE),
    'fullup':    Color(0xFF29B6F6),
    'reseller':  Color(0xFF66BB6A),
    'owner':     Color(0xFFFFCA28),
    'developer': Color(0xFFB388FF),
  };

  @override
  void initState() {
    super.initState();
    _bgController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 20),
    )..repeat();
    _stars = _generateStars();
    _fetchUsers();
  }

  @override
  void dispose() {
    _bgController.dispose();
    super.dispose();
  }

  List<_Star> _generateStars() {
    final r = math.Random();
    return List.generate(55, (_) => _Star(
      x: r.nextDouble(),
      y: r.nextDouble(),
      speed: 0.12 + r.nextDouble() * 0.35,
      size: 1.2 + r.nextDouble() * 2.0,
      opacity: 0.35 + r.nextDouble() * 0.65,
      sway: 0.008 + r.nextDouble() * 0.03,
      swaySpeed: 0.5 + r.nextDouble() * 1.5,
      phase: r.nextDouble() * math.pi * 2,
    ));
  }

  // ═════════════════════════════════════════════════════════════
  // API
  // ═════════════════════════════════════════════════════════════
  Future<void> _fetchUsers() async {
    setState(() => _isLoading = true);
    try {
      final uri = Uri.parse('$baseUrl/listUsers?key=${widget.sessionKey}');
      final res = await http.get(uri).timeout(const Duration(seconds: 15));
      if (res.statusCode != 200) {
        _showError('Server error: ${res.statusCode}');
        return;
      }
      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['authorized'] == true) {
        setState(() {
          _users = data['users'] ?? [];
          _isLoading = false;
        });
      } else {
        _showError(data['message'] ??
            'Gagal memuat user. Pastikan role kamu authorized.');
      }
    } catch (e) {
      _showError('Koneksi error: $e');
    }
  }

  Future<void> _upgradeRole() async {
    if (_selectedUsername == null || _selectedNewRole == null) return;

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF1A1025),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text('Konfirmasi Upgrade',
            style: TextStyle(color: Colors.white)),
        content: Text(
          'Upgrade @$_selectedUsername\n\n'
          'Dari: ${_currentRole?.toUpperCase()}\n'
          'Ke: ${_selectedNewRole?.toUpperCase()}\n\n'
          'Lanjutkan?',
          style: const TextStyle(color: Colors.white70),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Batal', style: TextStyle(color: Colors.white54)),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: ElevatedButton.styleFrom(backgroundColor: Colors.purpleAccent),
            child: const Text('Ya, Upgrade'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;

    setState(() => _isUpgrading = true);
    try {
      final uri = Uri.parse('$baseUrl/upgradeRole'
          '?key=${widget.sessionKey}'
          '&username=$_selectedUsername'
          '&role=$_selectedNewRole');
      final res = await http.get(uri).timeout(const Duration(seconds: 20));
      if (res.statusCode != 200) {
        _showError('Server error: ${res.statusCode}');
        return;
      }
      final data = jsonDecode(res.body);
      if (data['upgraded'] == true) {
        _showSuccess(data['message'] ?? 'Role berhasil di-upgrade!');
        setState(() {
          _selectedUsername = null;
          _currentRole = null;
          _selectedNewRole = null;
        });
        await _fetchUsers();
      } else {
        _showError(data['message'] ?? 'Gagal melakukan upgrade');
      }
    } catch (e) {
      _showError('Koneksi error: $e');
    } finally {
      setState(() => _isUpgrading = false);
    }
  }

  // ═════════════════════════════════════════════════════════════
  // Snackbar helpers
  // ═════════════════════════════════════════════════════════════
  void _showError(String message) {
    if (mounted) setState(() => _isLoading = false);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(children: [
          const Icon(Icons.error_outline, color: Colors.white),
          const SizedBox(width: 10),
          Expanded(child: Text(message)),
        ]),
        backgroundColor: Colors.redAccent[700],
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        duration: const Duration(seconds: 4),
      ),
    );
  }

  void _showSuccess(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(children: [
          const Icon(Icons.check_circle, color: Colors.white),
          const SizedBox(width: 10),
          Expanded(child: Text(message)),
        ]),
        backgroundColor: const Color(0xFF2E7D32),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        duration: const Duration(seconds: 3),
      ),
    );
  }

  // ═════════════════════════════════════════════════════════════
  // BUILD
  // ═════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF07020D),
      body: Stack(
        children: [
          // ── Base gradient ───────────────────────────────────
          Positioned.fill(
            child: Container(
              decoration: const BoxDecoration(
                gradient: RadialGradient(
                  center: Alignment(0, -0.4),
                  radius: 1.5,
                  colors: [
                    Color(0xFF2A1040),
                    Color(0xFF140624),
                    Color(0xFF07020D),
                  ],
                  stops: [0.0, 0.5, 1.0],
                ),
              ),
            ),
          ),

          // ── Grid background ─────────────────────────────────
          Positioned.fill(
            child: AnimatedBuilder(
              animation: _bgController,
              builder: (_, __) => CustomPaint(
                painter: _GridPainter(progress: _bgController.value),
              ),
            ),
          ),

          // ── Blur orbs ───────────────────────────────────────
          _buildBackgroundOrnaments(),

          // ── Falling stars ✨ ────────────────────────────────
          Positioned.fill(
            child: IgnorePointer(
              child: AnimatedBuilder(
                animation: _bgController,
                builder: (_, __) => CustomPaint(
                  painter: _FallingStarsPainter(
                    progress: _bgController.value,
                    stars: _stars,
                  ),
                ),
              ),
            ),
          ),

          // ── Content ─────────────────────────────────────────
          SafeArea(
            child: Column(
              children: [
                _buildAppBar(),
                Expanded(
                  child: _isLoading
                      ? const Center(
                          child: CircularProgressIndicator(
                              color: Colors.purpleAccent),
                        )
                      : RefreshIndicator(
                          onRefresh: _fetchUsers,
                          color: Colors.purpleAccent,
                          backgroundColor: const Color(0xFF1A1025),
                          child: SingleChildScrollView(
                            physics: const AlwaysScrollableScrollPhysics(),
                            padding: const EdgeInsets.symmetric(
                                horizontal: 18, vertical: 8),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.stretch,
                              children: [
                                _buildStatsBar(),
                                const SizedBox(height: 14),
                                _buildCurrentRoleCard(),
                                const SizedBox(height: 16),
                                _buildSelectUserSection(),
                                const SizedBox(height: 16),
                                _buildSelectNewRoleSection(),
                                const SizedBox(height: 26),
                                _buildUpgradeButton(),
                                const SizedBox(height: 14),
                                _buildFooterHint(),
                                const SizedBox(height: 24),
                              ],
                            ),
                          ),
                        ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ═════════════════════════════════════════════════════════════
  // Background ornaments
  // ═════════════════════════════════════════════════════════════
  Widget _buildBackgroundOrnaments() {
    return Stack(children: [
      Positioned(
        top: -120, left: -100,
        child: _blurCircle(340, Colors.purple.withOpacity(0.35), 90),
      ),
      Positioned(
        bottom: -100, right: -80,
        child: _blurCircle(280, Colors.deepPurpleAccent.withOpacity(0.28), 70),
      ),
      Positioned(
        top: 200, right: -60,
        child: _blurCircle(160, Colors.pinkAccent.withOpacity(0.14), 50),
      ),
    ]);
  }

  Widget _blurCircle(double size, Color color, double blur) {
    return Container(
      width: size, height: size,
      decoration: BoxDecoration(shape: BoxShape.circle, color: color),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: blur, sigmaY: blur),
        child: Container(color: Colors.transparent),
      ),
    );
  }

  // ═════════════════════════════════════════════════════════════
  // AppBar
  // ═════════════════════════════════════════════════════════════
  Widget _buildAppBar() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.07),
                shape: BoxShape.circle,
                border: Border.all(color: Colors.white.withOpacity(0.18)),
                boxShadow: [
                  BoxShadow(
                    color: Colors.purpleAccent.withOpacity(0.15),
                    blurRadius: 12,
                  ),
                ],
              ),
              child:
                  const Icon(Icons.arrow_back, color: Colors.white, size: 20),
            ),
          ),
          const SizedBox(width: 14),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(children: [
                  Icon(Icons.auto_awesome,
                      color: Colors.purpleAccent, size: 18),
                  SizedBox(width: 6),
                  Text('ROLE UPGRADE',
                      style: TextStyle(
                          fontSize: 19,
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 2)),
                ]),
                Text('Naikkan role user lain',
                    style: TextStyle(
                        fontSize: 11,
                        color: Colors.white54,
                        letterSpacing: 0.5)),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [
                Colors.purpleAccent.withOpacity(0.28),
                Colors.deepPurple.withOpacity(0.28),
              ]),
              borderRadius: BorderRadius.circular(10),
              border:
                  Border.all(color: Colors.purpleAccent.withOpacity(0.45)),
            ),
            child: const Row(children: [
              Icon(Icons.lock_outline,
                  size: 11, color: Colors.purpleAccent),
              SizedBox(width: 4),
              Text('SECURE',
                  style: TextStyle(
                      fontSize: 9,
                      color: Colors.purpleAccent,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 1)),
            ]),
          ),
        ],
      ),
    );
  }

  // ═════════════════════════════════════════════════════════════
  // Stats bar
  // ═════════════════════════════════════════════════════════════
  Widget _buildStatsBar() {
    final counts = <String, int>{};
    for (final u in _users) {
      final r = (u['role'] ?? 'member').toString().toLowerCase();
      counts[r] = (counts[r] ?? 0) + 1;
    }
    const order = ['member', 'fullup', 'reseller', 'owner', 'developer'];

    return SizedBox(
      height: 54,
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 2),
        children: [
          _statChip(Icons.groups, '${_users.length}', 'TOTAL',
              Colors.purpleAccent),
          const SizedBox(width: 8),
          ...order.where((r) => (counts[r] ?? 0) > 0).map((r) => Padding(
                padding: const EdgeInsets.only(right: 8),
                child: _statChip(
                  _roleIcons[r] ?? Icons.person,
                  '${counts[r]}',
                  r.toUpperCase(),
                  _roleColors[r] ?? Colors.white,
                ),
              )),
        ],
      ),
    );
  }

  Widget _statChip(IconData icon, String value, String label, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      decoration: BoxDecoration(
        color: color.withOpacity(0.09),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: color.withOpacity(0.32), width: 1),
        boxShadow: [
          BoxShadow(
            color: color.withOpacity(0.15),
            blurRadius: 12,
            spreadRadius: 1,
          ),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 16, color: color),
          const SizedBox(width: 8),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(value,
                  style: TextStyle(
                      color: color,
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                      height: 1.1)),
              Text(label,
                  style: TextStyle(
                      color: color.withOpacity(0.65),
                      fontSize: 9,
                      letterSpacing: 1,
                      fontWeight: FontWeight.w600)),
            ],
          ),
        ],
      ),
    );
  }

  // ═════════════════════════════════════════════════════════════
  // Current Role Card
  // ═════════════════════════════════════════════════════════════
  Widget _buildCurrentRoleCard() {
    final role = _currentRole ?? '';
    final color = _roleColors[role] ?? Colors.purpleAccent;
    final icon = _roleIcons[role] ?? Icons.badge_outlined;

    return _glassContainer(
      glowColor: color,
      child: Row(
        children: [
          Container(
            width: 56, height: 56,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: RadialGradient(colors: [
                color.withOpacity(0.35),
                color.withOpacity(0.05),
              ]),
              border: Border.all(color: color.withOpacity(0.5), width: 1.2),
              boxShadow: [
                BoxShadow(
                    color: color.withOpacity(0.3), blurRadius: 18),
              ],
            ),
            child: Icon(icon, color: color, size: 26),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(children: [
                  Icon(Icons.badge, color: Colors.white54, size: 12),
                  const SizedBox(width: 6),
                  const Text('ROLE SAAT INI',
                      style: TextStyle(
                          fontSize: 11,
                          color: Colors.white54,
                          letterSpacing: 1.5)),
                ]),
                const SizedBox(height: 6),
                Text(
                  _currentRole?.toUpperCase() ?? '— BELUM DIPILIH —',
                  style: TextStyle(
                    fontSize: 20,
                    color: _currentRole != null ? color : Colors.white38,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 2,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ═════════════════════════════════════════════════════════════
  // Select User
  // ═════════════════════════════════════════════════════════════
  Widget _buildSelectUserSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Padding(
          padding: EdgeInsets.only(left: 4, bottom: 8),
          child: Text('CARI USER',
              style: TextStyle(
                  fontSize: 12,
                  color: Colors.white70,
                  letterSpacing: 1.4,
                  fontWeight: FontWeight.w600)),
        ),
        GestureDetector(
          onTap: _showUserSelectionModal,
          child: _glassContainer(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            child: Row(children: [
              const Icon(Icons.person_search,
                  color: Colors.purpleAccent, size: 20),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  _selectedUsername != null
                      ? '@$_selectedUsername'
                      : 'Pilih user untuk di-upgrade...',
                  style: TextStyle(
                    fontSize: 15,
                    color: _selectedUsername != null
                        ? Colors.white
                        : Colors.white38,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              const Icon(Icons.chevron_right,
                  color: Colors.white54, size: 20),
            ]),
          ),
        ),
      ],
    );
  }

  // ═════════════════════════════════════════════════════════════
  // Select New Role
  // ═════════════════════════════════════════════════════════════
  Widget _buildSelectNewRoleSection() {
    final availableRoles =
        _currentRole != null ? (_roleHierarchy[_currentRole] ?? []) : <String>[];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Padding(
          padding: EdgeInsets.only(left: 4, bottom: 8),
          child: Text('PILIH ROLE BARU',
              style: TextStyle(
                  fontSize: 12,
                  color: Colors.white70,
                  letterSpacing: 1.4,
                  fontWeight: FontWeight.w600)),
        ),
        _glassContainer(
          padding: const EdgeInsets.all(14),
          child: _currentRole == null
              ? Padding(
                  padding: const EdgeInsets.symmetric(vertical: 22),
                  child: Center(
                    child: Text('Pilih user terlebih dahulu',
                        style: TextStyle(
                            fontSize: 13, color: Colors.white38)),
                  ),
                )
              : availableRoles.isEmpty
                  ? Padding(
                      padding: const EdgeInsets.symmetric(vertical: 22),
                      child: Center(
                        child: Column(children: [
                          const Icon(Icons.workspace_premium,
                              color: Colors.amber, size: 34),
                          const SizedBox(height: 8),
                          Text('User ini sudah di role TERTINGGI',
                              style: TextStyle(
                                  fontSize: 13, color: Colors.white70)),
                        ]),
                      ),
                    )
                  : Column(
                      children: availableRoles.map((role) {
                        final selected = _selectedNewRole == role;
                        final color = _roleColors[role] ?? Colors.purpleAccent;
                        final icon = _roleIcons[role] ?? Icons.star;
                        return GestureDetector(
                          onTap: () =>
                              setState(() => _selectedNewRole = role),
                          child: AnimatedContainer(
                            duration: const Duration(milliseconds: 200),
                            margin: const EdgeInsets.only(bottom: 8),
                            padding: const EdgeInsets.symmetric(
                                horizontal: 14, vertical: 12),
                            decoration: BoxDecoration(
                              gradient: selected
                                  ? LinearGradient(colors: [
                                      color.withOpacity(0.35),
                                      color.withOpacity(0.1),
                                    ])
                                  : LinearGradient(colors: [
                                      Colors.white.withOpacity(0.03),
                                      Colors.white.withOpacity(0.01),
                                    ]),
                              borderRadius: BorderRadius.circular(14),
                              border: Border.all(
                                color: selected
                                    ? color.withOpacity(0.8)
                                    : Colors.white.withOpacity(0.12),
                                width: selected ? 1.6 : 1,
                              ),
                              boxShadow: selected
                                  ? [
                                      BoxShadow(
                                        color: color.withOpacity(0.35),
                                        blurRadius: 16,
                                        spreadRadius: 1,
                                      ),
                                    ]
                                  : [],
                            ),
                            child: Row(children: [
                              Container(
                                padding: const EdgeInsets.all(6),
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: color.withOpacity(0.18),
                                ),
                                child: Icon(icon, color: color, size: 16),
                              ),
                              const SizedBox(width: 12),
                              Text(
                                role.toUpperCase(),
                                style: TextStyle(
                                  fontSize: 15,
                                  color: selected ? Colors.white : Colors.white70,
                                  fontWeight: selected
                                      ? FontWeight.bold
                                      : FontWeight.normal,
                                  letterSpacing: 1,
                                ),
                              ),
                              const Spacer(),
                              Icon(
                                selected
                                    ? Icons.check_circle
                                    : Icons.circle_outlined,
                                color: selected
                                    ? color
                                    : Colors.white24,
                                size: 20,
                              ),
                            ]),
                          ),
                        );
                      }).toList(),
                    ),
        ),
      ],
    );
  }

  // ═════════════════════════════════════════════════════════════
  // Upgrade Button
  // ═════════════════════════════════════════════════════════════
  Widget _buildUpgradeButton() {
    final canUpgrade = _selectedUsername != null &&
        _selectedNewRole != null &&
        !_isUpgrading;

    return AnimatedContainer(
      duration: const Duration(milliseconds: 250),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        gradient: canUpgrade
            ? const LinearGradient(colors: [
                Color(0xFF9C27B0),
                Color(0xFF673AB7),
                Color(0xFF3F51B5),
              ])
            : null,
        color: canUpgrade ? null : Colors.white.withOpacity(0.05),
        border: Border.all(
          color: canUpgrade
              ? Colors.purpleAccent.withOpacity(0.5)
              : Colors.white.withOpacity(0.1),
        ),
        boxShadow: canUpgrade
            ? [
                BoxShadow(
                    color: Colors.purpleAccent.withOpacity(0.5),
                    blurRadius: 22,
                    spreadRadius: 2),
                BoxShadow(
                    color: Colors.deepPurple.withOpacity(0.3),
                    blurRadius: 40,
                    spreadRadius: 4),
              ]
            : [],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(18),
          onTap: canUpgrade ? _upgradeRole : null,
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 16),
            child: Center(
              child: _isUpgrading
                  ? const SizedBox(
                      height: 20, width: 20,
                      child: CircularProgressIndicator(
                          color: Colors.white, strokeWidth: 2),
                    )
                  : Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.rocket_launch,
                            color: canUpgrade
                                ? Colors.white
                                : Colors.white38,
                            size: 20),
                        const SizedBox(width: 10),
                        Text(
                          'UPGRADE ROLE',
                          style: TextStyle(
                            fontSize: 15,
                            color: canUpgrade
                                ? Colors.white
                                : Colors.white38,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 2,
                          ),
                        ),
                      ],
                    ),
            ),
          ),
        ),
      ),
    );
  }

  // ═════════════════════════════════════════════════════════════
  // Footer hint
  // ═════════════════════════════════════════════════════════════
  Widget _buildFooterHint() {
    return Center(
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.auto_awesome,
              color: Colors.purpleAccent.withOpacity(0.6), size: 12),
          const SizedBox(width: 6),
          Text(
            'Upgrade role hanya untuk akunmu sendiri',
            style: TextStyle(
                fontSize: 11,
                color: Colors.white.withOpacity(0.35),
                letterSpacing: 0.5),
          ),
          const SizedBox(width: 6),
          Icon(Icons.auto_awesome,
              color: Colors.purpleAccent.withOpacity(0.6), size: 12),
        ],
      ),
    );
  }

  // ═════════════════════════════════════════════════════════════
  // Glass container w/ reflective border
  // ═════════════════════════════════════════════════════════════
  Widget _glassContainer({
    required Widget child,
    EdgeInsets padding = const EdgeInsets.all(18),
    Color? glowColor,
  }) {
    final glow = glowColor ?? Colors.purpleAccent;

    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(22),
        // ── Reflective border (gradient) ──
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Colors.white.withOpacity(0.42), // reflection terang kiri-atas
            Colors.white.withOpacity(0.06),
            Colors.white.withOpacity(0.22), // reflection kanan-bawah
          ],
          stops: const [0.0, 0.55, 1.0],
        ),
        boxShadow: [
          BoxShadow(
            color: glow.withOpacity(0.15),
            blurRadius: 22,
            spreadRadius: 1,
          ),
          BoxShadow(
            color: Colors.black.withOpacity(0.35),
            blurRadius: 18,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.all(1.4), // tebal border
        child: ClipRRect(
          borderRadius: BorderRadius.circular(20.6),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
            child: Container(
              padding: padding,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20.6),
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    Colors.white.withOpacity(0.09),
                    const Color(0xFF150A26).withOpacity(0.55),
                  ],
                ),
              ),
              child: Stack(
                children: [
                  // Highlight reflection di pojok kiri-atas
                  Positioned.fill(
                    child: IgnorePointer(
                      child: Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(20.6),
                          gradient: LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.center,
                            colors: [
                              Colors.white.withOpacity(0.10),
                              Colors.transparent,
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  child,
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ═════════════════════════════════════════════════════════════
  // Modal: Select User
  // ═════════════════════════════════════════════════════════════
  void _showUserSelectionModal() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => _buildUserSelectionSheet(),
    );
  }

  Widget _buildUserSelectionSheet() {
    List<dynamic> filtered = List.from(_users);
    return StatefulBuilder(
      builder: (context, setModalState) {
        return Container(
          height: MediaQuery.of(context).size.height * 0.78,
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [Color(0xFF1A1025), Color(0xFF0D0518)],
            ),
            borderRadius: BorderRadius.vertical(top: Radius.circular(30)),
            border: Border(
                top: BorderSide(color: Colors.white24, width: 1.2)),
          ),
          child: Column(children: [
            const SizedBox(height: 12),
            Container(
              width: 50, height: 5,
              decoration: BoxDecoration(
                color: Colors.white24,
                borderRadius: BorderRadius.circular(10),
              ),
            ),
            const SizedBox(height: 18),
            const Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.people, color: Colors.purpleAccent, size: 18),
                SizedBox(width: 8),
                Text('PILIH USER',
                    style: TextStyle(
                        fontSize: 17,
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1.5)),
              ],
            ),
            const SizedBox(height: 16),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: TextField(
                style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  hintText: 'Cari username...',
                  hintStyle: const TextStyle(color: Colors.white38),
                  prefixIcon: const Icon(Icons.search,
                      color: Colors.purpleAccent),
                  filled: true,
                  fillColor: Colors.white.withOpacity(0.06),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15),
                    borderSide: BorderSide.none,
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15),
                    borderSide: BorderSide(
                        color: Colors.white.withOpacity(0.15), width: 1),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15),
                    borderSide: const BorderSide(
                        color: Colors.purpleAccent, width: 1.4),
                  ),
                ),
                onChanged: (val) {
                  setModalState(() {
                    final q = val.toLowerCase();
                    filtered = _users
                        .where((u) => u['username']
                            .toString()
                            .toLowerCase()
                            .contains(q))
                        .toList();
                  });
                },
              ),
            ),
            const SizedBox(height: 10),
            Expanded(
              child: filtered.isEmpty
                  ? const Center(
                      child: Text('User tidak ditemukan',
                          style: TextStyle(color: Colors.white54)))
                  : ListView.builder(
                      itemCount: filtered.length,
                      itemBuilder: (_, i) {
                        final user = filtered[i];
                        final username = user['username'].toString();
                        final roleStr =
                            (user['role'] ?? 'member').toString().toLowerCase();
                        final color =
                            _roleColors[roleStr] ?? Colors.purpleAccent;
                        final icon = _roleIcons[roleStr] ?? Icons.person;
                        return Container(
                          margin: const EdgeInsets.symmetric(
                              horizontal: 16, vertical: 4),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.03),
                            borderRadius: BorderRadius.circular(14),
                            border: Border.all(
                                color: Colors.white.withOpacity(0.08)),
                          ),
                          child: ListTile(
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(14)),
                            leading: Container(
                              width: 42, height: 42,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                gradient: RadialGradient(colors: [
                                  color.withOpacity(0.35),
                                  color.withOpacity(0.05),
                                ]),
                                border: Border.all(
                                    color: color.withOpacity(0.5)),
                              ),
                              child: Center(
                                child: Text(
                                  username.substring(0, 1).toUpperCase(),
                                  style: TextStyle(
                                      color: color,
                                      fontWeight: FontWeight.bold),
                                ),
                              ),
                            ),
                            title: Text(username,
                                style: const TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.w600)),
                            subtitle: Row(children: [
                              Icon(icon, size: 12, color: color),
                              const SizedBox(width: 4),
                              Text(roleStr.toUpperCase(),
                                  style: TextStyle(
                                      fontSize: 11,
                                      color: color.withOpacity(0.9),
                                      fontWeight: FontWeight.w600,
                                      letterSpacing: 1)),
                            ]),
                            trailing: const Icon(Icons.chevron_right,
                                color: Colors.white38),
                            onTap: () {
                              setState(() {
                                _selectedUsername = username;
                                _currentRole = roleStr;
                                _selectedNewRole = null;
                              });
                              Navigator.pop(context);
                            },
                          ),
                        );
                      },
                    ),
            ),
          ]),
        );
      },
    );
  }
}