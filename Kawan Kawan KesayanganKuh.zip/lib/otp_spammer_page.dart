import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

const String _kBaseUrl = "http://cp.zyrostore.id:3448";

// ═══════════════════════════════════════════════════════════════════
// 📌 NOTE: OTP SPAMMER - No WhatsApp sender required
// ═══════════════════════════════════════════════════════════════════
// This tool uses HTTP requests to send OTP spam to multiple targets
// No WhatsApp socket/connection needed - works independently!
// ═══════════════════════════════════════════════════════════════════

class OtpSpammerPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;

  const OtpSpammerPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
  });

  @override
  State<OtpSpammerPage> createState() => _OtpSpammerPageState();
}

class _OtpSpammerPageState extends State<OtpSpammerPage>
    with SingleTickerProviderStateMixin {
  final TextEditingController _numberController = TextEditingController();
  final TextEditingController _quantityController = TextEditingController();

  bool _isRunning = false;
  int _totalSent = 0;
  int _successCount = 0;
  int _failedCount = 0;
  int _currentTarget = 0;
  String _statusLog = "";
  List<Map<String, dynamic>> _results = [];
  List<String> _targets = [];
  bool _isLoadingTargets = false;
  String _errorDetail = "";
  String? _currentJobId;
  Timer? _pollTimer;

  // ✅ Stats auto-disable
  Map<String, dynamic>? _otpStats;
  bool _isLoadingStats = false;
  bool _showStatsSection = false;

  late AnimationController _pulseController;
  late Animation<double> _pulseAnimation;
  late AnimationController _glowController;
  late Animation<double> _glowAnimation;
  late AnimationController _scanController;
  late Animation<double> _scanAnimation;

  // ── TEMA DARK BLUE OCEAN ESTETIK ──
  final Color darkBg = const Color(0xFF0A0A12);
  final Color darkBg2 = const Color(0xFF0A1628);
  final Color purpleDark = const Color(0xFF0A1A3A);
  final Color purpleSoft = const Color(0xFF2A6B9E);
  final Color purpleGlow = const Color(0xFF4DA8E8);
  final Color purpleNeon = const Color(0xFF6BC8FF);
  final Color textWhite = const Color(0xFFF0F4FF);
  final Color textGrey = const Color(0xFFA8C8E0);
  final Color textLight = const Color(0xFF6B8DA8);
  final Color glassBorder = const Color(0x14FFFFFF);
  final Color successGreen = const Color(0xFF22C55E);
  final Color dangerRed = const Color(0xFFEF4444);
  final Color warningOrange = const Color(0xFFF59E0B);

  @override
  void initState() {
    super.initState();
    _initAnimations();
    _fetchTargets();
    _fetchOtpStats();
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    _pulseController.dispose();
    _glowController.dispose();
    _scanController.dispose();
    _numberController.dispose();
    _quantityController.dispose();
    super.dispose();
  }

  void _initAnimations() {
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);
    _pulseAnimation = Tween<double>(begin: 0.6, end: 1.0).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOutSine),
    );

    _glowController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2000),
    )..repeat(reverse: true);
    _glowAnimation = Tween<double>(begin: 0.3, end: 0.8).animate(
      CurvedAnimation(parent: _glowController, curve: Curves.easeInOut),
    );

    _scanController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    )..repeat();
    _scanAnimation = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(parent: _scanController, curve: Curves.linear),
    );
  }

  Future<void> _fetchTargets() async {
    setState(() => _isLoadingTargets = true);
    try {
      final token = widget.sessionKey;

      final response = await http.get(
        Uri.parse('$_kBaseUrl/api/otp-targets?key=$token'),
        headers: {'Content-Type': 'application/json'},
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['success'] == true) {
          setState(() {
            _targets = List<String>.from(data['targets'] ?? []);
            _isLoadingTargets = false;
          });
        } else {
          setState(() {
            _targets = _getFallbackTargets();
            _isLoadingTargets = false;
          });
        }
      } else {
        setState(() {
          _targets = _getFallbackTargets();
          _isLoadingTargets = false;
        });
      }
    } catch (e) {
      setState(() {
        _targets = _getFallbackTargets();
        _isLoadingTargets = false;
      });
    }
  }

  Future<void> _fetchOtpStats() async {
    setState(() => _isLoadingStats = true);
    try {
      final token = widget.sessionKey;
      final resp = await http.get(
        Uri.parse('$_kBaseUrl/api/otp-stats?key=$token'),
        headers: {'Content-Type': 'application/json'},
      ).timeout(const Duration(seconds: 10));

      if (resp.statusCode == 200) {
        final data = jsonDecode(resp.body);
        if (data['success'] == true) {
          setState(() => _otpStats = data);
        }
      }
    } catch (e) {
      debugPrint('Error fetch stats: $e');
    } finally {
      setState(() => _isLoadingStats = false);
    }
  }

  Future<void> _resetOtpStats({String? targetName}) async {
    try {
      final token = widget.sessionKey;
      final resp = await http.post(
        Uri.parse('$_kBaseUrl/api/otp-reset-stats?key=$token'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'key': token,
          if (targetName != null) 'target': targetName,
        }),
      ).timeout(const Duration(seconds: 10));

      if (resp.statusCode == 200) {
        final data = jsonDecode(resp.body);
        if (data['success'] == true) {
          _showSnackBar(data['message'] ?? 'Reset berhasil', successGreen);
          await _fetchOtpStats();
        } else {
          _showSnackBar(data['message'] ?? 'Reset gagal', dangerRed);
        }
      }
    } catch (e) {
      _showSnackBar('Error: $e', dangerRed);
    }
  }

  List<String> _getFallbackTargets() {
    return [
      'Sayurbox', 'Matahari', 'Tokopedia', 'Shopee', 'Blibli',
      'Lazada', 'Grab', 'Gojek', 'OVO', 'DANA',
      'BCA', 'Mandiri', 'BRI', 'BNI', 'LinkAja',
      'Jenius', 'MyTelkomsel', 'MyIM3', 'BY.U', 'KFC', 'McD'
    ];
  }

  void _showSnackBar(String msg, Color color) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg, style: const TextStyle(color: Colors.white)),
        backgroundColor: color,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      ),
    );
  }

  Widget _buildGradientBorderCard({
    required Widget child,
    EdgeInsetsGeometry? padding,
    bool hasGlow = false,
  }) {
    return AnimatedBuilder(
      animation: _glowAnimation,
      builder: (context, _) {
        final glow = _glowAnimation.value;
        return Container(
          padding: padding ?? const EdgeInsets.all(2.5),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [purpleSoft, purpleGlow],
            ),
            boxShadow: hasGlow
                ? [
                    BoxShadow(
                      color: purpleGlow.withOpacity(0.15 + 0.1 * glow),
                      blurRadius: 20 + 10 * glow,
                      spreadRadius: 2 + 1 * glow,
                      offset: const Offset(0, 4),
                    ),
                  ]
                : null,
          ),
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(18),
              color: darkBg,
            ),
            child: child,
          ),
        );
      },
    );
  }

  Widget _buildGlassCard({
    required Widget child,
    EdgeInsetsGeometry? padding,
    bool hasGlow = false,
  }) {
    return Container(
      padding: padding ?? const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            Colors.white.withOpacity(0.04),
            Colors.white.withOpacity(0.01),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: hasGlow ? purpleGlow.withOpacity(0.12) : glassBorder,
          width: hasGlow ? 1.5 : 1,
        ),
        boxShadow: [
          BoxShadow(
            color: hasGlow ? purpleGlow.withOpacity(0.06) : Colors.black.withOpacity(0.2),
            blurRadius: hasGlow ? 20 : 12,
            spreadRadius: hasGlow ? 2 : 0,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: child,
    );
  }

  List<Map<String, dynamic>> _normalizeResults(dynamic raw) {
    if (raw == null) return [];
    try {
      final list = List<dynamic>.from(raw);
      return list.map<Map<String, dynamic>>((e) {
        if (e is! Map) return {'target': 'Unknown', 'status': 'fail'};
        final m = Map<String, dynamic>.from(e);
        final target = m['target'] ?? m['n'] ?? m['name'] ?? 'Unknown';
        final rawStatus = (m['status'] ?? m['s'] ?? '').toString().toLowerCase();
        final isOk = rawStatus == 'ok' ||
            rawStatus == 'success' ||
            rawStatus == '200' ||
            RegExp(r'^2\d\d$').hasMatch(rawStatus);
        return {
          'target': target.toString(),
          'status': isOk ? 'success' : 'fail',
          'raw': m,
        };
      }).toList();
    } catch (_) {
      return [];
    }
  }

  Future<void> _startSpam() async {
    final number = _numberController.text.trim();
    final quantity = _quantityController.text.trim();

    if (number.isEmpty || quantity.isEmpty) {
      setState(() => _statusLog = "Harap isi nomor dan jumlah!");
      return;
    }

    final num = number.replaceAll(RegExp(r'\D'), '');
    if (num.length < 8) {
      setState(() => _statusLog = "Nomor tidak valid! Minimal 8 digit.");
      return;
    }

    final count = int.tryParse(quantity);
    if (count == null || count < 1 || count > 100) {
      setState(() => _statusLog = "Jumlah harus 1-100!");
      return;
    }

    _pollTimer?.cancel();
    _pollTimer = null;

    setState(() {
      _isRunning = true;
      _totalSent = 0;
      _successCount = 0;
      _failedCount = 0;
      _results = [];
      _errorDetail = "";
      _currentJobId = null;
      _statusLog = "Memulai spam OTP ke $num...";
    });

    try {
      final token = widget.sessionKey;

      final response = await http.post(
        Uri.parse('$_kBaseUrl/api/spam-otp?key=$token'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'number': num,
          'quantity': count,
        }),
      ).timeout(const Duration(seconds: 30));

      if (!mounted) return;

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);

        // CASE 1: non-blocking jobId
        final jobId = data['jobId']?.toString();
        if (jobId != null && jobId.isNotEmpty) {
          setState(() {
            _currentJobId = jobId;
            _totalSent = data['total'] ?? 0;
            _statusLog = data['message'] ??
                "Job $jobId dimulai, memantau progress...";
          });
          _startPollingJob(jobId);
          return;
        }

        // CASE 2: sync result
        if (data['success'] == true) {
          setState(() {
            _totalSent = data['total'] ?? 0;
            _successCount = data['successCount'] ?? 0;
            _failedCount = data['failedCount'] ?? 0;
            _results = _normalizeResults(data['results']);
            _statusLog = data['message'] ?? "Selesai!";
            _errorDetail = "";
            _isRunning = false;
          });
          // refresh stats setelah spam
          _fetchOtpStats();
          return;
        }

        // CASE 3: cooldown
        if (data['cooldown'] == true) {
          setState(() {
            _statusLog = data['message'] ?? "Cooldown aktif!";
            _isRunning = false;
          });
          return;
        }

        setState(() {
          _statusLog = "Gagal: ${data['message'] ?? 'Unknown error'}";
          _errorDetail = data['message'] ?? '';
          _isRunning = false;
        });
        return;

      } else if (response.statusCode == 401) {
        setState(() {
          _statusLog = "Session expired! Silakan login ulang.";
          _errorDetail = "Session key tidak valid atau expired";
          _isRunning = false;
        });
        return;

      } else if (response.statusCode == 429) {
        final data = jsonDecode(response.body);
        setState(() {
          _statusLog = data['message'] ?? "Rate limit! Tunggu beberapa saat.";
          _errorDetail = data['message'] ?? '';
          _isRunning = false;
        });
        return;

      } else {
        final data = jsonDecode(response.body);
        setState(() {
          _statusLog = "Error ${response.statusCode}: ${data['message'] ?? 'Unknown'}";
          _errorDetail = data['message'] ?? 'No detail';
          _isRunning = false;
        });
        return;
      }
    } on TimeoutException {
      if (!mounted) return;
      setState(() {
        _statusLog = "Server timeout. Coba turunin quantity atau cek koneksi.";
        _errorDetail = "Request ke server lebih dari 30 detik";
        _isRunning = false;
      });
      return;
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _statusLog = "Connection error: ${e.toString().replaceFirst('Exception: ', '')}";
        _errorDetail = e.toString();
        _isRunning = false;
      });
      return;
    }
  }

  void _startPollingJob(String jobId) {
    _pollTimer?.cancel();
    int attempts = 0;
    const maxAttempts = 300;

    _pollTimer = Timer.periodic(const Duration(seconds: 1), (timer) async {
      attempts++;
      if (!mounted) {
        timer.cancel();
        return;
      }
      if (attempts > maxAttempts) {
        timer.cancel();
        setState(() {
          _statusLog = "Polling timeout (>5 menit) — job masih jalan di server.";
          _isRunning = false;
        });
        return;
      }

      try {
        final token = widget.sessionKey;
        final resp = await http
            .get(Uri.parse('$_kBaseUrl/api/spam-otp/status/$jobId?key=$token'))
            .timeout(const Duration(seconds: 8));

        if (!mounted) {
          timer.cancel();
          return;
        }

        if (resp.statusCode != 200) {
          if (resp.statusCode == 404) {
            timer.cancel();
            setState(() {
              _statusLog = "Job tidak ditemukan di server (mungkin sudah selesai).";
              _isRunning = false;
            });
          }
          return;
        }

        final data = jsonDecode(resp.body);
        if (data['success'] != true) return;

        final status = (data['status'] ?? 'running').toString();
        final progress = data['progress'] ?? 0;
        final total = data['totalTasks'] ?? 0;
        final ok = data['successCount'] ?? 0;
        final fail = data['failedCount'] ?? 0;
        final results = _normalizeResults(data['results']);

        setState(() {
          _totalSent = total;
          _successCount = ok;
          _failedCount = fail;
          _currentTarget = progress;
          _results = results;
          _statusLog =
              "Progress: $progress/$total • OK: $ok • Fail: $fail";
        });

        if (status == 'success' || status == 'failed') {
          timer.cancel();
          setState(() {
            _statusLog = status == 'success'
                ? "Selesai! $ok/$total terkirim."
                : "Gagal: ${data['error'] ?? 'Unknown error'}";
            _errorDetail = status == 'failed'
                ? (data['error'] ?? 'No detail').toString()
                : '';
            _isRunning = false;
            _currentJobId = null;
          });
          _fetchOtpStats();
        }
      } catch (_) {}
    });
  }

  void _stopSpam() {
    _pollTimer?.cancel();
    _pollTimer = null;
    setState(() {
      _isRunning = false;
      _currentJobId = null;
      _statusLog = "Dihentikan oleh user";
    });
  }

  Color _getStatusColor(String status) {
    if (status.contains('Selesai') || status.contains('Success') || status.contains('berhasil')) {
      return successGreen;
    }
    if (status.contains('Error') || status.contains('Gagal') || status.contains('Invalid')) {
      return dangerRed;
    }
    if (status.contains('Cooldown') || status.contains('Rate limit') || status.contains('Tunggu')) {
      return warningOrange;
    }
    if (status.contains('Memulai') || status.contains('Progress')) return purpleGlow;
    if (status.contains('Session expired')) return dangerRed;
    return textGrey;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: darkBg,
      body: Container(
        decoration: BoxDecoration(
          gradient: RadialGradient(
            center: Alignment.topCenter,
            radius: 1.2,
            colors: [
              purpleDark.withOpacity(0.3),
              darkBg,
              darkBg2,
            ],
            stops: const [0.0, 0.4, 1.0],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              _buildAppBar(),
              Expanded(
                child: SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      _buildHeader(),
                      const SizedBox(height: 20),
                      _buildNoteCard(),
                      const SizedBox(height: 16),
                      _buildInputSection(),
                      const SizedBox(height: 16),
                      _buildTargetsCounter(),
                      const SizedBox(height: 16),
                      _buildControlButtons(),
                      const SizedBox(height: 16),
                      _buildStatusLog(),
                      const SizedBox(height: 16),
                      if (_results.isNotEmpty) _buildResultsList(),
                      const SizedBox(height: 16),
                      _buildOtpStatsSection(),
                      const SizedBox(height: 16),
                      if (_errorDetail.isNotEmpty) _buildErrorDetail(),
                      const SizedBox(height: 16),
                      _buildInfoCard(),
                      const SizedBox(height: 16),
                      _buildFooter(),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildAppBar() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        border: Border(
          bottom: BorderSide(
            color: purpleGlow.withOpacity(0.08),
            width: 0.5,
          ),
        ),
      ),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [purpleSoft.withOpacity(0.2), purpleGlow.withOpacity(0.2)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: glassBorder),
              ),
              child: Icon(Icons.arrow_back_ios_new, color: textWhite, size: 18),
            ),
          ),
          const SizedBox(width: 12),
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              gradient: LinearGradient(
                colors: [purpleSoft, purpleGlow],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              boxShadow: [
                BoxShadow(
                  color: purpleGlow.withOpacity(0.3),
                  blurRadius: 12,
                  spreadRadius: 1,
                ),
              ],
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: Image.asset(
                'assets/images/reze.png',
                fit: BoxFit.cover,
                errorBuilder: (context, error, stackTrace) {
                  return Center(
                    child: Icon(Icons.send, color: textWhite, size: 18),
                  );
                },
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "OTP SPAMMER",
                  style: TextStyle(
                    color: textWhite,
                    fontFamily: 'Orbitron',
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.5,
                    fontSize: 13,
                  ),
                ),
                Text(
                  "SONIC CRASH PROJECT",
                  style: TextStyle(
                    color: purpleGlow.withOpacity(0.5),
                    fontFamily: 'Rajdhani',
                    fontWeight: FontWeight.w500,
                    letterSpacing: 2,
                    fontSize: 8,
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              gradient: _isRunning
                  ? LinearGradient(colors: [successGreen, successGreen.withOpacity(0.7)])
                  : LinearGradient(colors: [Colors.grey.shade700, Colors.grey.shade600]),
              borderRadius: BorderRadius.circular(10),
              boxShadow: _isRunning
                  ? [
                      BoxShadow(
                        color: successGreen.withOpacity(0.3),
                        blurRadius: 12,
                        spreadRadius: 1,
                      ),
                    ]
                  : null,
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 6,
                  height: 6,
                  decoration: BoxDecoration(
                    color: _isRunning ? successGreen : Colors.grey,
                    shape: BoxShape.circle,
                    boxShadow: _isRunning
                        ? [
                            BoxShadow(
                              color: successGreen.withOpacity(0.5),
                              blurRadius: 8,
                            ),
                          ]
                        : null,
                  ),
                ),
                const SizedBox(width: 6),
                Text(
                  _isRunning ? "ACTIVE" : "IDLE",
                  style: TextStyle(
                    color: textWhite,
                    fontSize: 8,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Orbitron',
                    letterSpacing: 0.5,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return AnimatedBuilder(
      animation: _pulseAnimation,
      builder: (context, child) {
        return Transform.scale(
          scale: _pulseAnimation.value,
          child: Center(
            child: Container(
              width: 90,
              height: 90,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(24),
                gradient: LinearGradient(
                  colors: [purpleSoft, purpleGlow],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                boxShadow: [
                  BoxShadow(
                    color: purpleGlow.withOpacity(0.4),
                    blurRadius: 40,
                    spreadRadius: 8,
                    offset: const Offset(0, 10),
                  ),
                  BoxShadow(
                    color: purpleGlow.withOpacity(0.2),
                    blurRadius: 60,
                    spreadRadius: 15,
                    offset: const Offset(0, 20),
                  ),
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(22),
                child: Image.asset(
                  'assets/images/reze.png',
                  fit: BoxFit.cover,
                  errorBuilder: (context, error, stackTrace) {
                    return Container(
                      color: darkBg2,
                      child: Center(
                        child: Icon(
                          Icons.flash_on,
                          color: textWhite.withOpacity(0.5),
                          size: 40,
                        ),
                      ),
                    );
                  },
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildNoteCard() {
    return _buildGlassCard(
      hasGlow: true,
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [purpleSoft.withOpacity(0.2), purpleGlow.withOpacity(0.1)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(Icons.info_outline, color: purpleNeon, size: 16),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "NO WHATSAPP SENDER NEEDED",
                  style: TextStyle(
                    color: purpleNeon,
                    fontSize: 9,
                    fontWeight: FontWeight.w700,
                    fontFamily: 'Orbitron',
                    letterSpacing: 0.5,
                  ),
                ),
                Text(
                  "Auto-skip target mati • Self-healing system",
                  style: TextStyle(
                    color: textGrey,
                    fontSize: 10,
                    fontFamily: 'Rajdhani',
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInputSection() {
    return _buildGradientBorderCard(
      hasGlow: true,
      padding: const EdgeInsets.all(2.5),
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: purpleGlow.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Icon(Icons.phone_android, color: purpleGlow, size: 16),
                ),
                const SizedBox(width: 10),
                Text(
                  "TARGET NUMBER",
                  style: TextStyle(
                    color: textGrey,
                    fontFamily: 'Orbitron',
                    fontSize: 10,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 1.5,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _numberController,
              style: TextStyle(
                color: textWhite,
                fontSize: 15,
                fontFamily: 'Rajdhani',
                fontWeight: FontWeight.w600,
              ),
              keyboardType: TextInputType.phone,
              decoration: InputDecoration(
                hintText: "6281234567890",
                hintStyle: TextStyle(
                  color: textLight,
                  fontFamily: 'Rajdhani',
                ),
                prefixIcon: Icon(Icons.phone_android, color: purpleGlow, size: 20),
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: glassBorder),
                  borderRadius: BorderRadius.circular(12),
                ),
                focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: purpleGlow, width: 2),
                  borderRadius: BorderRadius.circular(12),
                ),
                filled: true,
                fillColor: Colors.white.withOpacity(0.03),
                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              ),
            ),
            const SizedBox(height: 14),
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: purpleGlow.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Icon(Icons.numbers, color: purpleGlow, size: 16),
                ),
                const SizedBox(width: 10),
                Text(
                  "QUANTITY",
                  style: TextStyle(
                    color: textGrey,
                    fontFamily: 'Orbitron',
                    fontSize: 10,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 1.5,
                  ),
                ),
                const Spacer(),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: warningOrange.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: warningOrange.withOpacity(0.2)),
                  ),
                  child: Text(
                    "MAX 100",
                    style: TextStyle(
                      color: warningOrange,
                      fontSize: 8,
                      fontWeight: FontWeight.w700,
                      fontFamily: 'Orbitron',
                      letterSpacing: 0.5,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            TextField(
              controller: _quantityController,
              style: TextStyle(
                color: textWhite,
                fontSize: 15,
                fontFamily: 'Rajdhani',
                fontWeight: FontWeight.w600,
              ),
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                hintText: "1-100",
                hintStyle: TextStyle(
                  color: textLight,
                  fontFamily: 'Rajdhani',
                ),
                prefixIcon: Icon(Icons.format_list_numbered, color: purpleGlow, size: 20),
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: glassBorder),
                  borderRadius: BorderRadius.circular(12),
                ),
                focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: purpleGlow, width: 2),
                  borderRadius: BorderRadius.circular(12),
                ),
                filled: true,
                fillColor: Colors.white.withOpacity(0.03),
                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTargetsCounter() {
    final stats = _otpStats;
    final activeCount = stats?['activeCount'] ?? _targets.length;
    final disabledCount = stats?['disabledCount'] ?? 0;
    final totalCount = stats?['total'] ?? _targets.length;

    return _buildGlassCard(
      hasGlow: true,
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [purpleSoft.withOpacity(0.2), purpleGlow.withOpacity(0.1)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(Icons.track_changes, color: purpleGlow, size: 20),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "ACTIVE TARGETS",
                  style: TextStyle(
                    color: textGrey,
                    fontSize: 10,
                    fontWeight: FontWeight.w700,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  _isLoadingTargets
                      ? "Loading..."
                      : "$activeCount aktif${disabledCount > 0 ? " • $disabledCount mati" : ""}",
                  style: TextStyle(
                    color: textWhite,
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Rajdhani',
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [purpleSoft, purpleGlow],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Text(
              _isLoadingTargets ? "..." : "$activeCount/$totalCount",
              style: TextStyle(
                color: textWhite,
                fontSize: 12,
                fontWeight: FontWeight.bold,
                fontFamily: 'Orbitron',
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildControlButtons() {
    return _buildGradientBorderCard(
      hasGlow: true,
      padding: const EdgeInsets.all(2.5),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Row(
          children: [
            Expanded(
              child: AnimatedBuilder(
                animation: _pulseAnimation,
                builder: (context, child) {
                  return Container(
                    decoration: BoxDecoration(
                      gradient: _isRunning
                          ? null
                          : LinearGradient(
                              colors: [purpleSoft, purpleGlow],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: _isRunning
                          ? null
                          : [
                              BoxShadow(
                                color: purpleGlow.withOpacity(0.3),
                                blurRadius: 16,
                                spreadRadius: 2,
                                offset: const Offset(0, 4),
                              ),
                            ],
                    ),
                    child: ElevatedButton.icon(
                      onPressed: _isRunning ? null : _startSpam,
                      icon: Icon(
                        Icons.play_arrow,
                        color: Colors.white,
                        size: 20,
                      ),
                      label: Text(
                        "START",
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Orbitron',
                          letterSpacing: 2,
                          fontSize: 13,
                        ),
                      ),
                      style: ElevatedButton.styleFrom(
                        backgroundColor:
                            _isRunning ? Colors.grey.shade800.withOpacity(0.5) : Colors.transparent,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        elevation: 0,
                        shadowColor: Colors.transparent,
                      ),
                    ),
                  );
                },
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Container(
                decoration: BoxDecoration(
                  gradient: _isRunning
                      ? LinearGradient(
                          colors: [dangerRed, dangerRed.withOpacity(0.7)],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        )
                      : null,
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: _isRunning
                      ? [
                          BoxShadow(
                            color: dangerRed.withOpacity(0.3),
                            blurRadius: 16,
                            spreadRadius: 2,
                            offset: const Offset(0, 4),
                          ),
                        ]
                      : null,
                ),
                child: ElevatedButton.icon(
                  onPressed: _isRunning ? _stopSpam : null,
                  icon: Icon(
                    Icons.stop,
                    color: Colors.white,
                    size: 20,
                  ),
                  label: Text(
                    "STOP",
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Orbitron',
                      letterSpacing: 2,
                      fontSize: 13,
                    ),
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor:
                        _isRunning ? Colors.transparent : Colors.grey.shade800.withOpacity(0.5),
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    elevation: 0,
                    shadowColor: Colors.transparent,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatusLog() {
    return _buildGradientBorderCard(
      hasGlow: true,
      padding: const EdgeInsets.all(2.5),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [purpleSoft.withOpacity(0.2), purpleGlow.withOpacity(0.1)],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Icon(Icons.terminal, color: purpleGlow, size: 16),
                ),
                const SizedBox(width: 10),
                Text(
                  "STATUS LOG",
                  style: TextStyle(
                    color: textWhite,
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1.5,
                  ),
                ),
                const Spacer(),
                if (_totalSent > 0)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [purpleSoft, purpleGlow],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Text(
                      "$_totalSent",
                      style: TextStyle(
                        color: textWhite,
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Orbitron',
                      ),
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 12),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.03),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: glassBorder),
              ),
              child: Row(
                children: [
                  Container(
                    width: 4,
                    height: 4,
                    decoration: BoxDecoration(
                      color: _getStatusColor(_statusLog),
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                          color: _getStatusColor(_statusLog).withOpacity(0.5),
                          blurRadius: 8,
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      _statusLog.isEmpty ? "Menunggu perintah..." : _statusLog,
                      style: TextStyle(
                        color: _getStatusColor(_statusLog),
                        fontSize: 13,
                        fontWeight: FontWeight.w500,
                        fontFamily: 'Rajdhani',
                        height: 1.4,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            if (_totalSent > 0) ...[
              const SizedBox(height: 12),
              Row(
                children: [
                  _buildStatChip(
                    icon: Icons.check_circle,
                    label: "Success",
                    value: "$_successCount",
                    color: successGreen,
                  ),
                  const SizedBox(width: 8),
                  _buildStatChip(
                    icon: Icons.cancel,
                    label: "Failed",
                    value: "$_failedCount",
                    color: dangerRed,
                  ),
                  const SizedBox(width: 8),
                  _buildStatChip(
                    icon: Icons.flash_on,
                    label: "Total",
                    value: "$_totalSent",
                    color: purpleGlow,
                  ),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildStatChip({
    required IconData icon,
    required String label,
    required String value,
    required Color color,
  }) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 8),
        decoration: BoxDecoration(
          color: color.withOpacity(0.08),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: color.withOpacity(0.15)),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: color, size: 12),
            const SizedBox(width: 4),
            Text(
              value,
              style: TextStyle(
                color: color,
                fontSize: 12,
                fontWeight: FontWeight.bold,
                fontFamily: 'Orbitron',
              ),
            ),
            const SizedBox(width: 4),
            Text(
              label,
              style: TextStyle(
                color: textGrey,
                fontSize: 8,
                fontWeight: FontWeight.w500,
                fontFamily: 'Rajdhani',
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildResultsList() {
    return _buildGlassCard(
      hasGlow: true,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: purpleGlow.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(Icons.list_alt, color: purpleGlow, size: 16),
              ),
              const SizedBox(width: 10),
              Text(
                "DETAIL RESULTS",
                style: TextStyle(
                  color: textWhite,
                  fontSize: 11,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron',
                  letterSpacing: 1,
                ),
              ),
              const Spacer(),
              Text(
                "${_results.length}",
                style: TextStyle(
                  color: textGrey,
                  fontSize: 10,
                  fontWeight: FontWeight.w500,
                  fontFamily: 'Rajdhani',
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          SizedBox(
            height: 120,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: _results.length > 20 ? 20 : _results.length,
              itemBuilder: (context, index) {
                final result = _results[index];
                final isSuccess = result['status'] == 'success';
                return Container(
                  width: 80,
                  margin: const EdgeInsets.only(right: 8),
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: isSuccess
                        ? successGreen.withOpacity(0.08)
                        : dangerRed.withOpacity(0.08),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                      color: isSuccess
                          ? successGreen.withOpacity(0.2)
                          : dangerRed.withOpacity(0.2),
                    ),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        isSuccess ? Icons.check : Icons.close,
                        color: isSuccess ? successGreen : dangerRed,
                        size: 14,
                      ),
                      const SizedBox(height: 4),
                      Text(
                        result['target']?.toString() ?? 'Unknown',
                        style: TextStyle(
                          color: textGrey,
                          fontSize: 8,
                          fontWeight: FontWeight.w600,
                          fontFamily: 'Rajdhani',
                        ),
                        textAlign: TextAlign.center,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════
  // ✅ SECTION BARU: TARGET HEALTH
  // ═══════════════════════════════════════════════════════
  Widget _buildOtpStatsSection() {
    return _buildGlassCard(
      hasGlow: true,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          GestureDetector(
            onTap: () {
              setState(() => _showStatsSection = !_showStatsSection);
              if (_showStatsSection && _otpStats == null) {
                _fetchOtpStats();
              }
            },
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: purpleGlow.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Icon(Icons.analytics_outlined, color: purpleGlow, size: 16),
                ),
                const SizedBox(width: 10),
                Text(
                  "TARGET HEALTH",
                  style: TextStyle(
                    color: textWhite,
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1,
                  ),
                ),
                const Spacer(),
                if (_isLoadingStats)
                  SizedBox(
                    width: 14,
                    height: 14,
                    child: CircularProgressIndicator(
                      color: purpleGlow,
                      strokeWidth: 2,
                    ),
                  )
                else if (_otpStats != null)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(
                      color: (_otpStats!['disabledCount'] ?? 0) > 0
                          ? dangerRed.withOpacity(0.15)
                          : successGreen.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                        color: (_otpStats!['disabledCount'] ?? 0) > 0
                            ? dangerRed.withOpacity(0.4)
                            : successGreen.withOpacity(0.4),
                      ),
                    ),
                    child: Text(
                      '${_otpStats!['activeCount']}/${_otpStats!['total']}',
                      style: TextStyle(
                        color: (_otpStats!['disabledCount'] ?? 0) > 0
                            ? dangerRed
                            : successGreen,
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Orbitron',
                      ),
                    ),
                  )
                else
                  Icon(
                    _showStatsSection ? Icons.expand_less : Icons.expand_more,
                    color: textGrey,
                    size: 18,
                  ),
              ],
            ),
          ),

          if (_showStatsSection) ...[
            const SizedBox(height: 14),
            if (_otpStats == null && !_isLoadingStats)
              Padding(
                padding: const EdgeInsets.all(12),
                child: Center(
                  child: TextButton.icon(
                    onPressed: _fetchOtpStats,
                    icon: Icon(Icons.refresh, color: purpleGlow, size: 16),
                    label: Text(
                      "Muat Stats",
                      style: TextStyle(color: purpleGlow, fontSize: 12),
                    ),
                  ),
                ),
              ),

            if (_otpStats != null) ...[
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.03),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: glassBorder),
                ),
                child: Row(
                  children: [
                    _buildStatMini(
                      icon: Icons.check_circle,
                      label: 'Aktif',
                      value: '${_otpStats!['activeCount'] ?? 0}',
                      color: successGreen,
                    ),
                    const SizedBox(width: 8),
                    _buildStatMini(
                      icon: Icons.cancel,
                      label: 'Mati',
                      value: '${_otpStats!['disabledCount'] ?? 0}',
                      color: dangerRed,
                    ),
                    const SizedBox(width: 8),
                    _buildStatMini(
                      icon: Icons.rule,
                      label: 'Limit',
                      value: '${_otpStats!['threshold'] ?? 5}x',
                      color: warningOrange,
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 10),

              Container(
                constraints: const BoxConstraints(maxHeight: 320),
                child: ListView.builder(
                  shrinkWrap: true,
                  physics: const BouncingScrollPhysics(),
                  itemCount: (_otpStats!['targets'] as List).length,
                  itemBuilder: (context, index) {
                    final t = (_otpStats!['targets'] as List)[index];
                    final isDisabled = t['status'] == 'disabled';
                    final successRate = ((t['totalOk'] ?? 0) + (t['totalFail'] ?? 0)) > 0
                        ? ((t['totalOk'] ?? 0) / ((t['totalOk'] ?? 0) + (t['totalFail'] ?? 0)) * 100)
                        : 0.0;

                    return Container(
                      margin: const EdgeInsets.only(bottom: 6),
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                      decoration: BoxDecoration(
                        color: isDisabled
                            ? dangerRed.withOpacity(0.08)
                            : Colors.white.withOpacity(0.02),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(
                          color: isDisabled
                              ? dangerRed.withOpacity(0.25)
                              : glassBorder,
                        ),
                      ),
                      child: Row(
                        children: [
                          Container(
                            width: 6,
                            height: 6,
                            decoration: BoxDecoration(
                              color: isDisabled ? dangerRed : successGreen,
                              shape: BoxShape.circle,
                              boxShadow: [
                                BoxShadow(
                                  color: (isDisabled ? dangerRed : successGreen).withOpacity(0.5),
                                  blurRadius: 6,
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  t['name'] ?? 'unknown',
                                  style: TextStyle(
                                    color: isDisabled ? dangerRed : textWhite,
                                    fontSize: 12,
                                    fontWeight: FontWeight.w600,
                                    fontFamily: 'Rajdhani',
                                  ),
                                ),
                                if (isDisabled)
                                  Text(
                                    '${t['lastError'] ?? "auto-disabled"} • streak: ${t['streakFail']}x',
                                    style: TextStyle(
                                      color: dangerRed.withOpacity(0.7),
                                      fontSize: 9,
                                      fontFamily: 'Rajdhani',
                                    ),
                                  )
                                else
                                  Text(
                                    '${t['totalOk'] ?? 0} ok • ${t['totalFail'] ?? 0} fail • ${successRate.toStringAsFixed(0)}%',
                                    style: TextStyle(
                                      color: textLight,
                                      fontSize: 9,
                                      fontFamily: 'Rajdhani',
                                    ),
                                  ),
                              ],
                            ),
                          ),
                          if (isDisabled)
                            GestureDetector(
                              onTap: () => _resetOtpStats(targetName: t['name']),
                              child: Container(
                                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                decoration: BoxDecoration(
                                  color: purpleGlow.withOpacity(0.15),
                                  borderRadius: BorderRadius.circular(6),
                                  border: Border.all(color: purpleGlow.withOpacity(0.3)),
                                ),
                                child: Text(
                                  'REVIVE',
                                  style: TextStyle(
                                    color: purpleGlow,
                                    fontSize: 8,
                                    fontWeight: FontWeight.bold,
                                    fontFamily: 'Orbitron',
                                    letterSpacing: 0.5,
                                  ),
                                ),
                              ),
                            ),
                        ],
                      ),
                    );
                  },
                ),
              ),

              const SizedBox(height: 10),

              Row(
                children: [
                  Expanded(
                    child: GestureDetector(
                      onTap: _fetchOtpStats,
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 10),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.03),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: glassBorder),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.refresh, color: purpleGlow, size: 14),
                            const SizedBox(width: 6),
                            Text(
                              'REFRESH',
                              style: TextStyle(
                                color: purpleGlow,
                                fontSize: 9,
                                fontWeight: FontWeight.bold,
                                fontFamily: 'Orbitron',
                                letterSpacing: 0.5,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: GestureDetector(
                      onTap: () => _showResetConfirmDialog(),
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 10),
                        decoration: BoxDecoration(
                          color: warningOrange.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: warningOrange.withOpacity(0.3)),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.restart_alt, color: warningOrange, size: 14),
                            const SizedBox(width: 6),
                            Text(
                              'RESET ALL',
                              style: TextStyle(
                                color: warningOrange,
                                fontSize: 9,
                                fontWeight: FontWeight.bold,
                                fontFamily: 'Orbitron',
                                letterSpacing: 0.5,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ],
        ],
      ),
    );
  }

  Widget _buildStatMini({
    required IconData icon,
    required String label,
    required String value,
    required Color color,
  }) {
    return Expanded(
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, color: color, size: 12),
          const SizedBox(width: 4),
          Text(
            value,
            style: TextStyle(
              color: color,
              fontSize: 12,
              fontWeight: FontWeight.bold,
              fontFamily: 'Orbitron',
            ),
          ),
          const SizedBox(width: 4),
          Text(
            label,
            style: TextStyle(
              color: textGrey,
              fontSize: 9,
              fontFamily: 'Rajdhani',
            ),
          ),
        ],
      ),
    );
  }

  void _showResetConfirmDialog() {
    showDialog(
      context: context,
      builder: (context) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: darkBg,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: glassBorder, width: 1.5),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Icon(Icons.warning_amber_rounded, color: warningOrange, size: 24),
                  const SizedBox(width: 10),
                  Text(
                    'RESET SEMUA STATS?',
                    style: TextStyle(
                      color: warningOrange,
                      fontSize: 13,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Orbitron',
                      letterSpacing: 1,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              Text(
                'Semua target akan di-set kembali ke status "active". Statistik ok/fail akan di-reset ke 0.',
                style: TextStyle(
                  color: textGrey,
                  fontSize: 12,
                  fontFamily: 'Rajdhani',
                  height: 1.4,
                ),
              ),
              const SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: Text(
                      'BATAL',
                      style: TextStyle(
                        color: textLight,
                        fontSize: 11,
                        fontFamily: 'Orbitron',
                        letterSpacing: 1,
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  TextButton(
                    onPressed: () {
                      Navigator.pop(context);
                      _resetOtpStats();
                    },
                    style: TextButton.styleFrom(
                      backgroundColor: warningOrange.withOpacity(0.15),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                        side: BorderSide(color: warningOrange.withOpacity(0.4)),
                      ),
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    ),
                    child: Text(
                      'RESET',
                      style: TextStyle(
                        color: warningOrange,
                        fontSize: 11,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Orbitron',
                        letterSpacing: 1,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildErrorDetail() {
    return _buildGlassCard(
      hasGlow: true,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: dangerRed.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(Icons.error, color: dangerRed, size: 16),
              ),
              const SizedBox(width: 10),
              Text(
                "ERROR DETAIL",
                style: TextStyle(
                  color: dangerRed,
                  fontSize: 11,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron',
                  letterSpacing: 1,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: dangerRed.withOpacity(0.05),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: dangerRed.withOpacity(0.1)),
            ),
            child: Text(
              _errorDetail,
              style: TextStyle(
                color: textGrey,
                fontSize: 12,
                fontFamily: 'Rajdhani',
                height: 1.4,
              ),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            "💡 Tips: Pastikan nomor valid (62xx) dan koneksi internet stabil",
            style: TextStyle(
              color: textLight,
              fontSize: 10,
              fontFamily: 'Rajdhani',
              fontStyle: FontStyle.italic,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoCard() {
    return _buildGlassCard(
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: warningOrange.withOpacity(0.1),
              shape: BoxShape.circle,
            ),
            child: Icon(Icons.info_outline, color: warningOrange, size: 16),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              "Auto-skip target mati (5x fail). Auto-revive setelah 24 jam. Bisa spam ulang ke nomor sama, tapi target mungkin rate-limit.",
              style: TextStyle(
                color: textGrey,
                fontSize: 11,
                fontFamily: 'Rajdhani',
                height: 1.3,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFooter() {
    return Center(
      child: Text(
        "SONIC CRASH PROJECT",
        style: TextStyle(
          color: purpleGlow.withOpacity(0.15),
          fontSize: 10,
          fontWeight: FontWeight.bold,
          fontFamily: 'Orbitron',
          letterSpacing: 3,
        ),
      ),
    );
  }
}