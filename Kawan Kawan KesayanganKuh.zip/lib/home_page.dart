import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'theme.dart'; // <-- IMPORT THEME

const String baseUrl = "http://cp.zyrostore.id:3448";

class HomePage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listBugGb;
  final String role;
  final String expiredDate;
  final String initialTargetMode;

  const HomePage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    this.listBugGb = const [],
    required this.role,
    required this.expiredDate,
    this.initialTargetMode = 'bug_no',
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  // ── SHORTCUT KE THEME.DART ──
  Color get cBg => AppColors.bg;
  Color get cCard => AppColors.card;
  Color get cAccent => AppColors.accent;
  Color get cAccentLight => AppColors.accentLight;
  Color get cText => AppColors.text;
  Color get cTextSub => AppColors.textSub;
  Color get cBorder => AppColors.border;

  late AnimationController _pulseController;
  late AnimationController _resultCtrl;
  late Animation<double> _resultFade;
  late Animation<Offset> _resultSlide;

  final targetController = TextEditingController();

  String? _selectedBugId;
  bool _isSending = false;
  String? _responseMessage;
  
  int _dotCount = 0;
  Timer? _dotTimer;

  late String _targetMode; 

  // Global Sender Variables
  List<String> _globalSenders = [];
  bool _isLoadingSenders = false;
  bool _isGlobalEnabled = true; 
  int _privateSenderCount = 0;
  int _globalSenderCount = 0;
  
  // Server Quota Variables
  int _globalDailyLimit = 0;
  int _globalDailyUsed = 0;
  String? _globalResetTime;
  bool _isLoadingQuota = false;
  
  bool _loadingSender = false;
  Timer? _senderTimer;

  String _selectedSender = 'private';

  bool get canAccessGlobalSender {
    final r = widget.role.toLowerCase();
    return ['owner', 'developer', 'fullup', 'reseller'].contains(r);
  }

  static const _groupBugIds = {'android_group', 'lock_group', 'roid_group', 'crash_group'};
  static const _globalAllowedIds = ['delayinvis', 'fclik', 'hard_xx'];

  List<Map<String, dynamic>> get _activeBugList {
    if (_targetMode == 'bug_gb') {
      final fromGb = widget.listBugGb;
      if (fromGb.isNotEmpty) return List<Map<String, dynamic>>.from(fromGb);
      return widget.listBug.where((b) => _groupBugIds.contains((b['bug_id'] ?? '').toString())).toList();
    }
    final privateList = widget.listBug.where((b) => !_groupBugIds.contains((b['bug_id'] ?? '').toString())).toList();
    if (_selectedSender == 'global') {
      final top3 = privateList.where((b) => _globalAllowedIds.contains((b['bug_id'] ?? '').toString())).toList();
      if (top3.isNotEmpty) return top3;
      return privateList.take(3).toList();
    }
    return privateList;
  }

  void _resetBugSelection() {
    final list = _activeBugList;
    if (list.isNotEmpty) {
      _selectedBugId = list[0]['bug_id']?.toString() ?? '0';
    } else {
      _selectedBugId = null;
    }
  }

  @override
  void initState() {
    super.initState();
    _targetMode = widget.initialTargetMode == 'bug_gb' ? 'bug_gb' : 'bug_no';

    _pulseController = AnimationController(vsync: this, duration: const Duration(milliseconds: 1500))..repeat(reverse: true);
    _resultCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 450));
    
    _resultFade = CurvedAnimation(parent: _resultCtrl, curve: Curves.easeOut);
    _resultSlide = Tween<Offset>(begin: const Offset(0, 0.12), end: Offset.zero)
        .animate(CurvedAnimation(parent: _resultCtrl, curve: Curves.easeOutCubic));

    _fetchSenderStats();
    _fetchGlobalQuota();
    _fetchGlobalStatus();
    
    _senderTimer = Timer.periodic(const Duration(seconds: 30), (_) {
      _fetchSenderStats();
      if (_selectedSender == 'global') _fetchGlobalQuota();
    });

    _resetBugSelection();
    targetController.addListener(() { if (mounted) setState(() {}); });
    _startDotTimer();
  }

  @override
  void dispose() {
    _pulseController.dispose();
    _resultCtrl.dispose();
    targetController.dispose();
    _senderTimer?.cancel();
    _dotTimer?.cancel();
    super.dispose();
  }

  void _startDotTimer() {
    _dotTimer?.cancel();
    _dotTimer = Timer.periodic(const Duration(milliseconds: 400), (timer) {
      if (mounted) setState(() => _dotCount = (_dotCount + 1) % 4);
    });
  }

  String _getDots() => '.' * _dotCount;

  Future<void> _fetchSenderStats() async {
    if (_loadingSender) return;
    setState(() => _loadingSender = true);
    try {
      final response = await http.get(Uri.parse("$baseUrl/getSenderStats?key=${widget.sessionKey}")).timeout(const Duration(seconds: 10));
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true) {
          setState(() {
            _privateSenderCount = data['private'] ?? 0;
            _globalSenderCount = data['global'] ?? 0;
            _loadingSender = false;
          });
        } else {
          setState(() => _loadingSender = false);
        }
      } else {
        setState(() => _loadingSender = false);
      }
    } catch (_) {
      setState(() => _loadingSender = false);
    }
  }

  Future<void> _fetchGlobalQuota() async {
    setState(() => _isLoadingQuota = true);
    try {
      final res = await http.get(Uri.parse('$baseUrl/getGlobalQuota?key=${widget.sessionKey}')).timeout(const Duration(seconds: 10));
      final data = jsonDecode(res.body);
      if (data['valid'] == true && mounted) {
        setState(() {
          _globalDailyLimit = data['limit'] ?? 0;
          _globalDailyUsed = data['used'] ?? 0;
          _globalSenders = List<String>.from(data['senders'] ?? []);
          _globalResetTime = data['resetTime'];
          _globalSenderCount = _globalSenders.length;
        });
      }
    } catch (_) {
      // ignore
    } finally {
      if (mounted) setState(() => _isLoadingQuota = false);
    }
  }

  Future<void> _fetchGlobalStatus() async {
    try {
      final res = await http.get(Uri.parse('$baseUrl/globalStatus'));
      final data = jsonDecode(res.body);
      if (mounted) {
        setState(() {
          _isGlobalEnabled = data['enabled'] ?? true;
          if (!_isGlobalEnabled && _selectedSender == 'global') {
            _selectedSender = 'private';
            _resetBugSelection();
          }
        });
      }
    } catch (_) {}
  }

  String? formatPhoneNumber(String input) {
    final cleaned = input.replaceAll(RegExp(r'[^\d+]'), '');
    if (!cleaned.startsWith('+') || cleaned.length < 8) return null;
    return cleaned;
  }

  bool _isValidGroupTarget(String input) {
    final groupLink = RegExp(r'chat\.whatsapp\.com/[A-Za-z0-9]+');
    final groupJid = RegExp(r'@.g\.us$|@g\.us$');
    return groupLink.hasMatch(input) || groupJid.hasMatch(input);
  }

  void _setResponse(String type, String msg) {
    if (!mounted) return;
    setState(() => _responseMessage = '$type|$msg');
    _resultCtrl.forward(from: 0);
  }

  void _showSuccessPopup(String target, String senderType) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => _SuccessDialog(
        target: target,
        senderType: senderType,
        onDismiss: () => Navigator.of(context).pop(),
      ),
    );
  }

  Future<void> _sendBug() async {
    final rawInput = targetController.text.trim();
    final key = widget.sessionKey;
    
    if (_targetMode == 'bug_no') {
      if (formatPhoneNumber(rawInput) == null) {
        _showAlert("❌ Nomor Tidak Valid", "Gunakan format internasional.\nContoh: +62812xxxxxxxx");
        return;
      }
    } else {
      if (rawInput.isEmpty || !_isValidGroupTarget(rawInput)) {
        _showAlert("❌ Link Group Tidak Valid", "Masukkan link undangan group WhatsApp.");
        return;
      }
    }

    if (_selectedSender == 'global' && !canAccessGlobalSender) {
      _showAlert("❌ Akses Ditolak", "Sender Global hanya untuk mem ke atas!");
      return;
    }

    if (_selectedBugId == null || _selectedBugId!.isEmpty) {
      _showAlert("❌ No Bug Selected", "Pilih 1 bug untuk dikirim.");
      return;
    }

    if (_selectedSender == 'private' && _privateSenderCount == 0) {
      _showAlert("❌ No Private Sender", "Tidak ada private sender tersedia.");
      return;
    }
    if (_selectedSender == 'global' && _globalSenderCount == 0) {
      _showAlert("❌ No Global Sender", "Tidak ada global sender tersedia.");
      return;
    }
    
    // Cek Limit Global
    if (_selectedSender == 'global' && _globalDailyLimit < 9999) {
      if (_globalDailyUsed >= _globalDailyLimit) {
        _showAlert("❌ Limit Global Habis", "Sisa kirim global hari ini: 0 / $_globalDailyLimit\nCoba lagi besok.");
        return;
      }
    }

    setState(() {
      _isSending = true;
      _responseMessage = null;
    });
    _resultCtrl.reset();
    
    await showBugCountdown(context);

    try {
      final encodedTarget = Uri.encodeComponent(rawInput);
      
      final res = await http.get(Uri.parse(
        '$baseUrl/sendBug?key=$key&target=$encodedTarget&bug=${_selectedBugId}&bug_id=${_selectedBugId}&case=$_targetMode${_selectedSender == 'global' ? '&senderMode=global' : '&sender=private'}',
      )).timeout(const Duration(seconds: 15));
      
      final data = jsonDecode(res.body);

      if (data['valid'] == false) {
        _setResponse('error', 'Session key tidak valid. Silakan login ulang.');
      } else if (data['cooldown'] == true) {
        final wait = data['wait'] ?? 0;
        _setResponse('warning', 'Cooldown aktif! Tunggu $wait detik lagi.');
      } else if (data['sended'] == true) {
        final role = data['role'] ?? widget.role;
        
        // ✨ UPDATE ANGKA DARI SERVER SECARA INSTAN (ANTI NYANGKUT) ✨
        if (_selectedSender == 'global') {
          setState(() {
            _globalDailyUsed = data['globalUsed'] ?? (_globalDailyUsed + 1);
            _globalDailyLimit = data['globalLimit'] ?? _globalDailyLimit;
          });
          Future.delayed(const Duration(seconds: 1), () {
            if (mounted) _fetchGlobalQuota();
          });
        }
        
        _showSuccessPopup(rawInput, _selectedSender);
        targetController.clear();
        _setResponse('success', 'Bug berhasil dikirim ke $rawInput! [$role]');
      } else {
        _setResponse('error', data['message'] ?? 'Gagal mengirim. Server sedang maintenance.');
      }
    } on Exception catch (e) {
      if (e.toString().contains('TimeoutException')) {
        _setResponse('error', 'Request timeout. Periksa koneksi internet.');
      } else {
        _setResponse('error', 'Koneksi error. Periksa jaringan dan coba lagi.');
      }
    } finally {
      if (mounted) setState(() => _isSending = false);
    }
  }

  void _showAlert(String title, String msg) {
    showDialog(
      context: context,
      builder: (_) => BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
        child: AlertDialog(
          backgroundColor: cCard.withOpacity(0.9),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(24),
            side: BorderSide(color: cAccent, width: 1.5),
          ),
          title: Text(title, style: TextStyle(color: cAccentLight, fontFamily: 'Pek', fontWeight: FontWeight.bold)),
          content: Text(msg, style: TextStyle(color: cTextSub)),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text("OK", style: TextStyle(color: cAccent, fontWeight: FontWeight.bold)),
            ),
          ],
        ),
      ),
    );
  }

  Widget _glassCard({
    required Widget child,
    EdgeInsets padding = const EdgeInsets.all(16),
    BorderRadius? borderRadius,
    Color? borderColor,
    double blurSigma = 20,
  }) {
    final br = borderRadius ?? BorderRadius.circular(24);
    return ClipRRect(
      borderRadius: br,
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: blurSigma, sigmaY: blurSigma),
        child: Container(
          padding: padding,
          decoration: BoxDecoration(
            color: cCard.withOpacity(0.4), // Glass effect transparan
            borderRadius: br,
            border: Border.all(color: borderColor ?? cBorder, width: 1.5),
            boxShadow: [
              BoxShadow(color: Colors.black.withOpacity(0.2), blurRadius: 20, offset: const Offset(0, 8)),
            ],
          ),
          child: child,
        ),
      ),
    );
  }

  Widget _buildTopAppBar() {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 8, 16, 8),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: cCard.withOpacity(0.6),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: cBorder),
      ),
      child: Row(
        children: [
          Container(
            width: 38, height: 38,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: cAccent.withOpacity(0.2),
              border: Border.all(color: cAccent, width: 1.5),
            ),
            child: Icon(Icons.shield_rounded, color: cAccent, size: 20),
          ),
          const SizedBox(width: 12),
          Text(
            'NOVARCH BUG',
            style: TextStyle(color: cText, fontFamily: 'ARABOLIC', fontWeight: FontWeight.w900, fontSize: 18, letterSpacing: 2),
          ),
          const Spacer(),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: cAccentLight, width: 1.5),
              color: cAccentLight.withOpacity(0.1),
            ),
            child: Text(
              'V.1',
              style: TextStyle(color: cAccentLight, fontFamily: 'ARABOLIC', fontWeight: FontWeight.bold, fontSize: 12),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: cBorder, width: 1.5),
        boxShadow: [BoxShadow(color: cAccent.withOpacity(0.2), blurRadius: 20, offset: const Offset(0, 8))],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(22),
        child: SizedBox(
          height: 180,
          width: double.infinity,
          child: Stack(
            fit: StackFit.expand,
            children: [
              // Menggunakan background image dari assets
              Image.asset(
                'assets/images/home.jpg',
                fit: BoxFit.cover,
                errorBuilder: (context, error, stackTrace) => Container(color: cBg),
              ),
              Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [cAccent.withOpacity(0.3), cBg.withOpacity(0.9)],
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    Row(
                      children: [
                        Container(
                          width: 50, height: 50,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(color: cAccentLight, width: 2),
                          ),
                          child: ClipOval(
                            child: Image.asset(
                              'assets/images/logo.png',
                              fit: BoxFit.cover,
                              errorBuilder: (_, __, ___) => Icon(Icons.person, color: cAccentLight, size: 26),
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                widget.username.toUpperCase(),
                                style: TextStyle(color: cText, fontFamily: 'Pek', fontWeight: FontWeight.w900, fontSize: 16, letterSpacing: 1),
                              ),
                              const SizedBox(height: 2),
                              Text(
                                widget.role.toUpperCase(),
                                style: TextStyle(color: cAccent, fontFamily: 'Pek', fontWeight: FontWeight.bold, fontSize: 11, letterSpacing: 1.5),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                          decoration: BoxDecoration(
                            color: cBg.withOpacity(0.6),
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(color: cBorder),
                          ),
                          child: Row(
                            children: [
                              Icon(Icons.access_time_rounded, color: cTextSub, size: 12),
                              const SizedBox(width: 4),
                              Text(
                                widget.expiredDate,
                                style: TextStyle(color: cText, fontFamily: 'Pek', fontSize: 10),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const Spacer(),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        _buildStatItem(Icons.bug_report_rounded, cAccent, '${_activeBugList.length}', 'Total Bugs'),
                        Container(width: 1, height: 40, color: cBorder),
                        _buildStatItem(Icons.bolt_rounded, cAccentLight, 'GACOR', 'Success Rate'),
                        Container(width: 1, height: 40, color: cBorder),
                        _buildStatItem(Icons.check_circle_rounded, Colors.greenAccent, 'ACTIVE', 'Status'),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStatItem(IconData icon, Color color, String value, String label) {
    return Column(
      children: [
        Container(
          width: 40, height: 40,
          decoration: BoxDecoration(shape: BoxShape.circle, color: color.withOpacity(0.15)),
          child: Icon(icon, color: color, size: 20),
        ),
        const SizedBox(height: 6),
        Text(value, style: TextStyle(color: color, fontWeight: FontWeight.w900, fontSize: 13, fontFamily: 'Pek')),
        const SizedBox(height: 2),
        Text(label, style: TextStyle(color: cTextSub, fontSize: 9, fontFamily: 'Pek')),
      ],
    );
  }

  Widget _buildSelectBugPanel() {
    final isGroup = _targetMode == 'bug_gb';
    final privOn = _privateSenderCount > 0;
    final globOn = _globalSenderCount > 0;

    return _glassCard(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 32, height: 32,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: cAccent.withOpacity(0.2),
                  border: Border.all(color: cAccent, width: 1.5),
                ),
                child: Icon(isGroup ? Icons.groups_rounded : Icons.phone_android_rounded, color: cAccent, size: 16),
              ),
              const SizedBox(width: 10),
              Text(
                isGroup ? 'LINK GROUP' : 'NOMOR TARGET',
                style: TextStyle(color: cText, fontFamily: 'Pek', fontWeight: FontWeight.bold, fontSize: 13, letterSpacing: 1.2),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Container(
            height: 50,
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.3),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: cBorder, width: 1.5),
            ),
            child: Row(
              children: [
                const SizedBox(width: 12),
                Icon(isGroup ? Icons.link_rounded : Icons.public, color: cTextSub, size: 18),
                const SizedBox(width: 8),
                Expanded(
                  child: TextField(
                    controller: targetController,
                    style: TextStyle(color: cText, fontFamily: 'Pek', fontSize: 14),
                    cursorColor: cAccent,
                    keyboardType: isGroup ? TextInputType.url : TextInputType.phone,
                    decoration: InputDecoration(
                      isDense: true,
                      border: InputBorder.none,
                      hintText: isGroup ? 'https://chat.whatsapp.com/xxxxx' : '+62xxxxxxxxxxx',
                      hintStyle: TextStyle(color: cTextSub.withOpacity(0.4), fontFamily: 'Pek', fontSize: 13),
                      contentPadding: const EdgeInsets.symmetric(vertical: 14),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(right: 6),
                  child: Material(
                    color: cAccent,
                    borderRadius: BorderRadius.circular(10),
                    child: InkWell(
                      borderRadius: BorderRadius.circular(10),
                      onTap: () async {
                        final data = await Clipboard.getData(Clipboard.kTextPlain);
                        final text = data?.text?.trim() ?? '';
                        if (text.isEmpty) return;
                        targetController.text = text;
                        setState(() {});
                      },
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                        child: Text('PASTE', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 10)),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          Row(
            children: [
              Container(
                width: 32, height: 32,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: cAccentLight.withOpacity(0.2),
                  border: Border.all(color: cAccentLight, width: 1.5),
                ),
                child: Icon(Icons.bug_report, color: cAccentLight, size: 16),
              ),
              const SizedBox(width: 10),
              Text(
                'PILIH BUG',
                style: TextStyle(color: cText, fontFamily: 'Pek', fontWeight: FontWeight.bold, fontSize: 13, letterSpacing: 1.2),
              ),
              const Spacer(),
              _senderStatusChip('Pribadi', privOn),
              if (_targetMode != 'bug_gb') ...[
                const SizedBox(width: 6),
                _senderStatusChip('Global', globOn),
              ],
            ],
          ),
          const SizedBox(height: 12),
          SizedBox(
            height: 130,
            child: _activeBugList.isEmpty
                ? Center(child: Text('Tidak ada bug', style: TextStyle(color: cTextSub, fontSize: 12)))
                : ListView.builder(
                    scrollDirection: Axis.horizontal,
                    physics: const BouncingScrollPhysics(),
                    itemCount: _activeBugList.length,
                    itemBuilder: (context, index) {
                      final bug = _activeBugList[index];
                      final bugId = bug['bug_id'] as String? ?? '$index';
                      final isSelected = _selectedBugId == bugId;
                      final name = (bug['bug_name'] as String? ?? 'BUG').toUpperCase();
                      
                      return GestureDetector(
                        onTap: () => setState(() { _selectedBugId = bugId; }),
                        child: AnimatedBuilder(
                          animation: _pulseController,
                          builder: (context, child) {
                            final floatY = isSelected ? (_pulseController.value - 0.5) * 6 : 0.0;
                            return Transform.translate(offset: Offset(0, floatY), child: child);
                          },
                          child: AnimatedContainer(
                            duration: const Duration(milliseconds: 250),
                            width: 170,
                            margin: EdgeInsets.only(right: 12, top: isSelected ? 4 : 8, bottom: isSelected ? 4 : 0),
                            padding: const EdgeInsets.all(14),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(18),
                              gradient: LinearGradient(
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                                colors: isSelected
                                    ? [cAccent, cAccent.withOpacity(0.6)]
                                    : [Colors.white.withOpacity(0.08), Colors.white.withOpacity(0.02)],
                              ),
                              border: Border.all(
                                color: isSelected ? cAccentLight : cBorder,
                                width: isSelected ? 2.0 : 1.2,
                              ),
                              boxShadow: isSelected
                                  ? [BoxShadow(color: cAccent.withOpacity(0.4), blurRadius: 15, spreadRadius: 2)]
                                  : [],
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Container(
                                      width: 34, height: 34,
                                      decoration: BoxDecoration(
                                        color: isSelected ? Colors.white.withOpacity(0.2) : Colors.black.withOpacity(0.3),
                                        borderRadius: BorderRadius.circular(10),
                                      ),
                                      child: Icon(Icons.bug_report_rounded, color: isSelected ? Colors.white : cAccent, size: 18),
                                    ),
                                    const Spacer(),
                                    AnimatedContainer(
                                      duration: const Duration(milliseconds: 200),
                                      width: isSelected ? 20 : 8,
                                      height: isSelected ? 20 : 8,
                                      decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        color: isSelected ? Colors.greenAccent : Colors.white24,
                                      ),
                                      child: isSelected ? const Icon(Icons.check, size: 12, color: Colors.black) : null,
                                    ),
                                  ],
                                ),
                                const Spacer(),
                                Text(
                                  name,
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                    color: isSelected ? Colors.white : cText,
                                    fontFamily: 'Pek',
                                    fontWeight: FontWeight.w900,
                                    fontSize: 11,
                                    height: 1.2,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  Widget _senderStatusChip(String label, bool on) {
    final c = on ? Colors.greenAccent : Colors.redAccent;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: c.withOpacity(0.12),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: c.withOpacity(0.4)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(FontAwesomeIcons.whatsapp, size: 10, color: c),
          const SizedBox(width: 4),
          Text('$label: ${on ? 'On' : 'Off'}', style: TextStyle(color: c, fontSize: 9, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }

  Widget _buildSenderPanel() {
    final isUnlimited = _globalDailyLimit >= 9999;
    final remaining = isUnlimited ? 9999 : math.max(0, _globalDailyLimit - _globalDailyUsed);
    final progress = isUnlimited ? 1.0 : (_globalDailyLimit > 0 ? (_globalDailyUsed / _globalDailyLimit).clamp(0.0, 1.0) : 0.0);
    
    String resetString = "Reset otomatis";
    if (_globalResetTime != null) {
      final dt = DateTime.parse(_globalResetTime!).toLocal();
      resetString = "Reset otomatis ${dt.day.toString().padLeft(2, '0')}/${dt.month.toString().padLeft(2, '0')} ${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')} WIB";
    }

    return _glassCard(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.swap_horiz_rounded, color: cAccentLight, size: 22),
              const SizedBox(width: 8),
              Text(
                'PILIH SENDER',
                style: TextStyle(color: cText, fontFamily: 'Pek', fontWeight: FontWeight.bold, fontSize: 14, letterSpacing: 1),
              ),
              const Spacer(),
              GestureDetector(
                onTap: () {
                  _fetchSenderStats();
                  _fetchGlobalQuota();
                },
                child: Container(
                  width: 32, height: 32,
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: cBorder),
                  ),
                  child: (_isLoadingSenders || _loadingSender)
                      ? Padding(padding: const EdgeInsets.all(8), child: CircularProgressIndicator(strokeWidth: 2, color: cAccent))
                      : Icon(Icons.refresh_rounded, color: cAccentLight, size: 16),
                ),
              ),
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.greenAccent.withOpacity(0.5)),
                  color: Colors.greenAccent.withOpacity(0.1),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(width: 6, height: 6, decoration: const BoxDecoration(color: Colors.greenAccent, shape: BoxShape.circle)),
                    const SizedBox(width: 6),
                    Text(
                      '${_privateSenderCount + _globalSenderCount} sender online',
                      style: TextStyle(color: Colors.greenAccent, fontFamily: 'Pek', fontSize: 11),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),

          Row(
            children: [
              // Pribadi
              Expanded(
                child: GestureDetector(
                  onTap: () => setState(() { _selectedSender = 'private'; _resetBugSelection(); }),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    height: 100,
                    decoration: BoxDecoration(
                      color: _selectedSender == 'private' ? cAccent.withOpacity(0.8) : Colors.black.withOpacity(0.3),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                        color: _selectedSender == 'private' ? cAccentLight : cBorder,
                        width: 2.0,
                      ),
                      boxShadow: _selectedSender == 'private' ? [BoxShadow(color: cAccent.withOpacity(0.4), blurRadius: 15)] : [],
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.person_rounded, color: _selectedSender == 'private' ? Colors.white : cTextSub, size: 28),
                        const SizedBox(height: 8),
                        Text(
                          'Pribadi',
                          style: TextStyle(
                            color: _selectedSender == 'private' ? Colors.white : cTextSub,
                            fontFamily: 'Pek',
                            fontWeight: FontWeight.bold,
                            fontSize: 13,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          _privateSenderCount == 0 ? 'Offline' : '$_privateSenderCount sender',
                          style: TextStyle(
                            color: _selectedSender == 'private' ? Colors.white70 : (_privateSenderCount == 0 ? Colors.redAccent : cAccentLight),
                            fontFamily: 'Pek',
                            fontSize: 11,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              // Global
              Expanded(
                child: GestureDetector(
                  onTap: () {
                    if (!_isGlobalEnabled) {
                      _showAlert('❌ Global Offline', 'Sender global sedang dimatikan oleh Admin.');
                      return;
                    }
                    if (!canAccessGlobalSender) {
                      _showAlert('❌ Akses Ditolak', 'Sender Global hanya untuk Vip ke atas!');
                      return;
                    }
                    setState(() { _selectedSender = 'global'; _resetBugSelection(); });
                    _fetchGlobalQuota();
                  },
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    height: 100,
                    decoration: BoxDecoration(
                      color: _selectedSender == 'global' && _isGlobalEnabled ? cAccent.withOpacity(0.8) : Colors.black.withOpacity(0.3),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                        color: _selectedSender == 'global' && _isGlobalEnabled ? cAccentLight : cBorder,
                        width: 2.0,
                      ),
                      boxShadow: _selectedSender == 'global' && _isGlobalEnabled ? [BoxShadow(color: cAccent.withOpacity(0.4), blurRadius: 15)] : [],
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.public_rounded, color: _selectedSender == 'global' && _isGlobalEnabled ? Colors.white : cTextSub, size: 28),
                        const SizedBox(height: 8),
                        Text(
                          'Global',
                          style: TextStyle(
                            color: _selectedSender == 'global' && _isGlobalEnabled ? Colors.white : cTextSub,
                            fontFamily: 'Pek',
                            fontWeight: FontWeight.bold,
                            fontSize: 13,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          !_isGlobalEnabled ? 'OFFLINE' : (_globalSenderCount == 0 ? 'Offline' : '$_globalSenderCount sender'),
                          style: TextStyle(
                            color: _selectedSender == 'global' && _isGlobalEnabled ? Colors.white70 : (!_isGlobalEnabled ? Colors.redAccent : cAccentLight),
                            fontFamily: 'Pek',
                            fontSize: 11,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),

          const SizedBox(height: 16),

          // QUOTA UI
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.4),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: cBorder),
            ),
            child: Column(
              children: [
                Row(
                  children: [
                    Icon(Icons.data_usage_rounded, color: cAccent, size: 18),
                    const SizedBox(width: 8),
                    Text(
                      'KUOTA GLOBAL SENDER - HARI INI',
                      style: TextStyle(color: cText, fontFamily: 'Pek', fontWeight: FontWeight.bold, fontSize: 12, letterSpacing: 0.5),
                    ),
                    const Spacer(),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                      decoration: BoxDecoration(
                        color: (isUnlimited || remaining > 0) ? Colors.greenAccent.withOpacity(0.15) : Colors.redAccent.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: (isUnlimited || remaining > 0) ? Colors.greenAccent.withOpacity(0.5) : Colors.redAccent.withOpacity(0.5)),
                      ),
                      child: Text(
                        (isUnlimited || remaining > 0) ? 'TERSEDIA' : 'HABIS',
                        style: TextStyle(
                          color: (isUnlimited || remaining > 0) ? Colors.greenAccent : Colors.redAccent,
                          fontSize: 9,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    _buildQuotaCol('Total Limit', isUnlimited ? '∞' : '$_globalDailyLimit'),
                    Container(width: 1, height: 30, color: cBorder),
                    _buildQuotaCol('Terpakai', '$_globalDailyUsed'),
                    Container(width: 1, height: 30, color: cBorder),
                    _buildQuotaCol('Sisa Kuota', isUnlimited ? '∞' : '$remaining'),
                  ],
                ),
                const SizedBox(height: 12),
                ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: LinearProgressIndicator(
                    value: isUnlimited ? 1.0 : progress,
                    backgroundColor: Colors.white.withOpacity(0.1),
                    valueColor: AlwaysStoppedAnimation<Color>((isUnlimited || remaining > 0) ? cAccent : Colors.redAccent),
                    minHeight: 6,
                  ),
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Icon(Icons.access_time, color: cTextSub, size: 12),
                    const SizedBox(width: 6),
                    Text(
                      resetString,
                      style: TextStyle(color: cTextSub, fontSize: 10, fontFamily: 'Pek'),
                    ),
                  ],
                ),
              ],
            ),
          ),

          const SizedBox(height: 16),

          if (_targetMode != 'bug_gb') ...[
            Row(
              children: [
                Icon(Icons.list_alt_rounded, color: cAccentLight, size: 16),
                const SizedBox(width: 8),
                Text(
                  '${_globalSenders.length} sender aktif',
                  style: TextStyle(color: cText, fontSize: 12, fontFamily: 'Pek'),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Container(
              constraints: const BoxConstraints(maxHeight: 120),
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(0.2),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: cBorder),
              ),
              child: _globalSenders.isEmpty
                  ? Padding(
                      padding: const EdgeInsets.all(12),
                      child: Text('Belum ada sender aktif', style: TextStyle(color: cTextSub, fontSize: 11)),
                    )
                  : ListView.builder(
                      shrinkWrap: true,
                      padding: const EdgeInsets.all(10),
                      itemCount: _globalSenders.length,
                      itemBuilder: (context, index) {
                        final senderNum = _globalSenders[index].replaceAll('@s.whatsapp.net', '');
                        return Padding(
                          padding: const EdgeInsets.only(bottom: 6),
                          child: Row(
                            children: [
                              Container(width: 6, height: 6, decoration: const BoxDecoration(color: Colors.greenAccent, shape: BoxShape.circle)),
                              const SizedBox(width: 8),
                              Text(
                                senderNum,
                                style: TextStyle(color: cAccentLight, fontSize: 12, fontFamily: 'Pek'),
                              ),
                            ],
                          ),
                        );
                      },
                    ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildQuotaCol(String label, String value) {
    return Column(
      children: [
        Text(
          value,
          style: TextStyle(color: cText, fontFamily: 'Pek', fontWeight: FontWeight.w900, fontSize: 18),
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: TextStyle(color: cTextSub, fontSize: 10, fontFamily: 'Pek'),
        ),
      ],
    );
  }

  Widget _buildSendButton() {
    return AnimatedBuilder(
      animation: _isSending ? const AlwaysStoppedAnimation(1.0) : _pulseController,
      builder: (context, child) {
        return Container(
          height: 62,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            gradient: LinearGradient(
              colors: _isSending
                  ? [cAccent.withOpacity(0.5), cAccentLight.withOpacity(0.5)]
                  : [cAccent, cAccentLight],
              begin: Alignment.centerLeft,
              end: Alignment.centerRight,
            ),
            boxShadow: _isSending
                ? []
                : [
                    BoxShadow(
                      color: cAccent.withOpacity(0.3 + _pulseController.value * 0.3),
                      blurRadius: 20 + _pulseController.value * 10,
                      spreadRadius: 1,
                    ),
                  ],
          ),
          child: ElevatedButton(
            onPressed: _isSending ? null : _sendBug,
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.transparent,
              shadowColor: Colors.transparent,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
              elevation: 0,
            ),
            child: _isSending
                ? Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const SizedBox(width: 24, height: 24, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 3)),
                      const SizedBox(width: 16),
                      Text('MENGIRIM BUG$_getDots()', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 14, fontFamily: 'Pek', letterSpacing: 2)),
                    ],
                  )
                : Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.rocket_launch_rounded, color: Colors.white, size: 22),
                      const SizedBox(width: 10),
                      Text('SEND BUG', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 16, fontFamily: 'Pek', letterSpacing: 2)),
                    ],
                  ),
          ),
        );
      },
    );
  }

  Widget _buildResponseMessage() {
    if (_responseMessage == null) return const SizedBox.shrink();

    final parts = _responseMessage!.split('|');
    final type = parts[0];
    final msg = parts.length > 1 ? parts[1] : '';

    Color color;
    IconData icon;
    String title;
    switch (type) {
      case 'success': color = Colors.greenAccent; icon = Icons.check_circle_outline; title = 'Berhasil'; break;
      case 'warning': color = Colors.amberAccent; icon = Icons.warning_rounded; title = 'Peringatan'; break;
      default: color = Colors.redAccent; icon = Icons.error_outline; title = 'Gagal';
    }

    return FadeTransition(
      opacity: _resultFade,
      child: SlideTransition(
        position: _resultSlide,
        child: _glassCard(
          borderColor: color.withOpacity(0.5),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 32, height: 32,
                decoration: BoxDecoration(shape: BoxShape.circle, color: color.withOpacity(0.15)),
                child: Icon(icon, color: color, size: 18),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, style: TextStyle(color: color, fontFamily: 'Pek', fontSize: 13, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 3),
                    Text(msg, style: TextStyle(color: cTextSub, fontFamily: 'Pek', fontSize: 12)),
                  ],
                ),
              ),
              GestureDetector(
                onTap: () { setState(() => _responseMessage = null); _resultCtrl.reset(); },
                child: Icon(Icons.close_rounded, color: cTextSub, size: 16),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // ── MEMBUNGKUS DENGAN VALUE LISTENABLE BUILDER AGAR SUPPORT THEME ──
    return ValueListenableBuilder<AppThemeMode>(
      valueListenable: ThemeModeManager.current,
      builder: (context, _, __) {
        return Scaffold(
          // ✅ BACKGROUND UTAMA: Scaffold transparan agar image di Stack tampil full
          backgroundColor: cBg,
          body: Stack(
            children: [
              // ✅ 1. BACKGROUND IMAGE (homee.jpg) — full screen di belakang
              Positioned.fill(
                child: Image.asset(
                  'assets/images/homee.jpg',
                  fit: BoxFit.cover,
                  width: double.infinity,
                  height: double.infinity,
                  alignment: Alignment.center,
                  errorBuilder: (context, error, stackTrace) => Container(color: cBg),
                ),
              ),

              // ✅ 2. GRADIENT OVERLAY — lebih ringan agar image tetap terlihat
              Positioned.fill(
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        cBg.withOpacity(0.35),  // atas lebih terang (image terlihat)
                        cBg.withOpacity(0.60),  // tengah sedang
                        cBg.withOpacity(0.85),  // bawah lebih gelap (teks tombol jelas)
                      ],
                      stops: const [0.0, 0.5, 1.0],
                    ),
                  ),
                ),
              ),

              // ✅ 3. ORNAMEN CAHAYA (glow accent)
              Positioned(
                top: -100, right: -50,
                child: Container(
                  width: 300, height: 300,
                  decoration: BoxDecoration(shape: BoxShape.circle, color: cAccent.withOpacity(0.18)),
                  child: BackdropFilter(filter: ImageFilter.blur(sigmaX: 80, sigmaY: 80), child: Container()),
                ),
              ),
              Positioned(
                bottom: -120, left: -80,
                child: Container(
                  width: 260, height: 260,
                  decoration: BoxDecoration(shape: BoxShape.circle, color: cAccentLight.withOpacity(0.10)),
                  child: BackdropFilter(filter: ImageFilter.blur(sigmaX: 70, sigmaY: 70), child: Container()),
                ),
              ),

              // ✅ 4. CONTENT
              SafeArea(
                child: Column(
                  children: [
                    _buildTopAppBar(),
                    Expanded(
                      child: SingleChildScrollView(
                        physics: const BouncingScrollPhysics(),
                        padding: const EdgeInsets.only(bottom: 24),
                        child: Column(
                          children: [
                            _buildHeader(),
                            const SizedBox(height: 16),
                            Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 16),
                              child: Column(
                                children: [
                                  _buildSelectBugPanel(),
                                  const SizedBox(height: 16),
                                  _buildSenderPanel(),
                                  const SizedBox(height: 20),
                                  _buildSendButton(),
                                  _buildResponseMessage(),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

// ── DIALOGS ──

class _SuccessDialog extends StatefulWidget {
  final String target;
  final String senderType;
  final VoidCallback onDismiss;

  const _SuccessDialog({required this.target, required this.senderType, required this.onDismiss});

  @override
  State<_SuccessDialog> createState() => _SuccessDialogState();
}

class _SuccessDialogState extends State<_SuccessDialog> with TickerProviderStateMixin {
  late AnimationController _scaleController;
  late AnimationController _glowController;
  late Animation<double> _scaleAnimation;
  late Animation<double> _glowAnimation;

  @override
  void initState() {
    super.initState();
    _scaleController = AnimationController(vsync: this, duration: const Duration(milliseconds: 500));
    _glowController = AnimationController(vsync: this, duration: const Duration(milliseconds: 1500))..repeat(reverse: true);
    _scaleAnimation = Tween<double>(begin: 0.8, end: 1.0).animate(CurvedAnimation(parent: _scaleController, curve: Curves.elasticOut));
    _glowAnimation = Tween<double>(begin: 0.4, end: 1.0).animate(CurvedAnimation(parent: _glowController, curve: Curves.easeInOut));
    _scaleController.forward();
  }

  @override
  void dispose() {
    _scaleController.dispose();
    _glowController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isGlobal = widget.senderType.toLowerCase() == 'global';
    final primaryGlow = isGlobal ? const Color(0xFF00E5FF) : AppColors.accent;
    final secondaryGlow = isGlobal ? const Color(0xFF9D4EDD) : AppColors.accentLight;

    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.symmetric(horizontal: 20),
      child: ScaleTransition(
        scale: _scaleAnimation,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(28),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
            child: Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: AppColors.bg.withOpacity(0.85),
                borderRadius: BorderRadius.circular(28),
                border: Border.all(color: primaryGlow.withOpacity(0.5), width: 1.5),
                boxShadow: [BoxShadow(color: primaryGlow.withOpacity(0.2), blurRadius: 30, spreadRadius: 5)],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  AnimatedBuilder(
                    animation: _glowController,
                    builder: (context, _) {
                      return Container(
                        width: 80, height: 80,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: primaryGlow.withOpacity(0.15),
                          border: Border.all(color: primaryGlow, width: 2),
                          boxShadow: [BoxShadow(color: primaryGlow.withOpacity(0.3 * _glowAnimation.value), blurRadius: 25, spreadRadius: 5)],
                        ),
                        child: Icon(isGlobal ? Icons.public_rounded : Icons.security_rounded, color: Colors.white, size: 36),
                      );
                    },
                  ),
                  const SizedBox(height: 20),
                  Text(
                    isGlobal ? 'GLOBAL STRIKE!' : 'ATTACK SUCCESS',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 22,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Pek',
                      letterSpacing: 2,
                      shadows: [Shadow(color: primaryGlow.withOpacity(0.6), blurRadius: 12)],
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    'Payload delivered successfully',
                    style: TextStyle(color: Colors.white54, fontSize: 12, fontFamily: 'Pek'),
                  ),
                  const SizedBox(height: 24),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 12),
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.4),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: Colors.white.withOpacity(0.1)),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(isGlobal ? Icons.link_rounded : Icons.phone_android_rounded, color: primaryGlow, size: 20),
                        const SizedBox(width: 10),
                        Flexible(
                          child: Text(
                            widget.target,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w800, fontFamily: 'Pek'),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                    decoration: BoxDecoration(
                      color: primaryGlow.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: primaryGlow.withOpacity(0.3)),
                    ),
                    child: Text(
                      isGlobal ? 'SENDER GLOBAL' : 'SENDER PRIVATE',
                      style: TextStyle(color: primaryGlow, fontSize: 10, fontWeight: FontWeight.w900, fontFamily: 'Pek', letterSpacing: 1.5),
                    ),
                  ),
                  const SizedBox(height: 28),
                  GestureDetector(
                    onTap: widget.onDismiss,
                    child: Container(
                      width: double.infinity, height: 55,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(colors: [primaryGlow, secondaryGlow], begin: Alignment.centerLeft, end: Alignment.centerRight),
                        borderRadius: BorderRadius.circular(14),
                        boxShadow: [BoxShadow(color: primaryGlow.withOpacity(0.4), blurRadius: 20, offset: const Offset(0, 8))],
                      ),
                      child: Center(
                        child: Text(
                          'CLOSE',
                          style: TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w900, fontFamily: 'Pek', letterSpacing: 2),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ── COUNTDOWN SNIPER SCOPE ──

Future<void> showBugCountdown(BuildContext context) {
  return showGeneralDialog(
    context: context,
    barrierDismissible: false,
    barrierLabel: 'countdown',
    barrierColor: Colors.black.withOpacity(0.6),
    transitionDuration: const Duration(milliseconds: 320),
    pageBuilder: (_, __, ___) => const _BugCountdownDialog(),
    transitionBuilder: (_, anim, __, child) => FadeTransition(
      opacity: anim,
      child: ScaleTransition(
        scale: Tween<double>(begin: 0.85, end: 1.0).animate(CurvedAnimation(parent: anim, curve: Curves.easeOutBack)),
        child: child,
      ),
    ),
  );
}

class _BugCountdownDialog extends StatefulWidget {
  const _BugCountdownDialog();
  @override
  State<_BugCountdownDialog> createState() => _BugCountdownDialogState();
}

class _BugCountdownDialogState extends State<_BugCountdownDialog> with TickerProviderStateMixin {
  late AnimationController _rotCtrl;
  late AnimationController _pulseCtrl;
  late AnimationController _popCtrl;
  late Animation<double> _pop;
  int _count = 5;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _rotCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 2))..repeat();
    _pulseCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 600))..repeat(reverse: true);
    _popCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 400));
    _pop = Tween<double>(begin: 0.5, end: 1.0).animate(CurvedAnimation(parent: _popCtrl, curve: Curves.elasticOut));
    _popCtrl.forward();

    _timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) { t.cancel(); return; }
      setState(() => _count--);
      if (_count > 0) {
        _popCtrl.forward(from: 0);
      } else {
        t.cancel();
        Future.delayed(const Duration(milliseconds: 300), () { if (mounted) Navigator.of(context).pop(); });
      }
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    _rotCtrl.dispose();
    _pulseCtrl.dispose();
    _popCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    const Color scopeColor = Color(0xFF00FF41);
    const Color accentColor = Color(0xFFFF2D75);
    const Color bgCircle = Color(0xCC0A0A0F);

    return Material(
      type: MaterialType.transparency,
      child: Center(
        child: SizedBox(
          width: 280, height: 280,
          child: Stack(
            alignment: Alignment.center,
            clipBehavior: Clip.none,
            children: [
              AnimatedBuilder(
                animation: Listenable.merge([_rotCtrl, _pulseCtrl]),
                builder: (_, __) => CustomPaint(
                  size: const Size(280, 280),
                  painter: _SniperScopePainter(t: _rotCtrl.value, pulse: _pulseCtrl.value, scopeColor: scopeColor, accentColor: accentColor),
                ),
              ),
              AnimatedBuilder(
                animation: _pop,
                builder: (_, child) => Transform.scale(scale: _pop.value, child: child),
                child: Container(
                  width: 120, height: 120,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: bgCircle,
                    border: Border.all(color: scopeColor, width: 2),
                    boxShadow: [BoxShadow(color: scopeColor.withOpacity(0.3), blurRadius: 20, spreadRadius: 2)],
                  ),
                  child: Center(
                    child: Text(
                      _count > 0 ? '$_count' : '☠️',
                      style: TextStyle(
                        fontSize: _count > 0 ? 70 : 50,
                        height: 1.0,
                        fontWeight: FontWeight.w900,
                        fontFamily: 'Pek',
                        color: Colors.white,
                        shadows: [Shadow(color: scopeColor.withOpacity(0.8), blurRadius: 15)],
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                bottom: -20,
                child: Column(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                      decoration: BoxDecoration(
                        color: Colors.black.withOpacity(0.6),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: scopeColor.withOpacity(0.5), width: 1),
                      ),
                      child: Text(
                        _count > 0 ? 'LOCKING TARGET...' : 'PAYLOAD SENT!',
                        style: TextStyle(color: scopeColor, fontFamily: 'Pek', fontWeight: FontWeight.w900, fontSize: 12, letterSpacing: 2),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _SniperScopePainter extends CustomPainter {
  final double t;
  final double pulse;
  final Color scopeColor;
  final Color accentColor;

  _SniperScopePainter({required this.t, required this.pulse, required this.scopeColor, required this.accentColor});

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2 - 10;

    final linePaint = Paint()..color = scopeColor.withOpacity(0.6)..strokeWidth = 1.5..style = PaintingStyle.stroke;
    canvas.drawLine(Offset(center.dx - radius, center.dy), Offset(center.dx + radius, center.dy), linePaint);
    canvas.drawLine(Offset(center.dx, center.dy - radius), Offset(center.dx, center.dy + radius), linePaint);

    final outerRingPaint = Paint()..color = scopeColor..strokeWidth = 2..style = PaintingStyle.stroke;
    canvas.drawCircle(center, radius, outerRingPaint);

    final innerRingPaint = Paint()..color = scopeColor.withOpacity(0.5)..strokeWidth = 1..style = PaintingStyle.stroke;
    canvas.drawCircle(center, radius * 0.6, innerRingPaint);

    final scanPaint = Paint()..color = accentColor..strokeWidth = 3..style = PaintingStyle.stroke..strokeCap = StrokeCap.round;
    canvas.drawArc(Rect.fromCircle(center: center, radius: radius - 5), t * 2 * math.pi, 0.5, false, scanPaint);

    final bracketPaint = Paint()..color = accentColor..strokeWidth = 2..style = PaintingStyle.stroke..strokeCap = StrokeCap.square;
    const bLen = 20.0;
    final bGap = radius * 0.8;

    canvas.drawLine(Offset(center.dx - bGap, center.dy - bGap), Offset(center.dx - bGap + bLen, center.dy - bGap), bracketPaint);
    canvas.drawLine(Offset(center.dx - bGap, center.dy - bGap), Offset(center.dx - bGap, center.dy - bGap + bLen), bracketPaint);
    canvas.drawLine(Offset(center.dx + bGap, center.dy - bGap), Offset(center.dx + bGap - bLen, center.dy - bGap), bracketPaint);
    canvas.drawLine(Offset(center.dx + bGap, center.dy - bGap), Offset(center.dx + bGap, center.dy - bGap + bLen), bracketPaint);
    canvas.drawLine(Offset(center.dx - bGap, center.dy + bGap), Offset(center.dx - bGap + bLen, center.dy + bGap), bracketPaint);
    canvas.drawLine(Offset(center.dx - bGap, center.dy + bGap), Offset(center.dx - bGap, center.dy + bGap - bLen), bracketPaint);
    canvas.drawLine(Offset(center.dx + bGap, center.dy + bGap), Offset(center.dx + bGap - bLen, center.dy + bGap), bracketPaint);
    canvas.drawLine(Offset(center.dx + bGap, center.dy + bGap), Offset(center.dx + bGap, center.dy + bGap - bLen), bracketPaint);

    final tickPaint = Paint()..color = scopeColor.withOpacity(0.6)..strokeWidth = 1;
    for (int i = 0; i < 12; i++) {
      if (i % 3 == 0) continue;
      final angle = (i * 30) * math.pi / 180;
      final start = Offset(center.dx + (radius - 4) * math.cos(angle), center.dy + (radius - 4) * math.sin(angle));
      final end = Offset(center.dx + (radius - 12) * math.cos(angle), center.dy + (radius - 12) * math.sin(angle));
      canvas.drawLine(start, end, tickPaint);
    }

    final pulseRadius = 20.0 + (pulse * 10);
    canvas.drawCircle(center, pulseRadius, Paint()..color = accentColor.withOpacity(0.2 + pulse * 0.2)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 10));
  }

  @override
  bool shouldRepaint(covariant _SniperScopePainter oldDelegate) => oldDelegate.t != t || oldDelegate.pulse != pulse;
}