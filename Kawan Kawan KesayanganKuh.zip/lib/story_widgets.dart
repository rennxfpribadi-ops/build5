// story_widgets.dart
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:video_player/video_player.dart';

import 'theme.dart';

const String kFont = 'Pek';
const String baseUrl = 'http://cp.zyrostore.id:3448';

Color _onAccent() =>
    ThemeModeManager.isComic3d ? const Color(0xFF1A1A1A) : Colors.white;

// ═══════════════════════════════════════════════════════════════════════
//  MODEL
// ═══════════════════════════════════════════════════════════════════════
class StoryData {
  final String id;
  final String username;
  final String type;    // image / video / text
  final String content;
  final String? bgColor;
  int likes;
  int viewers;
  bool likedByMe;

  StoryData({
    required this.id,
    required this.username,
    required this.type,
    required this.content,
    this.bgColor,
    this.likes = 0,
    this.viewers = 0,
    this.likedByMe = false,
  });

  factory StoryData.fromJson(Map<String, dynamic> j) => StoryData(
        id: j['id']?.toString() ?? '',
        username: j['username']?.toString() ?? '',
        type: j['type']?.toString() ?? 'text',
        content: j['content']?.toString() ?? '',
        bgColor: j['bgColor']?.toString(),
        likes: (j['likes'] is int)
            ? j['likes']
            : int.tryParse(j['likes']?.toString() ?? '0') ?? 0,
        viewers: (j['viewers'] is int)
            ? j['viewers']
            : int.tryParse(j['viewers']?.toString() ?? '0') ?? 0,
        likedByMe: j['likedByMe'] == true,
      );

  String get fullUrl =>
      content.startsWith('http') ? content : '$baseUrl$content';
}

class StoryComment {
  final String id;
  final String username;
  final String text;
  final String? profileImage;
  final String createdAt;

  StoryComment({
    required this.id,
    required this.username,
    required this.text,
    this.profileImage,
    required this.createdAt,
  });

  factory StoryComment.fromJson(Map<String, dynamic> j) => StoryComment(
        id: j['id']?.toString() ?? '',
        username: j['username']?.toString() ?? '',
        text: j['text']?.toString() ?? '',
        profileImage: j['profile_image']?.toString(),
        createdAt: j['created_at']?.toString() ?? '',
      );
}

// ═══════════════════════════════════════════════════════════════════════
//  STORY BAR
// ═══════════════════════════════════════════════════════════════════════
class StoryBar extends StatefulWidget {
  final String sessionKey;
  final String username;

  const StoryBar({
    super.key,
    required this.sessionKey,
    required this.username,
  });

  @override
  State<StoryBar> createState() => _StoryBarState();
}

class _StoryBarState extends State<StoryBar> {
  List<StoryData> _myStories = [];
  List<StoryData> _otherStories = [];
  String? _myImage;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    _myImage = prefs.getString('profile_image_${widget.username}');

    try {
      final res = await http.get(
        Uri.parse('$baseUrl/story/list?key=${widget.sessionKey}'),
      ).timeout(const Duration(seconds: 10));
      final data = jsonDecode(res.body);

      if (data['success'] == true) {
        final allStories = (data['stories'] as List)
            .map((e) => StoryData.fromJson(Map<String, dynamic>.from(e)))
            .toList();

        final mine = allStories.where((s) => s.username == widget.username).toList();
        final others = allStories.where((s) => s.username != widget.username).toList();

        if (mounted) {
          setState(() {
            _myStories = mine;
            _otherStories = others;
            _loading = false;
          });
        }
        return;
      }
    } catch (e) {
      print('[STORY] Load error: $e');
    }

    if (mounted) setState(() => _loading = false);
  }

  void _onTapMy() {
    if (_myStories.isNotEmpty) {
      _openStoryViewer(_myStories, 0, true);
    } else {
      _showUploadSheet();
    }
  }

  void _showUploadSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (ctx) => _UploadOptionSheet(
        onPickImage: () {
          Navigator.pop(ctx);
          _pickMedia('image');
        },
        onPickVideo: () {
          Navigator.pop(ctx);
          _pickMedia('video');
        },
        onTextStory: () {
          Navigator.pop(ctx);
          _textStatus();
        },
      ),
    );
  }

  Future<void> _pickMedia(String type) async {
    try {
      final picker = ImagePicker();
      final picked = type == 'video'
          ? await picker.pickVideo(source: ImageSource.gallery)
          : await picker.pickImage(
              source: ImageSource.gallery, imageQuality: 85);

      if (picked == null) return;

      _showLoading('Mengupload...');

      final req = http.MultipartRequest(
        'POST',
        Uri.parse('$baseUrl/story/upload'),
      )
        ..fields['key'] = widget.sessionKey
        ..fields['username'] = widget.username
        ..fields['type'] = type
        ..files.add(await http.MultipartFile.fromPath('file', picked.path));

      final streamed = await req.send().timeout(const Duration(seconds: 60));
      final res = await http.Response.fromStream(streamed);
      final data = jsonDecode(res.body);

      if (!mounted) return;
      Navigator.pop(context);

      if (data['success'] == true) {
        _toast('Status diupload ✅', AppColors.green);
        await _load();
      } else {
        _toast(data['message'] ?? 'Gagal upload', AppColors.red);
      }
    } catch (e) {
      if (mounted) {
        Navigator.pop(context);
        _toast('Error: $e', AppColors.red);
      }
    }
  }

  void _textStatus() {
    final ctrl = TextEditingController();
    Color bg = const Color(0xFF7B1FA2);

    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.85),
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setD) => Dialog(
          backgroundColor: Colors.transparent,
          insetPadding: const EdgeInsets.all(20),
          child: Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: bg,
              borderRadius: BorderRadius.circular(20),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  height: 180,
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(14),
                  ),
                  alignment: Alignment.center,
                  child: TextField(
                    controller: ctrl,
                    maxLines: 5,
                    maxLength: 200,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.w600,
                      fontFamily: kFont,
                    ),
                    decoration: const InputDecoration(
                      border: InputBorder.none,
                      hintText: 'Tulis status kamu...',
                      hintStyle: TextStyle(
                          color: Colors.white54, fontFamily: kFont),
                      counterStyle: TextStyle(color: Colors.white54),
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                SizedBox(
                  height: 38,
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    children: [
                      const Color(0xFF7B1FA2),
                      const Color(0xFFC2185B),
                      const Color(0xFF1976D2),
                      const Color(0xFF00796B),
                      const Color(0xFFF57C00),
                      const Color(0xFFE64A19),
                      const Color(0xFF303F9F),
                      const Color(0xFF000000),
                    ].map((c) {
                      final sel = c.value == bg.value;
                      return GestureDetector(
                        onTap: () => setD(() => bg = c),
                        child: Container(
                          margin: const EdgeInsets.symmetric(horizontal: 4),
                          width: 34, height: 34,
                          decoration: BoxDecoration(
                            color: c,
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: sel ? Colors.white : Colors.white24,
                              width: sel ? 3 : 1,
                            ),
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: GestureDetector(
                        onTap: () => Navigator.pop(ctx),
                        child: Container(
                          height: 44,
                          decoration: BoxDecoration(
                            color: Colors.white24,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          alignment: Alignment.center,
                          child: const Text('BATAL',
                              style: TextStyle(
                                color: Colors.white,
                                fontFamily: kFont,
                                fontWeight: FontWeight.w700,
                              )),
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: GestureDetector(
                        onTap: () async {
                          final text = ctrl.text.trim();
                          if (text.isEmpty) return;

                          Navigator.pop(ctx);
                          _showLoading('Mengupload...');

                          final hex =
                              '#${bg.value.toRadixString(16).substring(2).toUpperCase()}';

                          try {
                            final res = await http.post(
                              Uri.parse('$baseUrl/story/text'),
                              body: {
                                'key': widget.sessionKey,
                                'username': widget.username,
                                'text': text,
                                'bgColor': hex,
                              },
                            ).timeout(const Duration(seconds: 15));

                            final data = jsonDecode(res.body);
                            if (!mounted) return;
                            Navigator.pop(context);

                            if (data['success'] == true) {
                              _toast('Status diupload ✅', AppColors.green);
                              await _load();
                            } else {
                              _toast(data['message'] ?? 'Gagal',
                                  AppColors.red);
                            }
                          } catch (e) {
                            if (mounted) {
                              Navigator.pop(context);
                              _toast('Error: $e', AppColors.red);
                            }
                          }
                        },
                        child: Container(
                          height: 44,
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          alignment: Alignment.center,
                          child: const Text('UPLOAD',
                              style: TextStyle(
                                color: Colors.black87,
                                fontFamily: kFont,
                                fontWeight: FontWeight.w700,
                              )),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _showLoading(String msg) {
    showDialog(
      context: context,
      barrierDismissible: false,
      barrierColor: Colors.black54,
      builder: (_) => Center(
        child: Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            color: AppColors.card,
            borderRadius: BorderRadius.circular(16),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              CircularProgressIndicator(color: AppColors.accent),
              const SizedBox(height: 12),
              Text(msg,
                  style: TextStyle(
                    color: AppColors.text,
                    fontFamily: kFont,
                    fontSize: 12,
                  )),
            ],
          ),
        ),
      ),
    );
  }

  void _toast(String msg, Color color) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg,
          style: TextStyle(
              color: _onAccent(),
              fontWeight: FontWeight.w600,
              fontFamily: kFont)),
      backgroundColor: color,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      margin: const EdgeInsets.all(16),
      duration: const Duration(seconds: 2),
    ));
  }

  void _openStoryViewer(List<StoryData> stories, int initialIndex, bool isMine) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => _StoryViewer(
          stories: stories,
          initialIndex: initialIndex,
          isMine: isMine,
          sessionKey: widget.sessionKey,
          currentUser: widget.username,
          onDeleted: _load,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const SizedBox(
        height: 100,
        child: Center(
          child: SizedBox(
            width: 20, height: 20,
            child: CircularProgressIndicator(strokeWidth: 2),
          ),
        ),
      );
    }

    return SizedBox(
      height: 108,
      child: ListView(
        scrollDirection: Axis.horizontal,
        physics: const BouncingScrollPhysics(),
        padding: const EdgeInsets.symmetric(horizontal: 16),
        children: [
          _buildMyStory(),
          ..._otherStories.map((s) => _buildStoryItem(s)),
        ],
      ),
    );
  }

  Widget _buildMyStory() {
    final hasImg = _myImage != null && _myImage!.isNotEmpty;
    final hasStory = _myStories.isNotEmpty;
    final isComic = ThemeModeManager.isComic3d;

    return GestureDetector(
      onTap: _onTapMy,
      child: Container(
        width: 74,
        margin: const EdgeInsets.only(right: 12),
        child: Column(
          children: [
            Stack(
              children: [
                Container(
                  width: 66, height: 66,
                  padding: const EdgeInsets.all(3),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: hasStory
                        ? LinearGradient(
                            colors: [
                              AppColors.accent,
                              AppColors.accentMid,
                            ],
                          )
                        : AppColors.btnGrad,
                    border: isComic
                        ? Border.all(
                            color: AppColors.border, width: 3)
                        : null,
                    boxShadow: hasStory && !isComic
                        ? [
                            BoxShadow(
                              color: AppColors.accent.withOpacity(0.6),
                              blurRadius: 14,
                              spreadRadius: 2,
                            ),
                          ]
                        : null,
                  ),
                  child: Container(
                    padding: const EdgeInsets.all(2),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: AppColors.card,
                    ),
                    child: ClipOval(
                      child: hasImg
                          ? Image.file(File(_myImage!),
                              fit: BoxFit.cover)
                          : Container(
                              color: AppColors.card2,
                              child: Icon(Icons.person_rounded,
                                  color: AppColors.textSub, size: 28),
                            ),
                    ),
                  ),
                ),
                // Tombol Plus (+) selalu ada untuk tambah story
                Positioned(
                  bottom: 0, right: 0,
                  child: GestureDetector(
                    onTap: _showUploadSheet,
                    child: Container(
                      width: 22, height: 22,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: AppColors.btnGrad,
                        border: Border.all(color: AppColors.bg, width: 2),
                      ),
                      child: Icon(
                        Icons.add_rounded,
                        color: _onAccent(),
                        size: 15,
                      ),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 5),
            Text(
              hasStory ? 'Statusku' : 'Buat Status',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                color: AppColors.text,
                fontSize: 10.5,
                fontFamily: kFont,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStoryItem(StoryData story) {
    final isComic = ThemeModeManager.isComic3d;
    
    // Kelompokkan story berdasarkan username
    final userStories = _otherStories.where((s) => s.username == story.username).toList();

    return GestureDetector(
      onTap: () => _openStoryViewer(userStories, 0, false),
      child: Container(
        width: 74,
        margin: const EdgeInsets.only(right: 12),
        child: Column(
          children: [
            Container(
              width: 66, height: 66,
              padding: const EdgeInsets.all(3),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: AppColors.btnGrad,
                border: isComic
                    ? Border.all(color: AppColors.border, width: 3)
                    : null,
              ),
              child: Container(
                padding: const EdgeInsets.all(2),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: AppColors.card,
                ),
                child: ClipOval(child: _thumbnail(story)),
              ),
            ),
            const SizedBox(height: 5),
            Text(story.username,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  color: AppColors.text,
                  fontSize: 10.5,
                  fontFamily: kFont,
                  fontWeight: FontWeight.w600,
                )),
          ],
        ),
      ),
    );
  }

  Widget _thumbnail(StoryData s) {
    if (s.type == 'text') {
      Color bg = AppColors.accent;
      if (s.bgColor != null) {
        try {
          bg = Color(
              int.parse('FF${s.bgColor!.substring(1)}', radix: 16));
        } catch (_) {}
      }
      return Container(
        color: bg,
        alignment: Alignment.center,
        padding: const EdgeInsets.all(6),
        child: Text(s.content,
            maxLines: 3,
            overflow: TextOverflow.ellipsis,
            textAlign: TextAlign.center,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 7,
              fontWeight: FontWeight.w600,
            )),
      );
    }

    if (s.type == 'image') {
      return Image.network(s.fullUrl,
          fit: BoxFit.cover,
          errorBuilder: (_, __, ___) => Icon(Icons.image_rounded,
              color: AppColors.textHint, size: 24));
    }

    return Container(
      color: AppColors.card2,
      child: Icon(Icons.play_circle_fill_rounded,
          color: AppColors.accent, size: 28),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════
//  UPLOAD OPTION SHEET
// ═══════════════════════════════════════════════════════════════════════
class _UploadOptionSheet extends StatelessWidget {
  final VoidCallback onPickImage;
  final VoidCallback onPickVideo;
  final VoidCallback onTextStory;

  const _UploadOptionSheet({
    required this.onPickImage,
    required this.onPickVideo,
    required this.onTextStory,
  });

  @override
  Widget build(BuildContext context) {
    final isComic = ThemeModeManager.isComic3d;
    return Container(
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: isComic ? null : AppColors.glassGrad,
        color: isComic ? AppColors.card : null,
        borderRadius: BorderRadius.circular(isComic ? 6 : 24),
        border: Border.all(
          color: AppColors.border,
          width: AppColors.borderWidth,
        ),
        boxShadow: AppColors.glassShadow,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text('Buat Status',
              style: TextStyle(
                color: AppColors.text,
                fontSize: 16,
                fontWeight: FontWeight.w700,
                fontFamily: kFont,
                letterSpacing: 1,
              )),
          const SizedBox(height: 20),
          Row(
            children: [
              Expanded(
                child: _OptionItem(
                  icon: Icons.photo_library_rounded,
                  label: 'Galeri',
                  onTap: onPickImage,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _OptionItem(
                  icon: Icons.videocam_rounded,
                  label: 'Video',
                  onTap: onPickVideo,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          GestureDetector(
            onTap: onTextStory,
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 14),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFF7B1FA2), Color(0xFF9C27B0)],
                ),
                borderRadius: BorderRadius.circular(isComic ? 4 : 14),
                border: isComic
                    ? Border.all(color: AppColors.border, width: 2)
                    : null,
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: const [
                  Icon(Icons.text_fields_rounded,
                      color: Colors.white, size: 18),
                  SizedBox(width: 8),
                  Text('Status Text',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                        fontFamily: kFont,
                        letterSpacing: 1,
                      )),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _OptionItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;

  const _OptionItem({
    required this.icon,
    required this.label,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(
          color: AppColors.accent.withOpacity(0.1),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: AppColors.accent.withOpacity(0.3),
            width: AppColors.borderWidth,
          ),
        ),
        child: Column(
          children: [
            Icon(icon, color: AppColors.accent, size: 24),
            const SizedBox(height: 6),
            Text(label,
                style: TextStyle(
                  color: AppColors.text,
                  fontSize: 11,
                  fontFamily: kFont,
                  fontWeight: FontWeight.w600,
                )),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════
//  STORY VIEWER (MULTI-STORY + KOMENTAR)
// ═══════════════════════════════════════════════════════════════════════
class _StoryViewer extends StatefulWidget {
  final List<StoryData> stories;
  final int initialIndex;
  final bool isMine;
  final String sessionKey;
  final String currentUser;
  final VoidCallback? onDeleted;

  const _StoryViewer({
    required this.stories,
    required this.initialIndex,
    required this.isMine,
    required this.sessionKey,
    required this.currentUser,
    this.onDeleted,
  });

  @override
  State<_StoryViewer> createState() => _StoryViewerState();
}

class _StoryViewerState extends State<_StoryViewer> {
  late PageController _pageController;
  late int _currentIndex;
  VideoPlayerController? _video;

  bool _liked = false;
  int _likes = 0;
  int _viewers = 0;
  bool _busy = false;

  int _commentCount = 0;

  @override
  void initState() {
    super.initState();
    _currentIndex = widget.initialIndex;
    _pageController = PageController(initialPage: _currentIndex);
    
    _loadStoryState();
  }

  void _loadStoryState() {
    final story = widget.stories[_currentIndex];
    _liked = story.likedByMe;
    _likes = story.likes;
    _viewers = story.viewers;
    
    _initVideo();
    if (!widget.isMine) _sendView();
    _fetchCommentCount();
  }

  void _changeStory(int index) {
    if (index < 0 || index >= widget.stories.length) {
      Navigator.pop(context);
      return;
    }
    
    setState(() {
      _currentIndex = index;
    });
    _pageController.animateToPage(
      index,
      duration: const Duration(milliseconds: 300),
      curve: Curves.easeInOut,
    );
    
    _loadStoryState();
  }

  Future<void> _initVideo() async {
    _video?.dispose();
    _video = null;

    final story = widget.stories[_currentIndex];
    if (story.type == 'video') {
      _video = VideoPlayerController.networkUrl(Uri.parse(story.fullUrl));
      await _video!.initialize();
      _video!.setLooping(true);
      _video!.play();
      if (mounted) setState(() {});
    } else {
      if (mounted) setState(() {});
    }
  }

  Future<void> _sendView() async {
    final story = widget.stories[_currentIndex];
    try {
      final res = await http.get(Uri.parse(
        '$baseUrl/story/view?id=${story.id}&key=${widget.sessionKey}',
      )).timeout(const Duration(seconds: 8));

      final data = jsonDecode(res.body);
      if (data['success'] == true && mounted) {
        setState(() {
          _viewers = (data['viewers'] is int)
              ? data['viewers']
              : _viewers + 1;
        });
      }
    } catch (_) {
      if (mounted) setState(() => _viewers++);
    }
  }

  Future<void> _toggleLike() async {
    if (_busy) return;
    setState(() => _busy = true);

    setState(() {
      _liked = !_liked;
      _likes += _liked ? 1 : -1;
      if (_likes < 0) _likes = 0;
    });

    final story = widget.stories[_currentIndex];
    try {
      final res = await http.get(Uri.parse(
        '$baseUrl/story/like?id=${story.id}&key=${widget.sessionKey}',
      )).timeout(const Duration(seconds: 8));

      final data = jsonDecode(res.body);
      if (data['success'] == true) {
        if (mounted) {
          setState(() {
            _liked = data['liked'] == true;
            _likes = (data['likes'] is int) ? data['likes'] : _likes;
          });
        }
      }
    } catch (_) {
      if (mounted) {
        setState(() {
          _liked = !_liked;
          _likes += _liked ? 1 : -1;
          if (_likes < 0) _likes = 0;
        });
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _deleteStory() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.card,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        title: Text('Hapus Story?',
            style: TextStyle(
              color: AppColors.text,
              fontFamily: kFont,
              fontWeight: FontWeight.bold,
            )),
        content: Text(
          'Story kamu bakal dihapus permanen. Yakin?',
          style: TextStyle(color: AppColors.textSub, fontFamily: kFont),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: Text('BATAL',
                style: TextStyle(
                    color: AppColors.textSub, fontFamily: kFont)),
          ),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: Text('HAPUS',
                style: TextStyle(
                    color: AppColors.red,
                    fontFamily: kFont,
                    fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );

    if (confirm != true) return;

    final story = widget.stories[_currentIndex];
    try {
      final res = await http.post(
        Uri.parse('$baseUrl/story/delete'),
        body: {
          'key': widget.sessionKey,
          'storyId': story.id,
        },
      ).timeout(const Duration(seconds: 10));

      final data = jsonDecode(res.body);

      if (data['success'] == true && data['deleted'] == true) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('Story dihapus ✅',
              style: TextStyle(
                  color: _onAccent(), fontFamily: kFont)),
          backgroundColor: AppColors.green,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12)),
          margin: const EdgeInsets.all(16),
        ));
        widget.onDeleted?.call();
        
        widget.stories.removeAt(_currentIndex);
        if (widget.stories.isEmpty) {
          Navigator.pop(context);
        } else {
          _changeStory(_currentIndex >= widget.stories.length ? widget.stories.length - 1 : _currentIndex);
        }
      } else {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text(data['message']?.toString() ?? 'Gagal hapus',
              style: TextStyle(
                  color: _onAccent(), fontFamily: kFont)),
          backgroundColor: AppColors.red,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12)),
          margin: const EdgeInsets.all(16),
        ));
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('Error: $e',
            style: TextStyle(color: _onAccent(), fontFamily: kFont)),
        backgroundColor: AppColors.red,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12)),
        margin: const EdgeInsets.all(16),
      ));
    }
  }

  // ── FITUR KOMENTAR ──
  Future<void> _fetchCommentCount() async {
    final story = widget.stories[_currentIndex];
    try {
      final res = await http.get(Uri.parse(
        '$baseUrl/story/comments?id=${story.id}&key=${widget.sessionKey}',
      )).timeout(const Duration(seconds: 8));

      final data = jsonDecode(res.body);
      if (data['success'] == true && mounted) {
        setState(() {
          _commentCount = data['count'] ?? (data['comments'] as List).length;
        });
      }
    } catch (_) {}
  }

  void _openCommentsSheet() {
    final story = widget.stories[_currentIndex];
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => _CommentSheet(
        storyId: story.id,
        sessionKey: widget.sessionKey,
        currentUser: widget.currentUser,
        onCommentAdded: () {
          setState(() => _commentCount++);
        },
      ),
    );
  }

  @override
  void dispose() {
    _video?.dispose();
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: GestureDetector(
        onTapUp: (details) {
          final width = MediaQuery.of(context).size.width;
          if (details.localPosition.dx < width * 0.3) {
            _changeStory(_currentIndex - 1);
          } else if (details.localPosition.dx > width * 0.7) {
            _changeStory(_currentIndex + 1);
          }
        },
        child: Stack(
          fit: StackFit.expand,
          children: [
            // Multi-Story Content
            PageView.builder(
              controller: _pageController,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: widget.stories.length,
              itemBuilder: (_, i) {
                return _content(widget.stories[i]);
              },
            ),

            // Progress Bars
            Positioned(
              top: 40, left: 10, right: 10,
              child: SafeArea(
                child: Row(
                  children: List.generate(
                    widget.stories.length,
                    (index) => Expanded(
                      child: Container(
                        height: 3,
                        margin: const EdgeInsets.symmetric(horizontal: 2),
                        decoration: BoxDecoration(
                          color: index == _currentIndex
                              ? Colors.white
                              : Colors.white.withOpacity(0.3),
                          borderRadius: BorderRadius.circular(2),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),

            // Header atas
            Positioned(
              top: 50, left: 0, right: 0,
              child: SafeArea(
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        Colors.black.withOpacity(0.6),
                        Colors.transparent,
                      ],
                    ),
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 38, height: 38,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: AppColors.btnGrad,
                          border: widget.isMine
                              ? Border.all(
                                  color: AppColors.accent, width: 2)
                              : null,
                        ),
                        child: const Icon(Icons.person_rounded,
                            color: Colors.white, size: 20),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          widget.isMine
                              ? '${widget.stories[_currentIndex].username} (Kamu)'
                              : widget.stories[_currentIndex].username,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 14,
                            fontWeight: FontWeight.w700,
                            fontFamily: kFont,
                          ),
                        ),
                      ),
                      if (widget.isMine)
                        IconButton(
                          onPressed: _deleteStory,
                          icon: const Icon(Icons.delete_outline_rounded,
                              color: Colors.white),
                        ),
                      IconButton(
                        onPressed: () => Navigator.pop(context),
                        icon: const Icon(Icons.close, color: Colors.white),
                      ),
                    ],
                  ),
                ),
              ),
            ),

            // KANAN BAWAH: Like, Penonton, Komentar
            Positioned(
              right: 16,
              bottom: 32,
              child: SafeArea(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    // Komentar Button
                    GestureDetector(
                      onTap: _openCommentsSheet,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 14, vertical: 10),
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.45),
                          borderRadius: BorderRadius.circular(30),
                          border: Border.all(
                            color: Colors.white24,
                            width: 1.5,
                          ),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(
                              Icons.chat_bubble_outline_rounded,
                              color: Colors.white,
                              size: 18,
                            ),
                            const SizedBox(width: 6),
                            Text(
                              '$_commentCount',
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 13,
                                fontWeight: FontWeight.bold,
                                fontFamily: kFont,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 10),

                    // Like Button
                    GestureDetector(
                      onTap: _toggleLike,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 14, vertical: 10),
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.45),
                          borderRadius: BorderRadius.circular(30),
                          border: Border.all(
                            color: _liked
                                ? AppColors.red.withOpacity(0.6)
                                : Colors.white24,
                            width: 1.5,
                          ),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(
                              _liked
                                  ? Icons.favorite_rounded
                                  : Icons.favorite_border_rounded,
                              color: _liked ? AppColors.red : Colors.white,
                              size: 20,
                            ),
                            const SizedBox(width: 6),
                            Text(
                              '$_likes',
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 13,
                                fontWeight: FontWeight.bold,
                                fontFamily: kFont,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 10),

                    // Penonton
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 14, vertical: 10),
                      decoration: BoxDecoration(
                        color: Colors.black.withOpacity(0.45),
                        borderRadius: BorderRadius.circular(30),
                        border: Border.all(
                          color: Colors.white24,
                          width: 1.5,
                        ),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(
                            Icons.visibility_rounded,
                            color: Colors.white,
                            size: 18,
                          ),
                          const SizedBox(width: 6),
                          Text(
                            '$_viewers',
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 13,
                              fontWeight: FontWeight.bold,
                              fontFamily: kFont,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _content(StoryData story) {
    if (story.type == 'image') {
      return Image.network(
        story.fullUrl,
        fit: BoxFit.contain,
        loadingBuilder: (_, c, p) => p == null
            ? c
            : const Center(
                child: CircularProgressIndicator(color: Colors.white)),
        errorBuilder: (_, __, ___) => const Center(
          child: Icon(Icons.broken_image, color: Colors.white54, size: 60),
        ),
      );
    }

    if (story.type == 'video') {
      if (story.id != widget.stories[_currentIndex].id) {
        return Container(color: Colors.black);
      }
      if (_video == null || !_video!.value.isInitialized) {
        return const Center(
            child: CircularProgressIndicator(color: Colors.white));
      }
      return Center(
        child: AspectRatio(
          aspectRatio: _video!.value.aspectRatio,
          child: VideoPlayer(_video!),
        ),
      );
    }

    Color bg = const Color(0xFF7B1FA2);
    if (story.bgColor != null) {
      try {
        bg = Color(
            int.parse('FF${story.bgColor!.substring(1)}', radix: 16));
      } catch (_) {}
    }
    return Container(
      color: bg,
      alignment: Alignment.center,
      padding: const EdgeInsets.all(40),
      child: Text(
        story.content,
        textAlign: TextAlign.center,
        style: const TextStyle(
          color: Colors.white,
          fontSize: 28,
          fontWeight: FontWeight.w700,
          fontFamily: kFont,
          height: 1.4,
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════
//  COMMENT BOTTOM SHEET (Endpoint story/comments)
// ═══════════════════════════════════════════════════════════════════════
class _CommentSheet extends StatefulWidget {
  final String storyId;
  final String sessionKey;
  final String currentUser;
  final VoidCallback onCommentAdded;

  const _CommentSheet({
    required this.storyId,
    required this.sessionKey,
    required this.currentUser,
    required this.onCommentAdded,
  });

  @override
  State<_CommentSheet> createState() => _CommentSheetState();
}

class _CommentSheetState extends State<_CommentSheet> {
  List<StoryComment> _comments = [];
  bool _loading = true;
  final TextEditingController _ctrl = TextEditingController();
  bool _sending = false;

  @override
  void initState() {
    super.initState();
    _fetchComments();
  }

  Future<void> _fetchComments() async {
    try {
      final res = await http.get(Uri.parse(
        '$baseUrl/story/comments?id=${widget.storyId}&key=${widget.sessionKey}',
      )).timeout(const Duration(seconds: 8));

      final data = jsonDecode(res.body);
      if (data['success'] == true && mounted) {
        setState(() {
          _comments = (data['comments'] as List)
              .map((e) => StoryComment.fromJson(Map<String, dynamic>.from(e)))
              .toList();
          _loading = false;
        });
      } else {
        if (mounted) setState(() => _loading = false);
      }
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _postComment() async {
    final text = _ctrl.text.trim();
    if (text.isEmpty || _sending) return;

    setState(() => _sending = true);
    
    // Optimistic UI
    final tempComment = StoryComment(
      id: 'temp_${DateTime.now().millisecondsSinceEpoch}',
      username: widget.currentUser,
      text: text,
      createdAt: DateTime.now().toIso8601String(),
    );
    setState(() {
      _comments.add(tempComment);
      _ctrl.clear();
    });
    widget.onCommentAdded();

    try {
      final res = await http.post(
        Uri.parse('$baseUrl/story/comments'),
        body: {
          'key': widget.sessionKey,
          'storyId': widget.storyId,
          'text': text,
        },
      ).timeout(const Duration(seconds: 10));

      final data = jsonDecode(res.body);
      if (data['success'] == true) {
        // Ganti temp comment dengan yg asli dari server
        _fetchComments();
      } else {
        // Rollback kalau gagal
        setState(() {
          _comments.remove(tempComment);
        });
      }
    } catch (_) {
      setState(() {
        _comments.remove(tempComment);
      });
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom,
      ),
      child: Container(
        height: MediaQuery.of(context).size.height * 0.75,
        decoration: BoxDecoration(
          color: AppColors.card,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
          border: ThemeModeManager.isComic3d
              ? Border.all(color: AppColors.border, width: 3)
              : null,
        ),
        child: Column(
          children: [
            // Handle bar
            Container(
              width: 40, height: 4,
              margin: const EdgeInsets.only(top: 12, bottom: 8),
              decoration: BoxDecoration(
                color: AppColors.textHint.withOpacity(0.5),
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            
            // Header
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Row(
                children: [
                  Icon(Icons.chat_bubble_rounded, color: AppColors.accent, size: 20),
                  const SizedBox(width: 8),
                  Text(
                    'Komentar (${_comments.length})',
                    style: TextStyle(
                      color: AppColors.text,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      fontFamily: kFont,
                    ),
                  ),
                ],
              ),
            ),
            Divider(color: AppColors.border, height: 1),

            // List Komentar
            Expanded(
              child: _loading
                  ? Center(child: CircularProgressIndicator(color: AppColors.accent))
                  : _comments.isEmpty
                      ? Center(
                          child: Text(
                            'Belum ada komentar.\nJadi yang pertama!',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: AppColors.textSub,
                              fontFamily: kFont,
                              fontSize: 13,
                            ),
                          ),
                        )
                      : ListView.builder(
                          padding: const EdgeInsets.all(16),
                          itemCount: _comments.length,
                          itemBuilder: (ctx, i) {
                            final c = _comments[i];
                            return Container(
                              margin: const EdgeInsets.only(bottom: 12),
                              padding: const EdgeInsets.all(12),
                              decoration: BoxDecoration(
                                color: AppColors.card2,
                                borderRadius: BorderRadius.circular(
                                    ThemeModeManager.isComic3d ? 4 : 16),
                                border: Border.all(
                                  color: AppColors.border,
                                  width: ThemeModeManager.isComic3d ? 2 : 1,
                                ),
                              ),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    width: 36, height: 36,
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      gradient: AppColors.btnGrad,
                                    ),
                                    child: Icon(
                                      Icons.person_rounded,
                                      color: _onAccent(),
                                      size: 18,
                                    ),
                                  ),
                                  const SizedBox(width: 10),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          c.username,
                                          style: TextStyle(
                                            color: AppColors.text,
                                            fontSize: 12,
                                            fontWeight: FontWeight.bold,
                                            fontFamily: kFont,
                                          ),
                                        ),
                                        const SizedBox(height: 4),
                                        Text(
                                          c.text,
                                          style: TextStyle(
                                            color: AppColors.textSub,
                                            fontSize: 13,
                                            fontFamily: kFont,
                                            height: 1.3,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            );
                          },
                        ),
            ),

            // Input Komentar
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: AppColors.card,
                border: Border(
                  top: BorderSide(color: AppColors.border),
                ),
              ),
              child: SafeArea(
                top: false,
                child: Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: _ctrl,
                        style: TextStyle(
                          color: AppColors.text,
                          fontFamily: kFont,
                        ),
                        decoration: InputDecoration(
                          hintText: 'Tulis komentar...',
                          hintStyle: TextStyle(
                            color: AppColors.textHint,
                            fontFamily: kFont,
                          ),
                          filled: true,
                          fillColor: AppColors.card2,
                          contentPadding: const EdgeInsets.symmetric(
                              horizontal: 16, vertical: 12),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(24),
                            borderSide: BorderSide.none,
                          ),
                        ),
                        onSubmitted: (_) => _postComment(),
                      ),
                    ),
                    const SizedBox(width: 8),
                    GestureDetector(
                      onTap: _sending ? null : _postComment,
                      child: Container(
                        width: 44, height: 44,
                        decoration: BoxDecoration(
                          gradient: AppColors.btnGrad,
                          shape: BoxShape.circle,
                        ),
                        child: _sending
                            ? Padding(
                                padding: const EdgeInsets.all(12),
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  color: _onAccent(),
                                ),
                              )
                            : Icon(
                                Icons.send_rounded,
                                color: _onAccent(),
                                size: 20,
                              ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}