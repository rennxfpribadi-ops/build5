// ============================================================
// 🎨 AMBIL LINK GB PAGE — Multi-Role + Theme Sync Edition
// File: ambil_link_gb_page.dart
// v5 — Role-based links, Chrome launcher, Theme sync
// ============================================================
//
// ⚠️  Tambahkan ke pubspec.yaml:
//    url_launcher: ^6.2.5
//
// Cara pakai:
//   AmbilLinkGBPage(
//     sessionKey: 'xxx',
//     username: 'john',
//     role: parseUserRole('owner'), // fullup / reseller / owner
//   )
// ============================================================
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import 'theme.dart';

// ════════════════════════════════════════════════════════════
// 👤 USER ROLE  (urutan enum = hierarki: fullup < reseller < owner)
// ════════════════════════════════════════════════════════════
enum UserRole { fullup, reseller, owner }

extension UserRoleX on UserRole {
  String get displayName {
    switch (this) {
      case UserRole.fullup:
        return 'FULL UP';
      case UserRole.reseller:
        return 'RESELLER';
      case UserRole.owner:
        return 'OWNER';
    }
  }
}

UserRole parseUserRole(String? raw) {
  switch (raw?.toLowerCase().trim()) {
    case 'owner':
      return UserRole.owner;
    case 'reseller':
      return UserRole.reseller;
    default:
      return UserRole.fullup;
  }
}

// ════════════════════════════════════════════════════════════
// 🔗 GROUP LINK MODEL
// ════════════════════════════════════════════════════════════
enum LinkAccent { amber, green, purple }

class GroupLink {
  final String id;
  final String label;
  final String subtitle;
  final String url;
  final UserRole requiredRole;
  final IconData icon;
  final LinkAccent accent;

  const GroupLink({
    required this.id,
    required this.label,
    required this.subtitle,
    required this.url,
    required this.requiredRole,
    required this.icon,
    required this.accent,
  });
}

/// 🔧 Daftar link — tambahkan/ubah URL di sini.
/// Aturan visibilitas: user dengan `role.index >= requiredRole.index`
/// akan melihat link tsb.
const List<GroupLink> kGroupLinks = [
  GroupLink(
    id: 'fullup',
    label: 'GROUP FULL UP',
    subtitle: 'Grup utama semua member',
    url: 'https://t.me/+JI2HFKQt1u1lNTU6',
    requiredRole: UserRole.fullup,
    icon: Icons.groups_rounded,
    accent: LinkAccent.amber,
  ),
  GroupLink(
    id: 'reseller',
    label: 'GROUP RESELLER',
    subtitle: 'Khusus member reseller',
    // 🔁 GANTI dengan link reseller sebenarnya
    url: 'https://t.me/+1dCwKHOzQrw4MDM1',
    requiredRole: UserRole.reseller,
    icon: Icons.workspace_premium_rounded,
    accent: LinkAccent.green,
  ),
  GroupLink(
    id: 'owner',
    label: 'GROUP OWNER',
    subtitle: 'Khusus owner & partner',
    // 🔁 GANTI dengan link owner sebenarnya
    url: 'https://t.me/+M1UxEnZjwns5Njg1',
    requiredRole: UserRole.owner,
    icon: Icons.diamond_rounded,
    accent: LinkAccent.purple,
  ),
];

Color _resolveAccent(LinkAccent a) {
  switch (a) {
    case LinkAccent.amber:
      return AppColors.amber;
    case LinkAccent.green:
      return AppColors.green;
    case LinkAccent.purple:
      return AppColors.purple;
  }
}

// ════════════════════════════════════════════════════════════
// 🎨 WIDGET
// ════════════════════════════════════════════════════════════
class AmbilLinkGBPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final UserRole role;

  const AmbilLinkGBPage({
    super.key,
    required this.sessionKey,
    required this.username,
    this.role = UserRole.fullup,
  });

  @override
  State<AmbilLinkGBPage> createState() => _AmbilLinkGBPageState();
}

class _AmbilLinkGBPageState extends State<AmbilLinkGBPage>
    with TickerProviderStateMixin {
  final Set<String> _copiedLinks = {};
  final Map<String, int> _copyTimestamps = {};
  bool _loading = true;
  bool _showRules = true;

  late final AnimationController _entryCtrl;
  late final AnimationController _pulseCtrl;
  late final Animation<double> _fade;
  late final Animation<Offset> _slide;

  List<GroupLink> get _visibleLinks => kGroupLinks
      .where((l) => widget.role.index >= l.requiredRole.index)
      .toList(growable: false);

  @override
  void initState() {
    super.initState();

    _entryCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 750),
    );
    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1600),
    )..repeat(reverse: true);

    _fade = CurvedAnimation(parent: _entryCtrl, curve: Curves.easeOutCubic);
    _slide = Tween<Offset>(
      begin: const Offset(0, 0.08),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _entryCtrl, curve: Curves.easeOutCubic));

    _loadStatus();
  }

  @override
  void dispose() {
    _entryCtrl.dispose();
    _pulseCtrl.dispose();
    super.dispose();
  }

  // ════════════════════════════════════════════════════════════
  // 🔍 LOAD STATUS DARI LOCAL STORAGE
  // ════════════════════════════════════════════════════════════
  Future<void> _loadStatus() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      for (final link in _visibleLinks) {
        final key = 'gb_link_${link.id}_copied_${widget.username}';
        if (prefs.getBool(key) ?? false) {
          _copiedLinks.add(link.id);
          _copyTimestamps[link.id] = prefs.getInt('${key}_timestamp') ?? 0;
        }
      }
    } catch (_) {}
    if (mounted) {
      setState(() {
        _loading = false;
        _showRules = _copiedLinks.isEmpty;
      });
      _entryCtrl.forward();
    }
  }

  // ════════════════════════════════════════════════════════════
  // 📋 COPY LINK (per-link, 1x saja)
  // ════════════════════════════════════════════════════════════
  Future<void> _copyLink(GroupLink link) async {
    if (_copiedLinks.contains(link.id)) {
      _snack('❌ Link ${link.label} sudah pernah di-copy!', success: false);
      return;
    }
    try {
      await Clipboard.setData(ClipboardData(text: link.url));
      final prefs = await SharedPreferences.getInstance();
      final key = 'gb_link_${link.id}_copied_${widget.username}';
      final now = DateTime.now().millisecondsSinceEpoch;
      await prefs.setBool(key, true);
      await prefs.setInt('${key}_timestamp', now);

      if (mounted) {
        setState(() {
          _copiedLinks.add(link.id);
          _copyTimestamps[link.id] = now;
          _showRules = false;
        });
      }
      _snack('✅ Link ${link.label} berhasil di-copy! (1x saja)',
          success: true);
    } catch (e) {
      _snack('❌ Gagal copy: $e', success: false);
    }
  }

  // ════════════════════════════════════════════════════════════
  // 🌐 BUKA LINK DI CHROME (external app)
  // ════════════════════════════════════════════════════════════
  Future<void> _openInChrome(GroupLink link) async {
    final uri = Uri.parse(link.url);
    try {
      final ok = await launchUrl(uri, mode: LaunchMode.externalApplication);
      if (!ok) {
        await launchUrl(uri, mode: LaunchMode.platformDefault);
      }
    } catch (e) {
      _snack('❌ Gagal membuka link: $e', success: false);
    }
  }

  void _snack(String msg, {required bool success}) {
    if (!mounted) return;
    final bg = success ? AppColors.green : AppColors.red;
    final fg = success ? Colors.black : Colors.white;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: bg,
        behavior: SnackBarBehavior.floating,
        content: Row(
          children: [
            Icon(
              success ? Icons.check_circle_rounded : Icons.error_rounded,
              color: fg,
              size: 20,
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                msg,
                style: TextStyle(color: fg, fontWeight: FontWeight.w800),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ════════════════════════════════════════════════════════════
  // 🏗 BUILD
  // ════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    // Rebuild otomatis saat theme berubah
    return ValueListenableBuilder<AppThemeMode>(
      valueListenable: ThemeModeManager.current,
      builder: (context, _, __) => _buildPage(context),
    );
  }

  Widget _buildPage(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      extendBodyBehindAppBar: true,
      appBar: _buildAppBar(),
      body: Stack(
        children: [
          Positioned.fill(child: _buildBackground()),
          SafeArea(
            child: _loading
                ? Center(
                    child:
                        CircularProgressIndicator(color: AppColors.accent))
                : FadeTransition(
                    opacity: _fade,
                    child: SlideTransition(
                      position: _slide,
                      child: SingleChildScrollView(
                        physics: const BouncingScrollPhysics(),
                        padding: const EdgeInsets.fromLTRB(16, 12, 16, 32),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            _buildHeaderCard(),
                            const SizedBox(height: 18),
                            ..._visibleLinks.map(
                              (link) => Padding(
                                padding: const EdgeInsets.only(bottom: 16),
                                child: _buildLinkCard(link),
                              ),
                            ),
                            if (_showRules) ...[
                              const SizedBox(height: 6),
                              _buildRulesCard(),
                            ],
                            const SizedBox(height: 30),
                          ],
                        ),
                      ),
                    ),
                  ),
          ),
        ],
      ),
    );
  }

  Widget _buildBackground() {
    if (ThemeModeManager.isComic3d) {
      return const SizedBox.shrink();
    }
    return Stack(
      children: [
        Positioned.fill(
          child: DecoratedBox(
            decoration: BoxDecoration(
              gradient: RadialGradient(
                center: Alignment.topCenter,
                radius: 1.4,
                colors: [
                  AppColors.accent.withOpacity(0.12),
                  AppColors.bg,
                  AppColors.dark,
                ],
                stops: const [0.0, 0.55, 1.0],
              ),
            ),
          ),
        ),
        Positioned(
          top: -80,
          right: -60,
          child: _glowOrb(180, AppColors.accent.withOpacity(0.15)),
        ),
        Positioned(
          bottom: -100,
          left: -80,
          child: _glowOrb(220, AppColors.accentMid.withOpacity(0.10)),
        ),
      ],
    );
  }

  Widget _glowOrb(double size, Color color) {
    return IgnorePointer(
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: RadialGradient(
            colors: [color, color.withOpacity(0.0)],
          ),
        ),
      ),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: Colors.transparent,
      elevation: 0,
      centerTitle: true,
      leadingWidth: 60,
      leading: Padding(
        padding: const EdgeInsets.only(left: 12),
        child: GestureDetector(
          onTap: () => Navigator.pop(context),
          child: Container(
            margin: const EdgeInsets.symmetric(vertical: 8),
            decoration: BoxDecoration(
              gradient: AppColors.btnGrad,
              borderRadius:
                  BorderRadius.circular(ThemeModeManager.isComic3d ? 4 : 12),
              border: Border.all(
                  color: ThemeModeManager.isComic3d
                      ? AppColors.border
                      : Colors.transparent,
                  width: ThemeModeManager.isComic3d ? 3 : 0),
              boxShadow: AppColors.softShadow,
            ),
            child: Icon(
              Icons.arrow_back_ios_new_rounded,
              color: ThemeModeManager.isComic3d ? Colors.black : Colors.white,
              size: 16,
            ),
          ),
        ),
      ),
      title: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          gradient: AppColors.btnGrad,
          borderRadius:
              BorderRadius.circular(ThemeModeManager.isComic3d ? 4 : 12),
          border: Border.all(
              color: ThemeModeManager.isComic3d
                  ? AppColors.border
                  : Colors.transparent,
              width: ThemeModeManager.isComic3d ? 3 : 0),
          boxShadow: AppColors.glassShadow,
        ),
        child: Text(
          'AMBIL LINK GB',
          style: TextStyle(
            color:
                ThemeModeManager.isComic3d ? Colors.black : Colors.white,
            fontWeight: FontWeight.w900,
            fontSize: 13,
            letterSpacing: 2,
            fontFamily: 'Astral',
          ),
        ),
      ),
    );
  }

  // ════════════════════════════════════════════════════════════
  // 📦 HEADER CARD
  // ════════════════════════════════════════════════════════════
  Widget _buildHeaderCard() {
    final isComic = ThemeModeManager.isComic3d;
    return Container(
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        color: isComic ? AppColors.card : null,
        gradient: isComic
            ? null
            : LinearGradient(
                colors: [AppColors.card, AppColors.card2],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
        borderRadius: BorderRadius.circular(AppColors.cardRadius),
        border: Border.all(
          color: AppColors.border,
          width: AppColors.borderWidth,
        ),
        boxShadow: AppColors.glassShadow,
      ),
      child: Column(
        children: [
          AnimatedBuilder(
            animation: _pulseCtrl,
            builder: (context, child) {
              final t = _pulseCtrl.value;
              return Container(
                width: 74,
                height: 74,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: AppColors.btnGrad,
                  border: Border.all(
                    color: isComic ? AppColors.border : Colors.transparent,
                    width: isComic ? AppColors.borderWidth : 0,
                  ),
                  boxShadow: isComic
                      ? AppColors.softShadow
                      : [
                          BoxShadow(
                            color:
                                AppColors.accent.withOpacity(0.35 + 0.25 * t),
                            blurRadius: 18 + 10 * t,
                            spreadRadius: 1 + 2 * t,
                          ),
                        ],
                ),
                child: Icon(
                  Icons.group_add_rounded,
                  color: isComic ? Colors.black : Colors.white,
                  size: 34,
                ),
              );
            },
          ),
          const SizedBox(height: 16),
          ShaderMask(
            shaderCallback: (rect) => LinearGradient(
              colors: [AppColors.text, AppColors.textSub],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ).createShader(rect),
            child: Text(
              'AMBIL LINK GROUP',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: AppColors.text,
                fontWeight: FontWeight.w900,
                fontSize: 18,
                letterSpacing: 2,
                fontFamily: 'Astral',
              ),
            ),
          ),
          const SizedBox(height: 10),
          // 🏷️ Role badge
          Container(
            padding:
                const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
            decoration: BoxDecoration(
              color: AppColors.accent.withOpacity(isComic ? 0.25 : 0.15),
              borderRadius: BorderRadius.circular(isComic ? 4 : 20),
              border: Border.all(
                color: isComic ? AppColors.border : AppColors.accent,
                width: isComic ? 2 : 1,
              ),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.badge_rounded,
                    color: AppColors.accent, size: 14),
                const SizedBox(width: 6),
                Text(
                  'Role: ${widget.role.displayName}',
                  style: TextStyle(
                    color: isComic ? Colors.black : AppColors.accent,
                    fontWeight: FontWeight.w900,
                    fontSize: 11,
                    letterSpacing: 1,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 10),
          Text(
            'Klik tombol COPY untuk menyalin link (1x saja per link). '
            'Atau klik BUKA DI CHROME untuk langsung membuka grup.',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: AppColors.textSub,
              fontSize: 12,
              height: 1.6,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  // ════════════════════════════════════════════════════════════
  // 🔗 LINK CARD (per link)
  // ════════════════════════════════════════════════════════════
  Widget _buildLinkCard(GroupLink link) {
    final isComic = ThemeModeManager.isComic3d;
    final accent = _resolveAccent(link.accent);
    final copied = _copiedLinks.contains(link.id);

    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: isComic ? AppColors.card : null,
        gradient: isComic
            ? null
            : LinearGradient(
                colors: [AppColors.card, AppColors.card2],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
        borderRadius: BorderRadius.circular(AppColors.cardRadius),
        border: Border.all(
          color: AppColors.border,
          width: AppColors.borderWidth,
        ),
        boxShadow: AppColors.glassShadow,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // ── Header ──
          Row(
            children: [
              Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                    colors: [accent, accent.withOpacity(0.6)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  border: Border.all(
                    color: isComic ? AppColors.border : Colors.transparent,
                    width: isComic ? 2 : 0,
                  ),
                ),
                child: Icon(link.icon,
                    color: isComic ? Colors.black : Colors.white, size: 18),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      link.label,
                      style: TextStyle(
                        color: AppColors.text,
                        fontWeight: FontWeight.w900,
                        fontSize: 12,
                        letterSpacing: 1.2,
                        fontFamily: 'Astral',
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      link.subtitle,
                      style: TextStyle(
                        color: AppColors.textHint,
                        fontSize: 10,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
              _statusBadge(copied, accent),
            ],
          ),
          const SizedBox(height: 14),

          // ── URL display ──
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(13),
            decoration: BoxDecoration(
              color: isComic
                  ? AppColors.card2
                  : Colors.black.withOpacity(0.35),
              borderRadius:
                  BorderRadius.circular(isComic ? 4 : 12),
              border: Border.all(
                color: isComic ? AppColors.border : AppColors.border,
                width: isComic ? 2 : 1,
              ),
            ),
            child: Text(
              link.url,
              style: TextStyle(
                color: copied ? AppColors.textHint : accent,
                fontSize: 12.5,
                fontWeight: FontWeight.w700,
                fontFamily: 'monospace',
              ),
            ),
          ),
          const SizedBox(height: 14),

          // ── Copy button ──
          GestureDetector(
            onTap: copied ? null : () => _copyLink(link),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 250),
              height: 54,
              decoration: BoxDecoration(
                gradient: copied ? null : AppColors.btnGrad,
                color: copied
                    ? (isComic
                        ? AppColors.card2
                        : Colors.black.withOpacity(0.4))
                    : null,
                borderRadius:
                    BorderRadius.circular(isComic ? 4 : 16),
                border: Border.all(
                  color: isComic ? AppColors.border : Colors.transparent,
                  width: isComic ? AppColors.borderWidth : 0,
                ),
                boxShadow: copied
                    ? null
                    : (isComic
                        ? AppColors.softShadow
                        : [
                            BoxShadow(
                              color: AppColors.accent.withOpacity(0.35),
                              blurRadius: 16,
                              offset: const Offset(0, 5),
                            ),
                          ]),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    copied ? Icons.lock_rounded : Icons.copy_rounded,
                    color: copied
                        ? AppColors.textHint
                        : (isComic ? Colors.black : Colors.white),
                    size: 20,
                  ),
                  const SizedBox(width: 8),
                  Text(
                    copied ? 'SUDAH DI-COPY' : 'COPY LINK',
                    style: TextStyle(
                      color: copied
                          ? AppColors.textHint
                          : (isComic ? Colors.black : Colors.white),
                      fontWeight: FontWeight.w900,
                      fontSize: 14,
                      letterSpacing: 1.2,
                      fontFamily: 'Astral',
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 10),

          // ── 🌐 Open in Chrome button ──
          GestureDetector(
            onTap: () => _openInChrome(link),
            child: Container(
              height: 48,
              decoration: BoxDecoration(
                color: isComic
                    ? accent.withOpacity(0.18)
                    : accent.withOpacity(0.10),
                borderRadius:
                    BorderRadius.circular(isComic ? 4 : 14),
                border: Border.all(
                  color: isComic
                      ? AppColors.border
                      : accent.withOpacity(0.6),
                  width: isComic ? 2.5 : 1.5,
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.open_in_new_rounded,
                      color: accent, size: 18),
                  const SizedBox(width: 8),
                  Text(
                    'BUKA DI CHROME',
                    style: TextStyle(
                      color: accent,
                      fontWeight: FontWeight.w900,
                      fontSize: 12.5,
                      letterSpacing: 1.2,
                      fontFamily: 'Astral',
                    ),
                  ),
                ],
              ),
            ),
          ),

          // ── Warning when copied ──
          if (copied) ...[
            const SizedBox(height: 10),
            Center(
              child: Text(
                '⚠️ Link ${link.label} hanya dapat di-copy 1x',
                style: TextStyle(
                  color: AppColors.red,
                  fontSize: 10.5,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _statusBadge(bool copied, Color accent) {
    final isComic = ThemeModeManager.isComic3d;
    final color = copied ? AppColors.red : accent;
    return AnimatedContainer(
      duration: const Duration(milliseconds: 250),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(isComic ? 0.22 : 0.18),
        borderRadius: BorderRadius.circular(isComic ? 4 : 10),
        border: Border.all(
          color: isComic ? AppColors.border : color,
          width: isComic ? 1.8 : 1,
        ),
      ),
      child: Text(
        copied ? 'USED' : 'FRESH',
        style: TextStyle(
          color: isComic ? Colors.black : color,
          fontSize: 9,
          fontWeight: FontWeight.w900,
          letterSpacing: 1,
        ),
      ),
    );
  }

  // ════════════════════════════════════════════════════════════
  // 📜 RULES CARD
  // ════════════════════════════════════════════════════════════
  Widget _buildRulesCard() {
    final isComic = ThemeModeManager.isComic3d;
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: isComic ? AppColors.card : null,
        gradient: isComic
            ? null
            : LinearGradient(
                colors: [AppColors.card, AppColors.card2],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
        borderRadius: BorderRadius.circular(AppColors.cardRadius),
        border: Border.all(
          color: AppColors.border,
          width: AppColors.borderWidth,
        ),
        boxShadow: AppColors.glassShadow,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.rule_folder_rounded,
                  color: AppColors.amber, size: 20),
              const SizedBox(width: 8),
              Text(
                'RULES / PERATURAN',
                style: TextStyle(
                  color: AppColors.text,
                  fontWeight: FontWeight.w900,
                  fontSize: 13,
                  letterSpacing: 1.5,
                  fontFamily: 'Astral',
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          const _RuleItem(
              num: '1',
              text:
                  'Setiap link group hanya bisa di-copy 1x saja, tidak bisa diulang.'),
          const _RuleItem(
              num: '2',
              text: 'Dilarang share link ke pihak lain di luar grup.'),
          const _RuleItem(
              num: '3',
              text:
                  'Satu akun hanya boleh klaim 1x per link. Tidak bisa di-reset.'),
          const _RuleItem(
              num: '4',
              text:
                  'Simpan link di tempat aman sebelum keluar dari halaman ini.'),
          const _RuleItem(
              num: '5',
              text:
                  'Pelanggaran akan berakibat banned permanent tanpa refund.'),
          const _RuleItem(
              num: '6',
              text:
                  'Dengan copy link ini, Anda setuju dengan semua aturan di atas.'),
        ],
      ),
    );
  }
}

// ════════════════════════════════════════════════════════════
// 🧩 RULE ITEM
// ════════════════════════════════════════════════════════════
class _RuleItem extends StatelessWidget {
  final String num;
  final String text;
  const _RuleItem({required this.num, required this.text});

  @override
  Widget build(BuildContext context) {
    final isComic = ThemeModeManager.isComic3d;
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 24,
            height: 24,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: AppColors.btnGrad,
              border: Border.all(
                color: isComic ? AppColors.border : Colors.transparent,
                width: isComic ? 1.8 : 0,
              ),
            ),
            child: Center(
              child: Text(
                num,
                style: TextStyle(
                  color: isComic ? Colors.black : Colors.white,
                  fontSize: 10,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              text,
              style: TextStyle(
                color: AppColors.textSub,
                fontSize: 11.5,
                height: 1.55,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }
}