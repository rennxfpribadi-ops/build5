// ============================================================
// 🎬 SPLASH SCREEN — Liquid Glass Edition (Refractive & Edge Reflection)
// File: splash.dart
// v10 — Hyper-Refractive Glass & Specular Edge Reflection
// ============================================================
import 'dart:async';
import 'dart:math' as math;
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

import 'musik_page.dart';       // 👈 TARGET BARU
import 'theme.dart';

class _MC {
  static bool get _comic => ThemeModeManager.isComic3d;
  static bool get _mono => ThemeModeManager.isMonochrome;

  // Warna dasar yang diadaptasi dari theme.dart
  static Color get bg => AppColors.bg;
  static Color get text => AppColors.text;
  static Color get textSub => AppColors.textSub;
  static Color get accent => AppColors.accent;
  static Color get accentMid => AppColors.accentMid;
  static Color get glassBorder => AppColors.glassBorder;
  
  // Kontainer kaca transparan tinggi (0.06 - 0.1) dengan nuansa jernih
  static Color get glassWhite => _mono 
      ? Colors.white.withOpacity(0.5) 
      : Colors.white.withOpacity(0.08);

  static Color get green => AppColors.green;
  static Color get amber => AppColors.amber;
  static Color get gold => AppColors.gold;

  // Warna khusus efek refraktif & kilau tepi (Specular Reflection)
  static Color get liquidGlow => _mono ? Colors.blue.withOpacity(0.25) : AppColors.accent.withOpacity(0.45);
  static Color get liquidBorder => _mono ? Colors.black.withOpacity(0.15) : Colors.white.withOpacity(0.4);
  static Color get shadowColor => _mono ? Colors.black.withOpacity(0.1) : Colors.black.withOpacity(0.55);
}

class SplashScreen extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;
  final String uid;

  const SplashScreen({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
    required this.listBug,
    required this.listDoos,
    required this.news,
    required this.uid,
  });

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with TickerProviderStateMixin {
  VideoPlayerController? _videoCtrl;

  bool _videoReady = false;
  bool _hasNavigated = false;
  bool _videoFinished = false;

  double _videoProgress = 0.0;
  Duration _videoPosition = Duration.zero;
  Duration _videoDuration = Duration.zero;

  Timer? _fallbackTimer;

  late final AnimationController _entryController;
  late final AnimationController _pulseController;
  late final AnimationController _cosmicController;
  late final AnimationController _logoController;
  late final AnimationController _badgeController;
  late final AnimationController _shimmerController;
  late final AnimationController _orbitController;
  late final AnimationController _reflectionController; // 👈 Controller baru untuk efek pantulan cahaya berjalan

  late Animation<double> _badgeSwing;
  late final Animation<double> _fadeAnimation;
  late final Animation<double> _scaleAnimation;
  late final Animation<Offset> _slideAnimation;

  @override
  void initState() {
    super.initState();

    _entryController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1600),
    );

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2000),
    )..repeat(reverse: true);

    _cosmicController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 16),
    )..repeat();

    _logoController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2600),
    )..repeat(reverse: true);

    _shimmerController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2800),
    )..repeat();

    _orbitController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 8),
    )..repeat();

    // Controller untuk animasi kilau pantulan sisi (Edge Reflection sweep)
    _reflectionController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 4),
    )..repeat();

    _badgeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2400),
    )..repeat(reverse: true);
    _badgeSwing = Tween<double>(begin: -0.06, end: 0.06).animate(
      CurvedAnimation(parent: _badgeController, curve: Curves.easeInOutSine),
    );

    _fadeAnimation = CurvedAnimation(
      parent: _entryController,
      curve: const Interval(0.0, 0.70, curve: Curves.easeOutCubic),
    );

    _scaleAnimation = Tween<double>(begin: 0.88, end: 1.0).animate(
      CurvedAnimation(
        parent: _entryController,
        curve: const Interval(0.0, 0.85, curve: Curves.easeOutBack),
      ),
    );

    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.14),
      end: Offset.zero,
    ).animate(
      CurvedAnimation(
        parent: _entryController,
        curve: const Interval(0.10, 0.90, curve: Curves.easeOutCubic),
      ),
    );

    _entryController.forward();
    _initVideo();
  }

  Future<void> _initVideo() async {
    VideoPlayerController? controller;

    try {
      controller = VideoPlayerController.asset('assets/videos/splash.mp4');
      _videoCtrl = controller;

      await controller.initialize();

      if (!mounted || _videoCtrl != controller) {
        controller.dispose();
        return;
      }

      controller.setLooping(false);
      controller.addListener(_onVideoProgress);

      final dur = controller.value.duration;

      setState(() {
        _videoReady = true;
        _videoProgress = 0.0;
        _videoPosition = Duration.zero;
        _videoDuration = dur;
      });

      await controller.play();

      final fallbackDur = dur > Duration.zero
          ? dur + const Duration(seconds: 2)
          : const Duration(seconds: 15);

      _fallbackTimer?.cancel();
      _fallbackTimer = Timer(fallbackDur, () {
        if (mounted && !_hasNavigated) _navigate();
      });
    } catch (_) {
      if (!mounted) return;

      setState(() {
        _videoReady = false;
      });

      _fallbackTimer?.cancel();
      _fallbackTimer = Timer(
        const Duration(seconds: 4),
        () {
          if (mounted && !_hasNavigated) _navigate();
        },
      );
    }
  }

  void _onVideoProgress() {
    final controller = _videoCtrl;

    if (!mounted || controller == null || !controller.value.isInitialized) {
      return;
    }

    final value = controller.value;
    final duration = value.duration;
    final position = value.position;

    if (duration.inMilliseconds > 0) {
      final progress = position.inMilliseconds / duration.inMilliseconds;

      if (mounted) {
        setState(() {
          _videoPosition = position;
          _videoDuration = duration;
          _videoProgress = progress.clamp(0.0, 1.0);
        });
      }

      if (position >= duration && !_videoFinished && !_hasNavigated) {
        _videoFinished = true;
        _navigate();
      }
    }
  }

  String _fmtDuration(Duration d) {
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  void _navigate() {
    if (!mounted || _hasNavigated) return;

    _hasNavigated = true;
    _fallbackTimer?.cancel();

    final resolvedUid =
        widget.uid.isNotEmpty ? widget.uid : widget.username;

    Navigator.of(context).pushReplacement(
      PageRouteBuilder(
        transitionDuration: const Duration(milliseconds: 800),
        reverseTransitionDuration: const Duration(milliseconds: 450),
        pageBuilder: (_, animation, __) {
          return AudioDashboardScreen(
            uid: resolvedUid,
            username: widget.username,
            password: widget.password,
            role: widget.role,
            expiredDate: widget.expiredDate,
            sessionKey: widget.sessionKey,
            listBug: widget.listBug,
            listDoos: widget.listDoos,
            news: widget.news,
          );
        },
        transitionsBuilder: (_, animation, __, child) {
          final curved = CurvedAnimation(
            parent: animation,
            curve: Curves.easeOutCubic,
          );
          return FadeTransition(
            opacity: curved,
            child: ScaleTransition(
              scale: Tween<double>(begin: 0.94, end: 1.0).animate(curved),
              child: child,
            ),
          );
        },
      ),
    );
  }

  @override
  void dispose() {
    _fallbackTimer?.cancel();

    final controller = _videoCtrl;
    if (controller != null) {
      controller.removeListener(_onVideoProgress);
      controller.dispose();
    }

    _entryController.dispose();
    _pulseController.dispose();
    _cosmicController.dispose();
    _logoController.dispose();
    _badgeController.dispose();
    _shimmerController.dispose();
    _orbitController.dispose();
    _reflectionController.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppThemeMode>(
      valueListenable: ThemeModeManager.current,
      builder: (context, _, __) {
        return Scaffold(
          backgroundColor: _MC.bg,
          body: Stack(
            fit: StackFit.expand,
            children: [
              _buildVideoBackground(),
              _buildThemeOverlay(),
              _buildCosmicBackground(),
              _buildMainContent(),
              _buildBottomProgress(),
              _buildSkipBadge(),
            ],
          ),
        );
      },
    );
  }

  Widget _buildVideoBackground() {
    final controller = _videoCtrl;

    if (!_videoReady || controller == null || !controller.value.isInitialized) {
      return Container(
        decoration: BoxDecoration(
          gradient: RadialGradient(
            center: Alignment.center,
            radius: 1.15,
            colors: [
              _MC.accent.withOpacity(0.4),
              _MC.bg,
            ],
          ),
        ),
      );
    }

    return Positioned.fill(
      child: FittedBox(
        fit: BoxFit.cover,
        child: SizedBox(
          width: controller.value.size.width,
          height: controller.value.size.height,
          child: VideoPlayer(controller),
        ),
      ),
    );
  }

  Widget _buildThemeOverlay() {
    return Positioned.fill(
      child: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              _MC.bg.withOpacity(0.1),
              _MC.bg.withOpacity(0.4),
              _MC.bg.withOpacity(0.85),
            ],
            stops: const [0.0, 0.5, 1.0],
          ),
        ),
      ),
    );
  }

  Widget _buildCosmicBackground() {
    return Positioned.fill(
      child: IgnorePointer(
        child: AnimatedBuilder(
          animation: Listenable.merge([_cosmicController, _orbitController]),
          builder: (_, __) {
            return CustomPaint(
              painter: _CosmicPainter(
                progress: _cosmicController.value,
                orbit: _orbitController.value,
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _buildMainContent() {
    return SafeArea(
      child: Center(
        child: AnimatedBuilder(
          animation: Listenable.merge(
              [_entryController, _logoController, _shimmerController]),
          builder: (context, child) {
            return FadeTransition(
              opacity: _fadeAnimation,
              child: SlideTransition(
                position: _slideAnimation,
                child: ScaleTransition(
                  scale: _scaleAnimation,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 24),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        _buildLiquidGlassLogo(),
                        const SizedBox(height: 26),
                        _buildTitle(),
                        const SizedBox(height: 16),
                        _buildQuote(),
                        const SizedBox(height: 24),
                        _buildStatusCard(),
                      ],
                    ),
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  // 💎 REFACTORY LOGO DENGAN EFEK REFRAKSI & EDGE REFLECTION
  Widget _buildLiquidGlassLogo() {
    return AnimatedBuilder(
      animation: Listenable.merge([_pulseController, _logoController, _orbitController, _reflectionController]),
      builder: (_, __) {
        final pulse = 1.0 + (_pulseController.value * 0.04);
        final float = math.sin(_logoController.value * math.pi * 2) * 3.0;
        final orbitAngle = _orbitController.value * math.pi * 2;
        final reflectionVal = (_reflectionController.value * 2.0) - 0.5;

        return Transform.translate(
          offset: Offset(0, float),
          child: Transform.scale(
            scale: pulse,
            child: SizedBox(
              width: 150,
              height: 150,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  Transform.rotate(
                    angle: orbitAngle,
                    child: CustomPaint(
                      size: const Size(150, 150),
                      painter: _OrbitRingPainter(),
                    ),
                  ),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(100),
                    child: BackdropFilter(
                      filter: ImageFilter.blur(sigmaX: 22, sigmaY: 22), // 👈 Blur Refraktif Tinggi
                      child: Container(
                        width: 120,
                        height: 120,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                            colors: [
                              Colors.white.withOpacity(0.35),
                              Colors.white.withOpacity(0.02),
                            ],
                          ),
                          // 👈 Specular Border 3D dengan Highlight Sudut Terang
                          border: Border.all(
                            color: Colors.white.withOpacity(0.6),
                            width: 1.8,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: _MC.liquidGlow,
                              blurRadius: 30,
                              spreadRadius: 3,
                            ),
                            BoxShadow(
                              color: Colors.black.withOpacity(0.3),
                              blurRadius: 18,
                              offset: const Offset(0, 10),
                            ),
                            // 👈 Inner Edge Reflection (Pantulan Cahaya Dalam Kaca)
                            BoxShadow(
                              color: Colors.white.withOpacity(0.4),
                              blurRadius: 4,
                              spreadRadius: -2,
                            ),
                          ],
                        ),
                        child: Stack(
                          children: [
                            // Efek pantulan cahaya melintasi kontainer (Reflection Sweep)
                            Positioned.fill(
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(100),
                                child: Transform.translate(
                                  offset: Offset(reflectionVal * 120, reflectionVal * 120),
                                  child: Container(
                                    decoration: BoxDecoration(
                                      gradient: RadialGradient(
                                        colors: [
                                          Colors.white.withOpacity(0.4),
                                          Colors.transparent,
                                        ],
                                        radius: 0.6,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Center(
                              child: Container(
                                width: 80,
                                height: 80,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: _MC.accent.withOpacity(0.3),
                                  border: Border.all(color: Colors.white.withOpacity(0.3), width: 1),
                                ),
                                child: Icon(
                                  Icons.auto_awesome_rounded,
                                  color: _MC.text,
                                  size: 40,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildTitle() {
    return Column(
      children: [
        AnimatedBuilder(
          animation: Listenable.merge([_shimmerController, _reflectionController]),
          builder: (_, __) {
            final shimmerPos = (_shimmerController.value * 3.0) - 1.0;

            return ClipRRect(
              borderRadius: BorderRadius.circular(20),
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18), // 👈 Refractive Blur Kuat
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 14),
                  decoration: BoxDecoration(
                    color: _MC.glassWhite,
                    borderRadius: BorderRadius.circular(20),
                    // 👈 Specular Border Highlight 3D Mengkilap
                    border: Border.all(
                      color: Colors.white.withOpacity(0.55),
                      width: 1.5,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: _MC.liquidGlow,
                        blurRadius: 22,
                        spreadRadius: 1,
                      ),
                      BoxShadow(
                        color: _MC.shadowColor,
                        blurRadius: 12,
                        offset: const Offset(0, 5),
                      ),
                      // 👈 Inner Edge Reflection
                      BoxShadow(
                        color: Colors.white.withOpacity(0.25),
                        blurRadius: 2,
                        spreadRadius: -1,
                      ),
                    ],
                  ),
                  child: Stack(
                    children: [
                      Positioned.fill(
                        child: IgnorePointer(
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(18),
                            child: Transform.translate(
                              offset: Offset(shimmerPos * 240, 0),
                              child: Container(
                                width: 70,
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    colors: [
                                      Colors.transparent,
                                      Colors.white.withOpacity(0.6),
                                      Colors.transparent,
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                      Text(
                        'Novarch Project',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: _MC.text,
                          fontSize: 24,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 2,
                          fontFamily: 'Deskripsi',
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
        const SizedBox(height: 14),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 24,
              height: 1.5,
              color: _MC.accent.withOpacity(0.7),
            ),
            const SizedBox(width: 10),
            Text(
              'LIQUID GLASS EXPERIENCE',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: _MC.textSub,
                fontSize: 10,
                fontWeight: FontWeight.w800,
                letterSpacing: 3.0,
              ),
            ),
            const SizedBox(width: 10),
            Container(
              width: 24,
              height: 1.5,
              color: _MC.accent.withOpacity(0.7),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildQuote() {
    return Column(
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(16),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(
                color: _MC.glassWhite,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: Colors.white.withOpacity(0.45), width: 1.3),
                boxShadow: [
                  BoxShadow(
                    color: _MC.shadowColor,
                    offset: const Offset(0, 6),
                    blurRadius: 16,
                  ),
                  BoxShadow(
                    color: Colors.white.withOpacity(0.2),
                    blurRadius: 2,
                    spreadRadius: -1,
                  ),
                ],
              ),
              child: Text(
                '“Setiap perjalanan dimulai dari satu langkah.”',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: _MC.text,
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  fontStyle: FontStyle.italic,
                  height: 1.4,
                ),
              ),
            ),
          ),
        ),
        const SizedBox(height: 12),
        Text(
          'Powered By @NovarchTeam',
          textAlign: TextAlign.center,
          style: TextStyle(
            color: _MC.amber,
            fontSize: 9,
            fontWeight: FontWeight.w900,
            letterSpacing: 1.4,
          ),
        ),
      ],
    );
  }

  Widget _buildStatusCard() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(20),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          decoration: BoxDecoration(
            color: _MC.glassWhite,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: Colors.white.withOpacity(0.5), width: 1.5),
            boxShadow: [
              BoxShadow(
                color: _MC.shadowColor,
                offset: const Offset(0, 8),
                blurRadius: 20,
              ),
              BoxShadow(
                color: Colors.white.withOpacity(0.25),
                blurRadius: 2,
                spreadRadius: -1,
              ),
            ],
          ),
          child: Row(
            children: [
              _buildStatusIcon(),
              const SizedBox(width: 13),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      _videoReady ? 'SYSTEM READY' : 'INITIALIZING SYSTEM',
                      style: TextStyle(
                        color: _MC.text,
                        fontSize: 11,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1.1,
                        fontFamily: 'Astral',
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      _videoReady
                          ? 'Preparing your dashboard...'
                          : 'Loading splash experience...',
                      style: TextStyle(
                        color: _MC.textSub,
                        fontSize: 9.5,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
              AnimatedBuilder(
                animation: _pulseController,
                builder: (_, __) {
                  return Opacity(
                    opacity: 0.45 + (_pulseController.value * 0.55),
                    child: Container(
                      width: 34,
                      height: 34,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: _MC.accent.withOpacity(0.25),
                        border: Border.all(color: Colors.white.withOpacity(0.5), width: 1),
                        boxShadow: [
                          BoxShadow(
                            color: _MC.liquidGlow,
                            offset: const Offset(0, 0),
                            blurRadius: 10,
                            spreadRadius: 1,
                          ),
                        ],
                      ),
                      child: Icon(
                        Icons.wifi_tethering_rounded,
                        color: _MC.accent,
                        size: 18,
                      ),
                    ),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStatusIcon() {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 350),
      curve: Curves.easeOutCubic,
      width: 42,
      height: 42,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: _videoReady
            ? _MC.green.withOpacity(0.25)
            : _MC.amber.withOpacity(0.25),
        border: Border.all(
          color: _videoReady ? _MC.green.withOpacity(0.7) : _MC.amber.withOpacity(0.7),
          width: 1.5,
        ),
        boxShadow: [
          BoxShadow(
            color: (_videoReady ? _MC.green : _MC.amber).withOpacity(0.4),
            blurRadius: 12,
            spreadRadius: 1,
          ),
        ],
      ),
      child: Icon(
        _videoReady ? Icons.check_rounded : Icons.bolt_rounded,
        color: _videoReady ? _MC.green : _MC.amber,
        size: 21,
      ),
    );
  }

  Widget _buildBottomProgress() {
    final timeLabel = _videoReady && _videoDuration > Duration.zero
        ? '${_fmtDuration(_videoPosition)} / ${_fmtDuration(_videoDuration)}'
        : 'LOADING';

    final percentLabel = _videoReady
        ? '${(_videoProgress * 100).round()}%'
        : '--%';

    return Positioned(
      left: 28,
      right: 28,
      bottom: 60,
      child: AnimatedOpacity(
        duration: const Duration(milliseconds: 600),
        curve: Curves.easeOutCubic,
        opacity: _videoReady ? 1.0 : 0.35,
        child: Column(
          children: [
            Row(
              children: [
                Text(
                  timeLabel,
                  style: TextStyle(
                    color: _MC.textSub,
                    fontSize: 9,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1,
                  ),
                ),
                const Spacer(),
                Text(
                  '$percentLabel  •  Novarch',
                  style: TextStyle(
                    color: _MC.textSub,
                    fontSize: 9,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            ClipRRect(
              borderRadius: BorderRadius.circular(20),
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
                child: Container(
                  height: 10,
                  decoration: BoxDecoration(
                    color: _MC.glassWhite,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: Colors.white.withOpacity(0.4), width: 1),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.white.withOpacity(0.2),
                        blurRadius: 2,
                        spreadRadius: -1,
                      ),
                    ],
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(18),
                    child: Container(
                      height: 8,
                      margin: const EdgeInsets.all(1),
                      color: Colors.black.withOpacity(0.2),
                      child: FractionallySizedBox(
                        alignment: Alignment.centerLeft,
                        widthFactor: _videoReady ? _videoProgress : 0.18,
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 350),
                          curve: Curves.easeOutCubic,
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [
                                _MC.accent.withOpacity(0.8),
                                _MC.accent,
                                _MC.accentMid,
                              ],
                            ),
                            borderRadius: BorderRadius.circular(18),
                            boxShadow: [
                              BoxShadow(
                                color: _MC.liquidGlow,
                                offset: const Offset(0, 0),
                                blurRadius: 8,
                                spreadRadius: 0,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSkipBadge() {
    return Positioned(
      top: 20,
      right: 20,
      child: SafeArea(
        child: AnimatedBuilder(
          animation: _badgeSwing,
          builder: (_, __) {
            return Transform.rotate(
              angle: _badgeSwing.value,
              child: GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: _navigate,
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(16),
                  child: BackdropFilter(
                    filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                      decoration: BoxDecoration(
                        color: _MC.glassWhite,
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: Colors.white.withOpacity(0.5), width: 1.5),
                        boxShadow: [
                          BoxShadow(
                            color: _MC.shadowColor,
                            offset: const Offset(0, 4),
                            blurRadius: 10,
                          ),
                          BoxShadow(
                            color: Colors.white.withOpacity(0.25),
                            blurRadius: 2,
                            spreadRadius: -1,
                          ),
                        ],
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            Icons.skip_next_rounded,
                            color: _MC.text,
                            size: 18,
                          ),
                          const SizedBox(width: 6),
                          Text(
                            'SKIP INTRO',
                            style: TextStyle(
                              color: _MC.text,
                              fontSize: 12,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 2,
                              fontFamily: 'Astral',
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

class _OrbitRingPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width * 0.48;

    final paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5
      ..strokeCap = StrokeCap.round;

    const dashCount = 24;
    for (int i = 0; i < dashCount; i++) {
      final angle = (i / dashCount) * math.pi * 2;
      final startAngle = angle;
      final sweepAngle = (math.pi * 2) / dashCount * 0.5;

      paint.color = i % 2 == 0
          ? _MC.accent.withOpacity(0.65)
          : _MC.amber.withOpacity(0.3);

      canvas.drawArc(
        Rect.fromCircle(center: center, radius: radius),
        startAngle,
        sweepAngle,
        false,
        paint,
      );
    }

    final dotAngle = -math.pi / 2;
    final dotPos = Offset(
      center.dx + radius * math.cos(dotAngle),
      center.dy + radius * math.sin(dotAngle),
    );

    final dotPaint = Paint()
      ..color = _MC.accent
      ..style = PaintingStyle.fill;

    canvas.drawCircle(dotPos, 3.5, dotPaint);

    final dotGlow = Paint()
      ..color = _MC.liquidGlow
      ..style = PaintingStyle.fill
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 5);

    canvas.drawCircle(dotPos, 7, dotGlow);
  }

  @override
  bool shouldRepaint(covariant _OrbitRingPainter oldDelegate) => false;
}

class _CosmicPainter extends CustomPainter {
  final double progress;
  final double orbit;

  _CosmicPainter({
    required this.progress,
    required this.orbit,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final random = math.Random(2026);
    final particlePaint = Paint()..style = PaintingStyle.fill;

    final particleColor = ThemeModeManager.isMonochrome
        ? Colors.black.withOpacity(0.08)
        : _MC.accent.withOpacity(0.3);

    for (int i = 0; i < 50; i++) {
      final x = random.nextDouble() * size.width;
      final baseY = random.nextDouble() * size.height;
      final movement = math.sin((progress * math.pi * 2) + i) * 6;
      final y = baseY + movement;
      final radius = 0.4 + random.nextDouble() * 1.2;
      final opacity = 0.12 + 0.28 * (0.5 + 0.5 * math.sin((progress * math.pi * 2) + i));

      particlePaint.color = particleColor.withOpacity(opacity.clamp(0.05, 0.45));
      canvas.drawCircle(Offset(x, y), radius, particlePaint);
    }

    final center = Offset(size.width * 0.5, size.height * 0.42);
    final ringPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5
      ..color = _MC.accent.withOpacity(0.25);

    final rotation = progress * math.pi * 2;

    canvas.save();
    canvas.translate(center.dx, center.dy);
    canvas.rotate(rotation);
    canvas.drawOval(
      Rect.fromCenter(
        center: Offset.zero,
        width: size.width * 0.85,
        height: size.width * 0.28,
      ),
      ringPaint,
    );
    canvas.restore();

    final glowPaint = Paint()
      ..shader = RadialGradient(
        colors: [
          _MC.accent.withOpacity(0.22),
          _MC.accent.withOpacity(0.0),
        ],
      ).createShader(
        Rect.fromCircle(center: center, radius: size.width * 0.45),
      );
    canvas.drawCircle(center, size.width * 0.45, glowPaint);
  }

  @override
  bool shouldRepaint(covariant _CosmicPainter oldDelegate) {
    return oldDelegate.progress != progress || oldDelegate.orbit != orbit;
  }
}
