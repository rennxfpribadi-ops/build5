// owner_page.dart
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:async';
import 'dart:ui';
import 'dart:io';
import 'package:image_picker/image_picker.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

import 'theme.dart';

const String kFont = 'Pek';
const String _kBase = 'http://cp.zyrostore.id:3448';

class _C {
  static Color get bg        => AppColors.bg;
  static Color get surface   => AppColors.dark;
  static Color get card      => AppColors.card;
  static Color get cardAlt   => AppColors.card2;
  static Color get border    => AppColors.border;
  static Color get borderLit => AppColors.borderLit;
  static Color get primary    => AppColors.accent;
  static Color get primaryMid => AppColors.accentMid;
  static Color get primaryLt  => AppColors.accentLight;
  static Color get primaryDk  => AppColors.accentDark;
  static Color get green => AppColors.green;
  static Color get amber => AppColors.amber;
  static Color get red   => AppColors.red;
  static Color get text    => AppColors.text;
  static Color get textSub => AppColors.textSub;
  static Color get textDim => AppColors.textHint;
  static LinearGradient get btnGrad => AppColors.btnGrad;
  static LinearGradient get glassGrad => AppColors.glassGrad;
  static List<BoxShadow> get glassShadow => AppColors.glassShadow;
  static List<BoxShadow> get softShadow => AppColors.softShadow;
}

Color _onAccent() =>
    ThemeModeManager.isComic3d ? const Color(0xFF1A1A1A) : Colors.white;

class OwnerPage extends StatefulWidget {
  final String sessionKey;
  final String username;

  const OwnerPage({
    super.key,
    required this.sessionKey,
    required this.username,
  });

  @override
  State<OwnerPage> createState() => _OwnerPageState();
}

class _OwnerPageState extends State<OwnerPage> {
  int _navIndex = 0;
  late String sessionKey;

  // Create State
  String selectedAccountType = 'member';
  final createUsernameController = TextEditingController();
  final createPasswordController = TextEditingController();
  File? _selectedImage;
  final ImagePicker _picker = ImagePicker();

  // Member: pilih paket durasi
  int _selectedMemberDays = 1;

  // List State
  List<dynamic> fullUserList = [];
  List<dynamic> filteredList = [];
  final List<String> roleOptions = ['reseller', 'fullup', 'member'];
  String selectedRole = 'member';
  int currentPage = 1;
  int itemsPerPage = 25;

  final deleteController = TextEditingController();
  bool isLoading = false;

  // ── PAKET MEMBER (fixed price) ──
  final Map<int, int> memberPackages = {
    1: 2000,
    3: 5000,
    7: 10000,
    14: 12000,
    30: 15000,
  };

  // ── PAKET FULLUP & RESELLER ──
  static const int fullupPrice = 35000;
  static const int resellerPrice = 70000;

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    _fetchUsers();
  }

  @override
  void dispose() {
    createUsernameController.dispose();
    createPasswordController.dispose();
    deleteController.dispose();
    super.dispose();
  }

  Future<void> _fetchUsers() async {
    setState(() => isLoading = true);
    try {
      final res = await http.get(Uri.parse('$_kBase/listUsers?key=$sessionKey'));
      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['authorized'] == true) {
        fullUserList = data['users'] ?? [];
        _filterAndPaginate();
      } else {
        _alert("Info", data['message'] ?? 'Gagal memuat user.');
      }
    } catch (_) {
      _alert("Error", "Gagal terhubung ke server.");
    }
    setState(() => isLoading = false);
  }

  void _filterAndPaginate() {
    setState(() {
      currentPage = 1;
      filteredList = fullUserList.where((u) => u['role'] == selectedRole).toList();
    });
  }

  List<dynamic> _getCurrentPageData() {
    final start = (currentPage - 1) * itemsPerPage;
    final end = (start + itemsPerPage);
    return filteredList.sublist(
      start, end > filteredList.length ? filteredList.length : end,
    );
  }

  int get totalPages => (filteredList.length / itemsPerPage).ceil();

  Future<void> _pickImage() async {
    try {
      final XFile? image = await _picker.pickImage(source: ImageSource.gallery);
      if (image != null) setState(() => _selectedImage = File(image.path));
    } catch (e) {
      _alert("Error", "Gagal memilih gambar: $e");
    }
  }

  int get _currentPrice {
    if (selectedAccountType == 'member') {
      return memberPackages[_selectedMemberDays] ?? 2000;
    } else if (selectedAccountType == 'fullup') {
      return fullupPrice;
    } else {
      return resellerPrice;
    }
  }

  // ═══════════════════════════════════════════════════════════════════
  //  SUBMIT
  // ═══════════════════════════════════════════════════════════════════
  Future<void> _submitCreate() async {
    final u = createUsernameController.text.trim();
    final p = createPasswordController.text.trim();

    if (u.isEmpty || p.isEmpty) {
      _alert("Peringatan", "Username dan Password wajib diisi.");
      return;
    }
    if (u.length < 3) {
      _alert("Error", "Username minimal 3 karakter.");
      return;
    }
    if (p.length < 2) {
      _alert("Error", "Password minimal 2 karakter.");
      return;
    }

    // ── MEMBER: LANGSUNG CREATE (tanpa QRIS) ──
    if (selectedAccountType == 'member') {
      await _directCreateMember(
        username: u,
        password: p,
        days: _selectedMemberDays,
      );
      return;
    }

    // ── FULLUP / RESELLER: via QRIS ──
    if (_selectedImage == null) {
      _alert("Peringatan", "Foto bukti transaksi wajib diunggah.");
      return;
    }

    int finalDays = 9999;
    String paketId = selectedAccountType == 'fullup' ? 'member_perm' : 'reseller_perm';

    if (!mounted) return;
    _showQrisDialog(
      username: u,
      password: p,
      days: finalDays,
      role: selectedAccountType,
      paketId: paketId,
      imageFile: _selectedImage!,
    );
  }

  // ── DIRECT CREATE MEMBER (tanpa bayar) ──
  Future<void> _directCreateMember({
    required String username,
    required String password,
    required int days,
  }) async {
    setState(() => isLoading = true);
    try {
      final res = await http.post(
        Uri.parse('$_kBase/owner/createMember'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'sessionKey': sessionKey,
          'username': username,
          'password': password,
          'days': days,
        }),
      );
      final data = jsonDecode(res.body);
      setState(() => isLoading = false);

      if (data['success'] == true) {
  createUsernameController.clear();
  createPasswordController.clear();
  setState(() {
    _selectedImage = null;
    _selectedMemberDays = 1;
    selectedAccountType = 'member';
  });
  _alert("Sukses", "Member berhasil dibuat (${days} hari).");   // ✅ tanpa await
  _fetchUsers();
} else {
  _alert("Gagal", data['message'] ?? 'Gagal create member.');
}
    } catch (e) {
      setState(() => isLoading = false);
      _alert("Error", "Gagal hubungi server: $e");
    }
  }

  void _showQrisDialog({
    required String username,
    required String password,
    required int days,
    required String role,
    required String paketId,
    required File imageFile,
  }) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      isDismissible: true,
      builder: (ctx) => _QrisDialogContent(
        sessionKey: sessionKey,
        username: username,
        password: password,
        days: days,
        role: role,
        paketId: paketId,
        imageFile: imageFile,
        onSuccess: () {
          createUsernameController.clear();
          createPasswordController.clear();
          setState(() {
            _selectedImage = null;
            _selectedMemberDays = 1;
            selectedAccountType = 'member';
          });
          _fetchUsers();
        },
      ),
    );
  }

  Future<void> _deleteUser() async {
    final username = deleteController.text.trim();
    if (username.isEmpty) {
      _alert("Peringatan", "Masukkan username yang ingin dihapus.");
      return;
    }
    setState(() => isLoading = true);
    try {
      final res = await http.get(
        Uri.parse('$_kBase/deleteUser?key=$sessionKey&username=$username'),
      );
      final data = jsonDecode(res.body);
      if (data['deleted'] == true) {
        _alert("Sukses", "User berhasil dihapus.");
        deleteController.clear();
        _fetchUsers();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal menghapus user.');
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  void _alert(String title, String message) {
    final isComic = ThemeModeManager.isComic3d;
    showDialog(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(isComic ? 6 : 20),
          child: BackdropFilter(
            filter: ImageFilter.blur(
              sigmaX: isComic ? 0 : 15,
              sigmaY: isComic ? 0 : 15,
            ),
            child: Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                gradient: isComic ? null : _C.glassGrad,
                color: isComic ? AppColors.card : null,
                borderRadius: BorderRadius.circular(isComic ? 6 : 20),
                border: Border.all(color: _C.border, width: AppColors.borderWidth),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.info_outline_rounded, color: _C.primaryLt, size: 40),
                  const SizedBox(height: 12),
                  Text(title, style: TextStyle(color: _C.text, fontFamily: kFont, fontSize: 16, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  Text(message, textAlign: TextAlign.center,
                      style: TextStyle(color: _C.textSub, fontFamily: kFont, fontSize: 13, height: 1.5)),
                  const SizedBox(height: 20),
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 12),
                      decoration: BoxDecoration(
                        gradient: _C.btnGrad,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text("OK", style: TextStyle(color: _onAccent(), fontFamily: kFont, fontWeight: FontWeight.bold)),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTopNav() {
    final isComic = ThemeModeManager.isComic3d;
    final items = ['Buat', 'List', 'Delete'];
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: _C.surface,
        borderRadius: BorderRadius.circular(isComic ? 4 : 12),
        border: Border.all(color: _C.border, width: AppColors.borderWidth),
      ),
      child: Row(
        children: List.generate(items.length, (index) {
          final isActive = _navIndex == index;
          return Expanded(
            child: GestureDetector(
              onTap: () {
                setState(() => _navIndex = index);
                if (index == 1) _fetchUsers();
              },
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                padding: const EdgeInsets.symmetric(vertical: 10),
                decoration: BoxDecoration(
                  color: isActive ? _C.card : Colors.transparent,
                  borderRadius: BorderRadius.circular(isComic ? 4 : 8),
                ),
                child: Center(
                  child: Text(
                    items[index],
                    style: TextStyle(
                      color: isActive ? _C.text : _C.textSub,
                      fontFamily: kFont,
                      fontWeight: isActive ? FontWeight.bold : FontWeight.normal,
                      fontSize: 13,
                    ),
                  ),
                ),
              ),
            ),
          );
        }),
      ),
    );
  }

  Widget _buildInput({
    required String label,
    required TextEditingController controller,
    required IconData icon,
    TextInputType type = TextInputType.text,
    String hint = "",
    bool obscure = false,
  }) {
    final isComic = ThemeModeManager.isComic3d;
    return Padding(
      padding: const EdgeInsets.only(bottom: 15),
      child: TextField(
        controller: controller,
        keyboardType: type,
        obscureText: obscure,
        style: TextStyle(color: _C.text, fontFamily: kFont),
        decoration: InputDecoration(
          labelText: label,
          hintText: hint,
          hintStyle: TextStyle(color: _C.textDim, fontFamily: kFont),
          labelStyle: TextStyle(color: _C.primaryLt, fontFamily: kFont),
          prefixIcon: Icon(icon, color: _C.primaryLt),
          filled: true,
          fillColor: _C.surface,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(isComic ? 4 : 12),
            borderSide: BorderSide(color: _C.border, width: AppColors.borderWidth),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(isComic ? 4 : 12),
            borderSide: BorderSide(color: _C.border, width: AppColors.borderWidth),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(isComic ? 4 : 12),
            borderSide: BorderSide(color: _C.primaryLt, width: 2),
          ),
        ),
      ),
    );
  }

  Widget _buildCreatePage() {
    final isComic = ThemeModeManager.isComic3d;

    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 100),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [_C.primaryDk, _C.primary],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(isComic ? 6 : 16),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    CircleAvatar(
                      backgroundColor: Colors.white.withOpacity(0.2),
                      child: const Icon(Icons.person_add, color: Colors.white),
                    ),
                    const SizedBox(width: 12),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("BUAT AKUN",
                            style: TextStyle(color: Colors.white.withOpacity(0.8),
                                fontFamily: kFont, fontSize: 10, letterSpacing: 1)),
                        Text("Jual akun baru",
                            style: TextStyle(color: Colors.white, fontFamily: kFont,
                                fontSize: 16, fontWeight: FontWeight.bold)),
                      ],
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Text(
                  "Member langsung aktif • Fullup/Reseller via QRIS",
                  style: TextStyle(color: Colors.white70, fontFamily: kFont, fontSize: 11),
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    _chipBadge("Seller ${widget.username}"),
                    const SizedBox(width: 8),
                    _chipBadge("OWNER"),
                  ],
                )
              ],
            ),
          ),
          const SizedBox(height: 20),
          _sectionTitle("JENIS AKUN"),
          _buildAccountTypeOption(
            type: 'member',
            title: 'Member (fixed package)',
            subtitle: 'Pilih durasi • langsung aktif • tanpa QRIS',
            priceInfo: 'Rp 2.000 - 15.000',
          ),
          _buildAccountTypeOption(
            type: 'fullup',
            title: 'Fullup permanent',
            subtitle: 'Foto bukti • setor 10% • via QRIS',
            priceInfo: 'Rp 35.000',
            additionalInfo: 'setor Rp 3.500',
          ),
          _buildAccountTypeOption(
            type: 'reseller',
            title: 'Reseller permanent',
            subtitle: 'Foto bukti • setor 10% • via QRIS',
            priceInfo: 'Rp 70.000',
            additionalInfo: 'setor Rp 7.000',
          ),
          const SizedBox(height: 20),
          _sectionTitle("DATA BUYER"),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: _C.card,
              borderRadius: BorderRadius.circular(isComic ? 6 : 16),
              border: Border.all(color: _C.border),
            ),
            child: Column(
              children: [
                _buildInput(
                  label: "Username buyer",
                  controller: createUsernameController,
                  icon: FontAwesomeIcons.user,
                  hint: "Username buyer",
                ),
                _buildInput(
                  label: "Password buyer",
                  controller: createPasswordController,
                  icon: FontAwesomeIcons.lock,
                  hint: "Password buyer",
                  obscure: true,
                ),
                if (selectedAccountType == 'member') ...[
                  const SizedBox(height: 8),
                  Text("PILIH PAKET DURASI",
                      style: TextStyle(color: _C.textSub, fontFamily: kFont,
                          fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 1)),
                  const SizedBox(height: 10),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: memberPackages.entries.map((e) {
                      final isActive = _selectedMemberDays == e.key;
                      return GestureDetector(
                        onTap: () => setState(() => _selectedMemberDays = e.key),
                        child: Container(
                          width: (MediaQuery.of(context).size.width - 76) / 2,
                          padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 12),
                          decoration: BoxDecoration(
                            color: isActive ? _C.primary.withOpacity(0.2) : _C.surface,
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(
                              color: isActive ? _C.primary : _C.border,
                              width: isActive ? 2 : 1,
                            ),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text("${e.key} hari",
                                  style: TextStyle(color: isActive ? _C.primaryLt : _C.text,
                                      fontFamily: kFont, fontWeight: FontWeight.bold, fontSize: 13)),
                              const SizedBox(height: 2),
                              Text("Rp ${_formatRp(e.value)}",
                                  style: TextStyle(color: _C.textSub, fontFamily: kFont, fontSize: 11)),
                            ],
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                  const SizedBox(height: 12),
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: _C.green.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: _C.green.withOpacity(0.3)),
                    ),
                    child: Row(
                      children: [
                        Icon(Icons.check_circle_outline, color: _C.green, size: 16),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            "Member $_selectedMemberDays hari langsung aktif • tanpa bayar",
                            style: TextStyle(color: _C.green, fontFamily: kFont,
                                fontSize: 11, fontWeight: FontWeight.bold),
                          ),
                        ),
                      ],
                    ),
                  ),
                ] else ...[
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: _C.amber.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: _C.amber.withOpacity(0.3)),
                    ),
                    child: Row(
                      children: [
                        Icon(Icons.warning_amber_rounded, color: _C.amber, size: 16),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            "Durasi otomatis PERMANEN (9999 hari) • Wajib upload bukti",
                            style: TextStyle(color: _C.amber, fontFamily: kFont,
                                fontSize: 11, fontWeight: FontWeight.bold),
                          ),
                        ),
                      ],
                    ),
                  ),
                ]
              ],
            ),
          ),
          if (selectedAccountType != 'member') ...[
            const SizedBox(height: 20),
            _sectionTitle("FOTO BUKTI (WAJIB)"),
            GestureDetector(
              onTap: _pickImage,
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 16),
                decoration: BoxDecoration(
                  color: _C.surface,
                  borderRadius: BorderRadius.circular(isComic ? 6 : 16),
                  border: Border.all(
                    color: _selectedImage != null ? _C.green : _C.border,
                    width: 2,
                  ),
                ),
                child: Column(
                  children: [
                    if (_selectedImage != null) ...[
                      Icon(Icons.check_circle, color: _C.green, size: 40),
                      const SizedBox(height: 10),
                      Text("Foto berhasil dipilih",
                          style: TextStyle(color: _C.green, fontFamily: kFont,
                              fontWeight: FontWeight.bold)),
                      TextButton(
                        onPressed: _pickImage,
                        child: Text("Ganti Foto",
                            style: TextStyle(color: _C.primaryLt, fontFamily: kFont)),
                      )
                    ] else ...[
                      Icon(Icons.image_outlined, color: _C.primaryLt, size: 40),
                      const SizedBox(height: 10),
                      Text("Pilih foto dari galeri",
                          style: TextStyle(color: _C.primaryLt, fontFamily: kFont,
                              fontWeight: FontWeight.bold, fontSize: 14)),
                      const SizedBox(height: 4),
                      Text("Bukti transfer akan dikirim ke owner",
                          style: TextStyle(color: _C.textSub, fontFamily: kFont, fontSize: 11)),
                    ]
                  ],
                ),
              ),
            ),
          ],
          const SizedBox(height: 30),
          Container(
            width: double.infinity,
            height: 52,
            decoration: BoxDecoration(
              gradient: _C.btnGrad,
              borderRadius: BorderRadius.circular(isComic ? 4 : 14),
            ),
            child: ElevatedButton(
              onPressed: isLoading ? null : _submitCreate,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.transparent,
                shadowColor: Colors.transparent,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(isComic ? 4 : 14)),
              ),
              child: isLoading
                  ? const SizedBox(width: 20, height: 20,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                  : Text(
                      selectedAccountType == 'member'
                          ? "BUAT MEMBER • Rp ${_formatRp(_currentPrice)}"
                          : "Submit • QRIS Rp ${_formatRp(_currentPrice)}",
                      style: TextStyle(color: _onAccent(), fontFamily: kFont,
                          fontWeight: FontWeight.bold, fontSize: 14, letterSpacing: 1),
                    ),
            ),
          ),
        ],
      ),
    );
  }

  String _formatRp(int amount) => amount.toString().replaceAllMapped(
      RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (m) => '${m[1]}.');

  Widget _chipBadge(String text) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.15),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white30),
      ),
      child: Text(text, style: TextStyle(color: Colors.white, fontFamily: kFont,
          fontSize: 10, fontWeight: FontWeight.bold)),
    );
  }

  Widget _sectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10, left: 4),
      child: Row(
        children: [
          Container(width: 4, height: 16, color: _C.primaryLt,
              margin: const EdgeInsets.only(right: 8)),
          Text(title, style: TextStyle(color: _C.textSub, fontFamily: kFont,
              fontSize: 12, fontWeight: FontWeight.bold, letterSpacing: 1)),
        ],
      ),
    );
  }

  Widget _buildAccountTypeOption({
    required String type,
    required String title,
    required String subtitle,
    required String priceInfo,
    String? additionalInfo,
  }) {
    final isSelected = selectedAccountType == type;
    final isComic = ThemeModeManager.isComic3d;
    return GestureDetector(
      onTap: () => setState(() => selectedAccountType = type),
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: isSelected ? _C.primary.withOpacity(0.1) : _C.card,
          borderRadius: BorderRadius.circular(isComic ? 6 : 16),
          border: Border.all(
            color: isSelected ? _C.primary : _C.border,
            width: isSelected ? 2 : 1,
          ),
        ),
        child: Row(
          children: [
            Icon(isSelected ? Icons.radio_button_checked : Icons.radio_button_off,
                color: isSelected ? _C.primary : _C.textDim),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: TextStyle(color: _C.text, fontFamily: kFont,
                      fontWeight: FontWeight.bold, fontSize: 14)),
                  const SizedBox(height: 4),
                  Text(subtitle, style: TextStyle(color: _C.textSub, fontFamily: kFont, fontSize: 11)),
                ],
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(priceInfo, style: TextStyle(color: _C.primaryLt, fontFamily: kFont,
                    fontWeight: FontWeight.bold, fontSize: 13)),
                if (additionalInfo != null) ...[
                  const SizedBox(height: 4),
                  Text(additionalInfo, style: TextStyle(color: _C.amber, fontFamily: kFont, fontSize: 10)),
                ]
              ],
            )
          ],
        ),
      ),
    );
  }

  Widget _buildListPage() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 100),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
            decoration: BoxDecoration(
              color: _C.surface,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: _C.border),
            ),
            child: DropdownButtonHideUnderline(
              child: DropdownButton<String>(
                value: selectedRole,
                isExpanded: true,
                dropdownColor: AppColors.card,
                style: TextStyle(color: _C.text, fontFamily: kFont),
                icon: Icon(Icons.arrow_drop_down_rounded, color: _C.primaryLt),
                items: roleOptions.map((role) {
                  return DropdownMenuItem(
                    value: role,
                    child: Text(role.toUpperCase(),
                        style: TextStyle(fontFamily: kFont, color: _C.text)),
                  );
                }).toList(),
                onChanged: (val) {
                  if (val != null) {
                    selectedRole = val;
                    _filterAndPaginate();
                  }
                },
              ),
            ),
          ),
          const SizedBox(height: 16),
          if (isLoading)
            Padding(padding: const EdgeInsets.all(30),
                child: Center(child: CircularProgressIndicator(color: _C.primaryLt)))
          else if (filteredList.isEmpty)
            Padding(
              padding: const EdgeInsets.all(30),
              child: Column(
                children: [
                  Icon(Icons.inbox_rounded, color: _C.textDim, size: 40),
                  const SizedBox(height: 10),
                  Text("Tidak ada user dengan role ini",
                      style: TextStyle(color: _C.textSub, fontFamily: kFont)),
                ],
              ),
            )
          else ...[
            ..._getCurrentPageData().map((u) => _buildUserItem(u)).toList(),
            _buildPagination(),
          ],
        ],
      ),
    );
  }

  Widget _buildUserItem(Map user) {
    final isComic = ThemeModeManager.isComic3d;
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 5),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: _C.card,
        borderRadius: BorderRadius.circular(isComic ? 4 : 14),
        border: Border.all(color: _C.border, width: AppColors.borderWidth),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: _C.primary.withOpacity(0.15),
              shape: BoxShape.circle,
              border: Border.all(color: _C.primary.withOpacity(0.3)),
            ),
            child: Icon(Icons.person_rounded, color: _C.primaryLt, size: 18),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(user['username'] ?? '-',
                    style: TextStyle(color: _C.text, fontFamily: kFont,
                        fontWeight: FontWeight.bold, fontSize: 14)),
                const SizedBox(height: 3),
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(
                        color: _C.primary.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: Text((user['role'] ?? 'member').toString().toUpperCase(),
                          style: TextStyle(color: _C.primaryLt, fontFamily: kFont,
                              fontSize: 9, fontWeight: FontWeight.bold)),
                    ),
                    const SizedBox(width: 8),
                    Icon(Icons.calendar_today_rounded, color: _C.textDim, size: 10),
                    const SizedBox(width: 4),
                    Expanded(
                      child: Text(user['expiredDate'] ?? '-',
                          style: TextStyle(color: _C.textSub, fontFamily: kFont, fontSize: 11),
                          overflow: TextOverflow.ellipsis),
                    ),
                  ],
                ),
              ],
            ),
          ),
          GestureDetector(
            onTap: () async {
              final confirm = await _confirmDialog("Hapus User?",
                  "Yakin ingin menghapus '${user['username']}'?");
              if (confirm) {
                deleteController.text = user['username'];
                _deleteUser();
              }
            },
            child: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: _C.primary.withOpacity(0.1),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: _C.primary.withOpacity(0.3)),
              ),
              child: Icon(Icons.delete_outline_rounded, color: _C.primaryLt, size: 16),
            ),
          ),
        ],
      ),
    );
  }

  Future<bool> _confirmDialog(String title, String message) async {
    final isComic = ThemeModeManager.isComic3d;
    final result = await showDialog<bool>(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: isComic ? AppColors.card : _C.card,
            borderRadius: BorderRadius.circular(isComic ? 6 : 20),
            border: Border.all(color: _C.border, width: AppColors.borderWidth),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.warning_amber_rounded, color: _C.amber, size: 40),
              const SizedBox(height: 12),
              Text(title, style: TextStyle(color: _C.text, fontFamily: kFont,
                  fontSize: 16, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              Text(message, textAlign: TextAlign.center,
                  style: TextStyle(color: _C.textSub, fontFamily: kFont,
                      fontSize: 13, height: 1.5)),
              const SizedBox(height: 20),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => Navigator.pop(context, false),
                      style: OutlinedButton.styleFrom(
                        side: BorderSide(color: _C.border),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(isComic ? 4 : 12)),
                        padding: const EdgeInsets.symmetric(vertical: 12),
                      ),
                      child: Text("Batal",
                          style: TextStyle(color: _C.textSub, fontFamily: kFont)),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Container(
                      decoration: BoxDecoration(
                        gradient: _C.btnGrad,
                        borderRadius: BorderRadius.circular(isComic ? 4 : 12),
                      ),
                      child: TextButton(
                        onPressed: () => Navigator.pop(context, true),
                        style: TextButton.styleFrom(
                            padding: const EdgeInsets.symmetric(vertical: 12)),
                        child: Text("Hapus",
                            style: TextStyle(color: _onAccent(), fontFamily: kFont,
                                fontWeight: FontWeight.bold)),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
    return result ?? false;
  }

  Widget _buildPagination() {
    if (totalPages <= 1) return const SizedBox.shrink();
    final isComic = ThemeModeManager.isComic3d;
    return Padding(
      padding: const EdgeInsets.only(top: 15),
      child: Wrap(
        spacing: 8,
        runSpacing: 8,
        alignment: WrapAlignment.center,
        children: List.generate(totalPages, (index) {
          final page = index + 1;
          final isActive = currentPage == page;
          return GestureDetector(
            onTap: () => setState(() => currentPage = page),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
              decoration: BoxDecoration(
                gradient: isActive ? _C.btnGrad : null,
                color: isActive ? null : _C.surface,
                borderRadius: BorderRadius.circular(isComic ? 4 : 8),
                border: Border.all(
                    color: isActive ? _C.primary : _C.border,
                    width: AppColors.borderWidth),
              ),
              child: Text("$page",
                  style: TextStyle(color: isActive ? _onAccent() : _C.textSub,
                      fontFamily: kFont, fontSize: 12, fontWeight: FontWeight.bold)),
            ),
          );
        }),
      ),
    );
  }

  Widget _buildDeletePage() {
    final isComic = ThemeModeManager.isComic3d;
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 100),
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: _C.card,
          borderRadius: BorderRadius.circular(isComic ? 6 : 16),
          border: Border.all(color: _C.border),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              "Masukkan username yang ingin dihapus. Aksi ini tidak bisa dibatalkan.",
              style: TextStyle(color: _C.textSub, fontFamily: kFont, fontSize: 12, height: 1.5),
            ),
            const SizedBox(height: 16),
            _buildInput(
              label: "Username Target",
              controller: deleteController,
              icon: FontAwesomeIcons.userEdit,
              hint: "Username yang ingin dihapus",
            ),
            const SizedBox(height: 10),
            Container(
              height: 52,
              decoration: BoxDecoration(
                gradient: _C.btnGrad,
                borderRadius: BorderRadius.circular(isComic ? 4 : 14),
              ),
              child: ElevatedButton(
                onPressed: isLoading ? null : _deleteUser,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.transparent,
                  shadowColor: Colors.transparent,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(isComic ? 4 : 14)),
                ),
                child: isLoading
                    ? const SizedBox(width: 20, height: 20,
                        child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                    : Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(FontAwesomeIcons.trash, color: _onAccent(), size: 18),
                          const SizedBox(width: 10),
                          Text("HAPUS USER",
                              style: TextStyle(color: _onAccent(), fontFamily: kFont,
                                  fontWeight: FontWeight.bold, fontSize: 14, letterSpacing: 1)),
                        ],
                      ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppThemeMode>(
      valueListenable: ThemeModeManager.current,
      builder: (context, _, __) {
        return Scaffold(
          backgroundColor: _C.bg,
          extendBody: true,
          body: AppBackground(
            imagePath: 'assets/images/mmk.jpg',
            child: SafeArea(
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
                    child: Row(
                      children: [
                        GestureDetector(
                          onTap: () => Navigator.pop(context),
                          child: Icon(Icons.arrow_back, color: _C.primaryLt, size: 24),
                        ),
                        const SizedBox(width: 16),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text("Akses jualan",
                                style: TextStyle(color: _C.primaryLt, fontFamily: kFont,
                                    fontSize: 18, fontWeight: FontWeight.bold)),
                            Text("${widget.username} • OWNER",
                                style: TextStyle(color: _C.textSub, fontFamily: kFont, fontSize: 11)),
                          ],
                        ),
                      ],
                    ),
                  ),
                  _buildTopNav(),
                  Expanded(
                    child: AnimatedSwitcher(
                      duration: const Duration(milliseconds: 250),
                      child: KeyedSubtree(
                        key: ValueKey(_navIndex),
                        child: _navIndex == 0
                            ? _buildCreatePage()
                            : _navIndex == 1
                                ? _buildListPage()
                                : _buildDeletePage(),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════
//  QRIS DIALOG (Untuk Fullup / Reseller — via Pakasir)
// ═══════════════════════════════════════════════════════════════════════
class _QrisDialogContent extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String password;
  final int days;
  final String role;
  final String paketId;
  final File imageFile;
  final VoidCallback onSuccess;

  const _QrisDialogContent({
    required this.sessionKey,
    required this.username,
    required this.password,
    required this.days,
    required this.role,
    required this.paketId,
    required this.imageFile,
    required this.onSuccess,
  });

  @override
  State<_QrisDialogContent> createState() => _QrisDialogContentState();
}

class _QrisDialogContentState extends State<_QrisDialogContent> {
  bool _loading = true;
  String? _depositId;
  String? _qrUrl;
  int _totalPayment = 0;
  Timer? _pollTimer;
  bool _success = false;
  int _sisaWaktu = 900;
  String? _errorMsg;

  @override
  void initState() {
    super.initState();
    _uploadAndCreateInvoice();
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    super.dispose();
  }

  Future<void> _uploadAndCreateInvoice() async {
    setState(() {
      _loading = true;
      _errorMsg = null;
    });
    try {
      var request = http.MultipartRequest('POST', Uri.parse('$_kBase/buy/createSetoran'));
      request.fields['sessionKey'] = widget.sessionKey;
      request.fields['paketId'] = widget.paketId;
      request.fields['username'] = widget.username;
      request.fields['password'] = widget.password;
      request.fields['role'] = widget.role;
      request.fields['days'] = widget.days.toString();

      request.files.add(await http.MultipartFile.fromPath('proof', widget.imageFile.path));

      var streamedResponse = await request.send();
      var response = await http.Response.fromStream(streamedResponse);
      final data = jsonDecode(response.body);

      if (data['success'] == true) {
        setState(() {
          _depositId = data['depositId'];
          _qrUrl = data['qrUrl'];
          _totalPayment = data['totalPayment'] ?? 0;
          _loading = false;
        });
        _startPolling();
        _startTimer();
      } else {
        setState(() {
          _loading = false;
          _errorMsg = data['message'] ?? 'Gagal buat invoice';
        });
      }
    } catch (e) {
      setState(() {
        _loading = false;
        _errorMsg = 'Error: $e';
      });
    }
  }

  void _startTimer() {
    Future.doWhile(() async {
      await Future.delayed(const Duration(seconds: 1));
      if (!mounted || _success) return false;
      if (_sisaWaktu > 0) setState(() => _sisaWaktu--);
      return _sisaWaktu > 0;
    });
  }

  void _startPolling() {
    _pollTimer?.cancel();
    _pollTimer = Timer.periodic(const Duration(seconds: 5), (_) async {
      if (!mounted || _depositId == null) return;
      try {
        final res = await http.post(
          Uri.parse('$_kBase/buy/createSetoran/status'),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({
            'sessionKey': widget.sessionKey,
            'depositId': _depositId,
          }),
        );
        final data = jsonDecode(res.body);

        if (data['status'] == 'success') {
          _pollTimer?.cancel();
          if (mounted) {
            setState(() => _success = true);
            widget.onSuccess();
          }
        } else if (data['status'] == 'expired' ||
            data['status'] == 'cancelled') {
          _pollTimer?.cancel();
          if (mounted) {
            setState(() {
              _loading = false;
              _errorMsg = 'Invoice expired. Silakan buat ulang.';
            });
          }
        }
      } catch (_) {}
    });
  }

  Future<void> _cancelInvoice() async {
    _pollTimer?.cancel();
    if (_depositId != null) {
      try {
        await http.post(
          Uri.parse('$_kBase/buy/createSetoran/cancel'),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({
            'sessionKey': widget.sessionKey,
            'depositId': _depositId,
          }),
        );
      } catch (_) {}
    }
    if (mounted) Navigator.pop(context);
  }

  String _formatTime(int totalSeconds) {
    final m = totalSeconds ~/ 60;
    final s = totalSeconds % 60;
    return '${m.toString().padLeft(2, '0')}:${s.toString().padLeft(2, '0')}';
  }

  String _formatRp(int amount) => amount.toString().replaceAllMapped(
      RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (m) => '${m[1]}.');

  @override
  Widget build(BuildContext context) {
    final isComic = ThemeModeManager.isComic3d;
    return Container(
      margin: const EdgeInsets.all(16),
      padding: EdgeInsets.fromLTRB(20, 20, 20,
          MediaQuery.of(context).viewInsets.bottom + 24),
      decoration: BoxDecoration(
        gradient: isComic ? null : _C.glassGrad,
        color: isComic ? AppColors.card : null,
        borderRadius: BorderRadius.circular(isComic ? 6 : 26),
        border: Border.all(color: _C.border, width: AppColors.borderWidth),
        boxShadow: _C.glassShadow,
      ),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 36, height: 4,
              decoration: BoxDecoration(color: _C.border,
                  borderRadius: BorderRadius.circular(2)),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Icon(_success ? Icons.check_circle_rounded : Icons.qr_code_2_rounded,
                    color: _success ? _C.green : _C.primaryLt, size: 22),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    _success ? 'AKUN DIBUAT!' : 'BAYAR Rp${_formatRp(_totalPayment)}',
                    style: TextStyle(color: _C.text, fontFamily: kFont,
                        fontSize: 15, fontWeight: FontWeight.w800, letterSpacing: 1),
                  ),
                ),
                if (!_success)
                  GestureDetector(
                    onTap: _cancelInvoice,
                    child: Icon(Icons.close_rounded, color: _C.textDim, size: 20),
                  ),
              ],
            ),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: _C.surface,
                borderRadius: BorderRadius.circular(isComic ? 4 : 12),
                border: Border.all(color: _C.border),
              ),
              child: Column(
                children: [
                  _row("Username", widget.username),
                  _row("Password", widget.password),
                  _row("Role", widget.role.toUpperCase()),
                  _row("Durasi", "${widget.days} hari"),
                ],
              ),
            ),
            const SizedBox(height: 16),
            if (_loading)
              Padding(
                padding: const EdgeInsets.all(30),
                child: Center(
                  child: Column(
                    children: [
                      CircularProgressIndicator(color: _C.primaryLt),
                      const SizedBox(height: 12),
                      Text('Membuat invoice & mengirim bukti...',
                          style: TextStyle(color: _C.textSub, fontFamily: kFont, fontSize: 12)),
                    ],
                  ),
                ),
              )
            else if (_errorMsg != null)
              _errorView(isComic)
            else if (_success)
              _successView(isComic)
            else if (_qrUrl != null)
              _qrView(isComic),
          ],
        ),
      ),
    );
  }

  Widget _row(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Text(label, style: TextStyle(color: _C.textSub, fontFamily: kFont, fontSize: 11)),
          const Spacer(),
          Text(value, style: TextStyle(color: _C.text, fontFamily: kFont,
              fontSize: 12, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }

  Widget _errorView(bool isComic) {
    return Column(
      children: [
        Icon(Icons.error_outline, color: _C.red, size: 40),
        const SizedBox(height: 12),
        Text(_errorMsg ?? 'Terjadi kesalahan', textAlign: TextAlign.center,
            style: TextStyle(color: _C.textSub, fontFamily: kFont, fontSize: 12)),
        const SizedBox(height: 16),
        SizedBox(
          width: double.infinity, height: 44,
          child: ElevatedButton(
            onPressed: _uploadAndCreateInvoice,
            style: ElevatedButton.styleFrom(
              backgroundColor: _C.primary,
              foregroundColor: _onAccent(),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(isComic ? 4 : 12)),
            ),
            child: Text('COBA LAGI', style: TextStyle(fontFamily: kFont,
                fontWeight: FontWeight.bold, color: _onAccent())),
          ),
        ),
        const SizedBox(height: 8),
        SizedBox(
          width: double.infinity, height: 44,
          child: OutlinedButton(
            onPressed: _cancelInvoice,
            style: OutlinedButton.styleFrom(
              side: BorderSide(color: _C.border),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(isComic ? 4 : 12)),
            ),
            child: Text('BATAL', style: TextStyle(color: _C.textSub,
                fontFamily: kFont, fontWeight: FontWeight.bold,
                fontSize: 12, letterSpacing: 1)),
          ),
        ),
      ],
    );
  }

  Widget _qrView(bool isComic) {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          decoration: BoxDecoration(
            color: _C.amber.withOpacity(0.15),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: _C.amber.withOpacity(0.3)),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.timer_outlined, color: _C.amber, size: 14),
              const SizedBox(width: 6),
              Text('Kedaluwarsa dalam ${_formatTime(_sisaWaktu)}',
                  style: TextStyle(color: _C.amber, fontFamily: kFont,
                      fontSize: 11, fontWeight: FontWeight.bold)),
            ],
          ),
        ),
        const SizedBox(height: 12),
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: _C.primary.withOpacity(0.4), width: 3),
          ),
          child: Image.network(
            _qrUrl!, width: 220, height: 220, fit: BoxFit.contain,
            loadingBuilder: (_, c, p) => p == null ? c
                : const SizedBox(width: 220, height: 220,
                    child: Center(child: CircularProgressIndicator())),
            errorBuilder: (_, __, ___) => const SizedBox(width: 220, height: 220,
                child: Center(child: Icon(Icons.broken_image, size: 60))),
          ),
        ),
        const SizedBox(height: 16),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          decoration: BoxDecoration(
            color: _C.primary.withOpacity(0.15),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: _C.primary.withOpacity(0.3)),
          ),
          child: Column(
            children: [
              Text("TOTAL BAYAR", style: TextStyle(color: _C.textSub,
                  fontFamily: kFont, fontSize: 10, letterSpacing: 1)),
              const SizedBox(height: 4),
              Text("Rp ${_formatRp(_totalPayment)}",
                  style: TextStyle(color: _C.primaryLt, fontFamily: kFont,
                      fontSize: 24, fontWeight: FontWeight.w900)),
            ],
          ),
        ),
        const SizedBox(height: 12),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(width: 14, height: 14,
                child: CircularProgressIndicator(strokeWidth: 2, color: _C.primaryLt)),
            const SizedBox(width: 10),
            Text('Menunggu pembayaran...',
                style: TextStyle(color: _C.textSub, fontFamily: kFont, fontSize: 12)),
          ],
        ),
        const SizedBox(height: 14),
        SizedBox(
          width: double.infinity, height: 44,
          child: OutlinedButton(
            onPressed: _cancelInvoice,
            style: OutlinedButton.styleFrom(
              side: BorderSide(color: _C.red.withOpacity(0.5)),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(isComic ? 4 : 12)),
            ),
            child: Text('BATAL', style: TextStyle(color: _C.red,
                fontFamily: kFont, fontWeight: FontWeight.bold,
                fontSize: 12, letterSpacing: 1)),
          ),
        ),
      ],
    );
  }

  Widget _successView(bool isComic) {
    return Column(
      children: [
        Container(
          width: 80, height: 80,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: LinearGradient(colors: [_C.green, _C.primaryLt]),
            border: isComic ? Border.all(color: AppColors.border, width: 3) : null,
          ),
          child: Icon(Icons.check_rounded, color: _onAccent(), size: 40),
        ),
        const SizedBox(height: 16),
        Text('AKUN BERHASIL DIBUAT!',
            style: TextStyle(color: _C.text, fontFamily: kFont,
                fontSize: 14, fontWeight: FontWeight.w800, letterSpacing: 1)),
        const SizedBox(height: 8),
        Text('Pembayaran diterima & akun sudah aktif',
            textAlign: TextAlign.center,
            style: TextStyle(color: _C.textSub, fontFamily: kFont, fontSize: 12)),
        const SizedBox(height: 20),
        SizedBox(
          width: double.infinity, height: 46,
          child: ElevatedButton(
            onPressed: () => Navigator.pop(context),
            style: ElevatedButton.styleFrom(
              backgroundColor: _C.green,
              foregroundColor: _onAccent(),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(isComic ? 4 : 12)),
            ),
            child: Text('SELESAI',
                style: TextStyle(fontFamily: kFont,
                    fontWeight: FontWeight.bold, color: _onAccent())),
          ),
        ),
      ],
    );
  }
}