// profile_page.dart
import 'dart:io';
import 'dart:ui';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:image_picker/image_picker.dart';

import 'theme.dart';   // ← SISTEM TEMA
import 'change_password_page.dart';

// ─── GLOBAL FONT ───────────────────────────────────────────────────────
const String kFont = 'Pek';

// ─── PALETTE (alias ke AppColors dinamis) ──────────────────────────────
class _C {
  static Color get bg        => AppColors.bg;
  static Color get surface   => AppColors.dark;
  static Color get card      => AppColors.card;
  static Color get cardAlt   => AppColors.card2;
  static Color get border    => AppColors.border;
  static Color get borderLit => AppColors.borderLit;
  static Color get glassBg   => AppColors.glassGrad.colors.first;
  static Color get glassBorder => AppColors.glassBorder;

  static Color get primary      => AppColors.accentMid;
  static Color get primaryLight => AppColors.accentLight;
  static Color get primaryDark  => AppColors.accentDark;
  static Color get accent       => AppColors.accentLight;
  static Color get success      => AppColors.green;
  static Color get secondary    => AppColors.accent;
  static Color get white        => AppColors.text;
  static Color get whiteDim     => AppColors.textSub;
  static Color get black        => AppColors.bg;
  static Color get text         => AppColors.text;
  static Color get textSub      => AppColors.textSub;
  static Color get textDim      => AppColors.textHint;
  static Color get textDark     => AppColors.textHint;

  static Color get green     => AppColors.green;
  static Color get amber     => AppColors.amber;
  static Color get red       => AppColors.red;
  static Color get grey      => AppColors.accent;
  static Color get greyMid   => AppColors.accentMid;
  static Color get greyLight => AppColors.accentLight;
  static Color get greyDark  => AppColors.accentDark;

  static LinearGradient get glassGrad    => AppColors.glassGrad;
  static List<BoxShadow> get softShadow  => AppColors.softShadow;
  static List<BoxShadow> get glowShadow  => ThemeModeManager.isComic3d
      ? AppColors.softShadow
      : [
          BoxShadow(
            color: AppColors.accentMid.withOpacity(0.3),
            blurRadius: 20,
            spreadRadius: 2,
          ),
        ];
  static LinearGradient get btnGrad      => AppColors.btnGrad;
  static List<BoxShadow> get glassShadow => AppColors.glassShadow;
}

// ─── WARNA TEKS DI ATAS TOMBOL GRADIENT ────────────────────────────────
Color _onAccent() =>
    ThemeModeManager.isComic3d ? const Color(0xFF1A1A1A) : Colors.white;

// ═══════════════════════════════════════════════════════════════════════
//  ANIMASI RING BERPUTAR PADA FOTO PROFIL
// ═══════════════════════════════════════════════════════════════════════
class _SpinningRingPainter extends CustomPainter {
  final double angle;
  final bool isComic;

  _SpinningRingPainter({required this.angle, required this.isComic});

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2;

    final rect = Rect.fromCircle(center: center, radius: radius);

    final paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = isComic ? 4.0 : 3.0;

    if (isComic) {
      paint.shader = SweepGradient(
        colors: [
          _C.primary,
          _C.secondary,
          _C.primary,
        ],
        transform: GradientRotation(angle),
      ).createShader(rect);
    } else {
      paint.shader = SweepGradient(
        colors: [
          _C.primary.withOpacity(0.0),
          _C.primary.withOpacity(0.8),
          _C.secondary.withOpacity(0.9),
          _C.primary.withOpacity(0.0),
        ],
        stops: const [0.0, 0.3, 0.7, 1.0],
        transform: GradientRotation(angle),
      ).createShader(rect);
    }

    canvas.drawCircle(center, radius, paint);
  }

  @override
  bool shouldRepaint(covariant _SpinningRingPainter old) =>
      old.angle != angle || old.isComic != isComic;
}

class ProfilePage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final String uid; // UID RAT — unique per account

  const ProfilePage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
    this.uid = '',
  });

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage>
    with SingleTickerProviderStateMixin {
  File? _profileImage;
  final ImagePicker _picker = ImagePicker();
  late AnimationController _ringController;

  @override
  void initState() {
    super.initState();
    _loadProfileImage();
    // Animasi ring berputar
    _ringController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 4),
    )..repeat();
  }

  @override
  void dispose() {
    _ringController.dispose();
    super.dispose();
  }

  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final imagePath = prefs.getString('profile_image_${widget.username}');
    if (imagePath != null && imagePath.isNotEmpty) {
      setState(() => _profileImage = File(imagePath));
    }
  }

  String _censorPassword(String text) {
    if (text.isEmpty) return "N/A";
    return "••••••••••••";
  }

  void _copyToClipboard(String text, String message) async {
    if (text.isEmpty) return;
    await Clipboard.setData(ClipboardData(text: text));
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message, style: const TextStyle(fontFamily: kFont)),
        behavior: SnackBarBehavior.floating,
        backgroundColor: _C.primary,
        duration: const Duration(seconds: 2),
      ),
    );
  }

  Future<void> _showImageSourceDialog() {
    final isComic = ThemeModeManager.isComic3d;
    return showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => ClipRRect(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(isComic ? 6 : 20),
        ),
        child: BackdropFilter(
          filter: ImageFilter.blur(
            sigmaX: isComic ? 0 : 15,
            sigmaY: isComic ? 0 : 15,
          ),
          child: Container(
            decoration: BoxDecoration(
              gradient: isComic ? null : _C.glassGrad,
              color: isComic ? AppColors.card : null,
              borderRadius: BorderRadius.vertical(
                top: Radius.circular(isComic ? 6 : 20),
              ),
              border: Border.all(
                color: _C.glassBorder,
                width: AppColors.borderWidth,
              ),
              boxShadow: _C.glassShadow,
            ),
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Center(
                  child: Container(
                    width: 40, height: 4,
                    decoration: BoxDecoration(
                      color: _C.whiteDim.withOpacity(0.3),
                      borderRadius: BorderRadius.circular(4),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Container(
                      width: 4, height: 18,
                      decoration: BoxDecoration(
                        gradient: _C.btnGrad,
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Text(
                      'PILIH GAMBAR',
                      style: TextStyle(
                        color: _C.white,
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 0.5,
                        fontFamily: kFont,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                _ActionItem(
                  icon: Icons.camera_alt,
                  color: _C.primary,
                  title: 'Kamera',
                  subtitle: 'Ambil foto dari kamera',
                  onTap: () {
                    Navigator.pop(context);
                    _pickImage(ImageSource.camera);
                  },
                ),
                const SizedBox(height: 10),
                _ActionItem(
                  icon: Icons.photo_library,
                  color: _C.secondary,
                  title: 'Galeri',
                  subtitle: 'Pilih dari galeri',
                  onTap: () {
                    Navigator.pop(context);
                    _pickImage(ImageSource.gallery);
                  },
                ),
                const SizedBox(height: 8),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _pickImage(ImageSource source) async {
    try {
      final XFile? pickedFile = await _picker.pickImage(
          source: source, imageQuality: 70);
      if (pickedFile != null) {
        final File imageFile = File(pickedFile.path);
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString(
            'profile_image_${widget.username}', imageFile.path);
        setState(() => _profileImage = imageFile);
      }
    } catch (e) {
      debugPrint("Error picking image: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    // ⚡ AUTO REBUILD SAAT TEMA GANTI
    return ValueListenableBuilder<AppThemeMode>(
      valueListenable: ThemeModeManager.current,
      builder: (context, _, __) {
        final isComic = ThemeModeManager.isComic3d;

        return Scaffold(
          backgroundColor: _C.bg,
          // Background sederhana dengan sentuhan gradient/glass
          body: Stack(
            children: [
              // Layer 1: Background Dasar
              if (isComic)
                Container(color: _C.bg)
              else
                Positioned.fill(
                  child: BackdropFilter(
                    filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
                    child: Container(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: [
                            _C.bg,
                            _C.primaryDark.withOpacity(0.2),
                            _C.bg,
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              
              // Layer 2: Konten Utama
              SafeArea(
                child: SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // ─── TOMBOL BACK ───
                      IconButton(
                        onPressed: () => Navigator.pop(context),
                        icon: Icon(Icons.arrow_back_ios_new_rounded, color: _C.primary),
                        style: IconButton.styleFrom(
                          backgroundColor: isComic ? _C.card : Colors.transparent,
                          side: isComic ? BorderSide(color: _C.border, width: 2) : BorderSide.none,
                        ),
                      ),
                      const SizedBox(height: 10),

                      // ─── FOTO PROFIL & RING BERPUTAR ───
                      Center(
                        child: GestureDetector(
                          onTap: _showImageSourceDialog,
                          child: Stack(
                            alignment: Alignment.center,
                            children: [
                              // Ring Berputar (Animasi)
                              AnimatedBuilder(
                                animation: _ringController,
                                builder: (context, child) {
                                  return CustomPaint(
                                    size: const Size(130, 130),
                                    painter: _SpinningRingPainter(
                                      angle: _ringController.value * 2 * math.pi,
                                      isComic: isComic,
                                    ),
                                  );
                                },
                              ),
                              // Foto Profil
                              Container(
                                width: 116,
                                height: 116,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: _C.card,
                                  border: Border.all(
                                    color: isComic ? _C.bg : Colors.transparent,
                                    width: 4,
                                  ),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black.withOpacity(isComic ? 0.1 : 0.3),
                                      blurRadius: 20,
                                      offset: const Offset(0, 10),
                                    )
                                  ],
                                ),
                                child: ClipOval(
                                  child: _profileImage != null
                                      ? Image.file(_profileImage!, fit: BoxFit.cover)
                                      : Icon(
                                          Icons.person_rounded,
                                          size: 60,
                                          color: _C.textDim,
                                        ),
                                ),
                              ),
                              // Tombol Edit (Kamera)
                              Positioned(
                                bottom: 4,
                                right: 4,
                                child: Container(
                                  padding: const EdgeInsets.all(8),
                                  decoration: BoxDecoration(
                                    color: _C.primary,
                                    shape: BoxShape.circle,
                                    border: Border.all(
                                      color: isComic ? _C.bg : Colors.white.withOpacity(0.2),
                                      width: 2,
                                    ),
                                    boxShadow: _C.softShadow,
                                  ),
                                  child: Icon(
                                    Icons.edit_rounded,
                                    size: 16,
                                    color: _onAccent(),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(height: 20),

                      // ─── USERNAME ───
                      Center(
                        child: Text(
                          widget.username.toUpperCase(),
                          style: TextStyle(
                            color: _C.white,
                            fontSize: 24,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 1.5,
                            fontFamily: kFont,
                          ),
                        ),
                      ),
                      const SizedBox(height: 8),

                      // ─── ROLE BADGE ───
                      Center(
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                          decoration: BoxDecoration(
                            color: isComic ? _C.primary : Colors.transparent,
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(
                              color: isComic ? _C.border : _C.primary.withOpacity(0.3),
                              width: isComic ? 2 : 1,
                            ),
                          ),
                          child: Text(
                            widget.role.toUpperCase(),
                            style: TextStyle(
                              color: isComic ? _onAccent() : _C.primary,
                              fontSize: 11,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 1.2,
                              fontFamily: kFont,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 35),

                      // ─── SECTION: INFO AKUN ───
                      _buildSectionTitle('INFO AKUN', isComic),
                      const SizedBox(height: 12),
                      
                      _buildListCard(
                        isComic: isComic,
                        icon: Icons.alternate_email_rounded,
                        label: 'USERNAME',
                        value: widget.username,
                        onCopy: () => _copyToClipboard(widget.username, 'Username disalin'),
                      ),
                      const SizedBox(height: 12),
                      
                      _buildListCard(
                        isComic: isComic,
                        icon: Icons.key_rounded,
                        label: 'PASSWORD',
                        value: _censorPassword(widget.password),
                        isObscured: true,
                        onCopy: () => _copyToClipboard(widget.password, 'Password disalin'),
                      ),
                      const SizedBox(height: 12),
                      
                      _buildListCard(
                        isComic: isComic,
                        icon: Icons.hub_rounded,
                        label: 'SESSION ID',
                        value: widget.sessionKey,
                        onCopy: () => _copyToClipboard(widget.sessionKey, 'Session ID disalin'),
                      ),
                      const SizedBox(height: 12),
                      
                      // ─── UID RAT (Di bawah Session ID) ───
                      _buildListCard(
                        isComic: isComic,
                        icon: Icons.fingerprint_rounded,
                        label: 'UID RAT',
                        value: widget.uid.isNotEmpty ? widget.uid : 'Belum tersedia',
                        onCopy: widget.uid.isEmpty ? null : () => _copyToClipboard(widget.uid, 'UID RAT disalin'),
                      ),

                      const SizedBox(height: 30),

                      // ─── SECTION: INFO TAMBAHAN ───
                      _buildSectionTitle('INFO TAMBAHAN', isComic),
                      const SizedBox(height: 12),
                      
                      _buildListCard(
                        isComic: isComic,
                        icon: Icons.timer_outlined,
                        label: 'WAKTU EXPIRED (WIB)',
                        value: widget.expiredDate,
                        iconColor: _C.amber,
                        // Expired tidak perlu di-copy biasanya, tapi bisa disesuaikan
                      ),
                      const SizedBox(height: 12),
                      
                      _buildListCard(
                        isComic: isComic,
                        icon: Icons.verified_user_rounded,
                        label: 'ROLE',
                        value: widget.role.toUpperCase(),
                        iconColor: _C.green,
                      ),

                      const SizedBox(height: 40),

                      // ─── TOMBOL GANTI PASSWORD ───
                      SizedBox(
                        width: double.infinity,
                        height: 50,
                        child: ElevatedButton(
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => ChangePasswordPage(
                                  username: widget.username,
                                  sessionKey: widget.sessionKey,
                                ),
                              ),
                            );
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: isComic ? _C.primary : _C.primary.withOpacity(0.1),
                            foregroundColor: isComic ? _onAccent() : _C.primary,
                            elevation: 0,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(isComic ? 6 : 14),
                              side: isComic 
                                  ? BorderSide(color: _C.border, width: 2) 
                                  : BorderSide(color: _C.primary.withOpacity(0.3), width: 1),
                            ),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.lock_reset_rounded, size: 20),
                              const SizedBox(width: 8),
                              Text(
                                'GANTI PASSWORD',
                                style: TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.bold,
                                  letterSpacing: 1,
                                  fontFamily: kFont,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(height: 40),
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  // ─── HELPER: JUDUL SECTION ───
  Widget _buildSectionTitle(String title, bool isComic) {
    return Row(
      children: [
        Container(
          width: 3,
          height: 16,
          decoration: BoxDecoration(
            color: _C.primary,
            borderRadius: BorderRadius.circular(2),
          ),
        ),
        const SizedBox(width: 8),
        Text(
          title,
          style: TextStyle(
            color: _C.textSub,
            fontSize: 12,
            fontWeight: FontWeight.bold,
            letterSpacing: 1,
            fontFamily: kFont,
          ),
        ),
      ],
    );
  }

  // ─── HELPER: KARTU LIST INFO ───
  Widget _buildListCard({
    required bool isComic,
    required IconData icon,
    required String label,
    required String value,
    Color? iconColor,
    VoidCallback? onCopy,
    bool isObscured = false,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
      decoration: BoxDecoration(
        color: isComic ? _C.card : null,
        gradient: !isComic ? _C.glassGrad : null,
        borderRadius: BorderRadius.circular(isComic ? 6 : 16),
        border: Border.all(
          color: isComic ? _C.border : _C.glassBorder,
          width: isComic ? 2 : 1,
        ),
        boxShadow: _C.softShadow,
      ),
      child: Row(
        children: [
          // Ikon Kiri
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: (iconColor ?? _C.primary).withOpacity(0.1),
              borderRadius: BorderRadius.circular(isComic ? 4 : 12),
              border: Border.all(
                color: (iconColor ?? _C.primary).withOpacity(0.2),
                width: 1,
              ),
            ),
            child: Icon(icon, color: iconColor ?? _C.primary, size: 20),
          ),
          const SizedBox(width: 14),
          
          // Teks Tengah
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: TextStyle(
                    color: _C.textDim,
                    fontSize: 10,
                    fontWeight: FontWeight.w600,
                    letterSpacing: 0.5,
                    fontFamily: kFont,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  value,
                  style: TextStyle(
                    color: _C.text,
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                    fontFamily: kFont,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
          
          // Tombol Copy Kanan
          if (onCopy != null)
            IconButton(
              onPressed: onCopy,
              icon: Icon(Icons.copy_rounded, size: 20, color: _C.textDim),
              splashRadius: 20,
              tooltip: 'Salin',
            ),
        ],
      ),
    );
  }
}

// ─── ACTION ITEM WIDGET (Untuk Bottom Sheet) ───────────────────────────
class _ActionItem extends StatefulWidget {
  final IconData icon;
  final Color color;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  const _ActionItem({
    required this.icon,
    required this.color,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  @override
  State<_ActionItem> createState() => _ActionItemState();
}

class _ActionItemState extends State<_ActionItem> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final isComic = ThemeModeManager.isComic3d;

    if (isComic) {
      return GestureDetector(
        onTapDown: (_) => setState(() => _pressed = true),
        onTapUp: (_) {
          setState(() => _pressed = false);
          widget.onTap();
        },
        onTapCancel: () => setState(() => _pressed = false),
        child: AnimatedScale(
          scale: _pressed ? 0.97 : 1.0,
          duration: const Duration(milliseconds: 130),
          child: Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: AppColors.card,
              borderRadius: BorderRadius.circular(AppColors.cardRadius),
              border: Border.all(color: AppColors.border, width: 3),
              boxShadow: AppColors.softShadow,
            ),
            child: _actionContent(),
          ),
        ),
      );
    }

    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedScale(
        scale: _pressed ? 0.97 : 1.0,
        duration: const Duration(milliseconds: 130),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(AppColors.cardRadius),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 8, sigmaY: 8),
            child: Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                gradient: _pressed
                    ? LinearGradient(
                        colors: [
                          widget.color.withOpacity(0.08),
                          Colors.transparent,
                        ],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      )
                    : _C.glassGrad,
                borderRadius: BorderRadius.circular(AppColors.cardRadius),
                border: Border.all(
                  color: _pressed
                      ? widget.color.withOpacity(0.2)
                      : _C.glassBorder,
                  width: 0.5,
                ),
                boxShadow: _pressed
                    ? [
                        BoxShadow(
                          color: widget.color.withOpacity(0.05),
                          blurRadius: 15,
                        ),
                      ]
                    : _C.softShadow,
              ),
              child: _actionContent(),
            ),
          ),
        ),
      ),
    );
  }

  Widget _actionContent() {
    final isComic = ThemeModeManager.isComic3d;
    return Row(
      children: [
        Container(
          width: 40, height: 40,
          decoration: BoxDecoration(
            gradient: isComic
                ? LinearGradient(
                    colors: [
                      widget.color,
                      widget.color.withOpacity(0.7),
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  )
                : LinearGradient(
                    colors: [
                      widget.color.withOpacity(0.1),
                      widget.color.withOpacity(0.02),
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
            borderRadius: BorderRadius.circular(isComic ? 4 : 10),
            border: isComic
                ? Border.all(color: AppColors.border, width: 2)
                : null,
          ),
          child: Icon(
            widget.icon,
            color: isComic ? const Color(0xFF1A1A1A) : widget.color,
            size: 20,
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                widget.title,
                style: TextStyle(
                  color: _C.white,
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  fontFamily: kFont,
                ),
              ),
              const SizedBox(height: 1),
              Text(
                widget.subtitle,
                style: TextStyle(
                  color: _C.textDim,
                  fontSize: 11,
                  fontFamily: kFont,
                ),
              ),
            ],
          ),
        ),
        Icon(
          Icons.arrow_forward_ios_rounded,
          size: 14,
          color: _C.textDim,
        ),
      ],
    );
  }
}