// ============================================================
// 🚀 LANDING PAGE — Liquid Glass Modern Edition + Auto Update
// File: landing.dart
// v15 — Responsive Fingerprint UI + Real-time WIB/WITA/WIT Clock
// ============================================================
import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'dart:ui' show ImageFilter;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:local_auth/local_auth.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:video_player/video_player.dart';

import 'buy.dart';
import 'cek_akun_page.dart';
import 'theme.dart';

// ============================================================
// UPDATE — Model & Service
// ============================================================
class UpdateInfo {
  final String latestVersion;
  final String downloadUrl;
  final String description;
  final bool mandatory;
  const UpdateInfo({
    required this.latestVersion,
    required this.downloadUrl,
    required this.description,
    required this.mandatory,
  });
}

class _Version implements Comparable<_Version> {
  final int major;
  final int minor;
  final int patch;
  const _Version(this.major, this.minor, this.patch);

  factory _Version.parse(String v) {
    final clean = v.split('+').first.replaceAll(RegExp(r'[^0-9.]'), '');
    final parts = clean.split('.');
    return _Version(
      int.tryParse(parts.isNotEmpty ? parts[0] : '0') ?? 0,
      int.tryParse(parts.length > 1 ? parts[1] : '0') ?? 0,
      int.tryParse(parts.length > 2 ? parts[2] : '0') ?? 0,
    );
  }

  @override
  int compareTo(_Version other) {
    if (major != other.major) return major.compareTo(other.major);
    if (minor != other.minor) return minor.compareTo(other.minor);
    return patch.compareTo(other.patch);
  }

  bool operator >(_Version o) => compareTo(o) > 0;
  bool operator <=(_Version o) => compareTo(o) <= 0;
}

class UpdateService {
  static const String _url =
      'https://raw.githubusercontent.com/rennxfpribadi-ops/Update-Novarch/refs/heads/main/version.json';

  static Future<UpdateInfo?> check() async {
    try {
      final res = await http
          .get(Uri.parse(_url))
          .timeout(const Duration(seconds: 8));
      if (res.statusCode != 200) return null;

      final data = jsonDecode(res.body) as Map<String, dynamic>;
      final latest = _Version.parse(data['version'] as String);
      final pkg = await PackageInfo.fromPlatform();
      final current = _Version.parse(pkg.version);

      if (latest <= current) return null;

      return UpdateInfo(
        latestVersion: data['version'] as String,
        downloadUrl: data['download_url'] as String,
        description: (data['description'] as String?) ?? '',
        mandatory: (data['mandatory'] as bool?) ?? false,
      );
    } catch (_) {
      return null;
    }
  }
}

// ============================================================
// LANDING PAGE
// ============================================================
class LandingPage extends StatefulWidget {
  const LandingPage({
    super.key,
    this.sessionKey = '',
    this.username = '',
  });

  static const String baseUrl = 'http://cp.zyrostore.id:3448';

  final String sessionKey;
  final String username;

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage>
    with TickerProviderStateMixin {
  // ---- Screen State ----
  bool _showOpeningNote = true;
  bool _showFingerprint = false;
  bool _showLoading = false;
  bool _isUnlocked = false;

  // ---- Real-Time Clock & Timezone State ----
  String _selectedTz = 'WIB'; // 'WIB' (+7), 'WITA' (+8), 'WIT' (+9)
  DateTime _nowUtc = DateTime.now().toUtc();
  Timer? _clockTimer;

  // ---- Loading Screen State ----
  int _loadLineIndex = 0;
  int _loadLinePct = 0;
  bool _loadLineDone = false;

  Timer? _loadTimer;

  final List<String> _loadLines = const [
    '> MEMUAT MODUL KEAMANAN',
    '> MENGHUBUNGKAN KE SERVER',
    '> MENYIAPKAN ANTARMUKA',
    '> SINKRONISASI DATA',
    '> MEMVERIFIKASI AKSES',
  ];

  // ---- Fingerprint State ----
  bool _isScanning = false;
  bool _fingerOnSensor = false;
  bool _scanSuccess = false;
  bool _scanFailed = false;
  double _scanProgress = 0;
  String _scanStatus = 'Tekan & tahan sampai 100% untuk lanjut';

  final LocalAuthentication _localAuth = LocalAuthentication();
  Timer? _scanTimer;
  Timer? _resetFailTimer;
  int _lastHapticStep = 0;

  late final VideoPlayerController _videoController;
  bool _videoReady = false;

  // ---- Update state ----
  UpdateInfo? _pendingUpdate;
  bool _updateShown = false;

  late final AnimationController _auroraCtrl;
  late final AnimationController _pulseCtrl;
  late final AnimationController _glitchCtrl;
  late final AnimationController _fadeCtrl;
  late final AnimationController _revealCtrl;
  late final AnimationController _scanCtrl;
  late final AnimationController _floatCtrl;

  @override
  void initState() {
    super.initState();

    // Real-time clock ticker (update setiap 200ms agar detik presisi)
    _clockTimer = Timer.periodic(const Duration(milliseconds: 200), (_) {
      if (!mounted) return;
      final currentUtc = DateTime.now().toUtc();
      if (currentUtc.second != _nowUtc.second) {
        setState(() {
          _nowUtc = currentUtc;
        });
      }
    });

    _auroraCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 12),
    )..repeat();

    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1700),
    )..repeat(reverse: true);

    _glitchCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 180),
    )..repeat(reverse: true);

    _fadeCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 850),
    )..forward();

    _revealCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1300),
    );

    _scanCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1550),
    );

    _floatCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 5),
    )..repeat(reverse: true);

    _initVideo();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      _checkForUpdates();
    });
  }

  void _initVideo() {
    _videoController = VideoPlayerController.asset('assets/videos/log.mp4');

    _videoController.initialize().then((_) {
      if (!mounted) return;
      setState(() => _videoReady = true);
      _videoController
        ..setLooping(true)
        ..setVolume(0)
        ..play();
    }).catchError((Object error) {
      debugPrint('Video initialization error: $error');
    });
  }

  @override
  void dispose() {
    _clockTimer?.cancel();
    _scanTimer?.cancel();
    _resetFailTimer?.cancel();
    _loadTimer?.cancel();
    _videoController.dispose();
    _auroraCtrl.dispose();
    _pulseCtrl.dispose();
    _glitchCtrl.dispose();
    _fadeCtrl.dispose();
    _revealCtrl.dispose();
    _scanCtrl.dispose();
    _floatCtrl.dispose();
    super.dispose();
  }

  // ============================================================
  // REAL-TIME CLOCK HELPER (WIB / WITA / WIT)
  // ============================================================
  DateTime _getSelectedZoneTime() {
    final offsetHours = switch (_selectedTz) {
      'WITA' => 8,
      'WIT' => 9,
      _ => 7, // WIB
    };
    return _nowUtc.add(Duration(hours: offsetHours));
  }

  String _formatTwoDigits(int n) => n.toString().padLeft(2, '0');

  String _formatClockTime(DateTime dt) {
    return '${_formatTwoDigits(dt.hour)}:${_formatTwoDigits(dt.minute)}:${_formatTwoDigits(dt.second)}';
  }

  String _formatClockDate(DateTime dt) {
    const days = [
      'SENIN',
      'SELASA',
      'RABU',
      'KAMIS',
      'JUMAT',
      'SABTU',
      'MINGGU'
    ];
    const months = [
      'JAN',
      'FEB',
      'MAR',
      'APR',
      'MEI',
      'JUN',
      'JUL',
      'AGU',
      'SEP',
      'OKT',
      'NOV',
      'DES'
    ];
    final dayName = days[dt.weekday - 1];
    final monthName = months[dt.month - 1];
    return '$dayName, ${dt.day} $monthName ${dt.year}';
  }

  // ============================================================
  // AUTO UPDATE
  // ============================================================
  Future<void> _checkForUpdates() async {
    final info = await UpdateService.check();
    if (!mounted || info == null) return;

    _pendingUpdate = info;

    for (var i = 0; i < 20; i++) {
      if (!mounted) return;
      if (!_isScanning &&
          !_fingerOnSensor &&
          !_showOpeningNote &&
          !_showLoading) break;
      await Future.delayed(const Duration(milliseconds: 500));
    }
    if (!mounted || _updateShown) return;

    await Future.delayed(const Duration(milliseconds: 700));
    if (!mounted || _updateShown) return;

    _updateShown = true;
    if (info.mandatory) {
      _showMandatoryUpdateDialog(info);
    } else {
      _showOptionalUpdateDialog(info);
    }
  }

  Future<void> _openDownloadUrl(String url) async {
    try {
      await launchUrl(
        Uri.parse(url),
        mode: LaunchMode.externalApplication,
      );
    } catch (e) {
      debugPrint('Launch error: $e');
    }
  }

  Future<void> _copyUrlToClipboard(String url) async {
    await Clipboard.setData(ClipboardData(text: url));
    HapticFeedback.mediumImpact();
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: AppColors.green.withOpacity(.85),
        content: const Text(
          '✓ URL berhasil disalin',
          style: TextStyle(
            color: Colors.black,
            fontWeight: FontWeight.w800,
          ),
        ),
        duration: const Duration(seconds: 2),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
        ),
      ),
    );
  }

  // ============================================================
  // MANDATORY UPDATE — FULL SCREEN DIALOG
  // ============================================================
  Future<void> _showMandatoryUpdateDialog(UpdateInfo info) async {
    return showGeneralDialog<void>(
      context: context,
      barrierDismissible: false,
      barrierLabel: 'Update Wajib',
      barrierColor: Colors.black.withOpacity(.75),
      transitionDuration: const Duration(milliseconds: 450),
      pageBuilder: (ctx, anim1, anim2) {
        return PopScope(
          canPop: false,
          child: _buildMandatoryFullScreen(ctx, info),
        );
      },
      transitionBuilder: (ctx, anim1, anim2, child) {
        final curve = CurvedAnimation(
          parent: anim1,
          curve: Curves.easeOutCubic,
        );
        return FadeTransition(
          opacity: curve,
          child: ScaleTransition(
            scale: Tween<double>(begin: .94, end: 1).animate(curve),
            child: child,
          ),
        );
      },
    );
  }

  Widget _buildMandatoryFullScreen(BuildContext ctx, UpdateInfo info) {
    return Material(
      color: Colors.transparent,
      child: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              const Color(0xFF0B0614),
              AppColors.bg,
              const Color(0xFF0B0614),
            ],
          ),
        ),
        child: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 28),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  AnimatedBuilder(
                    animation: _pulseCtrl,
                    builder: (_, __) {
                      final glow = .55 + (_pulseCtrl.value * .45);
                      return Container(
                        width: 150,
                        height: 150,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          boxShadow: [
                            BoxShadow(
                              color: AppColors.gold.withOpacity(glow * .45),
                              blurRadius: 70,
                              spreadRadius: 12,
                            ),
                          ],
                        ),
                        child: Container(
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: RadialGradient(
                              colors: [
                                AppColors.gold.withOpacity(.18),
                                Colors.transparent,
                              ],
                            ),
                            border: Border.all(
                              color: AppColors.gold.withOpacity(.45),
                              width: 2,
                            ),
                          ),
                          child: Center(
                            child: Icon(
                              Icons.warning_amber_rounded,
                              color: AppColors.gold,
                              size: 70,
                              shadows: [
                                Shadow(
                                  color: AppColors.gold.withOpacity(.9),
                                  blurRadius: 30,
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                  const SizedBox(height: 28),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 20,
                      vertical: 9,
                    ),
                    decoration: BoxDecoration(
                      color: const Color(0xFF3A1020),
                      borderRadius: BorderRadius.circular(30),
                      border: Border.all(
                        color: const Color(0xFFE23B5A).withOpacity(.7),
                        width: 1.2,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: const Color(0xFFE23B5A).withOpacity(.35),
                          blurRadius: 22,
                          spreadRadius: 1,
                        ),
                      ],
                    ),
                    child: const Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          Icons.lock_rounded,
                          color: Color(0xFFFF5C7A),
                          size: 15,
                        ),
                        SizedBox(width: 8),
                        Text(
                          'UPDATE WAJIB',
                          style: TextStyle(
                            color: Color(0xFFFF5C7A),
                            fontSize: 11,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 3,
                            fontFamily: 'Pek',
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    'NEW VERSION: V${info.latestVersion}',
                    style: const TextStyle(
                      color: Color(0xFFFF8FA3),
                      fontSize: 10,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 2,
                      fontFamily: 'Pek',
                    ),
                  ),
                  const SizedBox(height: 22),
                  const Text(
                    'UPDATE DIBUTUHKAN',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Color(0xFFE0C8FF),
                      fontSize: 30,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1.5,
                      fontFamily: 'Bubble',
                      shadows: [
                        Shadow(
                          color: Color(0xFF8B5CF6),
                          blurRadius: 25,
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 14),
                  const Text(
                    'Versi lama tidak didukung lagi.\nUpdate untuk melanjutkan.',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Color(0xFFB8A8D9),
                      fontSize: 12.5,
                      height: 1.6,
                      fontWeight: FontWeight.w500,
                      fontFamily: 'Pek',
                    ),
                  ),
                  const SizedBox(height: 26),
                  if (info.description.isNotEmpty)
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: const Color(0xFF1E1430).withOpacity(.85),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                          color: AppColors.gold.withOpacity(.55),
                          width: 1.2,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: AppColors.gold.withOpacity(.12),
                            blurRadius: 26,
                            spreadRadius: 2,
                          ),
                        ],
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            width: 38,
                            height: 38,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: AppColors.gold.withOpacity(.15),
                              border: Border.all(
                                color: AppColors.gold.withOpacity(.55),
                                width: 1,
                              ),
                            ),
                            child: Icon(
                              Icons.send_rounded,
                              color: AppColors.gold,
                              size: 18,
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text(
                                  'PESAN UPDATE',
                                  style: TextStyle(
                                    color: Color(0xFFE8D9A8),
                                    fontSize: 9,
                                    fontWeight: FontWeight.w900,
                                    letterSpacing: 2.4,
                                    fontFamily: 'Pek',
                                  ),
                                ),
                                const SizedBox(height: 6),
                                Text(
                                  info.description,
                                  style: const TextStyle(
                                    color: Color(0xFFF0EAD6),
                                    fontSize: 12,
                                    height: 1.5,
                                    fontWeight: FontWeight.w600,
                                    fontFamily: 'Pek',
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  const SizedBox(height: 26),
                  SizedBox(
                    width: double.infinity,
                    child: _Pressable(
                      onTap: () => _openDownloadUrl(info.downloadUrl),
                      child: Container(
                        height: 62,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(22),
                          gradient: const LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                            colors: [
                              Color(0xFF9B4DFF),
                              Color(0xFF7A2DE0),
                            ],
                          ),
                          border: Border.all(
                            color: Colors.white.withOpacity(.25),
                            width: 1.2,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: const Color(0xFF9B4DFF).withOpacity(.65),
                              blurRadius: 34,
                              spreadRadius: 2,
                              offset: const Offset(0, 10),
                            ),
                          ],
                        ),
                        child: const Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              Icons.download_rounded,
                              color: Colors.white,
                              size: 24,
                            ),
                            SizedBox(width: 10),
                            Text(
                              'UPDATE APK',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 15,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 2.4,
                                fontFamily: 'Pek',
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 14),
                  SizedBox(
                    width: double.infinity,
                    child: _Pressable(
                      onTap: () => _copyUrlToClipboard(info.downloadUrl),
                      child: Container(
                        height: 58,
                        decoration: BoxDecoration(
                          color: const Color(0xFF1A1028),
                          borderRadius: BorderRadius.circular(22),
                          border: Border.all(
                            color: const Color(0xFF9B4DFF).withOpacity(.55),
                            width: 1.2,
                          ),
                        ),
                        child: const Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              Icons.copy_rounded,
                              color: Color(0xFFC9A9FF),
                              size: 20,
                            ),
                            SizedBox(width: 10),
                            Text(
                              'SALIN URL',
                              style: TextStyle(
                                color: Color(0xFFC9A9FF),
                                fontSize: 13,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 2.4,
                                fontFamily: 'Pek',
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 22),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: const Color(0xFF14101E).withOpacity(.75),
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(
                        color: const Color(0xFF9B4DFF).withOpacity(.22),
                        width: 1,
                      ),
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          width: 26,
                          height: 26,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: const Color(0xFF9B4DFF).withOpacity(.6),
                              width: 1.2,
                            ),
                          ),
                          child: const Icon(
                            Icons.info_outline_rounded,
                            color: Color(0xFF9B4DFF),
                            size: 15,
                          ),
                        ),
                        const SizedBox(width: 11),
                        const Expanded(
                          child: Text(
                            'Update wajib. Aplikasi tidak dapat digunakan sebelum update selesai.',
                            style: TextStyle(
                              color: Color(0xFF9A8BB8),
                              fontSize: 10.5,
                              height: 1.55,
                              fontWeight: FontWeight.w500,
                              fontFamily: 'Pek',
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ============================================================
  // OPTIONAL UPDATE — SMALL POPUP
  // ============================================================
  Future<void> _showOptionalUpdateDialog(UpdateInfo info) async {
    return showDialog<void>(
      context: context,
      barrierDismissible: true,
      barrierColor: Colors.black.withOpacity(.55),
      builder: (ctx) => _buildOptionalPopup(ctx, info),
    );
  }

  Widget _buildOptionalPopup(BuildContext ctx, UpdateInfo info) {
    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 40),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(26),
          boxShadow: [
            BoxShadow(
              color: AppColors.accent.withOpacity(.45),
              blurRadius: 50,
              spreadRadius: 4,
            ),
            BoxShadow(
              color: Colors.black.withOpacity(.45),
              blurRadius: 34,
              offset: const Offset(0, 16),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(26),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 24, sigmaY: 24),
            child: Container(
              padding: const EdgeInsets.all(22),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(26),
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    AppColors.card.withOpacity(.96),
                    AppColors.bg.withOpacity(.98),
                  ],
                ),
                border: Border.all(
                  color: AppColors.borderLit.withOpacity(.45),
                  width: 1,
                ),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        width: 46,
                        height: 46,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: RadialGradient(
                            colors: [
                              AppColors.accent.withOpacity(.95),
                              AppColors.accentDark.withOpacity(.55),
                            ],
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: AppColors.accent.withOpacity(.55),
                              blurRadius: 22,
                              spreadRadius: 1,
                            ),
                          ],
                        ),
                        child: const Icon(
                          Icons.system_update_rounded,
                          color: Colors.white,
                          size: 24,
                        ),
                      ),
                      const SizedBox(width: 12),
                      const Expanded(
                        child: Text(
                          'Update Tersedia',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.w900,
                            letterSpacing: .5,
                            fontFamily: 'Pek',
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 5,
                    ),
                    decoration: BoxDecoration(
                      color: AppColors.gold.withOpacity(.15),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                        color: AppColors.gold.withOpacity(.55),
                        width: 1,
                      ),
                    ),
                    child: Text(
                      'Update tidak wajib',
                      style: TextStyle(
                        color: AppColors.gold,
                        fontSize: 9.5,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 1,
                        fontFamily: 'Pek',
                      ),
                    ),
                  ),
                  const SizedBox(height: 14),
                  Row(
                    children: [
                      const Text(
                        'Version',
                        style: TextStyle(
                          color: Colors.white70,
                          fontSize: 10.5,
                          fontWeight: FontWeight.w700,
                          fontFamily: 'Pek',
                        ),
                      ),
                      const SizedBox(width: 10),
                      Text(
                        'v${info.latestVersion}',
                        style: TextStyle(
                          color: AppColors.accent,
                          fontSize: 12,
                          fontWeight: FontWeight.w900,
                          fontFamily: 'Pek',
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  if (info.description.isNotEmpty) ...[
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: AppColors.card2.withOpacity(.6),
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(
                          color: AppColors.border.withOpacity(.5),
                          width: 1,
                        ),
                      ),
                      child: Text(
                        info.description,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 11,
                          height: 1.5,
                          fontWeight: FontWeight.w500,
                          fontFamily: 'Pek',
                        ),
                      ),
                    ),
                    const SizedBox(height: 10),
                  ],
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(11),
                    decoration: BoxDecoration(
                      color: AppColors.card2.withOpacity(.5),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(
                        color: AppColors.border.withOpacity(.5),
                        width: 1,
                      ),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Icon(
                              Icons.link_rounded,
                              color: AppColors.gold,
                              size: 13,
                            ),
                            const SizedBox(width: 6),
                            const Text(
                              'DOWNLOAD URL',
                              style: TextStyle(
                                color: Colors.white60,
                                fontSize: 8,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 2,
                                fontFamily: 'Pek',
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 6),
                        SelectableText(
                          info.downloadUrl,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 10,
                            height: 1.4,
                            fontWeight: FontWeight.w500,
                            fontFamily: 'Pek',
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Expanded(
                        child: _Pressable(
                          onTap: () => _copyUrlToClipboard(info.downloadUrl),
                          child: Container(
                            height: 48,
                            decoration: BoxDecoration(
                              color: AppColors.card2,
                              borderRadius: BorderRadius.circular(14),
                              border: Border.all(
                                color: AppColors.borderLit,
                                width: 1,
                              ),
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(
                                  Icons.copy_rounded,
                                  color: AppColors.gold,
                                  size: 16,
                                ),
                                const SizedBox(width: 6),
                                Text(
                                  'SALIN',
                                  style: TextStyle(
                                    color: AppColors.gold,
                                    fontSize: 10.5,
                                    fontWeight: FontWeight.w900,
                                    letterSpacing: 1.2,
                                    fontFamily: 'Pek',
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        flex: 2,
                        child: _Pressable(
                          onTap: () => _openDownloadUrl(info.downloadUrl),
                          child: Container(
                            height: 48,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(14),
                              gradient: AppColors.btnGrad,
                              border: Border.all(
                                color: Colors.white.withOpacity(.25),
                                width: 1,
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: AppColors.accent.withOpacity(.45),
                                  blurRadius: 22,
                                  offset: const Offset(0, 8),
                                ),
                              ],
                            ),
                            child: const Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(
                                  Icons.open_in_browser_rounded,
                                  color: Colors.white,
                                  size: 17,
                                ),
                                SizedBox(width: 6),
                                Text(
                                  'DOWNLOAD',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 10.5,
                                    fontWeight: FontWeight.w900,
                                    letterSpacing: 1.2,
                                    fontFamily: 'Pek',
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Align(
                    alignment: Alignment.center,
                    child: TextButton(
                      onPressed: () => Navigator.of(ctx).pop(),
                      style: TextButton.styleFrom(
                        foregroundColor: Colors.white54,
                        padding: const EdgeInsets.symmetric(
                          horizontal: 16,
                          vertical: 8,
                        ),
                      ),
                      child: const Text(
                        'NANTI SAJA',
                        style: TextStyle(
                          color: Colors.white54,
                          fontSize: 10,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 2,
                          fontFamily: 'Pek',
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ============================================================
  // FINGERPRINT SCAN — INSTANT RESPONSE + STRICT RELEASE ABORT
  // ============================================================
  void _fingerDown() {
    if (_scanSuccess) return;

    // Batalkan timer reset kegagalan sebelumnya jika user langsung menempelkan jari lagi
    _resetFailTimer?.cancel();
    _scanTimer?.cancel();

    HapticFeedback.mediumImpact();
    _lastHapticStep = 0;

    setState(() {
      _fingerOnSensor = true;
      _isScanning = true;
      _scanFailed = false;
      _scanProgress = 0.02; // Respon visual instan saat disentuh
      _scanStatus = 'Memindai sidik jari... 2%';
    });

    _scanCtrl.forward(from: 0);

    // Polling ultra-responsif setiap 16ms (~60fps)
    _scanTimer = Timer.periodic(const Duration(milliseconds: 16), (timer) {
      if (!mounted) {
        timer.cancel();
        return;
      }

      // Jika jari dilepas di tengah proses -> langsung gagal & reset
      if (!_fingerOnSensor) {
        timer.cancel();
        _abortScan(reason: 'Jari terlepas! Pemindaian gagal');
        return;
      }

      final progress = _scanCtrl.value.clamp(0.0, 1.0);
      final pct = (progress * 100).toInt();

      // Feedback getaran halus setiap kelipatan 25%
      final hapticStep = pct ~/ 25;
      if (hapticStep > _lastHapticStep && hapticStep < 4) {
        _lastHapticStep = hapticStep;
        HapticFeedback.selectionClick();
      }

      setState(() {
        _scanProgress = progress;
        if (progress < .35) {
          _scanStatus = 'Memindai pola biometrik... $pct%';
        } else if (progress < .75) {
          _scanStatus = 'Memverifikasi enkripsi AES-256... $pct%';
        } else if (progress < 1.0) {
          _scanStatus = 'Menyelesaikan autentikasi... $pct%';
        } else {
          _scanStatus = 'Verifikasi berhasil! 100%';
        }
      });

      if (progress >= 1.0) {
        timer.cancel();
        _completeScan();
      }
    });
  }

  void _fingerUp() {
    if (_scanSuccess) return;
    final wasScanning = _fingerOnSensor || _isScanning;
    _fingerOnSensor = false;

    if (wasScanning && _scanProgress < 1.0) {
      _abortScan(reason: 'Jari dilepas sebelum 100% — Mengulang...');
    }
  }

  void _abortScan({String reason = 'Jari dilepas! Pemindaian diulang'}) {
    if (_scanSuccess) return;
    _scanTimer?.cancel();
    _resetFailTimer?.cancel();
    _scanCtrl.reset();

    if (!mounted) return;
    setState(() {
      _fingerOnSensor = false;
      _isScanning = false;
      _scanProgress = 0.0;
      _scanFailed = true;
      _scanStatus = reason;
    });

    HapticFeedback.heavyImpact();

    // Otomatis reset kembali ke mode siap pindai setelah 900ms
    _resetFailTimer = Timer(const Duration(milliseconds: 900), () {
      if (!mounted || _fingerOnSensor || _scanSuccess) return;
      setState(() {
        _scanFailed = false;
        _scanProgress = 0.0;
        _scanStatus = 'Tekan & tahan sampai 100% untuk lanjut';
      });
    });
  }

  void _resetFingerprintState() {
    _scanTimer?.cancel();
    _resetFailTimer?.cancel();
    _scanCtrl.reset();
    setState(() {
      _fingerOnSensor = false;
      _isScanning = false;
      _scanSuccess = false;
      _scanFailed = false;
      _scanProgress = 0.0;
      _scanStatus = 'Tekan & tahan sampai 100% untuk lanjut';
    });
  }

  Future<void> _completeScan() async {
    bool authenticated = true;
    try {
      final supported = await _localAuth.isDeviceSupported();
      final biometrics = await _localAuth.canCheckBiometrics;
      if (supported && biometrics) {
        authenticated = await _localAuth.authenticate(
          localizedReason: 'Verifikasi sidik jari untuk membuka Novarch',
        );
      }
    } catch (error) {
      debugPrint('Biometric error: $error');
      authenticated = true;
    }

    if (!mounted) return;
    if (authenticated) {
      setState(() {
        _scanSuccess = true;
        _isScanning = false;
        _scanFailed = false;
        _scanProgress = 1.0;
        _scanStatus = '✓ AKSES DITERIMA • 100%';
      });
      HapticFeedback.heavyImpact();
      await Future.delayed(const Duration(milliseconds: 550));
      if (!mounted) return;

      setState(() {
        _showFingerprint = false;
        _showLoading = true;
      });
      _startLoadingSequence();
    } else {
      _abortScan(reason: 'Autentikasi biometrik gagal — Ulangi');
    }
  }

  // ============================================================
  // LOADING SEQUENCE
  // ============================================================
  void _startLoadingSequence() {
    _loadLineIndex = 0;
    _loadLinePct = 0;
    _loadLineDone = false;
    _loadTimer?.cancel();

    const int tickMs = 10;
    const int stepPct = 30;
    const int totalTicks = 35;

    int tickCount = 0;

    _loadTimer = Timer.periodic(const Duration(milliseconds: tickMs), (timer) {
      if (!mounted) {
        timer.cancel();
        return;
      }

      tickCount++;

      setState(() {
        if (!_loadLineDone) {
          _loadLinePct += stepPct;
          if (_loadLinePct >= 100) {
            _loadLinePct = 100;
            _loadLineDone = true;
          }
        } else {
          if (_loadLineIndex < _loadLines.length - 1) {
            _loadLineIndex++;
            _loadLinePct = 0;
            _loadLineDone = false;
          }
        }
      });

      if (tickCount >= totalTicks) {
        timer.cancel();
        setState(() {
          _loadLineIndex = _loadLines.length - 1;
          _loadLinePct = 100;
          _loadLineDone = true;
        });

        Future.delayed(const Duration(milliseconds: 30), () {
          if (!mounted) return;
          setState(() {
            _showLoading = false;
            _isUnlocked = true;
            _revealCtrl.forward(from: 0);
          });
        });
      }
    });
  }

  Future<void> _openUrl(String url) async {
    try {
      await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
    } catch (error) {
      debugPrint('Launch error: $error');
    }
  }

  void _openCekAkun() {
    Navigator.push(
      context,
      PageRouteBuilder(
        pageBuilder: (_, __, ___) => const CekAkunPage(),
        transitionDuration: const Duration(milliseconds: 400),
        transitionsBuilder: (_, anim, __, child) => SlideTransition(
          position: Tween<Offset>(begin: const Offset(1, 0), end: Offset.zero)
              .animate(CurvedAnimation(parent: anim, curve: Curves.easeOutCubic)),
          child: FadeTransition(opacity: anim, child: child),
        ),
      ),
    );
  }

  void _openBuy() {
    Navigator.push(
      context,
      PageRouteBuilder(
        pageBuilder: (_, __, ___) => BuyPage(
          sessionKey: widget.sessionKey,
          username: widget.username,
        ),
        transitionDuration: const Duration(milliseconds: 400),
        transitionsBuilder: (_, anim, __, child) => SlideTransition(
          position: Tween<Offset>(begin: const Offset(1, 0), end: Offset.zero)
              .animate(CurvedAnimation(parent: anim, curve: Curves.easeOutCubic)),
          child: FadeTransition(opacity: anim, child: child),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppThemeMode>(
      valueListenable: ThemeModeManager.current,
      builder: (context, mode, _) {
        return Scaffold(
          backgroundColor:
              _showFingerprint ? const Color(0xFF0A0D18) : AppColors.bg,
          body: Stack(
            children: [
              if (!_showOpeningNote && !_showLoading && !_showFingerprint)
                Positioned.fill(
                  child: CustomPaint(
                    painter: _AuroraPainter(animation: _auroraCtrl),
                  ),
                ),
              AnimatedSwitcher(
                duration: const Duration(milliseconds: 550),
                switchInCurve: Curves.easeOutCubic,
                switchOutCurve: Curves.easeIn,
                transitionBuilder: (child, animation) => FadeTransition(
                  opacity: animation,
                  child: child,
                ),
                child: _buildCurrentScreen(),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildCurrentScreen() {
    if (_showOpeningNote) return _buildOpeningNote();
    if (_showFingerprint) return _buildSecureAccess();
    if (_showLoading) return _buildLoadingScreen();
    return _buildLanding();
  }

  // ============================================================
  // OPENING NOTE
  // ============================================================
  Widget _buildOpeningNote() {
    final isComic = ThemeModeManager.isComic3d;
    final isMono = ThemeModeManager.isMonochrome;

    final bgColor = isMono ? Colors.black : AppColors.bg;
    final cardColor = isMono ? const Color(0xFF1A1A1A) : AppColors.card;

    final headerIconBg = isComic
        ? Colors.black
        : (isMono ? const Color(0xFF222222) : AppColors.card2);
    final headerIconBorder = AppColors.borderLit;
    final headerIconColor = AppColors.accent;

    final titleColor = AppColors.text;
    final subtitleColor = AppColors.textSub;

    final imageBorder = isComic ? Colors.black : AppColors.border;
    final imageRadius = isComic ? 8.0 : 18.0;

    return Container(
      key: const ValueKey('opening_note'),
      color: bgColor,
      child: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 8),
              child: Row(
                children: [
                  Container(
                    width: 52,
                    height: 52,
                    decoration: BoxDecoration(
                      color: headerIconBg,
                      borderRadius: BorderRadius.circular(isComic ? 6 : 14),
                      border: Border.all(
                        color: headerIconBorder,
                        width: isComic ? 3 : 1.5,
                      ),
                      boxShadow: AppColors.glassShadow,
                    ),
                    child: Icon(
                      Icons.menu_book_rounded,
                      color: headerIconColor,
                      size: 26,
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'CATATAN PEMBUKA',
                          style: TextStyle(
                            color: titleColor,
                            fontSize: 16,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 1.5,
                            fontFamily: isComic ? null : 'Astral',
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          'Baca dulu sebelum lanjut ke aplikasi',
                          style: TextStyle(
                            color: subtitleColor,
                            fontSize: 11,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                padding:
                    const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                child: Container(
                  decoration: BoxDecoration(
                    color: cardColor,
                    borderRadius: BorderRadius.circular(imageRadius),
                    border: Border.all(
                      color: imageBorder,
                      width: isComic ? 3 : 1.2,
                    ),
                    boxShadow: AppColors.glassShadow,
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(
                        imageRadius - (isComic ? 0 : 2)),
                    child: Image.asset(
                      'assets/images/catatan.jpg',
                      fit: BoxFit.fitWidth,
                      errorBuilder: (context, error, stackTrace) {
                        return Container(
                          padding: const EdgeInsets.all(40),
                          color: AppColors.card2,
                          child: Text(
                            'Gambar catatan.jpg tidak ditemukan.\nPastikan file ada di assets/images/',
                            style: TextStyle(color: titleColor),
                            textAlign: TextAlign.center,
                          ),
                        );
                      },
                    ),
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(bottom: 16, top: 8),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.touch_app_rounded,
                      color: subtitleColor, size: 16),
                  const SizedBox(width: 6),
                  Text(
                    'Gulir untuk membaca seluruh catatan',
                    style: TextStyle(
                      color: subtitleColor,
                      fontSize: 10,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
              child: _Pressable(
                onTap: () {
                  HapticFeedback.lightImpact();
                  _resetFingerprintState();
                  setState(() {
                    _showOpeningNote = false;
                    _showFingerprint = true;
                  });
                },
                child: Container(
                  height: 60,
                  width: double.infinity,
                  decoration: BoxDecoration(
                    gradient: AppColors.btnGrad,
                    borderRadius: BorderRadius.circular(isComic ? 10 : 30),
                    border: isComic
                        ? Border.all(color: Colors.black, width: 3)
                        : null,
                    boxShadow: AppColors.glassShadow,
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.check_circle_outline,
                          color: Colors.white, size: 22),
                      const SizedBox(width: 10),
                      Text(
                        'OKE, SAYA SUDAH BACA - LANJUT',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 13,
                          letterSpacing: 1.2,
                          fontFamily: isComic ? null : 'Astral',
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // LOADING SCREEN
  // ============================================================
  Widget _buildLoadingScreen() {
    final isMono = ThemeModeManager.isMonochrome;
    final bg = isMono ? Colors.black : AppColors.bg;

    const Color yellow = Color(0xFFFFD54F);
    const Color yellowBright = Color(0xFFFFE066);
    final yellowDim = yellow.withOpacity(.55);
    final yellowFaint = yellow.withOpacity(.35);

    final totalLines = _loadLines.length;
    final overallProgress = totalLines == 0
        ? 0.0
        : ((_loadLineIndex + (_loadLinePct / 100.0)) / totalLines)
            .clamp(0.0, 1.0);
    final overallPct = (overallProgress * 100).round();

    return Container(
      key: const ValueKey('loading_screen'),
      color: bg,
      child: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 28),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Row(
                  children: [
                    Icon(Icons.settings_suggest_rounded,
                        color: yellow, size: 22),
                    SizedBox(width: 10),
                    Text(
                      'NOVARCH PROJECT',
                      style: TextStyle(
                        color: yellow,
                        fontSize: 14,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 4,
                        fontFamily: 'Astral',
                        shadows: [
                          Shadow(color: yellowBright, blurRadius: 10),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 30),
                ...List.generate(_loadLines.length, (i) {
                  final isActive = i == _loadLineIndex;
                  final isDone = i < _loadLineIndex ||
                      (i == _loadLineIndex && _loadLineDone);
                  final isUpcoming = i > _loadLineIndex;

                  if (isUpcoming && !isActive && !isDone) {
                    return const SizedBox(height: 22);
                  }

                  final pct = isDone ? 100 : (isActive ? _loadLinePct : 0);

                  final Color textColor;
                  if (isDone) {
                    textColor = yellowDim;
                  } else if (isActive) {
                    textColor = yellowBright;
                  } else {
                    textColor = yellowFaint;
                  }

                  return Padding(
                    padding: const EdgeInsets.symmetric(vertical: 5),
                    child: Row(
                      children: [
                        SizedBox(
                          width: 16,
                          child: isDone
                              ? const Icon(Icons.check_rounded,
                                  color: yellow, size: 14)
                              : const Icon(Icons.chevron_right_rounded,
                                  color: yellow, size: 14),
                        ),
                        const SizedBox(width: 6),
                        Expanded(
                          child: Text(
                            '${_loadLines[i]} ... $pct%',
                            style: TextStyle(
                              color: textColor,
                              fontSize: 11,
                              letterSpacing: 1.2,
                              fontWeight:
                                  isActive ? FontWeight.w900 : FontWeight.w700,
                              fontFamily: 'Astral',
                              shadows: isActive
                                  ? [
                                      Shadow(
                                        color: yellowBright.withOpacity(.9),
                                        blurRadius: 10,
                                      ),
                                    ]
                                  : null,
                            ),
                          ),
                        ),
                      ],
                    ),
                  );
                }),
                const SizedBox(height: 32),
                Container(
                  height: 4,
                  decoration: BoxDecoration(
                    color: yellow.withOpacity(.12),
                    borderRadius: BorderRadius.circular(2),
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(2),
                    child: FractionallySizedBox(
                      alignment: Alignment.centerLeft,
                      widthFactor: overallProgress,
                      child: Container(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [yellowBright, yellow.withOpacity(.7)],
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: yellow.withOpacity(.7),
                              blurRadius: 8,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'LOADING...',
                      style: TextStyle(
                        color: yellowDim,
                        fontSize: 8,
                        letterSpacing: 3,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    Text(
                      '$overallPct%',
                      style: const TextStyle(
                        color: yellowBright,
                        fontSize: 11,
                        fontWeight: FontWeight.w900,
                        fontFamily: 'Astral',
                        shadows: [
                          Shadow(color: yellowBright, blurRadius: 8),
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ============================================================
  // GLASS HELPERS
  // ============================================================
  Widget _glass({
    required Widget child,
    EdgeInsetsGeometry padding = const EdgeInsets.all(18),
    double radius = 26,
    Color? tint,
    Gradient? gradient,
    double blur = 18,
    double glowOpacity = .22,
    Color? glowColor,
  }) {
    final base = tint ?? Colors.white;
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius),
        boxShadow: AppColors.glassShadow,
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(radius),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: blur, sigmaY: blur),
          child: Container(
            padding: padding,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(radius),
              gradient: gradient ??
                  LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      base.withOpacity(.10),
                      base.withOpacity(.03),
                    ],
                  ),
              border: Border.all(
                color: AppColors.glassBorder,
                width: ThemeModeManager.isComic3d ? 3 : 1.2,
              ),
            ),
            child: child,
          ),
        ),
      ),
    );
  }

  // ============================================================
  // SECURE ACCESS — MODERN BIOMETRIC UI + DIGITAL CLOCK
  // ============================================================
  Widget _buildSecureAccess() {
    final zoneTime = _getSelectedZoneTime();
    final timeStr = _formatClockTime(zoneTime);
    final dateStr = _formatClockDate(zoneTime);

    final Color activeCyan = const Color(0xFF38BDF8);
    final Color activeMagenta = const Color(0xFFE879F9);
    final Color failRed = const Color(0xFFF43F5E);
    final Color successGreen = const Color(0xFF34D399);

    return Container(
      key: const ValueKey('secure_access'),
      width: double.infinity,
      height: double.infinity,
      decoration: const BoxDecoration(
        gradient: RadialGradient(
          center: Alignment(0.0, -0.15),
          radius: 1.15,
          colors: [
            Color(0xFF1B1636),
            Color(0xFF0E1022),
            Color(0xFF080A14),
          ],
          stops: [0.0, 0.55, 1.0],
        ),
      ),
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 12),
          child: Column(
            children: [
              // ---- TOP BAR (Back Button & SECURE Badge) ----
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  _Pressable(
                    onTap: () {
                      HapticFeedback.lightImpact();
                      _resetFingerprintState();
                      setState(() {
                        _showFingerprint = false;
                        _showOpeningNote = true;
                      });
                    },
                    child: Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: const Color(0xFF15192B).withOpacity(.85),
                        border: Border.all(
                          color: Colors.white.withOpacity(.10),
                          width: 1,
                        ),
                      ),
                      child: const Icon(
                        Icons.arrow_back_rounded,
                        color: Colors.white70,
                        size: 20,
                      ),
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 10,
                    ),
                    decoration: BoxDecoration(
                      color: const Color(0xFF141829).withOpacity(.9),
                      borderRadius: BorderRadius.circular(30),
                      border: Border.all(
                        color: (_scanFailed
                                ? failRed
                                : _scanSuccess
                                    ? successGreen
                                    : activeCyan)
                            .withOpacity(.28),
                        width: 1,
                      ),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        AnimatedBuilder(
                          animation: _pulseCtrl,
                          builder: (_, __) {
                            final dotColor = _scanFailed
                                ? failRed
                                : _scanSuccess
                                    ? successGreen
                                    : activeCyan;
                            return Container(
                              width: 7,
                              height: 7,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: dotColor,
                                boxShadow: [
                                  BoxShadow(
                                    color: dotColor.withOpacity(
                                        .4 + (_pulseCtrl.value * .5)),
                                    blurRadius: 8,
                                    spreadRadius: 1,
                                  ),
                                ],
                              ),
                            );
                          },
                        ),
                        const SizedBox(width: 9),
                        Text(
                          _scanFailed
                              ? 'FAILED'
                              : _scanSuccess
                                  ? 'VERIFIED'
                                  : 'SECURE',
                          style: TextStyle(
                            color: _scanFailed
                                ? failRed
                                : _scanSuccess
                                    ? successGreen
                                    : activeCyan,
                            fontSize: 11,
                            fontWeight: FontWeight.w800,
                            letterSpacing: 2.2,
                            fontFamily: 'Astral',
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 14),

              // ---- REAL-TIME DIGITAL CLOCK + WIB/WITA/WIT SELECTOR ----
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
                decoration: BoxDecoration(
                  color: const Color(0xFF131728).withOpacity(.75),
                  borderRadius: BorderRadius.circular(22),
                  border: Border.all(
                    color: Colors.white.withOpacity(.09),
                    width: 1,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(.25),
                      blurRadius: 18,
                      offset: const Offset(0, 6),
                    ),
                  ],
                ),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.baseline,
                      textBaseline: TextBaseline.alphabetic,
                      children: [
                        ShaderMask(
                          shaderCallback: (bounds) => const LinearGradient(
                            colors: [
                              Color(0xFFE0F2FE),
                              Color(0xFF7DD3FC),
                              Color(0xFFC084FC),
                            ],
                          ).createShader(bounds),
                          child: Text(
                            timeStr,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 28,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 2.5,
                              fontFamily: 'Astral',
                              fontFeatures: [FontFeature.tabularFigures()],
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Text(
                          _selectedTz,
                          style: TextStyle(
                            color: activeCyan,
                            fontSize: 11,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 1.5,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(
                      dateStr,
                      style: TextStyle(
                        color: Colors.white.withOpacity(.48),
                        fontSize: 9.5,
                        fontWeight: FontWeight.w600,
                        letterSpacing: 1.6,
                      ),
                    ),
                    const SizedBox(height: 10),
                    // Pemilih Zona Waktu: WIB / WITA / WIT
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: ['WIB', 'WITA', 'WIT'].map((tz) {
                        final isSelected = _selectedTz == tz;
                        return Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 4),
                          child: GestureDetector(
                            onTap: () {
                              if (_selectedTz == tz) return;
                              HapticFeedback.selectionClick();
                              setState(() {
                                _selectedTz = tz;
                              });
                            },
                            child: AnimatedContainer(
                              duration: const Duration(milliseconds: 220),
                              padding: const EdgeInsets.symmetric(
                                horizontal: 14,
                                vertical: 5,
                              ),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(14),
                                gradient: isSelected
                                    ? LinearGradient(
                                        colors: [
                                          activeCyan.withOpacity(.28),
                                          activeMagenta.withOpacity(.25),
                                        ],
                                      )
                                    : null,
                                color: isSelected
                                    ? null
                                    : Colors.white.withOpacity(.04),
                                border: Border.all(
                                  color: isSelected
                                      ? activeCyan.withOpacity(.7)
                                      : Colors.white.withOpacity(.08),
                                  width: 1,
                                ),
                              ),
                              child: Text(
                                tz,
                                style: TextStyle(
                                  color: isSelected
                                      ? Colors.white
                                      : Colors.white.withOpacity(.55),
                                  fontSize: 10,
                                  fontWeight: isSelected
                                      ? FontWeight.w900
                                      : FontWeight.w600,
                                  letterSpacing: 1.4,
                                ),
                              ),
                            ),
                          ),
                        );
                      }).toList(),
                    ),
                  ],
                ),
              ),

              const Spacer(flex: 2),

              // ---- HEADER: SECURE ACCESS + GRADIENT TITLE ----
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    width: 18,
                    height: 1.2,
                    color: activeMagenta.withOpacity(.45),
                  ),
                  const SizedBox(width: 10),
                  Text(
                    'SECURE ACCESS',
                    style: TextStyle(
                      color: Colors.white.withOpacity(.6),
                      fontSize: 10,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 3.2,
                      fontFamily: 'Astral',
                    ),
                  ),
                  const SizedBox(width: 10),
                  Container(
                    width: 18,
                    height: 1.2,
                    color: activeCyan.withOpacity(.45),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              ShaderMask(
                shaderCallback: (bounds) => const LinearGradient(
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                  colors: [
                    Color(0xFFC084FC),
                    Color(0xFF60A5FA),
                    Color(0xFFF472B6),
                  ],
                ).createShader(bounds),
                child: const Text(
                  'VERIFIKASI SIDIK JARI',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 22,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 2.0,
                    fontFamily: 'Astral',
                  ),
                ),
              ),
              const SizedBox(height: 8),
              AnimatedSwitcher(
                duration: const Duration(milliseconds: 200),
                child: Text(
                  _scanStatus,
                  key: ValueKey(_scanStatus),
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: _scanFailed
                        ? failRed
                        : _scanSuccess
                            ? successGreen
                            : Colors.white.withOpacity(.65),
                    fontSize: 12,
                    fontWeight:
                        _scanFailed ? FontWeight.w700 : FontWeight.w500,
                    letterSpacing: 0.4,
                  ),
                ),
              ),

              const Spacer(flex: 2),

              // ---- RESPONSIVE FINGERPRINT SENSOR RING ----
              Listener(
                behavior: HitTestBehavior.opaque,
                onPointerDown: (_) => _fingerDown(),
                onPointerUp: (_) => _fingerUp(),
                onPointerCancel: (_) => _fingerUp(),
                child: AnimatedBuilder(
                  animation: Listenable.merge([_pulseCtrl, _scanCtrl]),
                  builder: (_, __) => _buildModernSensor(
                    cyan: activeCyan,
                    magenta: activeMagenta,
                    failRed: failRed,
                    successGreen: successGreen,
                  ),
                ),
              ),

              const Spacer(flex: 2),

              // ---- PILL: Sentuh & Tahan ----
              AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                padding: const EdgeInsets.symmetric(
                  horizontal: 22,
                  vertical: 11,
                ),
                decoration: BoxDecoration(
                  color: _fingerOnSensor
                      ? activeCyan.withOpacity(.16)
                      : const Color(0xFF141829).withOpacity(.88),
                  borderRadius: BorderRadius.circular(30),
                  border: Border.all(
                    color: _scanFailed
                        ? failRed.withOpacity(.6)
                        : _fingerOnSensor
                            ? activeCyan.withOpacity(.65)
                            : Colors.white.withOpacity(.10),
                    width: 1,
                  ),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      _scanFailed
                          ? Icons.error_outline_rounded
                          : Icons.touch_app_rounded,
                      color: _scanFailed
                          ? failRed
                          : _fingerOnSensor
                              ? activeCyan
                              : Colors.white70,
                      size: 16,
                    ),
                    const SizedBox(width: 9),
                    Text(
                      _isScanning
                          ? 'Memindai ${(_scanProgress * 100).toInt()}%'
                          : _scanFailed
                              ? 'Terlepas • Ulangi'
                              : 'Sentuh & Tahan',
                      style: TextStyle(
                        color: _scanFailed ? failRed : Colors.white.withOpacity(.85),
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 0.6,
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 14),

              // ---- BADGES: AES-256 & TRUSTED ----
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  _securityMiniBadge(
                    icon: Icons.shield_outlined,
                    label: 'AES-256',
                    color: activeCyan,
                  ),
                  const SizedBox(width: 10),
                  _securityMiniBadge(
                    icon: Icons.verified_user_outlined,
                    label: 'TRUSTED',
                    color: activeCyan,
                  ),
                ],
              ),

              const Spacer(flex: 2),

              // ---- BOTTOM BUTTON: ✕ BATAL ----
              _Pressable(
                onTap: () {
                  HapticFeedback.lightImpact();
                  _resetFingerprintState();
                  setState(() {
                    _showFingerprint = false;
                    _showOpeningNote = true;
                  });
                },
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 30,
                    vertical: 13,
                  ),
                  decoration: BoxDecoration(
                    color: const Color(0xFF141829).withOpacity(.85),
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(
                      color: Colors.white.withOpacity(.10),
                      width: 1,
                    ),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        Icons.close_rounded,
                        color: Colors.white.withOpacity(.6),
                        size: 15,
                      ),
                      const SizedBox(width: 8),
                      Text(
                        'BATAL',
                        style: TextStyle(
                          color: Colors.white.withOpacity(.65),
                          fontSize: 11,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 2.5,
                          fontFamily: 'Astral',
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 8),
            ],
          ),
        ),
      ),
    );
  }

  Widget _securityMiniBadge({
    required IconData icon,
    required String label,
    required Color color,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
      decoration: BoxDecoration(
        color: const Color(0xFF131728).withOpacity(.85),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: Colors.white.withOpacity(.08),
          width: 1,
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: color, size: 13),
          const SizedBox(width: 6),
          Text(
            label,
            style: TextStyle(
              color: Colors.white.withOpacity(.65),
              fontSize: 10,
              fontWeight: FontWeight.w700,
              letterSpacing: 1.3,
              fontFamily: 'Astral',
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildModernSensor({
    required Color cyan,
    required Color magenta,
    required Color failRed,
    required Color successGreen,
  }) {
    final isPressed = _fingerOnSensor;
    final progress = _scanProgress;

    final Color iconColor = _scanFailed
        ? failRed
        : _scanSuccess
            ? successGreen
            : isPressed
                ? cyan
                : Colors.white.withOpacity(.88);

    return AnimatedScale(
      scale: isPressed ? 1.05 : (_scanFailed ? 0.96 : 1.0),
      duration: const Duration(milliseconds: 140),
      curve: Curves.easeOutCubic,
      child: SizedBox(
        width: 226,
        height: 226,
        child: Stack(
          alignment: Alignment.center,
          children: [
            // Ambient glow di belakang cincin
            Container(
              width: 195,
              height: 195,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: (_scanFailed
                            ? failRed
                            : _scanSuccess
                                ? successGreen
                                : cyan)
                        .withOpacity(isPressed ? .32 : .14),
                    blurRadius: isPressed ? 48 : 32,
                    spreadRadius: isPressed ? 6 : 2,
                  ),
                  BoxShadow(
                    color: magenta.withOpacity(isPressed ? .24 : .10),
                    blurRadius: 42,
                    spreadRadius: 2,
                  ),
                ],
              ),
            ),

            // Custom Painter untuk Dashed Ring + Gradient Progress Arc
            CustomPaint(
              size: const Size(226, 226),
              painter: _BiometricRingPainter(
                progress: progress,
                isScanning: _isScanning,
                isFailed: _scanFailed,
                isSuccess: _scanSuccess,
                pulseValue: _pulseCtrl.value,
              ),
            ),

            // Lingkaran dalam sensor
            Container(
              width: 158,
              height: 158,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [
                    const Color(0xFF1E243B).withOpacity(.92),
                    const Color(0xFF121626).withOpacity(.96),
                  ],
                ),
                border: Border.all(
                  color: _scanFailed
                      ? failRed.withOpacity(.55)
                      : _scanSuccess
                          ? successGreen.withOpacity(.65)
                          : isPressed
                              ? cyan.withOpacity(.5)
                              : Colors.white.withOpacity(.08),
                  width: 1.4,
                ),
              ),
              child: Stack(
                alignment: Alignment.center,
                children: [
                  Icon(
                    _scanFailed
                        ? Icons.fingerprint_rounded
                        : _scanSuccess
                            ? Icons.check_rounded
                            : Icons.fingerprint_rounded,
                    size: 70,
                    color: iconColor,
                  ),
                  // Garis laser pemindai bergerak naik-turun saat jari ditempelkan
                  if (_isScanning && !_scanFailed && !_scanSuccess)
                    Positioned(
                      top: 34 + (84 * ((math.sin(progress * math.pi * 4) + 1) / 2)),
                      child: Container(
                        width: 88,
                        height: 2.5,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(2),
                          gradient: LinearGradient(
                            colors: [
                              Colors.transparent,
                              cyan,
                              magenta,
                              Colors.transparent,
                            ],
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: cyan.withOpacity(.9),
                              blurRadius: 10,
                              spreadRadius: 1,
                            ),
                          ],
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // LANDING
  // ============================================================
  Widget _buildLanding() {
    return SafeArea(
      key: const ValueKey('landing_main'),
      child: Stack(
        children: [
          SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            padding: const EdgeInsets.fromLTRB(18, 16, 18, 116),
            child: Column(
              children: [
                _spawn(.00, _buildHeader()),
                const SizedBox(height: 18),
                _spawn(.08, _buildHero()),
                const SizedBox(height: 15),
                _spawn(.18, _buildWelcomeCards()),
                const SizedBox(height: 15),
                _spawn(.30, _buildEngineStatus()),
                const SizedBox(height: 15),
                _spawn(.42, _buildOnlineCard()),
                const SizedBox(height: 15),
                _spawn(.54, _buildEnterButton()),
                const SizedBox(height: 12),
                _spawn(.58, _buildCekAkunButton()),
                const SizedBox(height: 12),
                _spawn(.62, _buildBuyButton()),
                const SizedBox(height: 12),
                _spawn(.67, _buildContactButton()),
                const SizedBox(height: 16),
                _spawn(.75, _buildFooter()),
              ],
            ),
          ),
          Positioned(
            left: 14,
            right: 14,
            bottom: 12,
            child: _buildBottomNavigation(),
          ),
        ],
      ),
    );
  }

  Widget _spawn(double start, Widget child) {
    final end = math.min(start + .32, 1.0);
    return AnimatedBuilder(
      animation: _revealCtrl,
      child: child,
      builder: (_, child) {
        final raw =
            ((_revealCtrl.value - start) / (end - start)).clamp(0.0, 1.0);
        final curve = Curves.easeOutBack.transform(raw);
        return Opacity(
          opacity: raw,
          child: Transform.translate(
            offset: Offset(0, 32 * (1 - curve)),
            child: Transform.scale(
              scale: .93 + (.07 * curve),
              child: child,
            ),
          ),
        );
      },
    );
  }

  Widget _buildHeader() {
    return Row(
      children: [
        Expanded(
          child: Column(
            children: [
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 22, vertical: 10),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(18),
                  gradient: AppColors.btnGrad,
                  border: Border.all(
                    color: Colors.white.withOpacity(.2),
                    width: 1.2,
                  ),
                  boxShadow: AppColors.glassShadow,
                ),
                child: const Text(
                  'NOVARCH',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 4,
                    fontFamily: 'ARABOLIC',
                  ),
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'LIQUID GLASS • FLUTTER ENGINE',
                style: TextStyle(
                  color: AppColors.textSub,
                  fontSize: 8,
                  letterSpacing: 2,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
        const SizedBox(width: 8),
        _glassIcon(
          Icons.support_agent_rounded,
          AppColors.gold,
          () => _openUrl('https://t.me/Jentrick2'),
        ),
      ],
    );
  }

  Widget _glassIcon(IconData icon, Color color, VoidCallback onTap) {
    return _Pressable(
      onTap: onTap,
      child: Container(
        width: 46,
        height: 46,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          color: AppColors.card2.withOpacity(.7),
          border: Border.all(
            color: AppColors.borderLit.withOpacity(.5),
            width: 1,
          ),
          boxShadow: [
            BoxShadow(
              color: color.withOpacity(.25),
              blurRadius: 20,
              offset: const Offset(0, 6),
            ),
          ],
        ),
        child: Icon(icon, color: color, size: 21),
      ),
    );
  }

  Widget _buildHero() {
    return Container(
      height: 218,
      width: double.infinity,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(28),
        border: Border.all(
          color: AppColors.borderLit.withOpacity(.5),
          width: 1.2,
        ),
        boxShadow: [
          BoxShadow(
            color: AppColors.accent.withOpacity(.35),
            blurRadius: 40,
            spreadRadius: 2,
          ),
          BoxShadow(
            color: Colors.black.withOpacity(.32),
            blurRadius: 30,
            offset: const Offset(0, 15),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(27),
        child: Stack(
          children: [
            if (_videoReady)
              Positioned.fill(
                child: Opacity(
                  opacity: .42,
                  child: FittedBox(
                    fit: BoxFit.cover,
                    child: SizedBox(
                      width: _videoController.value.size.width,
                      height: _videoController.value.size.height,
                      child: VideoPlayer(_videoController),
                    ),
                  ),
                ),
              )
            else
              Positioned.fill(
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    gradient: RadialGradient(
                      colors: [AppColors.card2, AppColors.bg],
                    ),
                  ),
                ),
              ),
            Positioned.fill(
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      AppColors.bg.withOpacity(.65),
                      AppColors.accent.withOpacity(.20),
                      AppColors.bg.withOpacity(.85),
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
              ),
            ),
            Positioned.fill(
              child: CustomPaint(
                painter: _CosmicPainter(animation: _pulseCtrl.value),
              ),
            ),
            Positioned(
              top: 15,
              right: 15,
              child: _statusPill('● LIVE', AppColors.green),
            ),
            Positioned(
              left: 20,
              bottom: 20,
              right: 20,
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'GOOD EVENING',
                          style: TextStyle(
                            color: AppColors.textSub,
                            fontSize: 9,
                            letterSpacing: 3,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          'WELCOME TO NOVARCH',
                          style: TextStyle(
                            color: AppColors.text,
                            fontSize: 20,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 1,
                            fontFamily: 'Astral',
                            shadows: [
                              Shadow(
                                color: AppColors.accent.withOpacity(.8),
                                blurRadius: 22,
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 10),
                        Row(
                          children: [
                            _statusPill('FLUTTER', AppColors.accent),
                            const SizedBox(width: 7),
                            _statusPill('LUXURY ON!', AppColors.gold),
                          ],
                        ),
                      ],
                    ),
                  ),
                  _floatingIcon(Icons.auto_awesome_rounded, AppColors.gold),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _statusPill(String text, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: color.withOpacity(.18),
        borderRadius: BorderRadius.circular(30),
        border: Border.all(
          color: color.withOpacity(.55),
          width: 1,
        ),
      ),
      child: Text(
        text,
        style: TextStyle(
          color: color,
          fontSize: 7.5,
          fontWeight: FontWeight.w900,
          letterSpacing: 1,
        ),
      ),
    );
  }

  Widget _floatingIcon(IconData icon, Color color) {
    return AnimatedBuilder(
      animation: _floatCtrl,
      builder: (_, __) {
        final offset = math.sin(_floatCtrl.value * math.pi) * 4;
        return Transform.translate(
          offset: Offset(0, -offset),
          child: Container(
            width: 60,
            height: 60,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: RadialGradient(
                colors: [
                  color.withOpacity(.95),
                  color.withOpacity(.4),
                ],
              ),
              border: Border.all(
                color: Colors.white.withOpacity(.28),
                width: 1.5,
              ),
              boxShadow: [
                BoxShadow(
                  color: color.withOpacity(.55),
                  blurRadius: 26,
                  spreadRadius: 2,
                ),
              ],
            ),
            child: Icon(icon, color: Colors.black, size: 27),
          ),
        );
      },
    );
  }

  Widget _buildWelcomeCards() {
    return Row(
      children: [
        Expanded(
          child: _infoCard(
            icon: Icons.waving_hand_rounded,
            value: 'WELCOME',
            label: 'NOVARCH USER',
            color: AppColors.accent,
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: _infoCard(
            icon: Icons.auto_awesome_rounded,
            value: 'LUXURY',
            label: 'LIQUID EDITION',
            color: AppColors.gold,
          ),
        ),
      ],
    );
  }

  Widget _infoCard({
    required IconData icon,
    required String value,
    required String label,
    required Color color,
  }) {
    return SizedBox(
      height: 142,
      child: _glass(
        padding: const EdgeInsets.all(16),
        radius: 24,
        glowOpacity: .18,
        glowColor: color,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(14),
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    color.withOpacity(.9),
                    color.withOpacity(.45),
                  ],
                ),
                border: Border.all(
                  color: Colors.white.withOpacity(.25),
                  width: 1,
                ),
                boxShadow: [
                  BoxShadow(
                    color: color.withOpacity(.45),
                    blurRadius: 18,
                  ),
                ],
              ),
              child: Icon(icon, color: Colors.black, size: 22),
            ),
            const Spacer(),
            Text(
              value,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                color: color,
                fontSize: 17,
                fontWeight: FontWeight.w900,
                fontFamily: 'Astral',
              ),
            ),
            const SizedBox(height: 4),
            Text(
              label,
              style: TextStyle(
                color: AppColors.textSub,
                fontSize: 7.5,
                letterSpacing: 1.4,
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEngineStatus() {
    return _glass(
      glowOpacity: .2,
      glowColor: AppColors.green,
      child: Column(
        children: [
          Row(
            children: [
              Container(
                width: 46,
                height: 46,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(14),
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      AppColors.green.withOpacity(.9),
                      AppColors.green.withOpacity(.45),
                    ],
                  ),
                  border: Border.all(
                    color: Colors.white.withOpacity(.22),
                    width: 1,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: AppColors.green.withOpacity(.4),
                      blurRadius: 16,
                    ),
                  ],
                ),
                child: const Icon(Icons.speed_rounded, color: Colors.white),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'ACTIVE SESSION',
                      style: TextStyle(
                        color: AppColors.textSub,
                        fontSize: 8,
                        letterSpacing: 2,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'NOVARCH CORE READY',
                      style: TextStyle(
                        color: AppColors.text,
                        fontSize: 13,
                        fontWeight: FontWeight.w900,
                        fontFamily: 'Astral',
                      ),
                    ),
                  ],
                ),
              ),
              _statusPill('READY', AppColors.green),
            ],
          ),
          const SizedBox(height: 16),
          AnimatedBuilder(
            animation: _pulseCtrl,
            builder: (_, __) {
              final value = .84 + (_pulseCtrl.value * .05);
              return ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: Stack(
                  children: [
                    Container(
                      height: 10,
                      color: AppColors.card2,
                    ),
                    FractionallySizedBox(
                      widthFactor: value,
                      child: Container(
                        height: 10,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              AppColors.green,
                              AppColors.green.withOpacity(.6),
                            ],
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: AppColors.green.withOpacity(.6),
                              blurRadius: 12,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
          const SizedBox(height: 10),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'ENGINE STABILITY',
                style: TextStyle(
                  color: AppColors.textSub,
                  fontSize: 7.5,
                  letterSpacing: 1.4,
                  fontWeight: FontWeight.w600,
                ),
              ),
              Text(
                'OPTIMAL',
                style: TextStyle(
                  color: AppColors.green,
                  fontSize: 7.5,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.4,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildOnlineCard() {
    return _glass(
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
      glowOpacity: .16,
      glowColor: AppColors.green,
      child: Row(
        children: [
          AnimatedBuilder(
            animation: _pulseCtrl,
            builder: (_, __) {
              final size = 12 + (_pulseCtrl.value * 3);
              return Container(
                width: size,
                height: size,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: AppColors.green,
                  boxShadow: [
                    BoxShadow(
                      color: AppColors.green.withOpacity(.8),
                      blurRadius: 16,
                      spreadRadius: 1,
                    ),
                  ],
                ),
              );
            },
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              'NOVARCH USERS ONLINE',
              style: TextStyle(
                color: AppColors.text,
                fontSize: 9,
                fontWeight: FontWeight.w900,
                letterSpacing: 1.7,
                fontFamily: 'Astral',
              ),
            ),
          ),
          Text(
            'LUXURY LIVE',
            style: TextStyle(
              color: AppColors.textSub,
              fontSize: 7,
              letterSpacing: 1.2,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEnterButton() {
    return _GradientButton(
      label: 'ENTER NOVARCH',
      icon: Icons.arrow_forward_rounded,
      color: AppColors.accent,
      onTap: () => Navigator.pushNamed(context, '/login'),
    );
  }

  Widget _buildCekAkunButton() {
    return _Pressable(
      onTap: _openCekAkun,
      child: Container(
        height: 58,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              AppColors.accent.withOpacity(.85),
              AppColors.accentDark.withOpacity(.6),
            ],
          ),
          border: Border.all(
            color: Colors.white.withOpacity(.22),
            width: 1.2,
          ),
          boxShadow: AppColors.glassShadow,
        ),
        child: const Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.manage_search_rounded, color: Colors.white, size: 22),
            SizedBox(width: 11),
            Text(
              'CEK AKUN',
              style: TextStyle(
                color: Colors.white,
                fontSize: 14,
                fontWeight: FontWeight.w900,
                letterSpacing: 2,
                fontFamily: 'Astral',
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBuyButton() {
    return _Pressable(
      onTap: _openBuy,
      child: Container(
        height: 58,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              AppColors.gold.withOpacity(.95),
              AppColors.amber.withOpacity(.7),
            ],
          ),
          border: Border.all(
            color: Colors.white.withOpacity(.3),
            width: 1.2,
          ),
          boxShadow: [
            BoxShadow(
              color: AppColors.gold.withOpacity(.5),
              blurRadius: 30,
              offset: const Offset(0, 10),
            ),
          ],
        ),
        child: const Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.shopping_cart_rounded, color: Colors.black, size: 22),
            SizedBox(width: 11),
            Text(
              'BELI AKUN',
              style: TextStyle(
                color: Colors.black,
                fontSize: 14,
                fontWeight: FontWeight.w900,
                letterSpacing: 2,
                fontFamily: 'Astral',
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildContactButton() {
    return _OutlineButton(
      label: 'CONTACT DEVELOPER',
      icon: Icons.telegram_rounded,
      color: AppColors.gold,
      onTap: () => _openUrl('https://t.me/Jentrick2'),
    );
  }

  Widget _buildBottomNavigation() {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(26),
        boxShadow: AppColors.glassShadow,
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(26),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 22, sigmaY: 22),
          child: Container(
            height: 72,
            padding: const EdgeInsets.symmetric(horizontal: 6),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(26),
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  AppColors.card2.withOpacity(.6),
                  AppColors.bg.withOpacity(.85),
                ],
              ),
              border: Border.all(
                color: AppColors.glassBorder,
                width: ThemeModeManager.isComic3d ? 3 : 1.2,
              ),
            ),
            child: Row(
              children: [
                Expanded(
                  child: _navItem(
                    icon: Icons.home_rounded,
                    label: 'HOME',
                    active: true,
                    color: AppColors.accent,
                    onTap: () {},
                  ),
                ),
                Expanded(
                  child: _navItem(
                    icon: Icons.manage_search_rounded,
                    label: 'CEK AKUN',
                    active: false,
                    color: AppColors.accent,
                    onTap: _openCekAkun,
                  ),
                ),
                Expanded(
                  child: _navItem(
                    icon: Icons.shopping_cart_rounded,
                    label: 'BELI',
                    active: false,
                    color: AppColors.gold,
                    onTap: _openBuy,
                  ),
                ),
                Expanded(
                  child: _navItem(
                    icon: Icons.login_rounded,
                    label: 'LOGIN',
                    active: false,
                    color: AppColors.accentLight,
                    onTap: () => Navigator.pushNamed(context, '/login'),
                  ),
                ),
                Expanded(
                  child: _navItem(
                    icon: Icons.telegram_rounded,
                    label: 'CONTACT',
                    active: false,
                    color: AppColors.gold,
                    onTap: () => _openUrl('https://t.me/Jentrick2'),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _navItem({
    required IconData icon,
    required String label,
    required bool active,
    required Color color,
    required VoidCallback onTap,
  }) {
    return _Pressable(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 280),
        curve: Curves.easeOutBack,
        margin: const EdgeInsets.symmetric(vertical: 10, horizontal: 3),
        decoration: BoxDecoration(
          color: active ? color.withOpacity(.2) : Colors.transparent,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(
            color: active ? color.withOpacity(.55) : Colors.transparent,
            width: 1,
          ),
          boxShadow: active
              ? [
                  BoxShadow(
                    color: color.withOpacity(.35),
                    blurRadius: 20,
                    spreadRadius: 1,
                  ),
                ]
              : null,
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            AnimatedContainer(
              duration: const Duration(milliseconds: 260),
              transform: active
                  ? Matrix4.translationValues(0, -2, 0)
                  : Matrix4.identity(),
              child: Icon(
                icon,
                color: active ? color : color.withOpacity(.8),
                size: 20,
              ),
            ),
            const SizedBox(height: 3),
            Text(
              label,
              style: TextStyle(
                color: active ? color : color.withOpacity(.75),
                fontSize: 6.5,
                fontWeight: FontWeight.w900,
                letterSpacing: 0.5,
              ),
              textAlign: TextAlign.center,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFooter() {
    return _glass(
      glowOpacity: .18,
      child: Column(
        children: [
          Text(
            'NOVARCH',
            style: TextStyle(
              color: AppColors.text,
              fontSize: 12,
              fontWeight: FontWeight.w900,
              letterSpacing: 4,
              fontFamily: 'Astral',
            ),
          ),
          const SizedBox(height: 6),
          Text(
            'LIQUID GLASS EXPERIENCE',
            style: TextStyle(
              color: AppColors.textSub,
              fontSize: 7.5,
              letterSpacing: 2,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 18),
          Container(
            height: 1,
            color: AppColors.border.withOpacity(.3),
          ),
          const SizedBox(height: 14),
          Text(
            '© 2026 NOVARCH • ALL RIGHTS RESERVED',
            style: TextStyle(
              color: AppColors.textHint,
              fontSize: 7.5,
              letterSpacing: 1.2,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// BIOMETRIC RING PAINTER (Matching Reference UI)
// ============================================================
class _BiometricRingPainter extends CustomPainter {
  final double progress;
  final bool isScanning;
  final bool isFailed;
  final bool isSuccess;
  final double pulseValue;

  _BiometricRingPainter({
    required this.progress,
    required this.isScanning,
    required this.isFailed,
    required this.isSuccess,
    required this.pulseValue,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final outerRadius = (size.width / 2) - 8;

    // 1. Dashed Outer Ring (seperti garis putus-putus melingkar pada gambar)
    const int dashCount = 76;
    const double dashAngle = (2 * math.pi) / dashCount;
    final dashPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.6
      ..strokeCap = StrokeCap.round
      ..color = isFailed
          ? const Color(0xFFF43F5E).withOpacity(.35)
          : isSuccess
              ? const Color(0xFF34D399).withOpacity(.45)
              : const Color(0xFF94A3B8).withOpacity(.28);

    for (int i = 0; i < dashCount; i++) {
      final start = i * dashAngle;
      canvas.drawArc(
        Rect.fromCircle(center: center, radius: outerRadius),
        start,
        dashAngle * 0.45,
        false,
        dashPaint,
      );
    }

    // 2. Gradient Arc (idle: melengkung di bagian atas-kiri; scanning: mengisi 0% -> 100%)
    final rect = Rect.fromCircle(center: center, radius: outerRadius);
    final SweepGradient gradient;
    if (isFailed) {
      gradient = const SweepGradient(
        colors: [
          Color(0xFFF43F5E),
          Color(0xFFFB7185),
          Color(0xFFF43F5E),
        ],
      );
    } else if (isSuccess) {
      gradient = const SweepGradient(
        colors: [
          Color(0xFF34D399),
          Color(0xFF38BDF8),
          Color(0xFF34D399),
        ],
      );
    } else {
      gradient = const SweepGradient(
        colors: [
          Color(0xFF38BDF8), // Cyan
          Color(0xFFC084FC), // Purple
          Color(0xFFF472B6), // Pink/Magenta
          Color(0xFF818CF8), // Indigo
          Color(0xFF38BDF8), // Cyan
        ],
      );
    }

    final arcPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = isScanning ? 3.8 : 2.8
      ..strokeCap = StrokeCap.round
      ..shader = gradient.createShader(rect);

    if (isScanning || isSuccess) {
      final sweep = (progress.clamp(0.0, 1.0)) * 2 * math.pi;
      canvas.drawArc(
        rect,
        -math.pi / 2,
        sweep,
        false,
        arcPaint,
      );
    } else if (isFailed) {
      canvas.drawArc(
        rect,
        0,
        2 * math.pi,
        false,
        arcPaint,
      );
    } else {
      // Idle decorative partial arc (dari kiri bawah melengkung ke kanan atas)
      final idleStart = math.pi * 0.68 + (pulseValue * 0.08);
      const idleSweep = math.pi * 1.18;
      canvas.drawArc(
        rect,
        idleStart,
        idleSweep,
        false,
        arcPaint,
      );
    }
  }

  @override
  bool shouldRepaint(covariant _BiometricRingPainter old) =>
      old.progress != progress ||
      old.isScanning != isScanning ||
      old.isFailed != isFailed ||
      old.isSuccess != isSuccess ||
      old.pulseValue != pulseValue;
}

// ============================================================
// PAINTERS
// ============================================================
class _AuroraPainter extends CustomPainter {
  final Animation<double> animation;
  _AuroraPainter({required this.animation}) : super(repaint: animation);

  @override
  void paint(Canvas canvas, Size size) {
    canvas.drawRect(
      Rect.fromLTWH(0, 0, size.width, size.height),
      Paint()..color = AppColors.bg,
    );

    final gridPaint = Paint()
      ..color = AppColors.border.withOpacity(.08)
      ..strokeWidth = 0.6;
    const spacing = 48.0;
    for (double x = 0; x < size.width; x += spacing) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), gridPaint);
    }
    for (double y = 0; y < size.height; y += spacing) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), gridPaint);
    }

    final t = animation.value * 2 * math.pi;
    final pts = [
      Offset(size.width * .15 + math.sin(t) * 40, size.height * .12),
      Offset(size.width * .85, size.height * .35 + math.cos(t) * 50),
      Offset(size.width * .5, size.height * .85 + math.sin(t) * 30),
    ];
    final colors = [
      AppColors.accent.withOpacity(.20),
      AppColors.accentLight.withOpacity(.12),
      AppColors.accentDark.withOpacity(.18),
    ];
    for (var i = 0; i < pts.length; i++) {
      final p = Paint()
        ..shader = RadialGradient(
          colors: [colors[i], Colors.transparent],
        ).createShader(Rect.fromCircle(center: pts[i], radius: 280));
      canvas.drawCircle(pts[i], 280, p);
    }

    final particle = Paint()..color = AppColors.accent.withOpacity(.14);
    for (int i = 0; i < 45; i++) {
      final x = ((i * 73.0) % size.width);
      final y = ((i * 127.0 + animation.value * 120) % size.height);
      canvas.drawCircle(Offset(x, y), 1.0, particle);
    }
  }

  @override
  bool shouldRepaint(covariant _AuroraPainter old) => true;
}

class _CosmicPainter extends CustomPainter {
  final double animation;
  _CosmicPainter({required this.animation});

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width * .76, size.height * .48);

    final ringPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1
      ..color = AppColors.accentLight.withOpacity(.22);

    for (int i = 0; i < 7; i++) {
      final radius = 30 + (i * 18) + animation * 5;
      canvas.drawCircle(center, radius, ringPaint);
    }

    final particles = Paint()..color = AppColors.gold.withOpacity(.26);
    for (int i = 0; i < 35; i++) {
      final x = (i * 43.0) % size.width;
      final y = (i * 29.0 + animation * 20) % size.height;
      canvas.drawCircle(Offset(x, y), 1.0, particles);
    }
  }

  @override
  bool shouldRepaint(covariant _CosmicPainter old) =>
      old.animation != animation;
}

// ============================================================
// WIDGET HELPERS
// ============================================================
class _Pressable extends StatefulWidget {
  final Widget child;
  final VoidCallback onTap;
  const _Pressable({required this.child, required this.onTap});

  @override
  State<_Pressable> createState() => _PressableState();
}

class _PressableState extends State<_Pressable>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 110),
    lowerBound: 0,
    upperBound: .045,
  );

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTapDown: (_) => _controller.forward(),
      onTapUp: (_) {
        _controller.reverse();
        widget.onTap();
      },
      onTapCancel: () => _controller.reverse(),
      child: AnimatedBuilder(
        animation: _controller,
        builder: (_, child) => Transform.scale(
          scale: 1 - _controller.value,
          child: child,
        ),
        child: widget.child,
      ),
    );
  }
}

class _GradientButton extends StatefulWidget {
  final String label;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;
  const _GradientButton({
    required this.label,
    required this.icon,
    required this.color,
    required this.onTap,
  });

  @override
  State<_GradientButton> createState() => _GradientButtonState();
}

class _GradientButtonState extends State<_GradientButton>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 120),
  );

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => _controller.forward(),
      onTapUp: (_) {
        _controller.reverse();
        widget.onTap();
      },
      onTapCancel: () => _controller.reverse(),
      child: AnimatedBuilder(
        animation: _controller,
        builder: (_, child) => Transform.scale(
          scale: 1 - (_controller.value * .035),
          child: child,
        ),
        child: Container(
          height: 60,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            gradient: AppColors.btnGrad,
            border: Border.all(
              color: Colors.white.withOpacity(.3),
              width: 1.2,
            ),
            boxShadow: AppColors.glassShadow,
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(widget.icon, color: Colors.white, size: 22),
              const SizedBox(width: 11),
              Text(
                widget.label,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 14,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.4,
                  fontFamily: 'Astral',
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _OutlineButton extends StatelessWidget {
  final String label;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;
  const _OutlineButton({
    required this.label,
    required this.icon,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return _Pressable(
      onTap: onTap,
      child: Container(
        height: 58,
        decoration: BoxDecoration(
          color: AppColors.card2.withOpacity(.5),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: color.withOpacity(.45),
            width: 1.2,
          ),
          boxShadow: [
            BoxShadow(
              color: color.withOpacity(.22),
              blurRadius: 22,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: color, size: 20),
            const SizedBox(width: 11),
            Text(
              label,
              style: TextStyle(
                color: color,
                fontSize: 12,
                fontWeight: FontWeight.w900,
                letterSpacing: 1.1,
                fontFamily: 'Astral',
              ),
            ),
          ],
        ),
      ),
    );
  }
}
