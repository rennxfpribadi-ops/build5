// developer_page.dart
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:ui';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

import 'theme.dart';

// ─── GLOBAL FONT ───────────────────────────────────────────────────────
const String kFont = 'Pek';
const String _kBase = 'http://cp.zyrostore.id:3448';

// ─── PALETTE ───────────────────────────────────────────────────────────
class _C {
  static Color get bg        => AppColors.bg;
  static Color get surface   => AppColors.dark;
  static Color get card      => AppColors.card;
  static Color get cardAlt   => AppColors.card2;
  static Color get border    => AppColors.border;
  static Color get borderLit => AppColors.borderLit;

  static Color get primary    => AppColors.accent;
  static Color get primaryMid => AppColors.accentMid;
  static Color get primaryLt  => AppColors.accentLight;
  static Color get primaryDk  => AppColors.accentDark;

  static Color get green => AppColors.green;
  static Color get amber => AppColors.amber;
  static Color get red   => AppColors.red;

  static Color get text    => AppColors.text;
  static Color get textSub => AppColors.textSub;
  static Color get textDim => AppColors.textHint;

  static LinearGradient get btnGrad => AppColors.btnGrad;
  static LinearGradient get glassGrad => AppColors.glassGrad;
  static List<BoxShadow> get glassShadow => AppColors.glassShadow;
  static List<BoxShadow> get softShadow => AppColors.softShadow;
}

Color _onAccent() =>
    ThemeModeManager.isComic3d ? const Color(0xFF1A1A1A) : Colors.white;

class DeveloperPage extends StatefulWidget {
  final String sessionKey;
  final String username;

  const DeveloperPage({
    super.key,
    required this.sessionKey,
    required this.username,
  });

  @override
  State<DeveloperPage> createState() => _DeveloperPageState();
}

class _DeveloperPageState extends State<DeveloperPage> {
  int _navIndex = 0;
  late String sessionKey;

  List<dynamic> fullUserList = [];
  List<dynamic> filteredList = [];

  final List<String> roleOptions = ['owner', 'admin', 'vip', 'reseller', 'fullup', 'member'];
  String selectedRole = 'member';

  int currentPage = 1;
  int itemsPerPage = 25;

  final createUsernameController = TextEditingController();
  final createPasswordController = TextEditingController();
  final createDayController = TextEditingController();
  final deleteController = TextEditingController();
  final editUsernameController = TextEditingController();
  final editDayController = TextEditingController();

  String newUserRole = 'member';
  bool isLoading = false;

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    _fetchUsers();
  }

  @override
  void dispose() {
    createUsernameController.dispose();
    createPasswordController.dispose();
    createDayController.dispose();
    deleteController.dispose();
    editUsernameController.dispose();
    editDayController.dispose();
    super.dispose();
  }

  // ═══════════════════════════════════════════════════════════════════
  //  FETCH USERS
  // ═══════════════════════════════════════════════════════════════════
  Future<void> _fetchUsers() async {
    setState(() => isLoading = true);
    try {
      final res = await http.get(
        Uri.parse('$_kBase/listUsers?key=$sessionKey'),
      );
      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['authorized'] == true) {
        fullUserList = data['users'] ?? [];
        _filterAndPaginate();
      } else {
        _alert("Info", data['message'] ?? 'Gagal memuat user.');
      }
    } catch (_) {
      _alert("Error", "Gagal terhubung ke server.");
    }
    setState(() => isLoading = false);
  }

  void _filterAndPaginate() {
    setState(() {
      currentPage = 1;
      filteredList = fullUserList
          .where((u) => u['role'] == selectedRole)
          .toList();
    });
  }

  List<dynamic> _getCurrentPageData() {
    final start = (currentPage - 1) * itemsPerPage;
    final end = (start + itemsPerPage);
    return filteredList.sublist(
      start,
      end > filteredList.length ? filteredList.length : end,
    );
  }

  int get totalPages => (filteredList.length / itemsPerPage).ceil();

  // ═══════════════════════════════════════════════════════════════════
  //  DELETE USER
  // ═══════════════════════════════════════════════════════════════════
  Future<void> _deleteUser() async {
    final username = deleteController.text.trim();
    if (username.isEmpty) {
      _alert("Peringatan", "Masukkan username yang ingin dihapus.");
      return;
    }

    setState(() => isLoading = true);
    try {
      final res = await http.get(
        Uri.parse('$_kBase/deleteUser?key=$sessionKey&username=$username'),
      );
      final data = jsonDecode(res.body);

      if (data['deleted'] == true) {
        _alert("Sukses", "User berhasil dihapus.");
        deleteController.clear();
        _fetchUsers();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal menghapus user.');
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  // ═══════════════════════════════════════════════════════════════════
  //  CREATE ACCOUNT — Langsung create (tanpa QRIS, durasi berapa pun)
  // ═══════════════════════════════════════════════════════════════════
  Future<void> _createAccount() async {
    final u = createUsernameController.text.trim();
    final p = createPasswordController.text.trim();
    final d = createDayController.text.trim();

    if (u.isEmpty || p.isEmpty || d.isEmpty) {
      _alert("Peringatan", "Semua field wajib diisi.");
      return;
    }

    final hari = int.tryParse(d) ?? 0;
    if (hari < 1) {
      _alert("Error", "Durasi minimal 1 hari.");
      return;
    }

    if (u.length < 3) {
      _alert("Error", "Username minimal 3 karakter.");
      return;
    }

    if (p.length < 2) {
      _alert("Error", "Password minimal 2 karakter.");
      return;
    }

    // ✅ Langsung create tanpa memanggil buy/create maupun QRIS
    await _createAccountDirect(u, p, hari);
  }

  // ═══════════════════════════════════════════════════════════════════
  //  CREATE DIRECT
  // ═══════════════════════════════════════════════════════════════════
  Future<void> _createAccountDirect(String u, String p, int d) async {
    setState(() => isLoading = true);
    try {
      final url = Uri.parse(
        '$_kBase/userAdd?key=$sessionKey&username=$u&password=$p&day=$d&role=$newUserRole',
      );
      final res = await http.get(url);
      final data = jsonDecode(res.body);

      if (data['created'] == true) {
        _alert("Sukses", "Akun '${u}' (${d} hari) berhasil dibuat.");
        createUsernameController.clear();
        createPasswordController.clear();
        createDayController.clear();
        setState(() => newUserRole = 'member');
        _fetchUsers();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal membuat akun.');
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  // ═══════════════════════════════════════════════════════════════════
  //  EDIT USER
  // ═══════════════════════════════════════════════════════════════════
  Future<void> _editUser() async {
    final u = editUsernameController.text.trim();
    final d = editDayController.text.trim();

    if (u.isEmpty || d.isEmpty) {
      _alert("Peringatan", "Semua field wajib diisi.");
      return;
    }

    setState(() => isLoading = true);
    try {
      final url = Uri.parse(
        '$_kBase/editUser?key=$sessionKey&username=$u&addDays=$d',
      );
      final res = await http.get(url);
      final data = jsonDecode(res.body);

      if (data['edited'] == true) {
        _alert("Sukses", "Durasi berhasil diperbarui.");
        editUsernameController.clear();
        editDayController.clear();
        _fetchUsers();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal mengubah durasi.');
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  // ═══════════════════════════════════════════════════════════════════
  //  ALERT DIALOG
  // ═══════════════════════════════════════════════════════════════════
  void _alert(String title, String message) {
    final isComic = ThemeModeManager.isComic3d;
    showDialog(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(isComic ? 6 : 20),
          child: BackdropFilter(
            filter: ImageFilter.blur(
              sigmaX: isComic ? 0 : 15,
              sigmaY: isComic ? 0 : 15,
            ),
            child: Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                gradient: isComic ? null : _C.glassGrad,
                color: isComic ? AppColors.card : null,
                borderRadius: BorderRadius.circular(isComic ? 6 : 20),
                border: Border.all(
                  color: _C.border,
                  width: AppColors.borderWidth,
                ),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.info_outline_rounded,
                      color: _C.primaryLt, size: 40),
                  const SizedBox(height: 12),
                  Text(title,
                      style: TextStyle(
                          color: _C.text,
                          fontFamily: kFont,
                          fontSize: 16,
                          fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  Text(message,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          color: _C.textSub,
                          fontFamily: kFont,
                          fontSize: 13,
                          height: 1.5)),
                  const SizedBox(height: 20),
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 32, vertical: 12),
                      decoration: BoxDecoration(
                        gradient: _C.btnGrad,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text("OK",
                          style: TextStyle(
                              color: _onAccent(),
                              fontFamily: kFont,
                              fontWeight: FontWeight.bold)),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  INPUT WIDGET
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildInput({
    required String label,
    required TextEditingController controller,
    required IconData icon,
    TextInputType type = TextInputType.text,
    String hint = "",
    bool obscure = false,
  }) {
    final isComic = ThemeModeManager.isComic3d;
    return Padding(
      padding: const EdgeInsets.only(bottom: 15),
      child: TextField(
        controller: controller,
        keyboardType: type,
        obscureText: obscure,
        style: TextStyle(color: _C.text, fontFamily: kFont),
        decoration: InputDecoration(
          labelText: label,
          hintText: hint,
          hintStyle: TextStyle(color: _C.textDim, fontFamily: kFont),
          labelStyle: TextStyle(color: _C.primaryLt, fontFamily: kFont),
          prefixIcon: Icon(icon, color: _C.primaryLt),
          filled: true,
          fillColor: _C.surface,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(isComic ? 4 : 12),
            borderSide:
                BorderSide(color: _C.border, width: AppColors.borderWidth),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(isComic ? 4 : 12),
            borderSide:
                BorderSide(color: _C.border, width: AppColors.borderWidth),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(isComic ? 4 : 12),
            borderSide: BorderSide(color: _C.primaryLt, width: 2),
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  GLASS CARD
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildGlassCard({
    required String title,
    required IconData icon,
    required List<Widget> children,
  }) {
    final isComic = ThemeModeManager.isComic3d;
    return ClipRRect(
      borderRadius: BorderRadius.circular(AppColors.cardRadius),
      child: BackdropFilter(
        filter: ImageFilter.blur(
          sigmaX: isComic ? 0 : 10,
          sigmaY: isComic ? 0 : 10,
        ),
        child: Container(
          margin: const EdgeInsets.only(bottom: 20),
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            gradient: isComic ? null : _C.glassGrad,
            color: isComic ? AppColors.card : null,
            borderRadius: BorderRadius.circular(AppColors.cardRadius),
            border: Border.all(
              color: _C.border,
              width: AppColors.borderWidth,
            ),
            boxShadow: _C.glassShadow,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: _C.primary.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(isComic ? 4 : 10),
                      border:
                          Border.all(color: _C.primary.withOpacity(0.3)),
                    ),
                    child: Icon(icon, color: _C.primaryLt, size: 18),
                  ),
                  const SizedBox(width: 12),
                  Text(
                    title,
                    style: TextStyle(
                      color: _C.text,
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                      fontFamily: kFont,
                      letterSpacing: 1,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              ...children,
            ],
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  ROLE DROPDOWN
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildRoleDropdown({
    required String value,
    required Function(String) onChanged,
  }) {
    final isComic = ThemeModeManager.isComic3d;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
      decoration: BoxDecoration(
        color: _C.surface,
        borderRadius: BorderRadius.circular(isComic ? 4 : 12),
        border: Border.all(color: _C.border, width: AppColors.borderWidth),
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          value: value,
          isExpanded: true,
          dropdownColor: AppColors.card,
          style: TextStyle(color: _C.text, fontFamily: kFont),
          icon: Icon(Icons.arrow_drop_down_rounded, color: _C.primaryLt),
          items: roleOptions.map((role) {
            return DropdownMenuItem(
              value: role,
              child: Text(role.toUpperCase(),
                  style: TextStyle(fontFamily: kFont, color: _C.text)),
            );
          }).toList(),
          onChanged: (val) {
            if (val != null) onChanged(val);
          },
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  USER LIST ITEM
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildUserItem(Map user) {
    final isComic = ThemeModeManager.isComic3d;
    return ClipRRect(
      borderRadius: BorderRadius.circular(isComic ? 4 : 14),
      child: BackdropFilter(
        filter: ImageFilter.blur(
          sigmaX: isComic ? 0 : 8,
          sigmaY: isComic ? 0 : 8,
        ),
        child: Container(
          margin: const EdgeInsets.symmetric(vertical: 5),
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          decoration: BoxDecoration(
            gradient: isComic ? null : _C.glassGrad,
            color: isComic ? AppColors.card : null,
            borderRadius: BorderRadius.circular(isComic ? 4 : 14),
            border:
                Border.all(color: _C.border, width: AppColors.borderWidth),
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: _C.primary.withOpacity(0.15),
                  shape: BoxShape.circle,
                  border: Border.all(color: _C.primary.withOpacity(0.3)),
                ),
                child: Icon(Icons.person_rounded,
                    color: _C.primaryLt, size: 18),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(user['username'] ?? '-',
                        style: TextStyle(
                            color: _C.text,
                            fontFamily: kFont,
                            fontWeight: FontWeight.bold,
                            fontSize: 14)),
                    const SizedBox(height: 3),
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 6, vertical: 2),
                          decoration: BoxDecoration(
                            color: _C.primary.withOpacity(0.15),
                            borderRadius: BorderRadius.circular(4),
                          ),
                          child: Text(
                              (user['role'] ?? 'member')
                                  .toString()
                                  .toUpperCase(),
                              style: TextStyle(
                                  color: _C.primaryLt,
                                  fontFamily: kFont,
                                  fontSize: 9,
                                  fontWeight: FontWeight.bold)),
                        ),
                        const SizedBox(width: 8),
                        Icon(Icons.calendar_today_rounded,
                            color: _C.textDim, size: 10),
                        const SizedBox(width: 4),
                        Expanded(
                          child: Text(user['expiredDate'] ?? '-',
                              style: TextStyle(
                                  color: _C.textSub,
                                  fontFamily: kFont,
                                  fontSize: 11),
                              overflow: TextOverflow.ellipsis),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              GestureDetector(
                onTap: () async {
                  final confirm = await _confirmDialog("Hapus User?",
                      "Yakin ingin menghapus '${user['username']}'?");
                  if (confirm) {
                    deleteController.text = user['username'];
                    _deleteUser();
                  }
                },
                child: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: _C.primary.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: _C.primary.withOpacity(0.3)),
                  ),
                  child: Icon(Icons.delete_outline_rounded,
                      color: _C.primaryLt, size: 16),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<bool> _confirmDialog(String title, String message) async {
    final isComic = ThemeModeManager.isComic3d;
    final result = await showDialog<bool>(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(isComic ? 6 : 20),
          child: BackdropFilter(
            filter: ImageFilter.blur(
              sigmaX: isComic ? 0 : 15,
              sigmaY: isComic ? 0 : 15,
            ),
            child: Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                gradient: isComic ? null : _C.glassGrad,
                color: isComic ? AppColors.card : null,
                borderRadius: BorderRadius.circular(isComic ? 6 : 20),
                border: Border.all(
                    color: _C.border, width: AppColors.borderWidth),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.warning_amber_rounded,
                      color: _C.amber, size: 40),
                  const SizedBox(height: 12),
                  Text(title,
                      style: TextStyle(
                          color: _C.text,
                          fontFamily: kFont,
                          fontSize: 16,
                          fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  Text(message,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          color: _C.textSub,
                          fontFamily: kFont,
                          fontSize: 13,
                          height: 1.5)),
                  const SizedBox(height: 20),
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton(
                          onPressed: () => Navigator.pop(context, false),
                          style: OutlinedButton.styleFrom(
                            side: BorderSide(color: _C.border),
                            shape: RoundedRectangleBorder(
                                borderRadius:
                                    BorderRadius.circular(isComic ? 4 : 12)),
                            padding:
                                const EdgeInsets.symmetric(vertical: 12),
                          ),
                          child: Text("Batal",
                              style: TextStyle(
                                  color: _C.textSub, fontFamily: kFont)),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Container(
                          decoration: BoxDecoration(
                            gradient: _C.btnGrad,
                            borderRadius:
                                BorderRadius.circular(isComic ? 4 : 12),
                          ),
                          child: TextButton(
                            onPressed: () => Navigator.pop(context, true),
                            style: TextButton.styleFrom(
                              padding:
                                  const EdgeInsets.symmetric(vertical: 12),
                            ),
                            child: Text("Hapus",
                                style: TextStyle(
                                    color: _onAccent(),
                                    fontFamily: kFont,
                                    fontWeight: FontWeight.bold)),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
    return result ?? false;
  }

  // ═══════════════════════════════════════════════════════════════════
  //  PAGINATION
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildPagination() {
    if (totalPages <= 1) return const SizedBox.shrink();
    final isComic = ThemeModeManager.isComic3d;
    return Padding(
      padding: const EdgeInsets.only(top: 15),
      child: Wrap(
        spacing: 8,
        runSpacing: 8,
        alignment: WrapAlignment.center,
        children: List.generate(totalPages, (index) {
          final page = index + 1;
          final isActive = currentPage == page;
          return GestureDetector(
            onTap: () => setState(() => currentPage = page),
            child: Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
              decoration: BoxDecoration(
                gradient: isActive ? _C.btnGrad : null,
                color: isActive ? null : _C.surface,
                borderRadius: BorderRadius.circular(isComic ? 4 : 8),
                border: Border.all(
                  color: isActive ? _C.primary : _C.border,
                  width: AppColors.borderWidth,
                ),
              ),
              child: Text("$page",
                  style: TextStyle(
                      color: isActive ? _onAccent() : _C.textSub,
                      fontFamily: kFont,
                      fontSize: 12,
                      fontWeight: FontWeight.bold)),
            ),
          );
        }),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  ACTION BUTTON
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildActionButton({
    required String label,
    required IconData icon,
    required VoidCallback onTap,
    bool isLoading = false,
  }) {
    final isComic = ThemeModeManager.isComic3d;
    return Container(
      height: 52,
      decoration: BoxDecoration(
        gradient: _C.btnGrad,
        borderRadius: BorderRadius.circular(isComic ? 4 : 14),
        border: isComic ? Border.all(color: AppColors.border, width: 3) : null,
        boxShadow: isComic
            ? AppColors.softShadow
            : [
                BoxShadow(
                    color: _C.primary.withOpacity(0.3),
                    blurRadius: 16,
                    offset: const Offset(0, 4))
              ],
      ),
      child: ElevatedButton(
        onPressed: isLoading ? null : onTap,
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.transparent,
          shadowColor: Colors.transparent,
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(isComic ? 4 : 14)),
        ),
        child: isLoading
            ? const SizedBox(
                width: 20,
                height: 20,
                child: CircularProgressIndicator(
                    strokeWidth: 2, color: Colors.white))
            : Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(icon, color: _onAccent(), size: 18),
                  const SizedBox(width: 10),
                  Text(label,
                      style: TextStyle(
                          color: _onAccent(),
                          fontFamily: kFont,
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                          letterSpacing: 1)),
                ],
              ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  PAGES
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildCreatePage() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 100),
      child: _buildGlassCard(
        title: "CREATE ACCOUNT",
        icon: FontAwesomeIcons.userPlus,
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            margin: const EdgeInsets.only(bottom: 16),
            decoration: BoxDecoration(
              color: _C.primary.withOpacity(0.08),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: _C.primary.withOpacity(0.2)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(Icons.info_outline_rounded,
                        color: _C.primaryLt, size: 16),
                    const SizedBox(width: 8),
                    Text("Info",
                        style: TextStyle(
                            color: _C.primaryLt,
                            fontFamily: kFont,
                            fontSize: 11,
                            fontWeight: FontWeight.bold)),
                  ],
                ),
                const SizedBox(height: 6),
                Text(
                  "• Akun langsung dibuat tanpa pembayaran\n"
                  "• Durasi berapa pun langsung aktif",
                  style: TextStyle(
                      color: _C.textSub,
                      fontFamily: kFont,
                      fontSize: 11,
                      height: 1.6),
                ),
              ],
            ),
          ),

          _buildInput(
            label: "Username",
            controller: createUsernameController,
            icon: FontAwesomeIcons.user,
            hint: "contoh: test1",
          ),
          _buildInput(
            label: "Password",
            controller: createPasswordController,
            icon: FontAwesomeIcons.lock,
            hint: "contoh: 0101",
          ),
          _buildInput(
            label: "Durasi (Hari)",
            controller: createDayController,
            icon: FontAwesomeIcons.calendarDay,
            type: TextInputType.number,
            hint: "9999 = Permanent",
          ),
          Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.only(left: 4, bottom: 8),
                  child: Text("PILIH ROLE",
                      style: TextStyle(
                          color: _C.textSub,
                          fontFamily: kFont,
                          fontSize: 11,
                          letterSpacing: 1.5,
                          fontWeight: FontWeight.bold)),
                ),
                _buildRoleDropdown(
                  value: newUserRole,
                  onChanged: (val) => setState(() => newUserRole = val),
                ),
              ],
            ),
          ),

          const SizedBox(height: 20),
          _buildActionButton(
            label: "BUAT AKUN",
            icon: FontAwesomeIcons.userPlus,
            onTap: _createAccount,
            isLoading: isLoading,
          ),
        ],
      ),
    );
  }

  Widget _buildListPage() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 100),
      child: _buildGlassCard(
        title: "USER LIST",
        icon: FontAwesomeIcons.users,
        children: [
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: _buildRoleDropdown(
              value: selectedRole,
              onChanged: (val) {
                selectedRole = val;
                _filterAndPaginate();
              },
            ),
          ),
          if (isLoading)
            Padding(
              padding: const EdgeInsets.all(30),
              child: Center(
                  child: CircularProgressIndicator(color: _C.primaryLt)),
            )
          else if (filteredList.isEmpty)
            Padding(
              padding: const EdgeInsets.all(30),
              child: Column(
                children: [
                  Icon(Icons.inbox_rounded, color: _C.textDim, size: 40),
                  const SizedBox(height: 10),
                  Text("Tidak ada user dengan role ini",
                      style: TextStyle(
                          color: _C.textSub, fontFamily: kFont)),
                ],
              ),
            )
          else ...[
            ..._getCurrentPageData().map((u) => _buildUserItem(u)).toList(),
            _buildPagination(),
          ],
        ],
      ),
    );
  }

  Widget _buildDeletePage() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 100),
      child: _buildGlassCard(
        title: "DELETE USER",
        icon: FontAwesomeIcons.userSlash,
        children: [
          Text(
            "Masukkan username yang ingin dihapus. Aksi ini tidak bisa dibatalkan.",
            style: TextStyle(
                color: _C.textSub,
                fontFamily: kFont,
                fontSize: 12,
                height: 1.5),
          ),
          const SizedBox(height: 16),
          _buildInput(
            label: "Username Target",
            controller: deleteController,
            icon: FontAwesomeIcons.userEdit,
            hint: "Username yang ingin dihapus",
          ),
          const SizedBox(height: 10),
          _buildActionButton(
            label: "HAPUS USER",
            icon: FontAwesomeIcons.trash,
            onTap: _deleteUser,
            isLoading: isLoading,
          ),
        ],
      ),
    );
  }

  Widget _buildAddDurationPage() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 100),
      child: _buildGlassCard(
        title: "EXTEND DURATION",
        icon: FontAwesomeIcons.clock,
        children: [
          _buildInput(
            label: "Username Target",
            controller: editUsernameController,
            icon: FontAwesomeIcons.userEdit,
            hint: "Username yang ingin diperpanjang",
          ),
          _buildInput(
            label: "Tambah Hari",
            controller: editDayController,
            icon: FontAwesomeIcons.calendarPlus,
            type: TextInputType.number,
          ),
          const SizedBox(height: 10),
          _buildActionButton(
            label: "ADD DAYS",
            icon: FontAwesomeIcons.calendarPlus,
            onTap: _editUser,
            isLoading: isLoading,
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  BOTTOM NAV
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildBottomNav() {
    final isComic = ThemeModeManager.isComic3d;
    final items = [
      {'icon': Icons.add_circle_rounded, 'label': 'Create'},
      {'icon': Icons.list_alt_rounded, 'label': 'List'},
      {'icon': Icons.delete_rounded, 'label': 'Delete'},
      {'icon': Icons.calendar_month_rounded, 'label': 'Duration'},
    ];

    return Container(
      margin: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        gradient: isComic ? null : _C.glassGrad,
        color: isComic ? AppColors.card : null,
        borderRadius: BorderRadius.circular(AppColors.cardRadius),
        border: Border.all(color: _C.border, width: AppColors.borderWidth),
        boxShadow: _C.glassShadow,
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(AppColors.cardRadius),
        child: BackdropFilter(
          filter: ImageFilter.blur(
            sigmaX: isComic ? 0 : 15,
            sigmaY: isComic ? 0 : 15,
          ),
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 6),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: List.generate(items.length, (i) {
                final isActive = _navIndex == i;
                return Expanded(
                  child: GestureDetector(
                    onTap: () {
                      setState(() => _navIndex = i);
                      if (i == 1) _fetchUsers();
                    },
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      margin: const EdgeInsets.symmetric(horizontal: 4),
                      decoration: BoxDecoration(
                        gradient: isActive ? _C.btnGrad : null,
                        borderRadius:
                            BorderRadius.circular(isComic ? 4 : 12),
                        border: isComic && isActive
                            ? Border.all(
                                color: AppColors.border, width: 2)
                            : null,
                        boxShadow: isActive && !isComic
                            ? [
                                BoxShadow(
                                    color: _C.primary.withOpacity(0.3),
                                    blurRadius: 10)
                              ]
                            : [],
                      ),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            items[i]['icon'] as IconData,
                            color:
                                isActive ? _onAccent() : _C.textDim,
                            size: 20,
                          ),
                          const SizedBox(height: 3),
                          Text(
                            items[i]['label'] as String,
                            style: TextStyle(
                              color:
                                  isActive ? _onAccent() : _C.textDim,
                              fontFamily: kFont,
                              fontSize: 9,
                              fontWeight: isActive
                                  ? FontWeight.bold
                                  : FontWeight.w500,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              }),
            ),
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  BUILD
  // ═══════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppThemeMode>(
      valueListenable: ThemeModeManager.current,
      builder: (context, _, __) {
        return Scaffold(
          backgroundColor: _C.bg,
          extendBody: true,
          body: AppBackground(
            imagePath: 'assets/images/mmk.jpg',
            child: SafeArea(
              child: Column(
                children: [
                  // HEADER
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
                    child: Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            gradient: _C.btnGrad,
                            borderRadius: BorderRadius.circular(
                                ThemeModeManager.isComic3d ? 4 : 12),
                            border: ThemeModeManager.isComic3d
                                ? Border.all(
                                    color: AppColors.border, width: 2)
                                : null,
                          ),
                          child: Icon(Icons.workspace_premium_rounded,
                              color: _onAccent(), size: 18),
                        ),
                        const SizedBox(width: 12),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text("DEVELOPER PANEL",
                                style: TextStyle(
                                    color: _C.text,
                                    fontFamily: kFont,
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                    letterSpacing: 2)),
                            Text(widget.username,
                                style: TextStyle(
                                    color: _C.textSub,
                                    fontFamily: kFont,
                                    fontSize: 11)),
                          ],
                        ),
                      ],
                    ),
                  ),

                  // PAGE CONTENT
                  Expanded(
                    child: AnimatedSwitcher(
                      duration: const Duration(milliseconds: 250),
                      child: KeyedSubtree(
                        key: ValueKey(_navIndex),
                        child: _navIndex == 0
                            ? _buildCreatePage()
                            : _navIndex == 1
                                ? _buildListPage()
                                : _navIndex == 2
                                    ? _buildDeletePage()
                                    : _buildAddDurationPage(),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          bottomNavigationBar: SafeArea(
            child: Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: _buildBottomNav(),
            ),
          ),
        );
      },
    );
  }
}