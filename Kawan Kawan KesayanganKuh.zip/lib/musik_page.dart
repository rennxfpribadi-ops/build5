import 'package:flutter/material.dart';
import 'dart:math' as math;
import 'dart:ui';
import 'package:audioplayers/audioplayers.dart';
import 'dashboard_page.dart';
import 'audio_manager.dart';
import 'theme.dart'; // 👈 WAJIB

class AudioDashboardScreen extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final String uid;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const AudioDashboardScreen({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
    required this.uid,
    required this.listBug,
    required this.listDoos,
    required this.news,
  });

  @override
  State<AudioDashboardScreen> createState() => _AudioDashboardScreenState();
}

class _AudioDashboardScreenState extends State<AudioDashboardScreen>
    with TickerProviderStateMixin {
  late AnimationController _rotationController;
  late AnimationController _eqController;
  late AnimationController _logoController;
  late AnimationController _glowController;

  final AudioManager _audioManager = AudioManager();
  final List<double> _barHeights = List.generate(21, (index) => 8.0);

  @override
  void initState() {
    super.initState();

    _rotationController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 4),
    );

    _logoController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 8),
    );

    _glowController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2000),
    )..repeat(reverse: true);

    _eqController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 120),
    )..addListener(() {
        if (_audioManager.isPlaying) {
          setState(() {
            for (int i = 0; i < _barHeights.length; i++) {
              _barHeights[i] = 8.0 + (math.Random().nextDouble() * 35.0);
            }
          });
        }
      });

    _eqController.repeat();

    _audioManager.init().then((_) {
      if (_audioManager.isPlaying) {
        _rotationController.repeat();
        _logoController.repeat();
      }
    });

    _audioManager.addListener(_onAudioChanged);
  }

  void _onAudioChanged() {
    if (!mounted) return;
    setState(() {
      if (_audioManager.isPlaying) {
        _rotationController.repeat();
        _logoController.repeat();
        _eqController.repeat();
      } else {
        _rotationController.stop();
        _logoController.stop();
        _eqController.stop();
      }
    });
  }

  @override
  void dispose() {
    _audioManager.removeListener(_onAudioChanged);
    _rotationController.dispose();
    _logoController.dispose();
    _glowController.dispose();
    _eqController.dispose();
    super.dispose();
  }

  void _goToDashboard() {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (_) => DashboardPage(
          uid: widget.uid,
          username: widget.username,
          password: widget.password,
          role: widget.role,
          expiredDate: widget.expiredDate,
          sessionKey: widget.sessionKey,
          listBug: widget.listBug,
          listDoos: widget.listDoos,
          news: widget.news,
        ),
      ),
    );
  }

  // ── helpers ──
  bool get _isComic => ThemeModeManager.isComic3d;
  bool get _isMono => ThemeModeManager.isMonochrome;

  Color get _iconOnGrad => (_isComic || _isMono) ? Colors.black : Colors.white;

  LinearGradient get _brandGrad => _isComic || _isMono
      ? AppColors.btnGrad
      : LinearGradient(
          colors: [AppColors.accent, AppColors.teal],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        );

  @override
  Widget build(BuildContext context) {
    return ThemeScope(
      child: Scaffold(
        backgroundColor: AppColors.bg,
        body: Stack(
          children: [
            Positioned.fill(child: _buildBackground()),
            SafeArea(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(
                    horizontal: 20.0, vertical: 16.0),
                child: Column(
                  children: [
                    _buildHeader(),
                    const SizedBox(height: 32),
                    _buildTitleSection(),
                    const SizedBox(height: 32),
                    _buildVinylPlayer(),
                    const SizedBox(height: 24),
                    _buildTrackInfo(),
                    const SizedBox(height: 32),
                    _buildEnterButton(),
                    const SizedBox(height: 16),
                    _buildFooter(),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ==================== BACKGROUND ====================
  Widget _buildBackground() {
    if (_isComic) return const SizedBox.shrink();
    if (_isMono) return ColoredBox(color: AppColors.bg);

    // Normal – purple luxury with blurred orbs
    return Stack(
      children: [
        Positioned.fill(
          child: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  AppColors.bg,
                  Color.lerp(AppColors.bg, AppColors.accentDark, 0.25)!,
                ],
              ),
            ),
          ),
        ),
        Positioned(
          top: -100,
          right: -100,
          child: ImageFiltered(
            imageFilter: ImageFilter.blur(sigmaX: 80, sigmaY: 80),
            child: Container(
              width: 300,
              height: 300,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: AppColors.accent.withOpacity(0.18),
              ),
            ),
          ),
        ),
        Positioned(
          bottom: -100,
          left: -100,
          child: ImageFiltered(
            imageFilter: ImageFilter.blur(sigmaX: 80, sigmaY: 80),
            child: Container(
              width: 300,
              height: 300,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: AppColors.teal.withOpacity(0.12),
              ),
            ),
          ),
        ),
      ],
    );
  }

  // ==================== HEADER ====================
  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      decoration: BoxDecoration(
        color: _isComic ? AppColors.card : AppColors.card.withOpacity(0.75),
        borderRadius: BorderRadius.circular(_isComic ? 4 : 30),
        border: Border.all(
          color: _isComic ? AppColors.border : AppColors.glassBorder,
          width: _isComic ? 3 : 1.5,
        ),
        boxShadow: AppColors.softShadow,
      ),
      child: Row(
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: _brandGrad,
              border: _isComic
                  ? Border.all(color: AppColors.border, width: 2)
                  : null,
            ),
            child: Icon(
              Icons.graphic_eq_rounded,
              size: 20,
              color: _iconOnGrad,
            ),
          ),
          const SizedBox(width: 12),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Novarch Music",
                style: TextStyle(
                  fontWeight: FontWeight.w900,
                  fontSize: 12,
                  fontStyle: FontStyle.italic,
                  color: AppColors.text,
                  letterSpacing: 0.5,
                ),
              ),
              Text(
                "PREMIUM ENGINE",
                style: TextStyle(
                  fontWeight: FontWeight.w800,
                  fontSize: 9,
                  color: AppColors.textSub,
                  letterSpacing: 1,
                ),
              ),
            ],
          ),
          const Spacer(),
          Flexible(
            child: Text(
              "${widget.username.toUpperCase()}",
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                fontSize: 10,
                fontWeight: FontWeight.bold,
                color: AppColors.textSub,
              ),
            ),
          ),
          const SizedBox(width: 10),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            decoration: BoxDecoration(
              color: AppColors.online.withOpacity(0.12),
              borderRadius: BorderRadius.circular(_isComic ? 2 : 20),
              border: Border.all(
                color: AppColors.online.withOpacity(_isComic ? 1 : 0.4),
                width: _isComic ? 2 : 1,
              ),
            ),
            child: Row(
              children: [
                Icon(Icons.circle, size: 6, color: AppColors.online),
                const SizedBox(width: 5),
                Text(
                  "LIVE",
                  style: TextStyle(
                    fontSize: 9,
                    color: AppColors.online,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ==================== TITLE SECTION ====================
  Widget _buildTitleSection() {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 6),
          decoration: BoxDecoration(
            color: AppColors.gold.withOpacity(0.12),
            borderRadius: BorderRadius.circular(_isComic ? 2 : 20),
            border: Border.all(
              color: AppColors.gold.withOpacity(_isComic ? 1 : 0.5),
              width: _isComic ? 2 : 1,
            ),
          ),
          child: Text(
            "PREMIUM SOUNDTRACK",
            style: TextStyle(
              color: AppColors.gold,
              fontWeight: FontWeight.w900,
              fontSize: 10,
              letterSpacing: 2,
            ),
          ),
        ),
        const SizedBox(height: 16),
        Text(
          "DENGARKAN MUSIK",
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 28,
            fontWeight: FontWeight.w900,
            fontStyle: FontStyle.italic,
            letterSpacing: 1.2,
            color: AppColors.text,
            height: 1.1,
          ),
        ),
        const SizedBox(height: 8),
        Text(
          "Nikmati pengalaman audio sebelum masuk\nke dashboard utama.",
          textAlign: TextAlign.center,
          style: TextStyle(
            color: AppColors.textSub,
            fontSize: 12,
            height: 1.5,
          ),
        ),
      ],
    );
  }

  // ==================== VINYL PLAYER ====================
  Widget _buildVinylPlayer() {
    return AnimatedBuilder(
      animation: _glowController,
      builder: (context, child) {
        final glowVal = _glowController.value;
        return Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: AppColors.card,
            borderRadius: BorderRadius.circular(_isComic ? 6 : 32),
            border: Border.all(
              color: _isComic ? AppColors.border : AppColors.glassBorder,
              width: _isComic ? 3 : 2,
            ),
            boxShadow: _isComic
                ? AppColors.glassShadow
                : [
                    BoxShadow(
                      color: AppColors.accent
                          .withOpacity(0.06 + glowVal * 0.06),
                      blurRadius: 40,
                      spreadRadius: 5,
                      offset: const Offset(0, 15),
                    ),
                  ],
          ),
          child: Stack(
            alignment: Alignment.center,
            children: [
              // outer glow
              Container(
                width: 250,
                height: 250,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  boxShadow: (_isComic || _isMono)
                      ? []
                      : [
                          BoxShadow(
                            color: AppColors.accent
                                .withOpacity(0.15 + glowVal * 0.1),
                            blurRadius: 60,
                            spreadRadius: 10,
                          ),
                          BoxShadow(
                            color: AppColors.teal.withOpacity(0.1),
                            blurRadius: 80,
                          ),
                        ],
                ),
              ),

              // record
              RotationTransition(
                turns: _rotationController,
                child: Container(
                  width: 250,
                  height: 250,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: const RadialGradient(
                      colors: [
                        Color(0xFF2A2A2A),
                        Color(0xFF151515),
                        Color(0xFF000000),
                      ],
                      stops: [0.4, 0.8, 1.0],
                    ),
                    border: _isComic
                        ? Border.all(color: Colors.black, width: 3)
                        : null,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.4),
                        blurRadius: 20,
                        offset: const Offset(0, 10),
                      ),
                    ],
                  ),
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      for (int i = 0; i < 8; i++)
                        Container(
                          width: 210.0 - (i * 20),
                          height: 210.0 - (i * 20),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: Colors.white.withOpacity(0.05),
                              width: 1,
                            ),
                          ),
                        ),

                      ClipOval(
                        child: RotationTransition(
                          turns: _logoController,
                          child: Container(
                            width: 90,
                            height: 90,
                            decoration: const BoxDecoration(
                              shape: BoxShape.circle,
                              color: Colors.grey,
                            ),
                            child: Image.asset(
                              'assets/images/Neverness.png',
                              fit: BoxFit.cover,
                              width: 90,
                              height: 90,
                              errorBuilder: (context, error, stackTrace) {
                                return const Center(
                                  child: Text(
                                    "N",
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.w900,
                                      fontSize: 32,
                                      fontStyle: FontStyle.italic,
                                    ),
                                  ),
                                );
                              },
                            ),
                          ),
                        ),
                      ),

                      Container(
                        width: 12,
                        height: 12,
                        decoration: const BoxDecoration(
                          shape: BoxShape.circle,
                          color: Colors.white,
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              // tonearm
              Positioned(
                top: 10,
                right: 20,
                child: Transform.rotate(
                  angle: _audioManager.isPlaying
                      ? -math.pi / 4.5
                      : -math.pi / 6,
                  alignment: Alignment.topCenter,
                  child: Column(
                    children: [
                      Container(
                        width: 16,
                        height: 16,
                        decoration: BoxDecoration(
                          color: Colors.grey,
                          shape: BoxShape.circle,
                          border: _isComic
                              ? Border.all(color: Colors.black, width: 2)
                              : null,
                        ),
                      ),
                      Container(
                        width: 6,
                        height: 110,
                        decoration: BoxDecoration(
                          color: Colors.grey[400],
                          borderRadius: BorderRadius.circular(3),
                        ),
                      ),
                      Container(
                        width: 18,
                        height: 18,
                        decoration: BoxDecoration(
                          color: AppColors.accent,
                          borderRadius: BorderRadius.circular(_isComic ? 2 : 4),
                          border: _isComic
                              ? Border.all(color: Colors.black, width: 2)
                              : null,
                          boxShadow: _isComic
                              ? const [
                                  BoxShadow(
                                    color: Colors.black,
                                    offset: Offset(2, 2),
                                    blurRadius: 0,
                                  )
                                ]
                              : [
                                  BoxShadow(
                                    color: AppColors.accent.withOpacity(0.5),
                                    blurRadius: 8,
                                  ),
                                ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              // RPM badge
              Positioned(
                bottom: 0,
                left: 10,
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: AppColors.online.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(_isComic ? 2 : 10),
                    border: _isComic
                        ? Border.all(color: AppColors.online, width: 2)
                        : null,
                  ),
                  child: Row(
                    children: [
                      Icon(Icons.circle, size: 6, color: AppColors.online),
                      const SizedBox(width: 5),
                      Text(
                        "33 1/3 RPM • SYNC",
                        style: TextStyle(
                          color: AppColors.online,
                          fontSize: 9,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  // ==================== TRACK INFO + EQUALIZER ====================
  Widget _buildTrackInfo() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(_isComic ? 6 : 24),
        border: Border.all(
          color: _isComic ? AppColors.border : AppColors.glassBorder,
          width: _isComic ? 3 : 1.5,
        ),
        boxShadow: AppColors.softShadow,
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.graphic_eq_rounded,
                  size: 14, color: AppColors.online),
              const SizedBox(width: 6),
              Text(
                "SEDANG DIPUTAR",
                style: TextStyle(
                  color: AppColors.textSub,
                  fontSize: 10,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 2,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            "BREAKBEAT DREAM",
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.w900,
              fontStyle: FontStyle.italic,
              letterSpacing: 1.5,
              color: AppColors.text,
            ),
          ),
          const SizedBox(height: 24),

          // Equalizer
          Container(
            height: 60,
            padding:
                const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            decoration: BoxDecoration(
              color: AppColors.card2,
              borderRadius: BorderRadius.circular(_isComic ? 4 : 16),
              border: Border.all(
                color: AppColors.borderLit,
                width: _isComic ? 2 : 1,
              ),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: List.generate(21, (index) {
                Color barColor;
                if (index % 4 == 0) {
                  barColor = AppColors.purple;
                } else if (index % 4 == 1) {
                  barColor = AppColors.accent;
                } else if (index % 4 == 2) {
                  barColor = AppColors.teal;
                } else {
                  barColor = AppColors.accentMid;
                }

                return AnimatedContainer(
                  duration: const Duration(milliseconds: 120),
                  width: 6,
                  height:
                      _audioManager.isPlaying ? _barHeights[index] : 4.0,
                  decoration: BoxDecoration(
                    color: _audioManager.isPlaying
                        ? barColor
                        : AppColors.textHint.withOpacity(0.3),
                    borderRadius: BorderRadius.circular(3),
                    boxShadow: _audioManager.isPlaying && !_isComic
                        ? [
                            BoxShadow(
                              color: barColor.withOpacity(0.4),
                              blurRadius: 4,
                              spreadRadius: 1,
                            )
                          ]
                        : [],
                  ),
                );
              }),
            ),
          ),

          const SizedBox(height: 24),

          // Play / Pause button
          GestureDetector(
            onTap: () => _audioManager.togglePlay(),
            child: Container(
              width: 64,
              height: 64,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: _brandGrad,
                border: _isComic
                    ? Border.all(color: Colors.black, width: 3)
                    : null,
                boxShadow: _isComic
                    ? AppColors.glassShadow
                    : [
                        BoxShadow(
                          color: AppColors.accent.withOpacity(0.4),
                          blurRadius: 20,
                          spreadRadius: 2,
                          offset: const Offset(0, 8),
                        ),
                      ],
              ),
              child: Icon(
                _audioManager.isPlaying
                    ? Icons.pause_rounded
                    : Icons.play_arrow_rounded,
                color: _iconOnGrad,
                size: 32,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ==================== TOMBOL MASUK ====================
  Widget _buildEnterButton() {
    final txtColor = (_isComic || _isMono) ? Colors.black : Colors.white;
    final subColor =
        (_isComic || _isMono) ? Colors.black54 : Colors.white70;

    return Container(
      width: double.infinity,
      height: 76,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(_isComic ? 4 : 24),
        gradient: _brandGrad,
        border: _isComic
            ? Border.all(color: Colors.black, width: 3)
            : null,
        boxShadow: _isComic
            ? AppColors.glassShadow
            : [
                BoxShadow(
                  color: AppColors.accent.withOpacity(0.3),
                  blurRadius: 25,
                  offset: const Offset(0, 10),
                ),
              ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(_isComic ? 4 : 24),
          onTap: _goToDashboard,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: (_isComic || _isMono)
                        ? Colors.black.withOpacity(0.1)
                        : Colors.white.withOpacity(0.2),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    Icons.rocket_launch_rounded,
                    color: txtColor,
                    size: 24,
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "MASUK DASHBOARD",
                        style: TextStyle(
                          color: txtColor,
                          fontWeight: FontWeight.w900,
                          fontSize: 16,
                          letterSpacing: 0.5,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        "Lanjut ke Menu Novarch",
                        style: TextStyle(
                          color: subColor,
                          fontSize: 11,
                          fontStyle: FontStyle.italic,
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(_isComic ? 4 : 14),
                    border: _isComic
                        ? Border.all(color: Colors.black, width: 2)
                        : null,
                    boxShadow: _isComic
                        ? const [
                            BoxShadow(
                              color: Colors.black,
                              offset: Offset(2, 2),
                              blurRadius: 0,
                            )
                          ]
                        : [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.1),
                              blurRadius: 8,
                              offset: const Offset(0, 4),
                            ),
                          ],
                  ),
                  child: Row(
                    children: [
                      Text(
                        "ENTER",
                        style: TextStyle(
                          color: AppColors.dark,
                          fontWeight: FontWeight.w900,
                          fontSize: 13,
                        ),
                      ),
                      const SizedBox(width: 4),
                      Icon(Icons.arrow_forward_rounded,
                          size: 16, color: AppColors.dark),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ==================== FOOTER ====================
  Widget _buildFooter() {
    return Text(
      "© 2026 NOVARCH PROJECT • PREMIUM TRACK",
      textAlign: TextAlign.center,
      style: TextStyle(
        color: AppColors.textHint,
        fontSize: 10,
        fontWeight: FontWeight.w800,
        letterSpacing: 1.5,
      ),
    );
  }
}