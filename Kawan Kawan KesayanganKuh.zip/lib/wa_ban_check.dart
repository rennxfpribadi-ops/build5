// wa_ban_check.dart — Liquid Glass Edition (Page)
import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'theme.dart';

class WaBanCheckPage extends StatefulWidget {
  final String sessionKey;
  const WaBanCheckPage({super.key, required this.sessionKey});

  @override
  State<WaBanCheckPage> createState() => _WaBanCheckPageState();
}

class _WaBanCheckPageState extends State<WaBanCheckPage>
    with TickerProviderStateMixin {
  final TextEditingController _phoneController = TextEditingController();

  late AnimationController _pulseCtrl;
  late Animation<double> _pulseAnim;

  bool _isLoading = false;
  bool _hasResult = false;

  String _checkedNumber = '';
  bool _isBanned = false;
  String _statusMessage = '';
  String _banReason = '';
  String _checkTime = '';

  final List<Map<String, dynamic>> _history = [];

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(
      duration: const Duration(milliseconds: 1800),
      vsync: this,
    )..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.4, end: 1.0).animate(
      CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _pulseCtrl.dispose();
    _phoneController.dispose();
    super.dispose();
  }

  Future<void> _checkBan() async {
    final raw = _phoneController.text.trim();
    if (raw.isEmpty) return;

    String phone = raw.replaceAll(RegExp(r'[^0-9]'), '');
    if (phone.startsWith('0')) phone = '62${phone.substring(1)}';
    if (!phone.startsWith('62')) phone = '62$phone';

    setState(() {
      _isLoading = true;
      _hasResult = false;
    });

    try {
      final response = await http.post(
        Uri.parse('https://api.whatsapp.com/send?phone=$phone'),
        headers: {'User-Agent': 'Mozilla/5.0'},
      ).timeout(const Duration(seconds: 10));

      final waResponse = await http.get(
        Uri.parse('https://wa.me/$phone'),
        headers: {'User-Agent': 'WhatsApp/2.23.24.79 A'},
      ).timeout(const Duration(seconds: 10));

      final now = DateTime.now();
      final timeStr =
          '${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}:${now.second.toString().padLeft(2, '0')}';

      bool banned = false;
      String reason = '';
      String msg = '';

      final body = waResponse.body.toLowerCase();
      if (waResponse.statusCode == 404 ||
          body.contains('invalid') ||
          body.contains('not found') ||
          body.contains('banned') ||
          body.contains('unavailable')) {
        banned = true;
        reason = 'Nomor tidak tersedia / terban di WhatsApp';
        msg = 'BANNED';
      } else if (waResponse.statusCode == 200 &&
          (body.contains('wa-btn') ||
              body.contains('open_iwa') ||
              body.contains('whatsapp'))) {
        banned = false;
        reason = 'Nomor aktif dan terdaftar di WhatsApp';
        msg = 'AKTIF';
      } else {
        banned = response.statusCode != 200;
        reason = banned
            ? 'Nomor mungkin di-ban atau tidak terdaftar'
            : 'Nomor kemungkinan aktif';
        msg = banned ? 'KEMUNGKINAN BAN' : 'KEMUNGKINAN AKTIF';
      }

      final result = {
        'phone': phone,
        'banned': banned,
        'msg': msg,
        'reason': reason,
        'time': timeStr,
      };

      setState(() {
        _isLoading = false;
        _hasResult = true;
        _checkedNumber = phone;
        _isBanned = banned;
        _statusMessage = msg;
        _banReason = reason;
        _checkTime = timeStr;
        _history.insert(0, result);
        if (_history.length > 5) _history.removeLast();
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
        _hasResult = true;
        _checkedNumber = phone;
        _isBanned = false;
        _statusMessage = 'ERROR';
        _banReason = 'Gagal cek: $e';
        _checkTime = '';
      });
    }
  }

  void _clear() {
    setState(() {
      _phoneController.clear();
      _hasResult = false;
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppThemeMode>(
      valueListenable: ThemeModeManager.current,
      builder: (context, _, __) {
        return Scaffold(
          backgroundColor: AppColors.bg,
          appBar: _buildAppBar(),
          body: SafeArea(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildHeaderCard(),
                  const SizedBox(height: 16),
                  _buildInputCard(),
                  const SizedBox(height: 16),
                  if (_isLoading) _buildLoadingCard(),
                  if (_hasResult && !_isLoading) _buildResultCard(),
                  if (_history.isNotEmpty && !_isLoading) ...[
                    const SizedBox(height: 16),
                    _buildHistory(),
                  ],
                  if (!_hasResult && !_isLoading && _history.isEmpty)
                    _buildEmptyState(),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: AppColors.bg.withOpacity(0.8),
      surfaceTintColor: Colors.transparent,
      elevation: 0,
      leading: IconButton(
        icon: Icon(Icons.arrow_back_ios_new_rounded, color: AppColors.text),
        onPressed: () => Navigator.pop(context),
      ),
      title: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'WA Ban Check',
            style: TextStyle(
              color: AppColors.text,
              fontSize: 17,
              fontWeight: FontWeight.w900,
            ),
          ),
          Text(
            'Cek status nomor WhatsApp',
            style: TextStyle(color: AppColors.textSub, fontSize: 11),
          ),
        ],
      ),
      bottom: PreferredSize(
        preferredSize: const Size.fromHeight(1),
        child: Container(color: AppColors.glassBorder, height: 1),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════════
  //  LIQUID GLASS WIDGETS
  // ═══════════════════════════════════════════════════════════════════════

  Widget _glassCard({
    required Widget child,
    Color? borderColor,
    EdgeInsetsGeometry padding = const EdgeInsets.all(16),
  }) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(AppColors.cardRadius),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
        child: Container(
          padding: padding,
          decoration: BoxDecoration(
            gradient: AppColors.glassGrad,
            borderRadius: BorderRadius.circular(AppColors.cardRadius),
            border: Border.all(
              color: borderColor ?? AppColors.glassBorder,
              width: 1.5,
            ),
            boxShadow: AppColors.glassShadow,
          ),
          child: child,
        ),
      ),
    );
  }

  Widget _buildHeaderCard() {
    return _glassCard(
      child: Row(
        children: [
          Container(
            width: 54,
            height: 54,
            decoration: BoxDecoration(
              color: AppColors.accent.withOpacity(0.2),
              shape: BoxShape.circle,
              border: Border.all(color: AppColors.accent.withOpacity(0.5), width: 1.5),
            ),
            child: Icon(FontAwesomeIcons.whatsapp,
                color: AppColors.accent, size: 24),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'CEK BAN WHATSAPP',
                  style: TextStyle(
                    color: AppColors.text,
                    fontSize: 14,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.2,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  'Cek apakah nomor WhatsApp di-ban',
                  style: TextStyle(
                    color: AppColors.textSub,
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
          AnimatedBuilder(
            animation: _pulseAnim,
            builder: (_, __) => Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              decoration: BoxDecoration(
                color: AppColors.green.withOpacity(_pulseAnim.value * 0.3),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: AppColors.green.withOpacity(0.5), width: 1),
              ),
              child: Text(
                'LIVE',
                style: TextStyle(
                  color: AppColors.green,
                  fontSize: 9,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInputCard() {
    return _glassCard(
      padding: EdgeInsets.zero,
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppColors.accent.withOpacity(0.1),
              border: Border(
                right: BorderSide(color: AppColors.glassBorder, width: 1),
              ),
            ),
            child: Icon(FontAwesomeIcons.whatsapp, color: AppColors.accent, size: 20),
          ),
          Expanded(
            child: TextField(
              controller: _phoneController,
              keyboardType: TextInputType.phone,
              inputFormatters: [
                FilteringTextInputFormatter.allow(RegExp(r'[0-9+\- ]')),
              ],
              style: TextStyle(
                color: AppColors.text,
                fontSize: 14,
                fontWeight: FontWeight.w700,
                letterSpacing: 0.5,
              ),
              decoration: InputDecoration(
                hintText: '08xxxxxxxxxx / 62...',
                hintStyle: TextStyle(
                  color: AppColors.textHint,
                  fontSize: 12,
                  fontWeight: FontWeight.w500,
                ),
                border: InputBorder.none,
                contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 16),
              ),
              onSubmitted: (_) => _checkBan(),
            ),
          ),
          GestureDetector(
            onTap: _isLoading ? null : _checkBan,
            child: Container(
              margin: const EdgeInsets.all(6),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(
                gradient: AppColors.btnGrad,
                borderRadius: BorderRadius.circular(10),
                boxShadow: [
                  BoxShadow(
                    color: AppColors.accent.withOpacity(0.3),
                    blurRadius: 10,
                    spreadRadius: 1,
                  ),
                ],
              ),
              child: _isLoading
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: Colors.white,
                      ),
                    )
                  : Text(
                      'CEK',
                      style: TextStyle(
                        color: ThemeModeManager.isComic3d ? Colors.black : Colors.white,
                        fontSize: 12,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1,
                      ),
                    ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLoadingCard() {
    return _glassCard(
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(
            width: 20,
            height: 20,
            child: CircularProgressIndicator(color: AppColors.accent, strokeWidth: 2.5),
          ),
          const SizedBox(width: 14),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Memeriksa nomor...',
                style: TextStyle(
                  color: AppColors.text,
                  fontSize: 13,
                  fontWeight: FontWeight.w800,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                'Menghubungi server WA',
                style: TextStyle(color: AppColors.textSub, fontSize: 11),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildResultCard() {
    final isError = _statusMessage == 'ERROR';
    final Color statusColor = isError
        ? AppColors.amber
        : _isBanned
            ? AppColors.red
            : AppColors.green;
    final IconData statusIcon = isError
        ? Icons.error_outline_rounded
        : _isBanned
            ? Icons.block_rounded
            : Icons.check_circle_rounded;
    final String statusLabel = isError
        ? 'ERROR'
        : _isBanned
            ? 'TERBAN 🚫'
            : 'AMAN ✅';

    return _glassCard(
      borderColor: statusColor.withOpacity(0.5),
      child: Column(
        children: [
          Row(
            children: [
              Container(
                width: 54,
                height: 54,
                decoration: BoxDecoration(
                  color: statusColor.withOpacity(0.2),
                  shape: BoxShape.circle,
                  border: Border.all(color: statusColor.withOpacity(0.5), width: 1.5),
                  boxShadow: [
                    BoxShadow(
                      color: statusColor.withOpacity(0.3),
                      blurRadius: 15,
                      spreadRadius: 2,
                    ),
                  ],
                ),
                child: Icon(statusIcon, color: statusColor, size: 24),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      statusLabel,
                      style: TextStyle(
                        color: statusColor,
                        fontSize: 18,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '+$_checkedNumber',
                      style: TextStyle(
                        color: AppColors.text,
                        fontSize: 13,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 0.5,
                      ),
                    ),
                  ],
                ),
              ),
              GestureDetector(
                onTap: () {
                  Clipboard.setData(ClipboardData(text: '+$_checkedNumber'));
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: const Text('Nomor disalin!',
                          style: TextStyle(fontWeight: FontWeight.w700)),
                      backgroundColor: AppColors.accent,
                      duration: const Duration(seconds: 2),
                    ),
                  );
                },
                child: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: AppColors.accent.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: AppColors.accent.withOpacity(0.3), width: 1),
                  ),
                  child: Icon(Icons.copy_rounded, color: AppColors.accent, size: 16),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.05),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: AppColors.glassBorder, width: 1),
            ),
            child: Row(
              children: [
                Icon(Icons.info_outline_rounded, color: statusColor, size: 16),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    _banReason,
                    style: TextStyle(
                      color: AppColors.textSub,
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                      height: 1.4,
                    ),
                  ),
                ),
              ],
            ),
          ),
          if (_checkTime.isNotEmpty) ...[
            const SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Icon(Icons.access_time_rounded, color: AppColors.textHint, size: 12),
                const SizedBox(width: 5),
                Text(
                  'Dicek pukul $_checkTime',
                  style: TextStyle(
                    color: AppColors.textHint,
                    fontSize: 10,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildHistory() {
    return _glassCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: AppColors.accent.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: AppColors.accent.withOpacity(0.4), width: 1),
                ),
                child: Text(
                  'RIWAYAT CEK',
                  style: TextStyle(
                    color: AppColors.accent,
                    fontSize: 9,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.2,
                  ),
                ),
              ),
              const Spacer(),
              GestureDetector(
                onTap: () => setState(() => _history.clear()),
                child: Text(
                  'Hapus',
                  style: TextStyle(
                    color: AppColors.textHint,
                    fontSize: 10,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          ..._history.asMap().entries.map((e) {
            final item = e.value;
            final bool banned = item['banned'] as bool;
            final Color c = item['msg'] == 'ERROR'
                ? AppColors.amber
                : banned
                    ? AppColors.red
                    : AppColors.green;
            return Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.05),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: AppColors.glassBorder, width: 1),
                ),
                child: Row(
                  children: [
                    Icon(
                      banned ? Icons.block_rounded : Icons.check_circle_rounded,
                      color: c,
                      size: 16,
                    ),
                    const SizedBox(width: 10),
                    Text(
                      '+${item['phone']}',
                      style: TextStyle(
                        color: AppColors.text,
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const Spacer(),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                      decoration: BoxDecoration(
                        color: c.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: c.withOpacity(0.5), width: 1),
                      ),
                      child: Text(
                        item['msg'] as String,
                        style: TextStyle(
                          color: c,
                          fontSize: 9,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Text(
                      item['time'] as String,
                      style: TextStyle(color: AppColors.textHint, fontSize: 9),
                    ),
                  ],
                ),
              ),
            );
          }),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    return Padding(
      padding: const EdgeInsets.only(top: 40),
      child: Center(
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: AppColors.accent.withOpacity(0.1),
                shape: BoxShape.circle,
                border: Border.all(color: AppColors.accent.withOpacity(0.3), width: 1.5),
                boxShadow: [
                  BoxShadow(
                    color: AppColors.accent.withOpacity(0.2),
                    blurRadius: 20,
                    spreadRadius: 2,
                  ),
                ],
              ),
              child: Icon(FontAwesomeIcons.whatsapp,
                  color: AppColors.accent, size: 40),
            ),
            const SizedBox(height: 24),
            Text(
              'Cek Status WhatsApp',
              style: TextStyle(
                color: AppColors.text,
                fontSize: 18,
                fontWeight: FontWeight.w900,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Masukkan nomor WhatsApp\nuntuk cek apakah di-ban',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: AppColors.textSub,
                fontSize: 13,
                height: 1.5,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }
}