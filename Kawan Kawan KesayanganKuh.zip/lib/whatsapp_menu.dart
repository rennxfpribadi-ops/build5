// whatsapp_menu.dart

import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:carousel_slider/carousel_slider.dart';

// ─── IMPORT HALAMAN ──────────────────────────────────────────────────
import 'home_page.dart';        // HomePage
import 'custom.dart';           // CustomPayloadPage
import 'bug_sender.dart';       // BugSenderPage
import 'tes_func_page.dart';    // TesFuncPage

// ─── SISTEM TEMA ─────────────────────────────────────────────────────
import 'theme.dart';

const String _lFont = 'Pek';
const String _lFontTitle = 'Deskripsi';

class _S {
  static const pagePadH = 20.0;
  static const gap = 10.0;
}

class _MenuOption {
  const _MenuOption({
    required this.title,
    required this.subtitle,
    required this.badge,
    required this.icon,
    required this.color1,
    required this.color2,
    required this.builder,
  });

  final String title;
  final String subtitle;
  final String badge;
  final IconData icon;
  final Color color1;
  final Color color2;
  final Widget Function() builder;
}

// ─── WARNA TEKS DI ATAS TOMBOL GRADIENT ──────────────────────────────
Color _onAccent() =>
    ThemeModeManager.isComic3d ? const Color(0xFF1A1A1A) : Colors.white;

class WhatsAppMenuPage extends StatefulWidget {
  const WhatsAppMenuPage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  @override
  State<WhatsAppMenuPage> createState() => _WhatsAppMenuPageState();
}

class _WhatsAppMenuPageState extends State<WhatsAppMenuPage>
    with TickerProviderStateMixin {
  int _current = 0;
  late final AnimationController _floatCtrl;
  late final AnimationController _ringCtrl;

  late final List<_MenuOption> _menuOptions;

  @override
  void initState() {
    super.initState();

    _floatCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 4),
    )..repeat(reverse: true);

    _ringCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 6),
    )..repeat();

    _menuOptions = [
      _MenuOption(
        title: 'NOVARCH BUG',
        subtitle: 'Bug tanpa custom',
        badge: 'SIAP',
        icon: Icons.bug_report_rounded,
        color1: const Color(0xFFFF4D6A),
        color2: const Color(0xFFB71C1C),
        builder: () => HomePage(
          username: widget.username,
          password: widget.password,
          sessionKey: widget.sessionKey,
          listBug: widget.listBug,
          role: widget.role,
          expiredDate: widget.expiredDate,
        ),
      ),
      _MenuOption(
        title: 'CUSTOM BUG',
        subtitle: 'Custom payload',
        badge: 'CUSTOM',
        icon: Icons.settings_applications_rounded,
        color1: const Color(0xFFB47BFF),
        color2: const Color(0xFF4A148C),
        builder: () => CustomPayloadPage(
          sessionKey: widget.sessionKey,
          username: widget.username,
          role: widget.role,
          listBug: widget.listBug,
        ),
      ),
      _MenuOption(
        title: 'KELOLA PENGIRIM',
        subtitle: 'Kelola pengirim',
        badge: 'KELOLA',
        icon: Icons.settings_ethernet_rounded,
        color1: const Color(0xFF00E5A0),
        color2: const Color(0xFF006400),
        builder: () => BugSenderPage(
          sessionKey: widget.sessionKey,
          username: widget.username,
          role: widget.role,
        ),
      ),
      _MenuOption(
        title: 'TES FUNC',
        subtitle: 'Tes function custom',
        badge: 'TES',
        icon: Icons.code_rounded,
        color1: const Color(0xFFFFD166),
        color2: const Color(0xFFB8860B),
        builder: () => TesFuncPage(
          sessionKey: widget.sessionKey,
          username: widget.username,
          role: widget.role,
        ),
      ),
    ];
  }

  @override
  void dispose() {
    _floatCtrl.dispose();
    _ringCtrl.dispose();
    super.dispose();
  }

  Color get _activeColor => _menuOptions[_current].color1;
  _MenuOption get _activeOption => _menuOptions[_current];

  void _openCurrent() {
    HapticFeedback.mediumImpact();
    Navigator.push(
      context,
      PageRouteBuilder(
        transitionDuration: const Duration(milliseconds: 450),
        pageBuilder: (_, __, ___) => _activeOption.builder(),
        transitionsBuilder: (_, anim, __, child) {
          final curved = CurvedAnimation(
            parent: anim,
            curve: Curves.easeOutCubic,
          );
          return FadeTransition(
            opacity: curved,
            child: SlideTransition(
              position: Tween<Offset>(
                begin: const Offset(0.08, 0),
                end: Offset.zero,
              ).animate(curved),
              child: child,
            ),
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppThemeMode>(
      valueListenable: ThemeModeManager.current,
      builder: (context, _, __) {
        final isComic = ThemeModeManager.isComic3d;
        final ink = AppColors.text;

        return AnnotatedRegion<SystemUiOverlayStyle>(
          value: SystemUiOverlayStyle(
            statusBarColor: Colors.transparent,
            statusBarBrightness: isComic ? Brightness.light : Brightness.dark,
            statusBarIconBrightness:
                isComic ? Brightness.dark : Brightness.light,
            systemNavigationBarColor: AppColors.bg,
            systemNavigationBarIconBrightness:
                isComic ? Brightness.dark : Brightness.light,
          ),
          child: Scaffold(
            backgroundColor: AppColors.bg,
            body: AppBackground(
              imagePath: 'assets/images/bg_anj.jpg',
              child: SafeArea(
                child: Stack(
                  children: [
                    // Efek partikel dekoratif
                    Positioned.fill(
                      child: IgnorePointer(
                        child: AnimatedBuilder(
                          animation: _floatCtrl,
                          builder: (_, __) => CustomPaint(
                            painter: _ParticlePainter(
                              progress: _floatCtrl.value,
                              color: _activeColor.withValues(
                                alpha: isComic ? 0.15 : 0.08,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Column(
                      children: [
                        _TopBar(
                          ink: ink,
                          activeOption: _activeOption,
                          activeColor: _activeColor,
                          current: _current,
                          total: _menuOptions.length,
                        ),
                        const SizedBox(height: 10),
                        Expanded(
                          child: CarouselSlider.builder(
                            options: CarouselOptions(
                              height: double.infinity,
                              viewportFraction: 0.80,
                              enableInfiniteScroll: true,
                              autoPlay: true,
                              autoPlayInterval: const Duration(seconds: 5),
                              autoPlayAnimationDuration:
                                  const Duration(milliseconds: 800),
                              autoPlayCurve: Curves.easeOutCubic,
                              enlargeCenterPage: true,
                              enlargeFactor: 0.15,
                              padEnds: true,
                              scrollPhysics: const BouncingScrollPhysics(),
                              onPageChanged: (i, _) {
                                HapticFeedback.selectionClick();
                                setState(() => _current = i);
                              },
                            ),
                            itemCount: _menuOptions.length,
                            itemBuilder: (context, index, realIndex) {
                              return _MenuSlide(
                                ink: ink,
                                option: _menuOptions[index],
                                isActive: index == _current,
                                floatAnim: _floatCtrl,
                                ringAnim: _ringCtrl,
                                current: _current,
                                total: _menuOptions.length,
                                onTap: _openCurrent,
                              );
                            },
                          ),
                        ),
                        _ProgressDots(
                          options: _menuOptions,
                          current: _current,
                          ink: ink,
                          onTap: (i) {
                            HapticFeedback.selectionClick();
                            setState(() => _current = i);
                          },
                        ),
                        const SizedBox(height: 16),
                        _BottomAction(
                          ink: ink,
                          color: _activeColor,
                          activeOption: _activeOption,
                          current: _current,
                          total: _menuOptions.length,
                          onTap: _openCurrent,
                        ),
                        const SizedBox(height: 20),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════
//  TOP BAR (Disesuaikan dengan Foto 2)
// ═══════════════════════════════════════════════════════════════════════
class _TopBar extends StatelessWidget {
  const _TopBar({
    required this.ink,
    required this.activeOption,
    required this.activeColor,
    required this.current,
    required this.total,
  });

  final Color ink;
  final _MenuOption activeOption;
  final Color activeColor;
  final int current;
  final int total;

  @override
  Widget build(BuildContext context) {
    final isComic = ThemeModeManager.isComic3d;

    return Padding(
      padding: const EdgeInsets.fromLTRB(_S.pagePadH, 16, _S.pagePadH, 0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                ShaderMask(
                  shaderCallback: (bounds) => LinearGradient(
                    colors: isComic
                        ? [AppColors.text, AppColors.text]
                        : [Colors.white, activeColor],
                  ).createShader(bounds),
                  child: Text(
                    'MENU UTAMA',
                    style: TextStyle(
                      fontFamily: _lFontTitle,
                      fontSize: 26,
                      fontWeight: FontWeight.w900,
                      fontStyle: FontStyle.italic,
                      letterSpacing: 1,
                      color: Colors.white,
                      shadows: isComic
                          ? null
                          : [
                              Shadow(
                                color: activeColor.withValues(alpha: 0.5),
                                blurRadius: 10,
                              )
                            ],
                    ),
                  ),
                ),
                const SizedBox(height: 6),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: isComic
                        ? AppColors.card
                        : Colors.black.withValues(alpha: 0.3),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                      color: isComic
                          ? AppColors.border
                          : Colors.white.withValues(alpha: 0.15),
                      width: isComic ? 2 : 1,
                    ),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        Icons.info_outline,
                        size: 12,
                        color: isComic ? AppColors.text : Colors.white70,
                      ),
                      const SizedBox(width: 4),
                      Text(
                        'informasi',
                        style: TextStyle(
                          color: isComic ? AppColors.text : Colors.white70,
                          fontSize: 10,
                          fontFamily: _lFont,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          _MiniCounter(
            color: activeColor,
            current: current,
            total: total,
          ),
        ],
      ),
    );
  }
}

class _MiniCounter extends StatelessWidget {
  const _MiniCounter({
    required this.color,
    required this.current,
    required this.total,
  });

  final Color color;
  final int current;
  final int total;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.15),
        borderRadius: BorderRadius.circular(ThemeModeManager.isComic3d ? 4 : 30),
        border: Border.all(
          color: color.withValues(alpha: 0.4),
          width: AppColors.borderWidth,
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 6,
            height: 6,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: color,
              boxShadow: ThemeModeManager.isComic3d
                  ? null
                  : [BoxShadow(color: color, blurRadius: 8)],
            ),
          ),
          const SizedBox(width: 8),
          Text(
            '$current/$total',
            style: TextStyle(
              color: color,
              fontSize: 12,
              fontWeight: FontWeight.w900,
              fontFamily: _lFont,
              letterSpacing: 1,
            ),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════
//  MENU SLIDE (Tanpa Kotak Background, Sesuai Foto 2)
// ═══════════════════════════════════════════════════════════════════════
class _MenuSlide extends StatelessWidget {
  const _MenuSlide({
    required this.ink,
    required this.option,
    required this.isActive,
    required this.floatAnim,
    required this.ringAnim,
    required this.current,
    required this.total,
    required this.onTap,
  });

  final Color ink;
  final _MenuOption option;
  final bool isActive;
  final Animation<double> floatAnim;
  final Animation<double> ringAnim;
  final int current;
  final int total;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final is3D = ThemeModeManager.isComic3d;

    return AnimatedBuilder(
      animation: floatAnim,
      builder: (_, __) {
        final float = math.sin(floatAnim.value * math.pi * 2) * 8;
        return Transform.translate(
          offset: Offset(0, isActive ? float : 0),
          child: GestureDetector(
            onTap: onTap,
            child: AnimatedScale(
              scale: isActive ? 1.0 : 0.85,
              duration: const Duration(milliseconds: 400),
              curve: Curves.easeOutCubic,
              child: AnimatedOpacity(
                opacity: isActive ? 1.0 : 0.4,
                duration: const Duration(milliseconds: 400),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    // Ring Berputar & Ikon
                    _BigIcon(
                      icon: option.icon,
                      color1: option.color1,
                      isActive: isActive,
                      ringAnim: ringAnim,
                      is3D: is3D,
                    ),
                    const SizedBox(height: 30),
                    // Judul
                    Text(
                      option.title,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: is3D ? AppColors.text : Colors.white,
                        fontSize: 24,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1.5,
                        fontFamily: _lFont,
                        shadows: is3D
                            ? null
                            : [
                                Shadow(
                                  color: Colors.black.withValues(alpha: 0.6),
                                  blurRadius: 12,
                                  offset: const Offset(0, 4),
                                ),
                              ],
                      ),
                    ),
                    const SizedBox(height: 8),
                    // Subjudul
                    Text(
                      option.subtitle,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: is3D
                            ? AppColors.textSub
                            : Colors.white.withValues(alpha: 0.7),
                        fontSize: 13,
                        fontWeight: FontWeight.w500,
                        fontFamily: _lFont,
                      ),
                    ),
                    const SizedBox(height: 20),
                    // Tombol Pill "BUKA MENU"
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 24, vertical: 10),
                      decoration: BoxDecoration(
                        color: option.color1.withValues(alpha: 0.15),
                        borderRadius: BorderRadius.circular(30),
                        border: Border.all(
                          color: option.color1.withValues(alpha: 0.6),
                          width: 1.5,
                        ),
                        boxShadow: is3D
                            ? null
                            : [
                                BoxShadow(
                                  color: option.color1.withValues(alpha: 0.3),
                                  blurRadius: 15,
                                  spreadRadius: 2,
                                ),
                              ],
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            Icons.touch_app_rounded,
                            color: option.color1,
                            size: 16,
                          ),
                          const SizedBox(width: 8),
                          Text(
                            'BUKA MENU',
                            style: TextStyle(
                              color: option.color1,
                              fontSize: 12,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 1,
                              fontFamily: _lFont,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 25),
                    // Indikator Geser X/Y
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 14, vertical: 6),
                      decoration: BoxDecoration(
                        color: is3D
                            ? AppColors.card
                            : Colors.black.withValues(alpha: 0.4),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                          color: is3D
                              ? AppColors.border
                              : Colors.white.withValues(alpha: 0.1),
                          width: is3D ? 2 : 1,
                        ),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            Icons.swipe_rounded,
                            color: is3D
                                ? AppColors.textSub
                                : Colors.white.withValues(alpha: 0.6),
                            size: 14,
                          ),
                          const SizedBox(width: 6),
                          Text(
                            'Geser ${current + 1}/$total',
                            style: TextStyle(
                              color: is3D
                                  ? AppColors.textSub
                                  : Colors.white.withValues(alpha: 0.8),
                              fontSize: 11,
                              fontFamily: _lFont,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}

class _BigIcon extends StatelessWidget {
  const _BigIcon({
    required this.icon,
    required this.color1,
    required this.isActive,
    required this.ringAnim,
    required this.is3D,
  });

  final IconData icon;
  final Color color1;
  final bool isActive;
  final Animation<double> ringAnim;
  final bool is3D;

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: ringAnim,
      builder: (_, __) => SizedBox(
        width: 150,
        height: 150,
        child: Stack(
          alignment: Alignment.center,
          children: [
            if (isActive) ...[
              // Ring Luar Berputar
              Transform.rotate(
                angle: ringAnim.value * math.pi * 2,
                child: CustomPaint(
                  size: const Size(150, 150),
                  painter: _RingPainter(
                    progress: ringAnim.value,
                    color: color1,
                    bgColor: color1.withValues(alpha: 0.1),
                  ),
                ),
              ),
              // Titik Orbit Berputar
              Transform.rotate(
                angle: ringAnim.value * math.pi * 2 + math.pi,
                child: Container(
                  width: 150,
                  height: 150,
                  alignment: Alignment.topCenter,
                  child: Container(
                    width: 8,
                    height: 8,
                    decoration: BoxDecoration(
                      color: color1,
                      shape: BoxShape.circle,
                      boxShadow: is3D
                          ? null
                          : [
                              BoxShadow(
                                color: color1,
                                blurRadius: 10,
                                spreadRadius: 2,
                              ),
                            ],
                    ),
                  ),
                ),
              ),
            ],
            // Lingkaran Dalam & Ikon
            Container(
              width: 100,
              height: 100,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: is3D ? AppColors.card : color1.withValues(alpha: 0.15),
                border: Border.all(
                  color: is3D ? AppColors.border : color1,
                  width: is3D ? 3 : 2,
                ),
                boxShadow: is3D
                    ? AppColors.softShadow
                    : [
                        BoxShadow(
                          color: color1.withValues(alpha: 0.5),
                          blurRadius: 30,
                          spreadRadius: 2,
                        ),
                      ],
              ),
              child: Icon(
                icon,
                color: is3D ? AppColors.text : color1,
                size: 45,
                shadows: is3D
                    ? null
                    : [
                        Shadow(
                          color: Colors.black.withValues(alpha: 0.5),
                          blurRadius: 10,
                          offset: const Offset(0, 3),
                        ),
                      ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════
//  PROGRESS DOTS
// ═══════════════════════════════════════════════════════════════════════
class _ProgressDots extends StatelessWidget {
  const _ProgressDots({
    required this.options,
    required this.current,
    required this.ink,
    required this.onTap,
  });

  final List<_MenuOption> options;
  final int current;
  final Color ink;
  final ValueChanged<int> onTap;

  @override
  Widget build(BuildContext context) {
    final is3D = ThemeModeManager.isComic3d;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 40),
      child: Row(
        children: List.generate(options.length, (i) {
          final active = i == current;
          final c = options[i].color1;
          return Expanded(
            child: GestureDetector(
              onTap: () => onTap(i),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 350),
                height: is3D ? 6 : 4,
                margin: const EdgeInsets.symmetric(horizontal: 4),
                decoration: BoxDecoration(
                  color: active ? c : ink.withValues(alpha: 0.15),
                  borderRadius: BorderRadius.circular(is3D ? 2 : 4),
                  border: is3D
                      ? Border.all(
                          color: AppColors.border,
                          width: 1.5,
                        )
                      : null,
                  boxShadow: active && !is3D
                      ? [
                          BoxShadow(
                            color: c.withValues(alpha: 0.7),
                            blurRadius: 8,
                          ),
                        ]
                      : null,
                ),
              ),
            ),
          );
        }),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════
//  BOTTOM ACTION (Mirip Foto 2)
// ═══════════════════════════════════════════════════════════════════════
class _BottomAction extends StatelessWidget {
  const _BottomAction({
    required this.ink,
    required this.color,
    required this.activeOption,
    required this.current,
    required this.total,
    required this.onTap,
  });

  final Color ink;
  final Color color;
  final _MenuOption activeOption;
  final int current;
  final int total;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final is3D = ThemeModeManager.isComic3d;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: _S.pagePadH),
      child: Column(
        children: [
          // Kartu Info Menu Aktif
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: is3D ? AppColors.card : Colors.black.withValues(alpha: 0.5),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: is3D
                    ? AppColors.border
                    : Colors.white.withValues(alpha: 0.1),
                width: is3D ? 2 : 1,
              ),
            ),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: color.withValues(alpha: 0.2),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(activeOption.icon, color: color, size: 20),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        activeOption.title,
                        style: TextStyle(
                          color: is3D ? AppColors.text : Colors.white,
                          fontWeight: FontWeight.bold,
                          fontFamily: _lFont,
                          fontSize: 14,
                        ),
                      ),
                      Text(
                        activeOption.subtitle,
                        style: TextStyle(
                          color: is3D
                              ? AppColors.textSub
                              : Colors.white.withValues(alpha: 0.6),
                          fontSize: 11,
                          fontFamily: _lFont,
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: color.withValues(alpha: 0.2),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Text(
                    '$current/$total',
                    style: TextStyle(
                      color: color,
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                      fontFamily: _lFont,
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: _S.gap),
          // Tombol Utama Buka Menu
          Material(
            color: Colors.transparent,
            borderRadius: BorderRadius.circular(is3D ? 6 : 18),
            clipBehavior: Clip.antiAlias,
            child: InkWell(
              borderRadius: BorderRadius.circular(is3D ? 6 : 18),
              onTap: () {
                HapticFeedback.heavyImpact();
                onTap();
              },
              splashColor: color.withValues(alpha: 0.35),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 400),
                height: 56,
                decoration: BoxDecoration(
                  gradient: is3D
                      ? null
                      : LinearGradient(
                          colors: [color, color.withValues(alpha: 0.7)],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                  color: is3D ? color : null,
                  borderRadius: BorderRadius.circular(is3D ? 6 : 18),
                  border: Border.all(
                    color: is3D
                        ? AppColors.border
                        : Colors.white.withValues(alpha: 0.2),
                    width: is3D ? 3 : 1,
                  ),
                  boxShadow: is3D
                      ? AppColors.softShadow
                      : [
                          BoxShadow(
                            color: color.withValues(alpha: 0.5),
                            blurRadius: 20,
                            spreadRadius: 1,
                            offset: const Offset(0, 8),
                          ),
                        ],
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.play_arrow_rounded,
                      color: is3D ? const Color(0xFF1A1A1A) : Colors.white,
                      size: 24,
                      shadows: is3D
                          ? null
                          : [
                              Shadow(
                                color: Colors.black.withValues(alpha: 0.5),
                                blurRadius: 6,
                              ),
                            ],
                    ),
                    const SizedBox(width: 8),
                    Text(
                      'BUKA MENU',
                      style: TextStyle(
                        color: is3D ? const Color(0xFF1A1A1A) : Colors.white,
                        fontSize: 14,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1.5,
                        fontFamily: _lFont,
                        shadows: is3D
                            ? null
                            : [
                                Shadow(
                                  color: Colors.black.withValues(alpha: 0.5),
                                  blurRadius: 6,
                                ),
                              ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(height: _S.gap),
          _InfoBanner(ink: ink),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════
//  INFO BANNER
// ═══════════════════════════════════════════════════════════════════════
class _InfoBanner extends StatelessWidget {
  const _InfoBanner({required this.ink});

  final Color ink;

  @override
  Widget build(BuildContext context) {
    final is3D = ThemeModeManager.isComic3d;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: is3D ? AppColors.card : AppColors.card.withValues(alpha: 0.75),
        borderRadius: BorderRadius.circular(is3D ? 6 : 14),
        border: Border.all(
          color: is3D ? AppColors.border : AppColors.border,
          width: is3D ? 2 : 1,
        ),
      ),
      child: Row(
        children: [
          Icon(
            Icons.info_outline_rounded,
            color: AppColors.accent,
            size: 14,
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              'Beberapa fitur ada yg work ada yg gak, mohon maaf & tunggu update berikutnya',
              style: TextStyle(
                fontSize: 10.5,
                height: 1.3,
                color: is3D ? AppColors.text : AppColors.textSub,
                fontFamily: _lFont,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════
//  CUSTOM PAINTERS
// ═══════════════════════════════════════════════════════════════════════
class _RingPainter extends CustomPainter {
  _RingPainter({
    required this.progress,
    required this.color,
    required this.bgColor,
  });

  final double progress;
  final Color color;
  final Color bgColor;

  @override
  void paint(Canvas canvas, Size size) {
    final center = size.center(Offset.zero);
    final radius = size.width / 2;
    
    // Background ring
    canvas.drawCircle(
      center,
      radius - 1,
      Paint()
        ..color = bgColor
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2,
    );
    
    // Foreground animated arc
    final sweep = 2 * math.pi * progress;
    canvas.drawArc(
      Rect.fromCircle(center: center, radius: radius - 1),
      -math.pi / 2,
      sweep,
      false,
      Paint()
        ..color = color
        ..style = PaintingStyle.stroke
        ..strokeWidth = 3
        ..strokeCap = StrokeCap.round,
    );
  }

  @override
  bool shouldRepaint(covariant _RingPainter old) =>
      old.progress != progress || old.color != color;
}

class _ParticlePainter extends CustomPainter {
  _ParticlePainter({required this.progress, required this.color});

  final double progress;
  final Color color;

  @override
  void paint(Canvas canvas, Size size) {
    final rnd = math.Random(42);
    final paint = Paint()..color = color;
    for (var i = 0; i < 22; i++) {
      final dx = rnd.nextDouble() * size.width;
      final dy = rnd.nextDouble() * size.height;
      final offset = math.sin((progress + i / 22) * math.pi * 2) * 20;
      canvas.drawCircle(
        Offset(dx, dy + offset),
        rnd.nextDouble() * 2.5 + 1,
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(covariant _ParticlePainter old) =>
      old.progress != progress;
}