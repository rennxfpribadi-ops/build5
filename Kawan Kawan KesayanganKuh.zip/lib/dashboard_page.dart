// dashboard_page.dart
import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:url_launcher/url_launcher.dart';
import 'package:video_player/video_player.dart';
import 'package:http/http.dart' as http;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

import 'theme.dart';
import 'audio_manager.dart';
import 'wa_ban_check.dart';
import 'admin_page.dart';
import 'owner_page.dart';
import 'developer_page.dart';
import 'user_management_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'ambil_link_gb_page.dart';
import 'device_dashboard.dart';
import 'controller.dart';
import 'change_password_page.dart';
import 'tools_gateway.dart';
import 'login_page.dart';
import 'bug_sender.dart';
import 'contact_page.dart';
import 'ai_page.dart';
import 'profile_page.dart';
import 'riwayat_page.dart';
import 'info_page.dart';
import 'pilih.dart';
import 'story_widgets.dart';
import 'chat.dart';
import 'tempat_phis.dart';
import 'alquran.dart';
import 'whatsapp_menu.dart';
import 'menu_tambahan.dart';
import 'role_upgrade.dart';
import 'uprole_page.dart';

// ─── GLOBAL FONT ───────────────────────────────────────────────────────
const String kFont = 'Pek';

// ─── BASE URL ──────────────────────────────────────────────────────────
const String kBaseUrl = 'http://cp.zyrostore.id:3448';

// ─── PALETTE ───────────────────────────────────────────────────────────
class _C {
  static Color get bg => AppColors.bg;
  static Color get surface => AppColors.dark;
  static Color get card => AppColors.card;
  static Color get cardAlt => AppColors.card2;
  static Color get card2 => AppColors.card2;
  static Color get border => AppColors.border;
  static Color get borderLit => AppColors.borderLit;
  static Color get glassBg => AppColors.glassGrad.colors.first;
  static Color get glassBorder => AppColors.glassBorder;

  static Color get primary => AppColors.accent;
  static Color get primaryMid => AppColors.accentMid;
  static Color get primaryLight => AppColors.accentLight;
  static Color get primaryDark => AppColors.accentDark;
  static Color get primaryGlow => AppColors.accentMid;

  static Color get secondary => AppColors.accentLight;
  static Color get accent => AppColors.accentLight;

  static Color get success => AppColors.green;
  static Color get warning => AppColors.amber;
  static Color get error => AppColors.red;

  static Color get red => AppColors.red;
  static Color get green => AppColors.green;
  static Color get amber => AppColors.amber;
  static Color get gold => AppColors.gold;
  static Color get pink => AppColors.pink;
  static Color get orange => AppColors.amber;
  static Color get purple => AppColors.purple;
  static Color get teal => AppColors.teal;
  static Color get blue => const Color(0xFF2979FF);

  static Color get grey => AppColors.accent;
  static Color get greyMid => AppColors.accentMid;
  static Color get greyLight => AppColors.accentLight;
  static Color get greyDark => AppColors.accentDark;
  static Color get greyGlow => AppColors.accentMid;

  static Color get text => AppColors.text;
  static Color get textSub => AppColors.textSub;
  static Color get textHint => AppColors.textHint;
  static Color get textDim => AppColors.textHint;
  static Color get textDark => AppColors.textHint;

  static Color get white => AppColors.text;
  static Color get whiteSoft => AppColors.textSub;
  static Color get whiteDim => AppColors.textSub;
  static Color get black => AppColors.bg;
  static Color get blackSoft => AppColors.dark;

  static LinearGradient get btnGrad => AppColors.btnGrad;
  static LinearGradient get glassGrad => AppColors.glassGrad;

  static List<BoxShadow> get glassShadow => AppColors.glassShadow;
  static List<BoxShadow> get softShadow => AppColors.softShadow;
  static List<BoxShadow> get glowShadow => ThemeModeManager.isComic3d
      ? AppColors.softShadow
      : [
          BoxShadow(
            color: AppColors.accentMid.withOpacity(0.3),
            blurRadius: 30,
            spreadRadius: 2,
          ),
        ];
}

Color _onAccent() =>
    ThemeModeManager.isComic3d ? const Color(0xFF1A1A1A) : Colors.white;

Color _roleColor(String role) {
  switch (role.toLowerCase()) {
    case 'developer':
      return const Color(0xFF00E5A0);
    case 'owner':
      return const Color(0xFF8B5CF6);
    case 'admin':
      return const Color(0xFFA855F7);
    case 'reseller':
      return const Color(0xFFD946EF);
    default:
      return AppColors.textSub;
  }
}

UserRole _toGbRole(String r) {
  switch (r.toLowerCase().trim()) {
    case 'developer':
    case 'owner':
      return UserRole.owner;
    case 'reseller':
      return UserRole.reseller;
    default:
      return UserRole.fullup;
  }
}

// ═══════════════════════════════════════════════════════════════════════
//  ANIMATED DOT
// ═══════════════════════════════════════════════════════════════════════
class _AnimatedDot extends StatefulWidget {
  final Color color;
  final double size;
  const _AnimatedDot({required this.color, this.size = 6});

  @override
  State<_AnimatedDot> createState() => _AnimatedDotState();
}

class _AnimatedDotState extends State<_AnimatedDot>
    with SingleTickerProviderStateMixin {
  late AnimationController _c;
  late Animation<double> _a;

  @override
  void initState() {
    super.initState();
    _c = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 900))
      ..repeat(reverse: true);
    _a = Tween<double>(begin: 0.3, end: 1.0)
        .animate(CurvedAnimation(parent: _c, curve: Curves.easeInOut));
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => FadeTransition(
        opacity: _a,
        child: Container(
          width: widget.size,
          height: widget.size,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: widget.color,
            boxShadow: [
              BoxShadow(
                color: widget.color.withOpacity(0.6),
                blurRadius: 6,
                spreadRadius: 1,
              )
            ],
          ),
        ),
      );
}

// ═══════════════════════════════════════════════════════════════════════
//  SOAP BUBBLE BORDER PAINTER (FOR DRAWER)
//  Ringan: hanya menggambar border iridescent seperti gelembung sabun.
//  Tanpa MaskFilter / blur / refraksi, dan tidak di-repaint selama drawer
//  digeser (statis + dibungkus RepaintBoundary).
// ═══════════════════════════════════════════════════════════════════════
class _SoapBubbleBorderPainter extends CustomPainter {
  final Color accentColor;
  final double radius;

  const _SoapBubbleBorderPainter({
    required this.accentColor,
    this.radius = 28.0,
  });

  RRect _rr(Rect rect, double inset) => RRect.fromRectAndRadius(
        rect.deflate(inset),
        Radius.circular(math.max(0.0, radius - inset)),
      );

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;

    // 1. Rim utama — warna pelangi tipis khas film gelembung sabun
    canvas.drawRRect(
      _rr(rect, 0.8),
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.6
        ..shader = SweepGradient(
          colors: [
            const Color(0xFFFF8AD8).withOpacity(0.70),
            const Color(0xFF8AF3FF).withOpacity(0.75),
            const Color(0xFFFFF2A8).withOpacity(0.55),
            accentColor.withOpacity(0.65),
            const Color(0xFFB69CFF).withOpacity(0.70),
            const Color(0xFFFF8AD8).withOpacity(0.70),
          ],
        ).createShader(rect),
    );

    // 2. Lapisan film tipis di dalam (bergeser warna)
    canvas.drawRRect(
      _rr(rect, 3.2),
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.0
        ..shader = SweepGradient(
          startAngle: 1.6,
          endAngle: 1.6 + math.pi * 2,
          colors: [
            const Color(0xFF8AF3FF).withOpacity(0.30),
            const Color(0xFFFF8AD8).withOpacity(0.26),
            const Color(0xFFFFF2A8).withOpacity(0.22),
            const Color(0xFF8AF3FF).withOpacity(0.30),
          ],
        ).createShader(rect),
    );

    // 3. Kilau pantulan (highlight) kiri-atas & kanan-bawah
    final hl = Paint()
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeWidth = 2.4
      ..color = Colors.white.withOpacity(0.85);
    final r2 = radius * 2;
    canvas.drawArc(
      Rect.fromLTWH(4, 4, r2 - 8, r2 - 8),
      math.pi + 0.30,
      0.85,
      false,
      hl,
    );
    canvas.drawArc(
      Rect.fromLTWH(size.width - r2 + 4, size.height - r2 + 4, r2 - 8, r2 - 8),
      0.30,
      0.70,
      false,
      hl
        ..strokeWidth = 1.6
        ..color = Colors.white.withOpacity(0.45),
    );

    // 4. Titik kilau kecil
    canvas.drawCircle(
      Offset(radius + 6, 5.5),
      1.6,
      Paint()..color = Colors.white.withOpacity(0.9),
    );
  }

  @override
  bool shouldRepaint(covariant _SoapBubbleBorderPainter old) =>
      old.accentColor != accentColor || old.radius != radius;
}

// ═══════════════════════════════════════════════════════════════════════
//  CUSTOM BOTTOM NAV BAR
// ═══════════════════════════════════════════════════════════════════════
class _CustomNavBar extends StatefulWidget {
  final List<Widget> items;
  final int currentIndex;
  final Function(int) onTap;

  const _CustomNavBar({
    required this.items,
    required this.currentIndex,
    required this.onTap,
  });

  @override
  State<_CustomNavBar> createState() => _CustomNavBarState();
}

class _CustomNavBarState extends State<_CustomNavBar>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _locationAnim;
  double _itemWidth = 0.0;
  double _currentLocation = 0.0;
  double _previousLocation = 0.0;
  final double _notchRadius = 35.0;
  final double _barHeight = 70.0;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 300),
    );
    _controller.addListener(() {
      setState(() {});
    });
  }

  @override
  void didUpdateWidget(covariant _CustomNavBar oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.currentIndex != widget.currentIndex && _itemWidth > 0) {
      _previousLocation = _currentLocation;
      _currentLocation = (widget.currentIndex * _itemWidth) + (_itemWidth / 2);
      _locationAnim =
          Tween<double>(begin: _previousLocation, end: _currentLocation)
              .animate(CurvedAnimation(
                  parent: _controller, curve: Curves.easeInOut));
      _controller.forward(from: 0);
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        _itemWidth = constraints.maxWidth / widget.items.length;
        if (_currentLocation == 0.0) {
          _currentLocation =
              (widget.currentIndex * _itemWidth) + (_itemWidth / 2);
          _previousLocation = _currentLocation;
        }

        final double animatedLocation =
            _controller.isAnimating ? _locationAnim.value : _currentLocation;

        return SizedBox(
          height: _barHeight + 20,
          child: Stack(
            alignment: Alignment.bottomCenter,
            children: [
              ClipPath(
                clipper: _NavBarClipper(
                  location: animatedLocation,
                  notchRadius: _notchRadius,
                  barHeight: _barHeight,
                ),
                child: Container(
                  width: double.infinity,
                  height: _barHeight,
                  decoration: const BoxDecoration(
                    image: DecorationImage(
                      image: AssetImage('assets/images/nvbar.jpg'),
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
              Positioned(
                bottom: 0,
                left: 0,
                right: 0,
                height: _barHeight,
                child: Row(
                  children: List.generate(widget.items.length, (index) {
                    return Expanded(
                      child: GestureDetector(
                        behavior: HitTestBehavior.opaque,
                        onTap: () {
                          HapticFeedback.lightImpact();
                          widget.onTap(index);
                        },
                        child: Center(
                          child: AnimatedOpacity(
                            duration: const Duration(milliseconds: 200),
                            opacity: index == widget.currentIndex ? 0.0 : 1.0,
                            child: IconTheme(
                              data: const IconThemeData(
                                color: Colors.white,
                                shadows: [
                                  Shadow(
                                      color: Colors.black45,
                                      blurRadius: 4,
                                      offset: Offset(0, 2))
                                ],
                              ),
                              child: widget.items[index],
                            ),
                          ),
                        ),
                      ),
                    );
                  }),
                ),
              ),
              Positioned(
                top: 5,
                left: animatedLocation - 30,
                child: GestureDetector(
                  onTap: () {
                    HapticFeedback.lightImpact();
                    widget.onTap(widget.currentIndex);
                  },
                  child: Container(
                    width: 60,
                    height: 60,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: const LinearGradient(
                        colors: [Color(0xFFFF9800), Color(0xFFE65100)],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: const Color(0xFFE65100).withOpacity(0.5),
                          blurRadius: 15,
                          spreadRadius: 2,
                          offset: const Offset(0, 5),
                        ),
                      ],
                      border: Border.all(
                          color: Colors.white.withOpacity(0.2), width: 2),
                    ),
                    child: Center(
                      child: IconTheme(
                        data:
                            const IconThemeData(color: Colors.white, size: 28),
                        child: widget.items[widget.currentIndex],
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _NavBarClipper extends CustomClipper<Path> {
  final double location;
  final double notchRadius;
  final double barHeight;

  _NavBarClipper({
    required this.location,
    required this.notchRadius,
    required this.barHeight,
  });

  @override
  Path getClip(Size size) {
    Path path = Path();
    final double radius = 20.0;

    path.moveTo(0, radius);
    path.quadraticBezierTo(0, 0, radius, 0);

    final double leftEdge = location - notchRadius * 1.8;
    path.lineTo(leftEdge, 0);

    path.cubicTo(
      location - notchRadius * 1.2,
      0,
      location - notchRadius * 0.8,
      notchRadius,
      location,
      notchRadius,
    );
    path.cubicTo(
      location + notchRadius * 0.8,
      notchRadius,
      location + notchRadius * 1.2,
      0,
      location + notchRadius * 1.8,
      0,
    );

    path.lineTo(size.width - radius, 0);
    path.quadraticBezierTo(size.width, 0, size.width, radius);
    path.lineTo(size.width, size.height - radius);
    path.quadraticBezierTo(
        size.width, size.height, size.width - radius, size.height);
    path.lineTo(radius, size.height);
    path.quadraticBezierTo(0, size.height, 0, size.height - radius);
    path.close();

    return path;
  }

  @override
  bool shouldReclip(covariant CustomClipper<Path> oldClipper) {
    if (oldClipper is _NavBarClipper) {
      return oldClipper.location != location;
    }
    return true;
  }
}

// ═══════════════════════════════════════════════════════════════════════
//  DASHBOARD PAGE
// ═══════════════════════════════════════════════════════════════════════
class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<dynamic> listBug;
  final List<dynamic> listDoos;
  final List<dynamic> news;
  final String uid;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listDoos,
    required this.sessionKey,
    required this.news,
    required this.uid,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with TickerProviderStateMixin, AutomaticKeepAliveClientMixin {
  @override
  bool get wantKeepAlive => true;

  late String sessionKey, username, password, role, expiredDate, uid;
  late List<dynamic> listBug, listDoos;
  late List<dynamic> newsList;

  WebSocketChannel? channel;
  String androidId = 'Novarch-Realese';

  int onlineUsers = 0;
  int activeConns = 0;
  int globalChatCount = 0;
  String lastChatPreview = 'Tap untuk gabung obrolan global...';

  // ─── DEVICE & ONLINE SYSTEM STATE ────────────────────────────────────
  String _deviceModel = 'Memuat...';
  String _osVersion = 'Android / iOS';
  int _batteryLevel = 100;
  String _batteryStatus = 'Normal';
  bool _isUsingWifi = false;
  String _networkType = 'Checking...';
  String _localIp = '127.0.0.1';
  Timer? _deviceMonitorTimer;

  Timer? _statsHttpTimer;
  bool _statsLoading = true;

  late AnimationController _bgCtrl;
  late AnimationController _pageCtrl;
  late AnimationController _pulseCtrl;
  late Animation<double> _pageFade;
  late Animation<double> _pulseAnim;
  late Animation<Offset> _pageSlide;
  final math.Random _random = math.Random();

  VideoPlayerController? _videoController;
  final AudioManager _audioManager = AudioManager();

  int _bottomNavIndex = 0;
  File? _profileImage;

  late PageController _qaPageCtrl;
  double _currentQaPage = 0.0;
  bool _isGridView = false; // default: mode slider

  // ═══════════════════════════════════════════════════════════════════
  //  Deteksi tema "Light Blue Clean" → background assets/images/white_dash.jpg
  // ═══════════════════════════════════════════════════════════════════
  bool get _isMonochromeTheme {
    // Tema 3D/comic selalu memakai back_dash.jpg
    if (ThemeModeManager.isComic3d) return false;

    bool matches(String raw) {
      final n = raw
          .toLowerCase()
          .replaceAll('_', ' ')
          .replaceAll('-', ' ')
          .replaceAll('.', ' ');
      final compact = n.replaceAll(' ', '');
      return (n.contains('light') && n.contains('blue')) ||
          (n.contains('clean') && n.contains('blue')) ||
          compact.contains('lightblue') ||
          compact.contains('blueclean') ||
          compact.contains('lightclean') ||
          compact.contains('cleanlight');
    }

    try {
      // 1. Cocokkan lewat daftar tema (nama + subtitle)
      for (final info in kThemeModes) {
        if (info.mode == ThemeModeManager.mode) {
          if (matches(info.name) || matches(info.subtitle)) return true;
          break;
        }
      }
      // 2. Cocokkan lewat nama enum / toString mode
      if (matches(ThemeModeManager.mode.toString())) return true;
    } catch (_) {}

    return false;
  }

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    username = widget.username;
    password = widget.password;
    role = widget.role;
    expiredDate = widget.expiredDate;
    listBug = widget.listBug;
    listDoos = widget.listDoos;
    newsList = widget.news;
    uid = widget.uid;

    _loadProfileImage();
    _initVideoPlayer();
    _initDeviceTelemetry();

    _bgCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 30))
      ..repeat();
    _pulseCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 2))
      ..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.85, end: 1.0).animate(
        CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));

    _pageCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 400));
    _pageFade = CurvedAnimation(parent: _pageCtrl, curve: Curves.easeOut);
    _pageSlide =
        Tween<Offset>(begin: const Offset(0, 0.03), end: Offset.zero)
            .animate(
                CurvedAnimation(parent: _pageCtrl, curve: Curves.easeOutCubic));

    _qaPageCtrl = PageController(viewportFraction: 0.88, initialPage: 0);
    _qaPageCtrl.addListener(() {
      if (mounted) {
        setState(() => _currentQaPage = _qaPageCtrl.page ?? 0.0);
      }
    });

    _audioManager.addListener(_onAudioChanged);
    _audioManager.init().then((_) {
      if (mounted) setState(() {});
    });

    _initConnection();

    _fetchStatsFromApi();
    _statsHttpTimer = Timer.periodic(const Duration(seconds: 5), (_) {
      _fetchStatsFromApi();
    });

    _deviceMonitorTimer = Timer.periodic(const Duration(seconds: 8), (_) {
      _refreshDynamicDeviceTelemetry();
    });

    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) {
        _pageCtrl.forward();
        try {
          _showWelcomeDialog();
        } catch (e) {
          debugPrint("Gagal menampilkan welcome dialog: $e");
        }
      }
    });

    _fetchChatPreview();
  }

  // ═══════════════════════════════════════════════════════════════════
  //  DEVICE TELEMETRY (Model, Baterai, WiFi/Mobile Data, IP)
  // ═══════════════════════════════════════════════════════════════════
  Future<void> _initDeviceTelemetry() async {
    try {
      final deviceInfo = DeviceInfoPlugin();
      if (Platform.isAndroid) {
        final android = await deviceInfo.androidInfo;
        final brand = android.brand.toUpperCase();
        final model = android.model;
        _deviceModel =
            model.toUpperCase().startsWith(brand) ? model : '$brand $model';
        _osVersion =
            'Android ${android.version.release} (SDK ${android.version.sdkInt})';
        if (android.id.isNotEmpty) {
          androidId = android.id;
        }
      } else if (Platform.isIOS) {
        final ios = await deviceInfo.iosInfo;
        _deviceModel = ios.utsname.machine;
        _osVersion = '${ios.systemName} ${ios.systemVersion}';
      } else {
        _deviceModel = Platform.operatingSystem.toUpperCase();
        _osVersion = Platform.operatingSystemVersion.split(' ').first;
      }
    } catch (e) {
      _deviceModel = 'Unknown Device';
      _osVersion = Platform.operatingSystem;
    }
    await _refreshDynamicDeviceTelemetry();
  }

  Future<void> _refreshDynamicDeviceTelemetry() async {
    int level = _batteryLevel;
    String statusText = _batteryStatus;
    bool wifi = false;
    String netLabel = 'Offline';
    String ipAddr = 'No IP';

    // 1. Cek Baterai (Linux/Android sysfs power_supply)
    try {
      if (Platform.isAndroid) {
        final capFile = File('/sys/class/power_supply/battery/capacity');
        final statFile = File('/sys/class/power_supply/battery/status');
        if (await capFile.exists()) {
          final rawCap = (await capFile.readAsString()).trim();
          level = int.tryParse(rawCap) ?? level;
        }
        if (await statFile.exists()) {
          final rawStat = (await statFile.readAsString()).trim();
          statusText = rawStat.isNotEmpty ? rawStat : 'Discharging';
        }
      }
    } catch (_) {}

    // 2. Cek Koneksi WiFi vs Seluler & IP Lokal via NetworkInterface
    try {
      final interfaces = await NetworkInterface.list(
        includeLoopback: false,
        type: InternetAddressType.IPv4,
      );
      if (interfaces.isNotEmpty) {
        for (final iface in interfaces) {
          final name = iface.name.toLowerCase();
          if (name.contains('wlan') ||
              name.contains('wifi') ||
              name.startsWith('en')) {
            wifi = true;
            netLabel = 'Wi-Fi Connected';
            if (iface.addresses.isNotEmpty) {
              ipAddr = iface.addresses.first.address;
            }
            break;
          }
        }
        if (!wifi) {
          netLabel = 'Mobile Data';
          if (interfaces.first.addresses.isNotEmpty) {
            ipAddr = interfaces.first.addresses.first.address;
          }
        }
      } else {
        wifi = false;
        netLabel = 'Disconnected';
        ipAddr = 'Offline';
      }
    } catch (_) {
      netLabel = 'Active Network';
    }

    if (!mounted) return;
    setState(() {
      _batteryLevel = level.clamp(0, 100);
      _batteryStatus = statusText;
      _isUsingWifi = wifi;
      _networkType = netLabel;
      _localIp = ipAddr;
    });
  }

  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final imagePath = prefs.getString('profile_image_$username');
    if (imagePath != null && imagePath.isNotEmpty) {
      if (mounted) {
        setState(() => _profileImage = File(imagePath));
      }
    }
  }

  Widget _safeBuild(Widget Function() builder) {
    try {
      return builder();
    } catch (e, st) {
      debugPrint("Widget Error caught by _safeBuild: $e\n$st");
      return const SizedBox.shrink();
    }
  }

  Future<void> _fetchStatsFromApi() async {
    try {
      final results = await Future.wait([
        http
            .get(Uri.parse('$kBaseUrl/onlineusers'))
            .timeout(const Duration(seconds: 6)),
        http
            .get(Uri.parse('$kBaseUrl/activeconnections'))
            .timeout(const Duration(seconds: 6)),
      ]);

      if (!mounted) return;

      int newOnline = onlineUsers;
      int newActive = activeConns;

      if (results[0].statusCode == 200) {
        final data = jsonDecode(results[0].body) as Map<String, dynamic>;
        final val = data['online'] ?? data['count'] ?? 0;
        newOnline = val is int ? val : int.tryParse('$val') ?? newOnline;
      }

      if (results[1].statusCode == 200) {
        final data = jsonDecode(results[1].body) as Map<String, dynamic>;
        final val = data['connections'] ?? data['count'] ?? 0;
        newActive = val is int ? val : int.tryParse('$val') ?? newActive;
      }

      if (!mounted) return;
      setState(() {
        onlineUsers = newOnline;
        activeConns = newActive;
        _statsLoading = false;
      });
    } catch (e) {
      debugPrint("[STATS] HTTP error: $e");
      if (mounted && _statsLoading) {
        setState(() => _statsLoading = false);
      }
    }
  }

  void _initVideoPlayer() async {
    try {
      _videoController = VideoPlayerController.asset('assets/videos/log.mp4');
      await _videoController!.initialize();
      _videoController!.setLooping(true);
      _videoController!.setVolume(0);
      _videoController!.play();
      if (mounted) setState(() {});
    } catch (e) {
      debugPrint("Gagal memuat video: $e");
      _videoController = null;
    }
  }

  void _onAudioChanged() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    _statsHttpTimer?.cancel();
    _deviceMonitorTimer?.cancel();
    _audioManager.removeListener(_onAudioChanged);
    _videoController?.dispose();
    try {
      channel?.sink.close(status.goingAway);
    } catch (_) {}
    _bgCtrl.dispose();
    _pageCtrl.dispose();
    _pulseCtrl.dispose();
    _qaPageCtrl.dispose();
    super.dispose();
  }

  void _hapticLight() => HapticFeedback.lightImpact();
  void _hapticMedium() => HapticFeedback.mediumImpact();

  Future<void> _fetchChatPreview() async {
    Future.doWhile(() async {
      await Future.delayed(const Duration(seconds: 15));
      if (!mounted) return false;
      try {
        setState(() {
          globalChatCount = 10 + _random.nextInt(30);
        });
      } catch (_) {}
      return true;
    });
  }

  void _initConnection() {
    _connectWS();
  }

  void _connectWS() {
    try {
      channel = WebSocketChannel.connect(Uri.parse(kBaseUrl));
      channel!.sink.add(jsonEncode({
        'type': 'validate',
        'key': sessionKey,
        'androidId': androidId,
      }));
      channel!.stream.listen(
        (event) {
          try {
            final data = jsonDecode(event);
            if (data['type'] == 'myInfo' && data['valid'] == false) {
              _handleInvalidSession('Sesi tidak valid. Silakan login ulang.');
            }
          } catch (e) {
            debugPrint("WS parse error: $e");
          }
        },
        onError: (e) => debugPrint("WS stream error: $e"),
      );
    } catch (e) {
      debugPrint("WebSocket Error: $e");
    }
  }

  void _handleInvalidSession(String message) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    if (!mounted) return;
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const LoginPage()),
      (_) => false,
    );
  }

  void _showWelcomeDialog() {
    _hapticMedium();
    final isComic = ThemeModeManager.isComic3d;
    showGeneralDialog(
      context: context,
      barrierDismissible: false,
      barrierLabel: '',
      barrierColor: Colors.black.withOpacity(0.85),
      transitionDuration: const Duration(milliseconds: 500),
      transitionBuilder: (_, anim, __, child) => ScaleTransition(
        scale: CurvedAnimation(parent: anim, curve: Curves.easeOutBack),
        child: FadeTransition(opacity: anim, child: child),
      ),
      pageBuilder: (ctx, _, __) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 28),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(isComic ? 6 : 24),
          child: BackdropFilter(
            filter: ImageFilter.blur(
              sigmaX: isComic ? 0 : 20,
              sigmaY: isComic ? 0 : 20,
            ),
            child: Container(
              padding: const EdgeInsets.all(28),
              decoration: BoxDecoration(
                gradient: isComic ? null : _C.glassGrad,
                color: isComic ? AppColors.card : null,
                borderRadius: BorderRadius.circular(isComic ? 6 : 24),
                border: Border.all(
                  color:
                      isComic ? AppColors.border : _C.primary.withOpacity(0.3),
                  width: isComic ? 3 : 1.5,
                ),
                boxShadow: isComic
                    ? AppColors.glassShadow
                    : [
                        BoxShadow(
                            color: _C.primary.withOpacity(0.3),
                            blurRadius: 60,
                            spreadRadius: 4),
                      ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: _C.btnGrad,
                      border: isComic
                          ? Border.all(color: AppColors.border, width: 3)
                          : null,
                      boxShadow: isComic
                          ? null
                          : [
                              BoxShadow(
                                  color: _C.primary.withOpacity(0.5),
                                  blurRadius: 30,
                                  spreadRadius: 4),
                            ],
                    ),
                    child: Icon(Icons.waving_hand_rounded,
                        color: _onAccent(), size: 40),
                  ),
                  const SizedBox(height: 24),
                  Text('Welcome Back',
                      style: TextStyle(
                          color: _C.white,
                          fontSize: 26,
                          fontWeight: FontWeight.w900,
                          fontFamily: kFont,
                          letterSpacing: -0.5)),
                  const SizedBox(height: 12),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 6),
                    decoration: BoxDecoration(
                      color: _C.primary.withOpacity(isComic ? 0.3 : 0.1),
                      borderRadius: BorderRadius.circular(isComic ? 4 : 20),
                      border: Border.all(
                          color: _C.primary.withOpacity(0.5),
                          width: isComic ? 2 : 1),
                    ),
                    child: Text('Selamat Datang di Novarch',
                        style: TextStyle(
                            color: isComic
                                ? const Color(0xFF1A1A1A)
                                : _C.primaryLight,
                            fontSize: 13,
                            fontWeight: FontWeight.bold,
                            fontFamily: kFont,
                            letterSpacing: 0.5)),
                  ),
                  const SizedBox(height: 16),
                  Text(
                      'Novarch dirancang untuk keamanan & OSINT tools premium',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          color: _C.textSub,
                          fontSize: 13,
                          fontFamily: kFont,
                          height: 1.5)),
                  const SizedBox(height: 20),
                  Container(
                      height: 1,
                      decoration: BoxDecoration(
                          gradient: LinearGradient(colors: [
                        Colors.transparent,
                        _C.primary.withOpacity(0.3),
                        Colors.transparent
                      ]))),
                  const SizedBox(height: 16),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.code_rounded, color: _C.textDim, size: 14),
                      const SizedBox(width: 6),
                      Text('By @Jentrick2',
                          style: TextStyle(
                              color: _C.textDim,
                              fontSize: 12,
                              fontFamily: kFont,
                              letterSpacing: 1)),
                    ],
                  ),
                  const SizedBox(height: 24),
                  GestureDetector(
                    onTap: () {
                      _hapticLight();
                      Navigator.pop(ctx);
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 40, vertical: 14),
                      decoration: BoxDecoration(
                        gradient: _C.btnGrad,
                        borderRadius: BorderRadius.circular(isComic ? 4 : 14),
                        border: isComic
                            ? Border.all(
                                color: AppColors.border, width: 2)
                            : null,
                        boxShadow: isComic
                            ? AppColors.softShadow
                            : [
                                BoxShadow(
                                    color: _C.primary.withOpacity(0.4),
                                    blurRadius: 20,
                                    offset: const Offset(0, 6)),
                              ],
                      ),
                      child: Text('MULAI',
                          style: TextStyle(
                              color: _onAccent(),
                              fontSize: 14,
                              fontWeight: FontWeight.bold,
                              fontFamily: kFont,
                              letterSpacing: 2)),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  void _navigate(Widget page) {
    _hapticLight();
    Navigator.push(context, _slideRoute(page));
  }

  void _openDrawerPage(Widget page) {
    Navigator.pop(context);
    _hapticLight();
    Future.delayed(const Duration(milliseconds: 100), () {
      if (!mounted) return;
      Navigator.push(context, _slideRoute(page));
    });
  }

  void _showComingSoonAfterClose() {
    Navigator.pop(context);
    _hapticMedium();
    Future.delayed(const Duration(milliseconds: 250), () {
      if (!mounted) return;
      _showComingSoonDialog();
    });
  }

  void _showComingSoonDialog() {
    final isComic = ThemeModeManager.isComic3d;
    showGeneralDialog(
      context: context,
      barrierDismissible: true,
      barrierLabel: '',
      barrierColor: Colors.black.withOpacity(0.75),
      transitionDuration: const Duration(milliseconds: 400),
      transitionBuilder: (_, anim, __, child) => ScaleTransition(
        scale: CurvedAnimation(parent: anim, curve: Curves.easeOutBack),
        child: FadeTransition(opacity: anim, child: child),
      ),
      pageBuilder: (ctx, _, __) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 32),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(isComic ? 6 : 24),
          child: BackdropFilter(
            filter: ImageFilter.blur(
                sigmaX: isComic ? 0 : 20, sigmaY: isComic ? 0 : 20),
            child: Container(
              padding: const EdgeInsets.all(28),
              decoration: BoxDecoration(
                gradient: isComic ? null : _C.glassGrad,
                color: isComic ? AppColors.card : null,
                borderRadius: BorderRadius.circular(isComic ? 6 : 24),
                border: Border.all(
                    color: _C.pink.withOpacity(0.4),
                    width: isComic ? 3 : 1.5),
                boxShadow: isComic
                    ? AppColors.glassShadow
                    : [
                        BoxShadow(
                            color: _C.pink.withOpacity(0.3),
                            blurRadius: 60,
                            spreadRadius: 4),
                      ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(colors: [
                        _C.pink.withOpacity(0.9),
                        _C.pink.withOpacity(0.5)
                      ], begin: Alignment.topLeft, end: Alignment.bottomRight),
                      boxShadow: isComic
                          ? null
                          : [
                              BoxShadow(
                                  color: _C.pink.withOpacity(0.4),
                                  blurRadius: 30,
                                  spreadRadius: 4),
                            ],
                    ),
                    child: const Icon(Icons.shopping_bag_rounded,
                        color: Colors.white, size: 40),
                  ),
                  const SizedBox(height: 20),
                  Text('COMING SOON',
                      style: TextStyle(
                          color: _C.pink,
                          fontSize: 22,
                          fontWeight: FontWeight.w900,
                          fontFamily: kFont,
                          letterSpacing: 2)),
                  const SizedBox(height: 8),
                  Text('Buyer Management',
                      style: TextStyle(
                          color: _C.white,
                          fontSize: 16,
                          fontWeight: FontWeight.w700,
                          fontFamily: kFont)),
                  const SizedBox(height: 12),
                  Text('Fitur ini sedang dalam pengembangan.\nStay tune ya!',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          color: _C.textSub,
                          fontSize: 12,
                          fontFamily: kFont,
                          height: 1.5)),
                  const SizedBox(height: 24),
                  GestureDetector(
                    onTap: () {
                      _hapticLight();
                      Navigator.pop(ctx);
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 48, vertical: 12),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(colors: [
                          _C.pink,
                          _C.pink.withOpacity(0.7)
                        ]),
                        borderRadius: BorderRadius.circular(isComic ? 4 : 14),
                        border: isComic
                            ? Border.all(
                                color: AppColors.border, width: 2)
                            : null,
                        boxShadow: isComic
                            ? AppColors.softShadow
                            : [
                                BoxShadow(
                                    color: _C.pink.withOpacity(0.4),
                                    blurRadius: 20,
                                    offset: const Offset(0, 6)),
                              ],
                      ),
                      child: Text('OK',
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 14,
                              fontWeight: FontWeight.bold,
                              fontFamily: kFont,
                              letterSpacing: 2)),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  void _onBottomNavTapped(int index) {
    HapticFeedback.mediumImpact();
    setState(() => _bottomNavIndex = index);
  }

  Widget _buildCurrentPage() {
    switch (_bottomNavIndex) {
      case 0:
        return _buildHomeContent();
      case 1:
        return _safeBuild(() => WhatsAppMenuPage(
            username: username,
            sessionKey: sessionKey,
            password: password,
            role: role,
            listBug: listBug
                .whereType<Map>()
                .map((item) => Map<String, dynamic>.from(item))
                .toList(),
            expiredDate: expiredDate));
      case 2:
        return _safeBuild(() => MenuTambahanPage(
            username: username,
            password: password,
            role: role,
            expiredDate: expiredDate,
            sessionKey: sessionKey));
      case 3:
        return _safeBuild(() => InfoPage(sessionKey: sessionKey));
      case 4:
        return _safeBuild(() => ToolsPage(
            sessionKey: sessionKey,
            userRole: role,
            listDoos: listDoos
                .whereType<Map>()
                .map((item) => Map<String, dynamic>.from(item))
                .toList(),
            username: username));
      default:
        return _buildHomeContent();
    }
  }

  Future<void> _openUrl(String url) async {
    _hapticLight();
    await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
  }

  void _openGlobalChat() {
    _hapticMedium();
    Navigator.push(
        context,
        _slideRoute(ChatPage(
            sessionKey: sessionKey, username: username, role: role)));
  }

  void _showThemePicker() {
    _hapticLight();
    final isComic = ThemeModeManager.isComic3d;
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setModalState) {
          return ClipRRect(
            borderRadius: BorderRadius.vertical(
                top: Radius.circular(AppColors.sheetRadius)),
            child: BackdropFilter(
              filter: ImageFilter.blur(
                  sigmaX: isComic ? 0 : 15, sigmaY: isComic ? 0 : 15),
              child: Container(
                decoration: BoxDecoration(
                  gradient: isComic ? null : _C.glassGrad,
                  color: isComic ? AppColors.card : null,
                  borderRadius: BorderRadius.vertical(
                      top: Radius.circular(AppColors.sheetRadius)),
                  border: Border.all(
                      color: _C.border, width: AppColors.borderWidth),
                  boxShadow: _C.glassShadow,
                ),
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Center(
                        child: Container(
                            width: 40,
                            height: 4,
                            decoration: BoxDecoration(
                                color: _C.textSub.withOpacity(0.3),
                                borderRadius: BorderRadius.circular(4)))),
                    const SizedBox(height: 16),
                    Row(
                      children: [
                        Container(
                            width: 4,
                            height: 18,
                            decoration: BoxDecoration(
                                gradient: _C.btnGrad,
                                borderRadius: BorderRadius.circular(2))),
                        const SizedBox(width: 10),
                        Text('PILIH TEMA',
                            style: TextStyle(
                                color: _C.white,
                                fontSize: 15,
                                fontWeight: FontWeight.w700,
                                letterSpacing: 0.5,
                                fontFamily: kFont)),
                        const Spacer(),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 10, vertical: 3),
                          decoration: BoxDecoration(
                              color: _C.primary.withOpacity(0.15),
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(
                                  color: _C.primary.withOpacity(0.3))),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(Icons.palette_rounded,
                                  color: _C.primary, size: 11),
                              const SizedBox(width: 4),
                              Text('${kThemeModes.length}',
                                  style: TextStyle(
                                      color: _C.primary,
                                      fontSize: 10,
                                      fontFamily: kFont,
                                      fontWeight: FontWeight.bold)),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 14),
                    ...kThemeModes.map((info) {
                      final isSelected = ThemeModeManager.mode == info.mode;
                      return GestureDetector(
                        onTap: () async {
                          _hapticMedium();
                          await ThemeModeManager.setMode(info.mode);
                          if (mounted) setState(() {});
                          setModalState(() {});
                        },
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          margin: const EdgeInsets.only(bottom: 10),
                          padding: const EdgeInsets.all(14),
                          decoration: BoxDecoration(
                            color: isSelected
                                ? _C.primary.withOpacity(0.12)
                                : _C.surface,
                            borderRadius:
                                BorderRadius.circular(AppColors.cardRadius),
                            border: Border.all(
                                color: isSelected ? _C.primary : _C.border,
                                width: isSelected
                                    ? (isComic ? 3 : 2)
                                    : AppColors.borderWidth),
                            boxShadow: isSelected
                                ? [
                                    BoxShadow(
                                        color: _C.primary.withOpacity(0.2),
                                        blurRadius: 20,
                                        spreadRadius: 1)
                                  ]
                                : null,
                          ),
                          child: Row(
                            children: [
                              Container(
                                width: 44,
                                height: 44,
                                decoration: BoxDecoration(
                                  gradient: isSelected ? _C.btnGrad : null,
                                  color: isSelected ? null : _C.card,
                                  borderRadius:
                                      BorderRadius.circular(isComic ? 4 : 10),
                                  border: Border.all(
                                      color: isSelected
                                          ? _C.primary
                                          : _C.border,
                                      width: isComic ? 2 : 1),
                                ),
                                child: Icon(info.icon,
                                    color:
                                        isSelected ? _onAccent() : _C.primary,
                                    size: 22),
                              ),
                              const SizedBox(width: 14),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(info.name,
                                        style: TextStyle(
                                            color: isSelected
                                                ? _C.primary
                                                : _C.text,
                                            fontSize: 14,
                                            fontWeight: FontWeight.bold,
                                            fontFamily: kFont)),
                                    const SizedBox(height: 2),
                                    Text(info.subtitle,
                                        style: TextStyle(
                                            color: _C.textSub,
                                            fontSize: 11,
                                            fontFamily: kFont)),
                                  ],
                                ),
                              ),
                              AnimatedSwitcher(
                                duration: const Duration(milliseconds: 200),
                                child: isSelected
                                    ? Icon(Icons.check_circle_rounded,
                                        key: const ValueKey('active'),
                                        color: _C.primary,
                                        size: 22)
                                    : Icon(Icons.radio_button_unchecked_rounded,
                                        key: const ValueKey('inactive'),
                                        color: _C.textDim,
                                        size: 22),
                              ),
                            ],
                          ),
                        ),
                      );
                    }),
                    const SizedBox(height: 4),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildHomeContent() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(0, 8, 0, 96),
      child: Column(
        children: [
          _safeBuild(
              () => StoryBar(sessionKey: sessionKey, username: username)),
          const SizedBox(height: 8),
          _safeBuild(() => _buildLiveFeedCard()),
          const SizedBox(height: 12),
          _safeBuild(() => _buildWelcomeCard()),
          const SizedBox(height: 14),
          _safeBuild(() => _buildGlobalChatCard()),
          const SizedBox(height: 20),
          _safeBuild(() => _buildQuickActions()),
          const SizedBox(height: 8),
          // ─── ONLINE SYSTEM (Di bawah Quick Action & di atas Novarch Crew) ───
          _safeBuild(() => _buildOnlineSystemCard()),
          const SizedBox(height: 10),
          _safeBuild(() => _buildMantaCoreCrew()),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  ONLINE SYSTEM CARD (Detail Device: Model, Baterai, WiFi, OS/IP)
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildOnlineSystemCard() {
    final Color batteryColor = _batteryLevel > 50
        ? const Color(0xFF00E5A0)
        : (_batteryLevel > 20
            ? const Color(0xFFFBBF24)
            : const Color(0xFFEF4444));
    final IconData batteryIcon = _batteryStatus.toLowerCase().contains('charg')
        ? Icons.battery_charging_full_rounded
        : (_batteryLevel > 80
            ? Icons.battery_full_rounded
            : (_batteryLevel > 35
                ? Icons.battery_std_rounded
                : Icons.battery_alert_rounded));

    final Color wifiColor =
        _isUsingWifi ? const Color(0xFF38BDF8) : const Color(0xFFA855F7);

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(AppColors.cardRadius),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 16, sigmaY: 16),
          child: Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  const Color(0xFF151E24).withOpacity(0.82),
                  const Color(0xFF0D1318).withOpacity(0.90),
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(AppColors.cardRadius),
              border: Border.all(
                color: const Color(0xFF00E5A0).withOpacity(0.32),
                width: 1.5,
              ),
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFF00E5A0).withOpacity(0.08),
                  blurRadius: 22,
                  spreadRadius: 1,
                ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Header Online System
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 12, vertical: 7),
                      decoration: BoxDecoration(
                        color: const Color(0xFF00E5A0).withOpacity(0.14),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                          color: const Color(0xFF00E5A0).withOpacity(0.45),
                        ),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const _AnimatedDot(
                              color: Color(0xFF00E5A0), size: 7),
                          const SizedBox(width: 8),
                          Text(
                            'ONLINE SYSTEM',
                            style: TextStyle(
                              color: const Color(0xFF00E5A0),
                              fontWeight: FontWeight.w900,
                              fontSize: 11.5,
                              fontFamily: kFont,
                              letterSpacing: 1.1,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const Spacer(),
                    GestureDetector(
                      onTap: () {
                        _hapticLight();
                        _refreshDynamicDeviceTelemetry();
                      },
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 5),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.06),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: Colors.white.withOpacity(0.12),
                          ),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(Icons.sync_rounded,
                                color: Color(0xFF38BDF8), size: 13),
                            const SizedBox(width: 4),
                            Text(
                              'SYNC',
                              style: TextStyle(
                                color: Colors.white.withOpacity(0.85),
                                fontSize: 9.5,
                                fontWeight: FontWeight.w800,
                                fontFamily: kFont,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 14),

                // Grid 2x2 Detail Device
                Row(
                  children: [
                    Expanded(
                      child: _buildSystemSpecTile(
                        icon: Icons.smartphone_rounded,
                        accentColor: const Color(0xFF00E5A0),
                        title: 'DEVICE MODEL',
                        value: _deviceModel,
                        subValue: _osVersion,
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: _buildSystemSpecTile(
                        icon: batteryIcon,
                        accentColor: batteryColor,
                        title: 'BATTERY STATUS',
                        value: '$_batteryLevel%',
                        subValue: _batteryStatus,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Expanded(
                      child: _buildSystemSpecTile(
                        icon: _isUsingWifi
                            ? Icons.wifi_rounded
                            : Icons.signal_cellular_alt_rounded,
                        accentColor: wifiColor,
                        title: 'CONNECTION',
                        value: _isUsingWifi ? 'Wi-Fi Active' : _networkType,
                        subValue: _isUsingWifi
                            ? 'Using WiFi Network'
                            : 'Non-WiFi / Cellular',
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: _buildSystemSpecTile(
                        icon: Icons.lan_rounded,
                        accentColor: const Color(0xFFFBBF24),
                        title: 'LOCAL IP & NODE',
                        value: _localIp,
                        subValue: 'Ping: Connected',
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildSystemSpecTile({
    required IconData icon,
    required Color accentColor,
    required String title,
    required String value,
    required String subValue,
  }) {
    return Container(
      padding: const EdgeInsets.all(11),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.32),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: accentColor.withOpacity(0.22),
          width: 1,
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 34,
            height: 34,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              color: accentColor.withOpacity(0.14),
              border: Border.all(color: accentColor.withOpacity(0.35)),
            ),
            child: Icon(icon, color: accentColor, size: 17),
          ),
          const SizedBox(width: 9),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    color: Colors.white.withOpacity(0.55),
                    fontSize: 8.5,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 0.6,
                    fontFamily: kFont,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 2),
                Text(
                  value,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 11.5,
                    fontWeight: FontWeight.w900,
                    fontFamily: kFont,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 1),
                Text(
                  subValue,
                  style: TextStyle(
                    color: accentColor.withOpacity(0.85),
                    fontSize: 9,
                    fontWeight: FontWeight.w600,
                    fontFamily: kFont,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLiveFeedCard() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        children: [
          Container(
            height: 220,
            width: double.infinity,
            decoration: BoxDecoration(
              color: Colors.black,
              borderRadius: BorderRadius.circular(AppColors.cardRadius),
              border:
                  Border.all(color: _C.border, width: AppColors.borderWidth),
              boxShadow: _C.softShadow,
            ),
            clipBehavior: Clip.antiAlias,
            child: Stack(
              fit: StackFit.expand,
              children: [
                if (_videoController != null &&
                    _videoController!.value.isInitialized)
                  FittedBox(
                    fit: BoxFit.cover,
                    child: SizedBox(
                      width: _videoController!.value.size.width,
                      height: _videoController!.value.size.height,
                      child: VideoPlayer(_videoController!),
                    ),
                  )
                else
                  Center(
                      child: Icon(Icons.swap_vert_rounded,
                          color: Colors.white.withOpacity(0.8), size: 80)),
                Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        Colors.black.withOpacity(0.5),
                        Colors.transparent
                      ],
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      stops: const [0.0, 0.4],
                    ),
                  ),
                ),
                Positioned(
                  top: 16,
                  left: 16,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 10, vertical: 6),
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.8),
                      borderRadius: BorderRadius.circular(20),
                      border:
                          Border.all(color: Colors.white.withOpacity(0.3)),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                            width: 8,
                            height: 8,
                            decoration: const BoxDecoration(
                                shape: BoxShape.circle, color: Colors.red)),
                        const SizedBox(width: 6),
                        const Text('LIVE FEED',
                            style: TextStyle(
                                color: Colors.white,
                                fontSize: 10,
                                fontWeight: FontWeight.bold,
                                letterSpacing: 1.2)),
                      ],
                    ),
                  ),
                ),
                Positioned(
                  bottom: 20,
                  left: 16,
                  child: Text('NOVARCH',
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                          fontWeight: FontWeight.w900,
                          fontFamily: kFont,
                          letterSpacing: 2.0)),
                ),
                Positioned(
                  bottom: 16,
                  left: 0,
                  right: 0,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      _buildDot(isActive: false),
                      const SizedBox(width: 4),
                      _buildDot(isActive: true),
                      const SizedBox(width: 4),
                      _buildDot(isActive: false),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDot({required bool isActive}) {
    return Container(
      width: isActive ? 24 : 8,
      height: 4,
      decoration: BoxDecoration(
        color: isActive ? Colors.white : Colors.white.withOpacity(0.4),
        borderRadius: BorderRadius.circular(2),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  WELCOME & STATS CARD
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildWelcomeCard() {
    const Color primaryTeal = Color(0xFF00E5A0);
    const Color secondaryCyan = Color(0xFF00B4D8);
    const Color emeraldText = Color(0xFF34D399);
    const Color amberAccent = Color(0xFFFBBF24);

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(24),
          boxShadow: const [
            BoxShadow(
              color: Color(0xFF0E0A08),
              offset: Offset(8, 8),
              blurRadius: 18,
            ),
            BoxShadow(
              color: Color(0xFF3C3430),
              offset: Offset(-5, -5),
              blurRadius: 14,
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(24),
          child: Stack(
            children: [
              Positioned.fill(
                child: BackdropFilter(
                  filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
                  child: Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          const Color(0xFF1E2A27).withOpacity(0.8),
                          const Color(0xFF131A18).withOpacity(0.9),
                        ],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(24),
                      border: Border.all(
                        color: Colors.white.withOpacity(0.08),
                        width: 1.5,
                      ),
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Stack(
                          clipBehavior: Clip.none,
                          children: [
                            Container(
                              width: 52,
                              height: 52,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                gradient: const LinearGradient(
                                  colors: [primaryTeal, secondaryCyan],
                                  begin: Alignment.topLeft,
                                  end: Alignment.bottomRight,
                                ),
                                boxShadow: [
                                  BoxShadow(
                                    color: primaryTeal.withOpacity(0.35),
                                    blurRadius: 12,
                                    offset: const Offset(0, 4),
                                  ),
                                ],
                              ),
                              child: Center(
                                child: ClipOval(
                                  child: _profileImage != null
                                      ? Image.file(
                                          _profileImage!,
                                          width: 52,
                                          height: 52,
                                          fit: BoxFit.cover,
                                        )
                                      : Container(
                                          width: 52,
                                          height: 52,
                                          color: const Color(0xFF1A1614),
                                          child: const Icon(
                                            Icons.person_rounded,
                                            color: primaryTeal,
                                            size: 28,
                                          ),
                                        ),
                                ),
                              ),
                            ),
                            Positioned(
                              bottom: 0,
                              right: 0,
                              child: Container(
                                width: 14,
                                height: 14,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: primaryTeal,
                                  border: Border.all(
                                    color: const Color(0xFF1A1614),
                                    width: 2.5,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'WELCOME BACK,',
                                style: TextStyle(
                                  color: const Color(0xFFA39585),
                                  fontSize: 10,
                                  fontWeight: FontWeight.w700,
                                  letterSpacing: 1.2,
                                  fontFamily: kFont,
                                ),
                              ),
                              const SizedBox(height: 2),
                              Text(
                                username,
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 18,
                                  fontWeight: FontWeight.w900,
                                  fontFamily: kFont,
                                ),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ],
                          ),
                        ),
                        Container(
                          width: 36,
                          height: 36,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: const LinearGradient(
                              colors: [Color(0xFF181412), Color(0xFF241D19)],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            border: Border.all(
                              color: amberAccent.withOpacity(0.3),
                              width: 1,
                            ),
                            boxShadow: const [
                              BoxShadow(
                                color: Color(0xFF0E0A08),
                                offset: Offset(2, 2),
                                blurRadius: 5,
                              ),
                            ],
                          ),
                          child: const Center(
                            child: Icon(
                              Icons.timer_outlined,
                              color: amberAccent,
                              size: 16,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 10, vertical: 4),
                          decoration: BoxDecoration(
                            color: primaryTeal.withOpacity(0.15),
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(
                              color: primaryTeal.withOpacity(0.3),
                              width: 1,
                            ),
                          ),
                          child: Text(
                            role.toUpperCase(),
                            style: TextStyle(
                              color: primaryTeal,
                              fontSize: 9.5,
                              fontWeight: FontWeight.w800,
                              letterSpacing: 0.6,
                              fontFamily: kFont,
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 10, vertical: 4),
                          decoration: BoxDecoration(
                            color: const Color(0xFF10B981).withOpacity(0.15),
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(
                              color: const Color(0xFF10B981).withOpacity(0.3),
                              width: 1,
                            ),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              _AnimatedDot(color: emeraldText, size: 5.5),
                              const SizedBox(width: 5),
                              Text(
                                'ONLINE',
                                style: TextStyle(
                                  color: emeraldText,
                                  fontSize: 9.5,
                                  fontWeight: FontWeight.w800,
                                  letterSpacing: 0.6,
                                  fontFamily: kFont,
                                ),
                              ),
                            ],
                          ),
                        ),
                        const Spacer(),
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(
                              Icons.fingerprint_rounded,
                              color: Color(0xFFA39585),
                              size: 14,
                            ),
                            const SizedBox(width: 4),
                            ConstrainedBox(
                              constraints: const BoxConstraints(maxWidth: 90),
                              child: Text(
                                androidId,
                                style: TextStyle(
                                  color: const Color(0xFFA39585),
                                  fontSize: 10,
                                  fontFamily: kFont,
                                ),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                    const SizedBox(height: 18),
                    Row(
                      children: [
                        Expanded(
                          child: _buildClayStatBox(
                            icon: Icons.groups_rounded,
                            value: _statsLoading ? '...' : '$onlineUsers',
                            label: 'Online',
                            accentColor: emeraldText,
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: _buildClayStatBox(
                            icon: Icons.link_rounded,
                            value: _statsLoading ? '...' : '$activeConns',
                            label: 'Active',
                            accentColor: primaryTeal,
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: _buildClayStatBox(
                            icon: Icons.calendar_today_rounded,
                            value: expiredDate.length > 7
                                ? expiredDate.substring(0, 7)
                                : expiredDate,
                            label: 'Expired',
                            accentColor: amberAccent,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildClayStatBox({
    required IconData icon,
    required String value,
    required String label,
    required Color accentColor,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 8),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF181412), Color(0xFF241D19)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: Colors.white.withOpacity(0.05),
          width: 1,
        ),
        boxShadow: const [
          BoxShadow(
            color: Color(0xFF0E0A08),
            offset: Offset(3, 3),
            blurRadius: 6,
          ),
          BoxShadow(
            color: Color(0xFF342C28),
            offset: Offset(-2, -2),
            blurRadius: 5,
          ),
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 34,
            height: 34,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: accentColor.withOpacity(0.15),
              border: Border.all(
                color: accentColor.withOpacity(0.3),
                width: 1,
              ),
            ),
            child: Center(
              child: Icon(icon, color: accentColor, size: 16),
            ),
          ),
          const SizedBox(height: 10),
          Text(
            value,
            style: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.w900,
              fontSize: 13,
              fontFamily: kFont,
            ),
            textAlign: TextAlign.center,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
          const SizedBox(height: 2),
          Text(
            label,
            style: TextStyle(
              color: const Color(0xFFA39585),
              fontSize: 10,
              fontFamily: kFont,
            ),
            textAlign: TextAlign.center,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    );
  }

  Widget _buildGlobalChatCard() {
    final isComic = ThemeModeManager.isComic3d;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: GestureDetector(
        onTap: _openGlobalChat,
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            gradient: isComic ? null : _C.glassGrad,
            color: isComic ? AppColors.card : null,
            borderRadius: BorderRadius.circular(AppColors.cardRadius),
            border: Border.all(
                color: isComic ? AppColors.border : _C.glassBorder,
                width: AppColors.borderWidth),
            boxShadow: _C.glassShadow,
          ),
          child: Row(
            children: [
              Container(
                width: 52,
                height: 52,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                      colors: [
                        _C.primary.withOpacity(0.30),
                        _C.primary.withOpacity(0.05)
                      ],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight),
                  border: Border.all(
                      color: _C.primary.withOpacity(0.4), width: 2),
                  boxShadow: isComic
                      ? null
                      : [
                          BoxShadow(
                              color: _C.primary.withOpacity(0.3),
                              blurRadius: 14,
                              spreadRadius: 1),
                        ],
                ),
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    Icon(Icons.public_rounded,
                        color: _C.primary, size: 26),
                    Positioned(
                      top: 8,
                      right: 8,
                      child: AnimatedBuilder(
                        animation: _pulseCtrl,
                        builder: (_, __) => Container(
                          width: 10,
                          height: 10,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: _C.red,
                            border: Border.all(
                                color: isComic ? AppColors.card : _C.bg,
                                width: 2),
                            boxShadow: [
                              BoxShadow(
                                  color: _C.red.withOpacity(
                                      0.4 + 0.4 * _pulseCtrl.value),
                                  blurRadius: 6 + 4 * _pulseCtrl.value),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Text('Global Chat',
                            style: TextStyle(
                                color: _C.text,
                                fontSize: 14,
                                fontWeight: FontWeight.w700,
                                fontFamily: kFont)),
                        const SizedBox(width: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 6, vertical: 1),
                          decoration: BoxDecoration(
                              color: _C.green.withOpacity(0.15),
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(
                                  color: _C.green.withOpacity(0.4),
                                  width: 1)),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              AnimatedBuilder(
                                animation: _pulseCtrl,
                                builder: (_, __) => Container(
                                    width: 5,
                                    height: 5,
                                    decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        color: _C.green.withOpacity(
                                            0.5 + 0.5 * _pulseCtrl.value))),
                              ),
                              const SizedBox(width: 4),
                              Text('LIVE',
                                  style: TextStyle(
                                      color: _C.green,
                                      fontFamily: kFont,
                                      fontSize: 8,
                                      fontWeight: FontWeight.bold,
                                      letterSpacing: 0.5)),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(lastChatPreview,
                        style: TextStyle(
                            color: _C.textSub,
                            fontSize: 11,
                            fontFamily: kFont),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis),
                  ],
                ),
              ),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                    color: _C.primary.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                        color: _C.primary.withOpacity(0.3), width: 1)),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.people_alt_rounded,
                        color: _C.primary, size: 11),
                    const SizedBox(width: 3),
                    Text('$globalChatCount',
                        style: TextStyle(
                            color: _C.primary,
                            fontFamily: kFont,
                            fontSize: 10,
                            fontWeight: FontWeight.bold)),
                  ],
                ),
              ),
              const SizedBox(width: 6),
              Icon(Icons.arrow_forward_ios_rounded,
                  color: _C.textDim, size: 14),
            ],
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  QUICK ACTIONS (Grid & Slide)
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildQuickActions() {
    final actions = [
      _QuickActionData(
        icon: FontAwesomeIcons.whatsapp,
        bgIcon: FontAwesomeIcons.whatsapp,
        title: 'Manage Sender',
        subtitle: 'Manage active sender',
        gradient: [const Color(0xFFDB2777), const Color(0xFF881337)],
        badge: 'SENDER',
        onTap: () {
          _hapticLight();
          Navigator.push(
            context,
            _slideRoute(BugSenderPage(
                sessionKey: sessionKey, username: username, role: role)),
          );
        },
      ),
      _QuickActionData(
        icon: FontAwesomeIcons.crown,
        bgIcon: FontAwesomeIcons.crown,
        title: 'Up Role Akun',
        subtitle: 'Upgrade Role Otomatis',
        gradient: [const Color(0xFFD97706), const Color(0xFF7C2D12)],
        badge: 'UPROLE',
        onTap: () {
          _hapticLight();
          Navigator.push(
              context,
              _slideRoute(UpRolePage(
                  sessionKey: sessionKey,
                  username: username,
                  currentRole: role)));
        },
      ),
      _QuickActionData(
        icon: Icons.shield_rounded,
        bgIcon: Icons.shield_rounded,
        title: 'Wa Ban Check',
        subtitle: 'Check Wa Banned',
        gradient: [const Color(0xFF9333EA), const Color(0xFF312E81)],
        badge: 'CHECKER',
        onTap: () {
          _hapticLight();
          Navigator.push(
            context,
            _slideRoute(WaBanCheckPage(sessionKey: sessionKey)),
          );
        },
      ),
      _QuickActionData(
        icon: FontAwesomeIcons.robot,
        bgIcon: FontAwesomeIcons.robot,
        title: 'Asistent AI',
        subtitle: 'Robot Asistent AI',
        gradient: [const Color(0xFFEF4444), const Color(0xFF991B1B)],
        badge: 'ASISTENT',
        onTap: () {
          _hapticLight();
          Navigator.push(
            context,
            _slideRoute(AIPage(
              sessionKey: sessionKey,
              username: username,
              role: role,
            )),
          );
        },
      ),
      _QuickActionData(
        icon: FontAwesomeIcons.clockRotateLeft,
        bgIcon: FontAwesomeIcons.clockRotateLeft,
        title: 'Riwayat Akun',
        subtitle: 'Riwayat Aktivitas Akunmu',
        gradient: [const Color(0xFF3B82F6), const Color(0xFF1E3A8A)],
        badge: 'RIWAYAT',
        onTap: () {
          _hapticLight();
          Navigator.push(
            context,
            _slideRoute(RiwayatPage(
              sessionKey: sessionKey,
              role: role,
            )),
          );
        },
      ),
      _QuickActionData(
        icon: FontAwesomeIcons.bookQuran,
        bgIcon: FontAwesomeIcons.bookQuran,
        title: 'Al Quran',
        subtitle: 'Baca Al-Quran',
        gradient: [const Color(0xFF0D9488), const Color(0xFF064E3B)],
        badge: 'QURAN',
        onTap: () {
          _hapticLight();
          Navigator.push(context, _slideRoute(const AlQuranPage()));
        },
      ),
      _QuickActionData(
        icon: FontAwesomeIcons.telegram,
        bgIcon: FontAwesomeIcons.telegram,
        title: 'Novarch Channel',
        subtitle: 'Novarch Info Channel',
        gradient: [const Color(0xFF0284C7), const Color(0xFF1E3A8A)],
        badge: 'CHANNEL',
        onTap: () => _openUrl('https://t.me/NovarchTeams'),
      ),
    ];

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 18),
          child: Row(
            children: [
              _AnimatedDot(color: const Color(0xFFFBBF24), size: 7),
              const SizedBox(width: 8),
              Text(
                'QUICK ACTIONS',
                style: TextStyle(
                  color: const Color(0xFFFBBF24),
                  fontWeight: FontWeight.w900,
                  fontSize: 12,
                  fontFamily: kFont,
                  letterSpacing: 1.0,
                ),
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.all(3),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFF181412), Color(0xFF241D19)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: Colors.white.withOpacity(0.06),
                    width: 1,
                  ),
                  boxShadow: const [
                    BoxShadow(
                      color: Color(0xFF0E0A08),
                      offset: Offset(2, 2),
                      blurRadius: 5,
                    ),
                    BoxShadow(
                      color: Color(0xFF342C28),
                      offset: Offset(-1.5, -1.5),
                      blurRadius: 4,
                    ),
                  ],
                ),
                child: Row(
                  children: [
                    _buildToggleBtn(
                      label: 'GRID',
                      isActive: _isGridView,
                      onTap: () => setState(() => _isGridView = true),
                    ),
                    const SizedBox(width: 2),
                    _buildToggleBtn(
                      label: 'SLIDE',
                      isActive: !_isGridView,
                      onTap: () => setState(() => _isGridView = false),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        if (_isGridView)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
                childAspectRatio: 1.32,
              ),
              itemCount: actions.length,
              itemBuilder: (context, index) {
                return _QuickActionGridCard(action: actions[index]);
              },
            ),
          )
        else
          SizedBox(
            height: 150,
            child: _InfiniteCarousel(
              itemCount: actions.length,
              height: 150,
              viewportFraction: 0.78,
              autoPlay: true,
              onPageChanged: (i) {
                if (mounted) setState(() => _currentQaPage = i.toDouble());
              },
              builder: (context, index) {
                return Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 6),
                  child: _QuickActionSliderCard(action: actions[index]),
                );
              },
            ),
          ),
        if (!_isGridView) ...[
          const SizedBox(height: 6),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(actions.length, (index) {
              final bool isActive =
                  _currentQaPage.round() % actions.length == index;
              return AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                margin: const EdgeInsets.symmetric(horizontal: 4),
                width: isActive ? 24 : 8,
                height: 8,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(4),
                  color: isActive ? const Color(0xFFFBBF24) : Colors.white24,
                ),
              );
            }),
          ),
        ],
      ],
    );
  }

  Widget _buildToggleBtn({
    required String label,
    required bool isActive,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: () {
        _hapticLight();
        onTap();
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        decoration: BoxDecoration(
          color: isActive ? const Color(0xFFFBBF24) : Colors.transparent,
          borderRadius: BorderRadius.circular(9),
        ),
        child: Text(
          label,
          style: TextStyle(
            color: isActive ? Colors.black : const Color(0xFFA39585),
            fontSize: 9.5,
            fontWeight: FontWeight.w800,
            fontFamily: kFont,
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  NOVARCH CREW (Glassmorphism Blur)
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildMantaCoreCrew() {
    final members = <_CrewMember>[
      const _CrewMember(
        role: 'Donaturs',
        name: '@Princeizz25',
        icon: Icons.code_rounded,
        color: Color(0xFFE91E8C),
        badge: 'DONATUR OF NOVARCH',
      ),
      const _CrewMember(
        role: 'Main Developer',
        name: '@Maklohdngo',
        icon: Icons.workspace_premium_rounded,
        color: Color(0xFFFFD54F),
        badge: 'LEADER',
      ),
      const _CrewMember(
        role: 'Channels',
        name: '@NovarchTeams',
        icon: Icons.play_circle_fill_rounded,
        color: Color(0xFFFF4081),
        badge: 'CHANNELS INFORMATION',
      ),
    ];

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(AppColors.cardRadius),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
          child: Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.04),
              gradient: LinearGradient(
                colors: [
                  Colors.white.withOpacity(0.08),
                  Colors.white.withOpacity(0.02),
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(AppColors.cardRadius),
              border: Border.all(
                color: Colors.white.withOpacity(0.15),
                width: 1.5,
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 12, vertical: 8),
                  decoration: BoxDecoration(
                    color: const Color(0xFF7C4DFF).withOpacity(0.2),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                        color: const Color(0xFF7C4DFF).withOpacity(0.4)),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.groups_rounded,
                          color: Color(0xFFD1C4E9), size: 16),
                      const SizedBox(width: 8),
                      Text(
                        'NOVARCH TEAMS',
                        style: TextStyle(
                          color: const Color(0xFFD1C4E9),
                          fontWeight: FontWeight.bold,
                          fontSize: 12,
                          fontFamily: kFont,
                          letterSpacing: 1.0,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                Row(
                  children: members.map((member) {
                    return Expanded(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 4),
                        child: _buildCrewCard(
                          role: member.role,
                          name: member.name,
                          icon: member.icon,
                          color: member.color,
                          badge: member.badge,
                        ),
                      ),
                    );
                  }).toList(),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildCrewCard({
    required String role,
    required String name,
    required IconData icon,
    required Color color,
    required String badge,
  }) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.3),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white.withOpacity(0.1), width: 1),
      ),
      child: Column(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: color.withOpacity(0.2),
              border: Border.all(color: color, width: 1.5),
            ),
            child: Icon(icon, color: color, size: 20),
          ),
          const SizedBox(height: 8),
          Text(
            role,
            style: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontSize: 12,
              fontFamily: kFont,
            ),
            textAlign: TextAlign.center,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
          const SizedBox(height: 2),
          Text(
            name,
            style: TextStyle(
              color: Colors.white.withOpacity(0.6),
              fontSize: 9,
              fontFamily: kFont,
            ),
            textAlign: TextAlign.center,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
            decoration: BoxDecoration(
              color: color.withOpacity(0.15),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: color.withOpacity(0.5), width: 1),
            ),
            child: Text(
              badge,
              style: TextStyle(
                color: color,
                fontSize: 8,
                fontWeight: FontWeight.bold,
                fontFamily: kFont,
                letterSpacing: 0.5,
              ),
              textAlign: TextAlign.center,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBreakbeatButton() {
    final isPlaying = _audioManager.isPlaying;
    return GestureDetector(
      onTap: () {
        _hapticMedium();
        _audioManager.togglePlay();
      },
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 4),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(
          color: _C.card,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
              color: _C.primary.withOpacity(0.35), width: 1.2),
          boxShadow: [
            BoxShadow(
                color: _C.primary.withOpacity(0.08), blurRadius: 10)
          ],
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 22,
              height: 22,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: _C.btnGrad,
                boxShadow: [
                  BoxShadow(
                    color: _C.primary.withOpacity(0.45),
                    blurRadius: 8,
                    spreadRadius: 1,
                  ),
                ],
              ),
              child: Icon(
                Icons.music_note_rounded,
                color: _onAccent(),
                size: 13,
              ),
            ),
            const SizedBox(width: 7),
            Text('Breakbeat Dream',
                style: TextStyle(
                    color: _C.text,
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                    fontFamily: kFont)),
            const SizedBox(width: 8),
            Row(
              mainAxisSize: MainAxisSize.min,
              children: List.generate(
                3,
                (i) => AnimatedContainer(
                  duration: const Duration(milliseconds: 300),
                  margin: const EdgeInsets.symmetric(horizontal: 1),
                  width: 2,
                  height: isPlaying ? (i == 1 ? 12.0 : 7.0) : 4.0,
                  decoration: BoxDecoration(
                      color: _C.primary,
                      borderRadius: BorderRadius.circular(1)),
                ),
              ),
            ),
            const SizedBox(width: 6),
            Icon(
                isPlaying
                    ? Icons.pause_rounded
                    : Icons.play_arrow_rounded,
                color: _C.text,
                size: 16),
          ],
        ),
      ),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: Colors.transparent,
      elevation: 0,
      titleSpacing: 0,
      leading: Builder(
        builder: (ctx) => _MenuBtn(onTap: () {
          _hapticLight();
          Scaffold.of(ctx).openDrawer();
        }),
      ),
      title: const SizedBox.shrink(),
      actions: [
        _buildBreakbeatButton(),
        _AppBarIcon(icon: Icons.palette_rounded, onTap: _showThemePicker),
        _AppBarIcon(
            icon: Icons.headset_mic_outlined,
            onTap: () {
              _hapticLight();
              Navigator.push(
                  context, _slideRoute(const ContactPage()));
            }),
        _AppBarIcon(
            icon: Icons.account_circle_outlined,
            onTap: () {
              _navigate(ProfilePage(
                  username: username,
                  password: password,
                  role: role,
                  expiredDate: expiredDate,
                  sessionKey: sessionKey,
                  uid: uid));
            }),
        const SizedBox(width: 8),
      ],
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  LIQUID GLASS DRAWER (ringan, border gelembung sabun)
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildDrawer() {
    final isComic = ThemeModeManager.isComic3d;
    final roleLower = role.toLowerCase().trim();
    final gbRole = _toGbRole(role);
    final rColor = _roleColor(role);

    final developerMenus = <Widget>[];
    if (roleLower == 'developer') {
      developerMenus.addAll([
        const SizedBox(height: 14),
        _DrawerSectionTitle(label: 'DEVELOPER ACCESS', color: _C.gold),
        _DrawerItem(
            icon: Icons.military_tech_rounded,
            iconColor: _C.gold,
            label: 'Naikkan Role',
            onTap: () =>
                _openDrawerPage(RoleUpgradePage(sessionKey: sessionKey))),
        _DrawerItem(
            icon: Icons.code_rounded,
            iconColor: _C.gold,
            label: 'Hacker Acces',
            onTap: () => _openDrawerPage(DeveloperPage(
                sessionKey: sessionKey, username: username))),
        _DrawerItem(
            icon: Icons.workspace_premium_rounded,
            iconColor: _C.gold,
            label: 'Owner Acces',
            onTap: () => _openDrawerPage(OwnerPage(
                sessionKey: sessionKey, username: username))),
        _DrawerItem(
            icon: Icons.storefront_rounded,
            iconColor: _C.gold,
            label: 'Seller Acces',
            onTap: () =>
                _openDrawerPage(SellerPage(keyToken: sessionKey))),
        _DrawerItem(
            icon: Icons.shopping_bag_rounded,
            iconColor: _C.pink,
            label: 'Buyer Management',
            trailing: const _SoonBadge(),
            onTap: _showComingSoonAfterClose),
      ]);
    }

    final akunMenus = <Widget>[
      const SizedBox(height: 14),
      const _DrawerSectionTitle(label: 'AKUN & PERAN'),
      _DrawerItem(
          icon: Icons.person_rounded,
          label: 'Profil Saya',
          onTap: () => _openDrawerPage(ProfilePage(
              username: username,
              password: password,
              role: role,
              expiredDate: expiredDate,
              sessionKey: sessionKey,
              uid: uid))),
      _DrawerItem(
          icon: Icons.lock_reset_rounded,
          label: 'Ganti Password',
          onTap: () => _openDrawerPage(ChangePasswordPage(
              username: username, sessionKey: sessionKey))),
      _DrawerItem(
          icon: Icons.link_rounded,
          label: 'Ambil Link GB',
          onTap: () => _openDrawerPage(AmbilLinkGBPage(
              sessionKey: sessionKey,
              username: username,
              role: gbRole))),
      _DrawerItem(
          icon: Icons.upgrade_rounded,
          label: 'Up Role',
          onTap: () => _openDrawerPage(UpRolePage(
              sessionKey: sessionKey,
              username: username,
              currentRole: role))),
    ];

    final bisnisMenus = <Widget>[];
    if (roleLower == 'reseller' ||
        roleLower == 'owner' ||
        roleLower == 'developer') {
      bisnisMenus.addAll([
        const SizedBox(height: 14),
        _DrawerSectionTitle(label: 'BISNIS', color: _C.teal),
      ]);

      if (roleLower == 'reseller') {
        bisnisMenus.add(_DrawerItem(
            icon: Icons.storefront_rounded,
            iconColor: _C.teal,
            label: 'Akses Jualan',
            onTap: () =>
                _openDrawerPage(SellerPage(keyToken: sessionKey))));
      }
      if (roleLower == 'owner') {
        bisnisMenus.add(_DrawerItem(
            icon: Icons.workspace_premium_rounded,
            iconColor: _C.teal,
            label: 'Akses Jualan',
            onTap: () => _openDrawerPage(
                OwnerPage(sessionKey: sessionKey, username: username))));
      }
      if (roleLower == 'developer') {
        bisnisMenus.add(_DrawerItem(
            icon: Icons.code_rounded,
            iconColor: _C.teal,
            label: 'Hacker Acces',
            onTap: () => _openDrawerPage(DeveloperPage(
                sessionKey: sessionKey, username: username))));
      }
      bisnisMenus.add(_DrawerItem(
          icon: Icons.shopping_bag_rounded,
          iconColor: _C.pink,
          label: 'Buyer Management',
          trailing: const _SoonBadge(),
          onTap: _showComingSoonAfterClose));
    }

    final aktivitasMenus = <Widget>[
      const SizedBox(height: 14),
      const _DrawerSectionTitle(label: 'AKTIVITAS'),
      _DrawerItem(
          icon: Icons.history_rounded,
          label: 'Riwayat Aktivitas',
          onTap: () => _openDrawerPage(
              RiwayatPage(sessionKey: sessionKey, role: role))),
      _DrawerItem(
        icon: Icons.logout_rounded,
        label: 'Keluar',
        isDestructive: true,
        trailing:
            Icon(Icons.power_settings_new_rounded, color: _C.red, size: 18),
        onTap: () async {
          _hapticMedium();
          Navigator.pop(context);
          try {
            await _audioManager.stop();
          } catch (_) {}
          final prefs = await SharedPreferences.getInstance();
          await prefs.clear();
          if (!mounted) return;
          Navigator.of(context).pushAndRemoveUntil(
              MaterialPageRoute(builder: (_) => const LoginPage()),
              (_) => false);
        },
      ),
    ];

    const double kGlassR = 28.0;
    final media = MediaQuery.of(context);
    final br = BorderRadius.circular(isComic ? 8 : kGlassR);

    return Drawer(
      backgroundColor: Colors.transparent,
      elevation: 0,
      shadowColor: Colors.transparent,
      surfaceTintColor: Colors.transparent,
      width: media.size.width * 0.82,
      child: Padding(
        padding: EdgeInsets.fromLTRB(
            10, media.padding.top + 8, 8, media.padding.bottom + 10),
        child: DecoratedBox(
          // satu shadow saja (sebelumnya dua shadow blur besar)
          decoration: BoxDecoration(
            borderRadius: br,
            boxShadow: isComic
                ? _C.glassShadow
                : [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.40),
                      blurRadius: 18,
                      offset: const Offset(4, 6),
                    ),
                  ],
          ),
          child: ClipRRect(
            borderRadius: br,
            child: BackdropFilter(
              // blur diturunkan 30 -> 12 supaya GPU jauh lebih ringan
              filter: ImageFilter.blur(
                sigmaX: isComic ? 0 : 12,
                sigmaY: isComic ? 0 : 12,
              ),
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: br,
                  gradient: isComic
                      ? null
                      : const LinearGradient(
                          colors: [
                            Color(0x33FFFFFF),
                            Color(0x6B1A2530),
                            Color(0xA00A0F14),
                          ],
                          stops: [0.0, 0.45, 1.0],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                  color: isComic ? AppColors.card : null,
                  border: isComic
                      ? Border.all(color: _C.border, width: 3.0)
                      : null,
                ),
                child: Stack(
                  children: [
                    ListView(
                      physics: const ClampingScrollPhysics(),
                      padding: const EdgeInsets.fromLTRB(14, 18, 14, 24),
                      children: [
                        _DrawerHeader(
                            username: username,
                            role: role,
                            expiredDate: expiredDate),
                        ...developerMenus,
                        ...akunMenus,
                        ...bisnisMenus,
                        ...aktivitasMenus,
                      ],
                    ),
                    // Border gelembung sabun (hanya garis tepi)
                    if (!isComic)
                      Positioned.fill(
                        child: IgnorePointer(
                          child: RepaintBoundary(
                            child: CustomPaint(
                              painter: _SoapBubbleBorderPainter(
                                accentColor: rColor,
                                radius: kGlassR,
                              ),
                            ),
                          ),
                        ),
                      ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    final isComic = ThemeModeManager.isComic3d;
    final isMonochrome = _isMonochromeTheme;

    return Scaffold(
      backgroundColor: isMonochrome ? Colors.white : _C.bg,
      extendBody: true,
      appBar: _buildAppBar(),
      drawer: _buildDrawer(),
      body: Stack(
        children: [
          // ─── BACKGROUND IMAGE (Dark/Normal vs Light Blue Clean) ───
          if (!isMonochrome) ...[
            Positioned.fill(
              child: Image.asset(
                'assets/images/back_dash.jpg',
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => Container(color: _C.bg),
              ),
            ),
            Positioned.fill(
              child: Container(
                color: Colors.black.withOpacity(0.65),
              ),
            ),
          ],
          if (isMonochrome) ...[
            Positioned.fill(
              child: Image.asset(
                'assets/images/white_dash.jpg',
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) =>
                    const ColoredBox(color: Colors.white),
              ),
            ),
          ],

          FadeTransition(
            opacity: _pageFade,
            child: SlideTransition(
              position: _pageSlide,
              child: _safeBuild(() => _buildCurrentPage()),
            ),
          ),

          if (!isMonochrome)
            IgnorePointer(
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      _C.primary.withOpacity(0.05),
                      Colors.transparent,
                      Colors.black.withOpacity(isComic ? 0.0 : 0.4),
                    ],
                    stops: const [0.0, 0.4, 1.0],
                  ),
                ),
              ),
            ),
        ],
      ),
      bottomNavigationBar: _safeBuild(
        () => SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.only(bottom: 12, left: 16, right: 16),
            child: _CustomNavBar(
              items: const <Widget>[
                Icon(Icons.home_rounded, size: 26),
                Icon(FontAwesomeIcons.whatsapp, size: 24),
                Icon(Icons.apps_rounded, size: 26),
                Icon(Icons.info_rounded, size: 26),
                Icon(Icons.construction_rounded, size: 26),
              ],
              currentIndex: _bottomNavIndex,
              onTap: _onBottomNavTapped,
            ),
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════
//  WIDGET PENDUKUNG
// ═══════════════════════════════════════════════════════════════════════

class _QuickActionData {
  final IconData icon;
  final IconData bgIcon;
  final String title;
  final String subtitle;
  final List<Color> gradient;
  final String badge;
  final VoidCallback onTap;

  _QuickActionData({
    required this.icon,
    required this.bgIcon,
    required this.title,
    required this.subtitle,
    required this.gradient,
    required this.badge,
    required this.onTap,
  });
}

class _CrewMember {
  final String role;
  final String name;
  final IconData icon;
  final Color color;
  final String badge;

  const _CrewMember({
    required this.role,
    required this.name,
    required this.icon,
    required this.color,
    required this.badge,
  });
}

class _QuickActionSliderCard extends StatelessWidget {
  final _QuickActionData action;
  const _QuickActionSliderCard({required this.action});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: action.onTap,
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          gradient: LinearGradient(
              colors: action.gradient,
              begin: Alignment.topLeft,
              end: Alignment.bottomRight),
          border: Border.all(color: Colors.white.withOpacity(0.14), width: 1),
          boxShadow: [
            BoxShadow(
                color: action.gradient.first.withOpacity(0.35),
                blurRadius: 12,
                offset: const Offset(0, 5))
          ],
        ),
        child: Stack(
          children: [
            Positioned(
              right: -12,
              bottom: -12,
              child: Icon(action.bgIcon,
                  color: Colors.white.withOpacity(0.08), size: 92),
            ),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                        width: 40,
                        height: 40,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            color: Colors.white.withOpacity(0.22)),
                        child:
                            Icon(action.icon, color: Colors.white, size: 20),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 9, vertical: 3),
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(8),
                            color: Colors.black.withOpacity(0.4),
                            border: Border.all(
                                color: Colors.white.withOpacity(0.2))),
                        child: Text(action.badge,
                            style: const TextStyle(
                                color: Colors.white,
                                fontSize: 10,
                                fontWeight: FontWeight.bold,
                                fontFamily: kFont)),
                      ),
                    ],
                  ),
                  const Spacer(),
                  Align(
                    alignment: Alignment.topRight,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(8),
                          color: Colors.white.withOpacity(0.22)),
                      child: const Text('Tap →',
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 11,
                              fontWeight: FontWeight.bold,
                              fontFamily: kFont)),
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(action.title,
                      style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                          fontFamily: kFont),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis),
                  const SizedBox(height: 4),
                  Text(action.subtitle,
                      style: TextStyle(
                          color: Colors.white.withOpacity(0.8),
                          fontSize: 12,
                          fontFamily: kFont),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════
//  QUICK ACTION GRID CARD (Claymorphic Gradient Style)
// ═══════════════════════════════════════════════════════════════════════
class _QuickActionGridCard extends StatelessWidget {
  final _QuickActionData action;
  const _QuickActionGridCard({required this.action});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: action.onTap,
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(18),
          gradient: LinearGradient(
            colors: action.gradient,
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          border: Border.all(
            color: Colors.white.withOpacity(0.12),
            width: 1,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.45),
              blurRadius: 12,
              offset: const Offset(0, 6),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  width: 34,
                  height: 34,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(11),
                    color: Colors.black.withOpacity(0.28),
                  ),
                  child: Center(
                    child: Icon(
                      action.icon,
                      color: Colors.white,
                      size: 16,
                    ),
                  ),
                ),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 3.5),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(6),
                    color: Colors.black.withOpacity(0.38),
                  ),
                  child: Text(
                    action.badge,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 8.5,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 0.4,
                      fontFamily: kFont,
                    ),
                  ),
                ),
              ],
            ),
            const Spacer(),
            Text(
              action.title,
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w900,
                fontSize: 13.5,
                fontFamily: kFont,
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            const SizedBox(height: 2),
            Text(
              action.subtitle,
              style: TextStyle(
                color: Colors.white.withOpacity(0.75),
                fontSize: 10,
                fontFamily: kFont,
                fontWeight: FontWeight.w500,
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }
}

class _InfiniteCarouselState extends State<_InfiniteCarousel> {
  late PageController _controller;
  int _currentPage = 1000;
  late int _realIndex;
  Timer? _autoTimer;

  @override
  void initState() {
    super.initState();
    _controller = PageController(
        initialPage: _currentPage,
        viewportFraction: widget.viewportFraction);
    _realIndex = _currentPage % widget.itemCount;
    if (widget.autoPlay) _startAutoPlay();
  }

  void _startAutoPlay() {
    _autoTimer?.cancel();
    _autoTimer = Timer.periodic(const Duration(seconds: 3), (_) {
      if (mounted && _controller.hasClients) {
        _controller.nextPage(
            duration: const Duration(milliseconds: 600),
            curve: Curves.easeInOut);
      }
    });
  }

  @override
  void dispose() {
    _autoTimer?.cancel();
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: widget.height,
      child: NotificationListener<ScrollNotification>(
        onNotification: (notification) {
          if (notification is ScrollUpdateNotification) {
            final page = _controller.page?.round() ?? 0;
            final newIndex = page % widget.itemCount;
            if (newIndex != _realIndex) {
              _realIndex = newIndex;
              widget.onPageChanged?.call(_realIndex);
            }
          }
          return false;
        },
        child: PageView.builder(
          controller: _controller,
          clipBehavior: Clip.none,
          physics: const BouncingScrollPhysics(),
          onPageChanged: (page) {
            final newIndex = page % widget.itemCount;
            if (newIndex != _realIndex) {
              _realIndex = newIndex;
              widget.onPageChanged?.call(_realIndex);
            }
          },
          itemBuilder: (context, index) {
            final realIndex = index % widget.itemCount;
            final child = widget.builder(context, realIndex);
            return AnimatedBuilder(
              animation: _controller,
              child: child,
              builder: (context, child) {
                double page = _currentPage.toDouble();
                if (_controller.hasClients &&
                    _controller.position.haveDimensions) {
                  page = _controller.page ?? page;
                }
                // jarak halaman ini dari posisi tengah (-1..1)
                final double delta = (index - page).clamp(-1.0, 1.0).toDouble();
                final abs = delta.abs();
                final scale = 1.0 - (abs * 0.10);
                final opacity = 1.0 - (abs * 0.45);
                return Opacity(
                  opacity: opacity,
                  child: Transform(
                    alignment: Alignment.center,
                    transform: Matrix4.identity()
                      ..setEntry(3, 2, 0.0012)
                      ..rotateY(delta * -0.38)
                      ..scale(scale, scale),
                    child: child,
                  ),
                );
              },
            );
          },
        ),
      ),
    );
  }
}

class _InfiniteCarousel extends StatefulWidget {
  final int itemCount;
  final double height;
  final double viewportFraction;
  final bool autoPlay;
  final void Function(int)? onPageChanged;
  final Widget Function(BuildContext, int) builder;

  const _InfiniteCarousel({
    Key? key,
    required this.itemCount,
    required this.height,
    this.viewportFraction = 0.85,
    this.autoPlay = false,
    this.onPageChanged,
    required this.builder,
  }) : super(key: key);

  @override
  State<_InfiniteCarousel> createState() => _InfiniteCarouselState();
}

class _DrawerHeader extends StatelessWidget {
  final String username;
  final String role;
  final String expiredDate;

  const _DrawerHeader(
      {required this.username,
      required this.role,
      required this.expiredDate});

  @override
  Widget build(BuildContext context) {
    final rColor = _roleColor(role);
    final isComic = ThemeModeManager.isComic3d;
    return Container(
      margin: const EdgeInsets.only(bottom: 4),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: isComic ? AppColors.card : Colors.white.withOpacity(0.08),
        borderRadius: BorderRadius.circular(isComic ? 6 : 18),
        border: Border.all(
            color: isComic
                ? rColor.withOpacity(0.35)
                : Colors.white.withOpacity(0.22),
            width: isComic ? 3.0 : 1.0),
      ),
      child: Row(
        children: [
          Container(
            width: 56,
            height: 56,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: rColor, width: isComic ? 3 : 2),
            ),
            child: ClipOval(
                child: Container(
                    color: _C.surface,
                    child: Icon(Icons.person_rounded,
                        size: 30, color: _C.white))),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(username,
                    style: TextStyle(
                        color: _C.white,
                        fontSize: 16,
                        fontWeight: FontWeight.w800,
                        fontFamily: kFont),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis),
                const SizedBox(height: 6),
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 3),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                            colors: [
                              rColor,
                              rColor.withOpacity(0.55)
                            ],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight),
                        borderRadius:
                            BorderRadius.circular(isComic ? 3 : 20),
                      ),
                      child: Text(role.toUpperCase(),
                          style: TextStyle(
                              color: _onAccent(),
                              fontSize: 9,
                              fontWeight: FontWeight.w800,
                              letterSpacing: 0.7,
                              fontFamily: kFont)),
                    ),
                    const SizedBox(width: 6),
                    Flexible(
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 3),
                        decoration: BoxDecoration(
                          color: _C.red.withOpacity(0.14),
                          borderRadius:
                              BorderRadius.circular(isComic ? 3 : 20),
                          border: Border.all(
                              color: _C.red.withOpacity(0.38), width: 1),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.calendar_today_rounded,
                                color: _C.red, size: 9),
                            const SizedBox(width: 4),
                            Flexible(
                                child: Text('Exp: $expiredDate',
                                    style: TextStyle(
                                        color: _C.red,
                                        fontSize: 9,
                                        fontWeight: FontWeight.w700,
                                        fontFamily: kFont),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis)),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                Row(
                  children: [
                    _Dot(color: _C.green),
                    const SizedBox(width: 4),
                    _Dot(color: _C.primary),
                    const SizedBox(width: 4),
                    _Dot(color: _C.teal),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _Dot extends StatelessWidget {
  final Color color;
  const _Dot({required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
        width: 4,
        height: 4,
        decoration: BoxDecoration(
            shape: BoxShape.circle, color: color.withOpacity(0.9)));
  }
}

class _DrawerSectionTitle extends StatelessWidget {
  final String label;
  final Color? color;

  const _DrawerSectionTitle({required this.label, this.color});

  @override
  Widget build(BuildContext context) {
    final c = color ?? _C.primary;
    return Padding(
      padding: const EdgeInsets.fromLTRB(4, 8, 4, 8),
      child: Row(
        children: [
          Container(
              width: 16,
              height: 2,
              decoration: BoxDecoration(
                  color: c, borderRadius: BorderRadius.circular(2))),
          const SizedBox(width: 8),
          Text(label,
              style: TextStyle(
                  color: c,
                  fontSize: 11,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.5,
                  fontFamily: kFont)),
        ],
      ),
    );
  }
}

class _SoonBadge extends StatelessWidget {
  const _SoonBadge();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
      decoration: BoxDecoration(
          color: _C.pink.withOpacity(0.12),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: _C.pink.withOpacity(0.35))),
      child: Text('SOON',
          style: TextStyle(
              color: _C.pink,
              fontSize: 8,
              fontWeight: FontWeight.w800,
              letterSpacing: 0.5,
              fontFamily: kFont)),
    );
  }
}

class _DrawerItem extends StatefulWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final bool isDestructive;
  final Color? iconColor;
  final Widget? trailing;

  const _DrawerItem({
    required this.icon,
    required this.label,
    required this.onTap,
    this.isDestructive = false,
    this.iconColor,
    this.trailing,
  });

  @override
  State<_DrawerItem> createState() => _DrawerItemState();
}

class _DrawerItemState extends State<_DrawerItem> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final color =
        widget.isDestructive ? _C.red : (widget.iconColor ?? _C.primary);
    final isComic = ThemeModeManager.isComic3d;
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 100),
        margin: const EdgeInsets.only(bottom: 8),
        padding:
            const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          color: _pressed
              ? color.withOpacity(isComic ? 0.1 : 0.16)
              : (isComic ? AppColors.card : Colors.white.withOpacity(0.06)),
          borderRadius: BorderRadius.circular(isComic ? 4 : 14),
          border: Border.all(
            color: _pressed
                ? color.withOpacity(0.65)
                : (isComic ? _C.border : Colors.white.withOpacity(0.14)),
            width: isComic ? 2.5 : 1.0,
          ),
        ),
        child: Row(
          children: [
            Container(
              width: 34,
              height: 34,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: color.withOpacity(0.14),
                border:
                    Border.all(color: color.withOpacity(0.36), width: 1.1),
              ),
              child: Icon(widget.icon, color: color, size: 17),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(widget.label,
                  style: TextStyle(
                      color: widget.isDestructive ? _C.red : _C.white,
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                      fontFamily: kFont),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis),
            ),
            const SizedBox(width: 8),
            widget.trailing ??
                Icon(Icons.arrow_forward_ios_rounded,
                    color: _C.textDim, size: 12),
          ],
        ),
      ),
    );
  }
}

class _AppBarIcon extends StatefulWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _AppBarIcon({required this.icon, required this.onTap});

  @override
  State<_AppBarIcon> createState() => _AppBarIconState();
}

class _MenuBtn extends StatefulWidget {
  final VoidCallback onTap;
  const _MenuBtn({required this.onTap});

  @override
  State<_MenuBtn> createState() => _MenuBtnState();
}

class _MenuBtnState extends State<_MenuBtn> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(10),
      child: GestureDetector(
        onTapDown: (_) => setState(() => _down = true),
        onTapUp: (_) {
          setState(() => _down = false);
          widget.onTap();
        },
        onTapCancel: () => setState(() => _down = false),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 120),
          decoration: BoxDecoration(
            gradient: _down && !ThemeModeManager.isComic3d
                ? _C.glassGrad
                : null,
            color: _down && ThemeModeManager.isComic3d
                ? AppColors.card2
                : null,
            borderRadius: BorderRadius.circular(
                ThemeModeManager.isComic3d ? 4 : 10),
            border: Border.all(
                color: _down
                    ? _C.primary.withOpacity(0.3)
                    : _C.border,
                width: AppColors.borderWidth),
          ),
          child: Icon(Icons.menu_rounded,
              color: _down ? _C.primary : _C.textDim, size: 20),
        ),
      ),
    );
  }
}

PageRoute _slideRoute(Widget page) => PageRouteBuilder(
      pageBuilder: (_, __, ___) => page,
      transitionDuration: const Duration(milliseconds: 350),
      transitionsBuilder: (_, anim, __, child) => SlideTransition(
        position: Tween<Offset>(
                begin: const Offset(1, 0), end: Offset.zero)
            .animate(CurvedAnimation(
                parent: anim, curve: Curves.easeOutCubic)),
        child: FadeTransition(opacity: anim, child: child),
      ),
    );

class _AppBarIconState extends State<_AppBarIcon> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 8),
      child: GestureDetector(
        onTapDown: (_) => setState(() => _down = true),
        onTapUp: (_) {
          setState(() => _down = false);
          widget.onTap();
        },
        onTapCancel: () => setState(() => _down = false),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 120),
          width: 36,
          height: 36,
          decoration: BoxDecoration(
            gradient: _down && !ThemeModeManager.isComic3d
                ? _C.glassGrad
                : null,
            color: _down && ThemeModeManager.isComic3d
                ? AppColors.card2
                : null,
            borderRadius: BorderRadius.circular(
                ThemeModeManager.isComic3d ? 4 : 10),
            border: Border.all(
                color: _down
                    ? _C.primary.withOpacity(0.3)
                    : _C.border,
                width: AppColors.borderWidth),
          ),
          child: Icon(widget.icon,
              color: _down ? _C.primary : _C.textDim, size: 18),
        ),
      ),
    );
  }
}
