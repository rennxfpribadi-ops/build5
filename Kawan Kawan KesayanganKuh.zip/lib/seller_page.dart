// seller_page.dart
import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';

import 'theme.dart';

const String kFont = 'Pek'; // Pastikan font Anda terdaftar
const String baseUrl = 'http://cp.zyrostore.id:3448';
const String _kBase = baseUrl;

// ─── API HELPERS (listUsers & deleteUsers lewat baseUrl) ─────────────────
class _ListResult {
  final List<Map<String, dynamic>> users;
  final String? meUsername;
  final String? meRole;
  const _ListResult(this.users, {this.meUsername, this.meRole});
}

Map<String, dynamic>? _asMap(dynamic v) =>
    v is Map ? Map<String, dynamic>.from(v) : null;

dynamic _decodeJson(http.Response res) {
  try {
    return jsonDecode(res.body);
  } catch (_) {
    throw Exception('Respon server tidak valid (HTTP ${res.statusCode})');
  }
}

/// GET $baseUrl/reseller/listUsers?key=...
Future<_ListResult> apiListUsers(String key) async {
  final uri = Uri.parse(
    '$baseUrl/listUsers?key=${Uri.encodeQueryComponent(key)}',
  );
  final res = await http.get(uri).timeout(const Duration(seconds: 20));
  final data = _decodeJson(res);

  final root = _asMap(data);
  if (root != null && root['success'] == false) {
    throw Exception(root['message'] ?? 'Gagal memuat daftar user.');
  }

  // Ambil list user dari berbagai kemungkinan bentuk respon
  dynamic rawList = data is List
      ? data
      : (root?['users'] ?? root?['listUsers'] ?? root?['data'] ?? root?['list'] ?? []);
  if (rawList is Map && rawList['users'] != null) rawList = rawList['users'];

  final users = <Map<String, dynamic>>[];
  if (rawList is List) {
    for (final e in rawList) {
      final m = _asMap(e);
      if (m != null) {
        users.add(m);
      } else if (e != null) {
        users.add({'username': e.toString()});
      }
    }
  } else if (rawList is Map) {
    // bentuk { "budi": {...}, "andi": {...} }
    rawList.forEach((k, v) {
      final m = _asMap(v) ?? <String, dynamic>{};
      users.add({'username': k.toString(), ...m});
    });
  }

  // Info akun pemilik session (kalau server menyertakan)
  final me = _asMap(root?['me'] ?? root?['user'] ?? root?['profile'] ?? root?['owner']);
  final meUser = (me?['username'] ?? root?['username'])?.toString();
  final meRole = (me?['role'] ?? root?['role'])?.toString();

  return _ListResult(users, meUsername: meUser, meRole: meRole);
}

/// POST $baseUrl/reseller/deleteUsers  (fallback GET bila server tidak menerima POST)
Future<void> apiDeleteUser(String key, String username) async {
  final uri = Uri.parse('$baseUrl/deleteUsers');
  http.Response res = await http
      .post(uri, body: {'key': key, 'username': username})
      .timeout(const Duration(seconds: 20));

  if (res.statusCode == 404 || res.statusCode == 405) {
    final getUri = Uri.parse(
      '$baseUrl/deleteUsers'
      '?key=${Uri.encodeQueryComponent(key)}'
      '&username=${Uri.encodeQueryComponent(username)}',
    );
    res = await http.get(getUri).timeout(const Duration(seconds: 20));
  }

  final data = _asMap(_decodeJson(res));
  if (data == null || data['success'] != true) {
    throw Exception(data?['message'] ?? 'Gagal menghapus akun');
  }
}

// ─── PALETTE WRAPPER (sekarang mengikuti theme.dart) ─────────────────────
class _C {
  static Color get bg => AppColors.bg;
  static Color get card => AppColors.card;
  static Color get border => AppColors.border;
  static Color get primary => AppColors.accent;
  static Color get primaryDark => AppColors.accentDark;
  static Color get text => AppColors.text;
  static Color get textSub => AppColors.textSub;
  static Color get green => AppColors.green;
  static Color get amber => AppColors.amber;
  static Color get red => AppColors.red;
}

class SellerPage extends StatefulWidget {
  final String keyToken;
  final String? username;
  final String? role;

  const SellerPage({
    super.key,
    required this.keyToken,
    this.username,
    this.role,
  });

  @override
  State<SellerPage> createState() => _SellerPageState();
}

class _SellerPageState extends State<SellerPage> {
  final _usernameCtrl = TextEditingController();
  final _passwordCtrl = TextEditingController();
  final _dayCtrl = TextEditingController(text: '1');
  final ValueNotifier<int> _refreshNotifier = ValueNotifier<int>(0);

  String _selectedType = 'member'; // 'member' atau 'fullup'
  File? _imageFile;
  bool _isLoading = false;
  final ImagePicker _picker = ImagePicker();

  String? _username;
  String? _role;

  @override
  void initState() {
    super.initState();
    _username = widget.username;
    _role = widget.role;
    _loadProfile();
  }

  @override
  void didUpdateWidget(covariant SellerPage oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.username != oldWidget.username && (widget.username ?? '').isNotEmpty) {
      _username = widget.username;
    }
    if (widget.role != oldWidget.role && (widget.role ?? '').isNotEmpty) {
      _role = widget.role;
    }
  }

  // Ambil username & role dari server bila belum dikirim dari halaman sebelumnya
  Future<void> _loadProfile() async {
    if ((_username ?? '').isNotEmpty && (_role ?? '').isNotEmpty) return;
    try {
      final r = await apiListUsers(widget.keyToken);
      if (!mounted) return;
      setState(() {
        if ((_username ?? '').isEmpty && (r.meUsername ?? '').isNotEmpty) {
          _username = r.meUsername;
        }
        if ((_role ?? '').isEmpty && (r.meRole ?? '').isNotEmpty) {
          _role = r.meRole;
        }
      });
    } catch (_) {}
  }

  @override
  void dispose() {
    _usernameCtrl.dispose();
    _passwordCtrl.dispose();
    _dayCtrl.dispose();
    _refreshNotifier.dispose();
    super.dispose();
  }

  // ─── PICK IMAGE ───
  Future<void> _pickImage() async {
    final pickedFile = await _picker.pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      setState(() => _imageFile = File(pickedFile.path));
    }
  }

  // ─── SUBMIT ───
  Future<void> _createAccount() async {
    final u = _usernameCtrl.text.trim();
    final p = _passwordCtrl.text.trim();
    final d = _selectedType == 'member' ? _dayCtrl.text.trim() : '9999';

    if (u.isEmpty || p.isEmpty || (_selectedType == 'member' && d.isEmpty)) {
      _alert("Peringatan", "Semua field wajib diisi.");
      return;
    }

    if (_imageFile == null) {
      _alert("Peringatan", "Foto bukti transaksi wajib diupload!");
      return;
    }

    setState(() => _isLoading = true);

    try {
      var request = http.MultipartRequest('POST', Uri.parse("$_kBase/reseller/create"));
      request.fields['key'] = widget.keyToken;
      request.fields['username'] = u;
      request.fields['password'] = p;
      request.fields['day'] = d;
      request.fields['type'] = _selectedType;

      var pic = await http.MultipartFile.fromPath('bukti', _imageFile!.path);
      request.files.add(pic);

      var response = await request.send();
      var responseData = await response.stream.bytesToString();
      var data = jsonDecode(responseData);

      setState(() => _isLoading = false);

      if (data['success'] != true) {
        _alert("Gagal", "❌ ${data['message'] ?? 'Gagal membuat akun.'}");
        return;
      }

      if (data['mode'] == 'qris') {
        if (!mounted) return;
        _showQrisDialog(
          depositId: data['depositId'],
          qrUrl: data['qrUrl'],
          totalPayment: data['totalPayment'] ?? 3000,
          username: u,
          password: p,
          days: int.parse(d),
        );
      }
    } catch (e) {
      setState(() => _isLoading = false);
      _alert("Error", "❌ Koneksi error: $e");
    }
  }

  void _clearForm() {
    _usernameCtrl.clear();
    _passwordCtrl.clear();
    _dayCtrl.text = '1';
    setState(() {
      _imageFile = null;
      _selectedType = 'member';
    });
  }

  void _alert(String title, String message) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: _C.card,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AppColors.cardRadius),
          side: BorderSide(color: _C.border, width: AppColors.borderWidth),
        ),
        title: Text(title, style: TextStyle(fontFamily: kFont, fontWeight: FontWeight.bold, color: _C.text)),
        content: Text(message, style: TextStyle(fontFamily: kFont, color: _C.textSub)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("OK", style: TextStyle(fontFamily: kFont, fontWeight: FontWeight.bold, color: _C.primary)),
          ),
        ],
      ),
    );
  }

  void _showQrisDialog({
    required String depositId,
    required String qrUrl,
    required int totalPayment,
    required String username,
    required String password,
    required int days,
  }) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      isDismissible: false,
      enableDrag: false,
      builder: (ctx) => _QrisResellerSheet(
        sessionKey: widget.keyToken,
        depositId: depositId,
        qrUrl: qrUrl,
        totalPayment: totalPayment,
        username: username,
        password: password,
        days: days,
        onSuccess: () {
          _clearForm();
          _refreshNotifier.value++;
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // tampilkan username & role ASLI (fallback aman)
    final displayUsername = (_username ?? '').trim().isEmpty ? 'User' : _username!.trim();
    final displayRole = (_role ?? '').trim().isEmpty ? 'USER' : _role!.trim().toUpperCase();

    return ThemeScope(
      child: DefaultTabController(
        length: 3,
        child: Scaffold(
          backgroundColor: _C.bg,
          appBar: AppBar(
            backgroundColor: _C.card,
            elevation: 0,
            leading: IconButton(
              onPressed: () => Navigator.pop(context),
              icon: Icon(Icons.arrow_back_ios_new_rounded, color: _C.text, size: 18),
            ),
            title: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Akses jualan',
                  style: TextStyle(
                    color: _C.primary,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    fontFamily: kFont,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  '$displayUsername • $displayRole',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(color: _C.textSub, fontSize: 11, fontFamily: kFont),
                ),
              ],
            ),
            bottom: TabBar(
              labelColor: _C.primary,
              unselectedLabelColor: _C.textSub,
              indicatorColor: _C.primary,
              labelStyle: const TextStyle(
                fontFamily: kFont,
                fontWeight: FontWeight.bold,
                fontSize: 12,
              ),
              tabs: const [
                Tab(text: "Buat"),
                Tab(text: "List"),
                Tab(text: "Delete"),
              ],
            ),
          ),
          body: TabBarView(
            children: [
              _buildBuatTab(),
              _ListUsersTab(
                sessionKey: widget.keyToken,
                refreshNotifier: _refreshNotifier,
              ),
              _DeleteUsersTab(
                sessionKey: widget.keyToken,
                refreshNotifier: _refreshNotifier,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildBuatTab() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Banner Jual Akun
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              gradient: AppColors.btnGrad,
              borderRadius: BorderRadius.circular(AppColors.cardRadius),
              border: Border.all(
                color: _C.border,
                width: AppColors.borderWidth,
              ),
              boxShadow: AppColors.glassShadow,
            ),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.2),
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(Icons.person_add_alt_1, color: Colors.white, size: 28),
                ),
                const SizedBox(width: 16),
                const Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "BUAT AKUN",
                      style: TextStyle(
                        color: Colors.white70,
                        fontSize: 10,
                        letterSpacing: 1,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      "jual akun baru",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        fontFamily: kFont,
                      ),
                    ),
                    SizedBox(height: 4),
                    Text(
                      "Foto bukti wajib • auto create",
                      style: TextStyle(color: Colors.white70, fontSize: 11),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),

          // Section Jenis Akun
          _buildSectionTitle("JENIS AKUN"),
          _buildTypeCard(
            type: 'member',
            title: "Member (custom hari)",
            subtitle: "Custom 1-30 hari • foto bukti • auto create",
            priceInfo: "Rp 2.000 - Rp 15.000",
          ),
          _buildTypeCard(
            type: 'fullup',
            title: "Fullup permanent",
            subtitle: "Foto bukti • auto create",
            priceInfo: "Rp 35.000",
          ),
          const SizedBox(height: 24),

          // Section Data Buyer
          _buildSectionTitle("DATA BUYER"),
          _buildInput(
            label: "Username buyer",
            ctrl: _usernameCtrl,
            icon: Icons.person_outline,
          ),
          _buildInput(
            label: "Password buyer",
            ctrl: _passwordCtrl,
            icon: Icons.lock_outline,
            obscure: true,
          ),

          // Durasi (Hanya muncul jika member)
          if (_selectedType == 'member') ...[
            const SizedBox(height: 12),
            _buildSectionTitle("DURASI (HARI)"),
            Row(
              children: [1, 3, 7, 14, 30].map((d) {
                final isSelected = _dayCtrl.text == d.toString();
                return Expanded(
                  child: GestureDetector(
                    onTap: () => setState(() => _dayCtrl.text = d.toString()),
                    child: Container(
                      margin: const EdgeInsets.only(right: 8),
                      padding: const EdgeInsets.symmetric(vertical: 10),
                      decoration: BoxDecoration(
                        color: isSelected ? _C.primary.withOpacity(0.1) : _C.card,
                        border: Border.all(
                          color: isSelected ? _C.primary : _C.border,
                          width: AppColors.borderWidth,
                        ),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Center(
                        child: Text(
                          "$d hr",
                          style: TextStyle(
                            color: isSelected ? _C.primary : _C.text,
                            fontSize: 11,
                            fontWeight: FontWeight.bold,
                            fontFamily: kFont,
                          ),
                        ),
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
          ] else ...[
            const SizedBox(height: 12),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: _C.primary.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(
                  color: _C.primary.withOpacity(0.3),
                  width: AppColors.borderWidth,
                ),
              ),
              child: Text(
                "Durasi: PERMANEN (9999 Hari)",
                style: TextStyle(
                  color: _C.primary,
                  fontWeight: FontWeight.bold,
                  fontSize: 12,
                  fontFamily: kFont,
                ),
              ),
            ),
          ],

          const SizedBox(height: 24),

          // Section Foto Bukti
          _buildSectionTitle("FOTO BUKTI (WAJIB)"),
          GestureDetector(
            onTap: _pickImage,
            child: Container(
              width: double.infinity,
              height: 120,
              decoration: BoxDecoration(
                color: _C.card,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: _imageFile != null ? _C.primary : _C.border,
                  width: _imageFile != null ? (AppColors.borderWidth + 1) : AppColors.borderWidth,
                ),
              ),
              child: _imageFile != null
                  ? ClipRRect(
                      borderRadius: BorderRadius.circular(10),
                      child: Image.file(_imageFile!, fit: BoxFit.cover),
                    )
                  : Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.image_outlined, color: _C.textSub, size: 32),
                        const SizedBox(height: 8),
                        Text(
                          "Pilih foto dari galeri",
                          style: TextStyle(color: _C.textSub, fontFamily: kFont, fontSize: 12),
                        ),
                      ],
                    ),
            ),
          ),

          const SizedBox(height: 32),

          // Tombol Submit
          SizedBox(
            width: double.infinity,
            height: 50,
            child: ElevatedButton(
              onPressed: _isLoading ? null : _createAccount,
              style: ElevatedButton.styleFrom(
                backgroundColor: _C.primary,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(AppColors.cardRadius),
                  side: BorderSide(color: _C.border, width: AppColors.borderWidth),
                ),
              ),
              child: _isLoading
                  ? const CircularProgressIndicator(color: Colors.white)
                  : const Text(
                      "Submit • bayar 10% / Rp 3.000",
                      style: TextStyle(
                        fontFamily: kFont,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                        fontSize: 14,
                      ),
                    ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12, left: 4),
      child: Text(
        title,
        style: TextStyle(
          color: _C.primary,
          fontFamily: kFont,
          fontSize: 11,
          fontWeight: FontWeight.bold,
          letterSpacing: 1,
        ),
      ),
    );
  }

  Widget _buildTypeCard({
    required String type,
    required String title,
    required String subtitle,
    required String priceInfo,
  }) {
    final isSelected = _selectedType == type;
    return GestureDetector(
      onTap: () => setState(() => _selectedType = type),
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: isSelected ? _C.primary.withOpacity(0.08) : _C.card,
          borderRadius: BorderRadius.circular(AppColors.cardRadius),
          border: Border.all(
            color: isSelected ? _C.primary : _C.border,
            width: AppColors.borderWidth,
          ),
          boxShadow: AppColors.softShadow,
        ),
        child: Row(
          children: [
            Icon(
              isSelected ? Icons.radio_button_checked : Icons.radio_button_off,
              color: isSelected ? _C.primary : _C.textSub,
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      color: _C.text,
                      fontFamily: kFont,
                      fontSize: 13,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    subtitle,
                    style: TextStyle(
                      color: _C.textSub,
                      fontFamily: kFont,
                      fontSize: 10,
                    ),
                  ),
                ],
              ),
            ),
            Text(
              priceInfo,
              style: TextStyle(
                color: _C.amber,
                fontFamily: kFont,
                fontSize: 11,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInput({
    required String label,
    required TextEditingController ctrl,
    required IconData icon,
    bool obscure = false,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextField(
        controller: ctrl,
        obscureText: obscure,
        style: TextStyle(color: _C.text, fontFamily: kFont, fontSize: 13),
        decoration: InputDecoration(
          labelText: label,
          labelStyle: TextStyle(color: _C.textSub, fontFamily: kFont, fontSize: 12),
          prefixIcon: Icon(icon, color: _C.textSub, size: 20),
          filled: true,
          fillColor: _C.card,
          contentPadding: const EdgeInsets.symmetric(vertical: 14),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: _C.border, width: AppColors.borderWidth),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: _C.border, width: AppColors.borderWidth),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: _C.primary, width: AppColors.borderWidth + 1),
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════
//  LIST USERS TAB (baca dari /reseller/listUsers)
// ═══════════════════════════════════════════════════════════════════════
class _ListUsersTab extends StatefulWidget {
  final String sessionKey;
  final ValueNotifier<int> refreshNotifier;

  const _ListUsersTab({
    required this.sessionKey,
    required this.refreshNotifier,
  });

  @override
  State<_ListUsersTab> createState() => _ListUsersTabState();
}

class _ListUsersTabState extends State<_ListUsersTab> {
  bool _loading = true;
  String? _error;
  List<Map<String, dynamic>> _users = [];

  @override
  void initState() {
    super.initState();
    widget.refreshNotifier.addListener(_fetch);
    _fetch();
  }

  @override
  void dispose() {
    widget.refreshNotifier.removeListener(_fetch);
    super.dispose();
  }

  Future<void> _fetch() async {
    if (!mounted) return;
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final r = await apiListUsers(widget.sessionKey);
      if (!mounted) return;
      setState(() {
        _users = r.users;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = e.toString().replaceFirst('Exception: ', '');
        _loading = false;
      });
    }
  }

  String _pick(Map<String, dynamic> u, List<String> keys, [String fallback = '']) {
    for (final k in keys) {
      final v = u[k];
      if (v != null && v.toString().isNotEmpty) return v.toString();
    }
    return fallback;
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return Center(
        child: CircularProgressIndicator(color: _C.primary),
      );
    }

    if (_error != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.error_outline, color: _C.red, size: 48),
              const SizedBox(height: 12),
              Text(
                _error!,
                textAlign: TextAlign.center,
                style: TextStyle(color: _C.textSub, fontFamily: kFont),
              ),
              const SizedBox(height: 16),
              OutlinedButton(
                onPressed: _fetch,
                style: OutlinedButton.styleFrom(
                  side: BorderSide(color: _C.primary),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(AppColors.cardRadius),
                  ),
                ),
                child: Text("Coba lagi",
                    style: TextStyle(color: _C.primary, fontFamily: kFont, fontWeight: FontWeight.bold)),
              ),
            ],
          ),
        ),
      );
    }

    if (_users.isEmpty) {
      return RefreshIndicator(
        color: _C.primary,
        onRefresh: _fetch,
        child: ListView(
          physics: const AlwaysScrollableScrollPhysics(),
          children: [
            SizedBox(
              height: MediaQuery.of(context).size.height * 0.7,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.person_off_outlined, color: _C.textSub, size: 64),
                  const SizedBox(height: 12),
                  Text(
                    "Belum ada user",
                    style: TextStyle(color: _C.textSub, fontFamily: kFont, fontSize: 14),
                  ),
                ],
              ),
            ),
          ],
        ),
      );
    }

    return RefreshIndicator(
      color: _C.primary,
      onRefresh: _fetch,
      child: ListView.builder(
        padding: const EdgeInsets.all(16),
        physics: const AlwaysScrollableScrollPhysics(),
        itemCount: _users.length,
        itemBuilder: (ctx, i) {
          final raw = _users[i];
          final u = raw;
          final uname = _pick(u, ['username', 'user', 'name'], '-');
          final pass = _pick(u, ['password', 'pass']);
          final expired = _pick(u, ['expired', 'expiry', 'expiredAt', 'expired_at']);
          final status = _pick(u, ['status', 'active'], '-');
          final type = _pick(u, ['type', 'plan', 'role']);
          final isActive = status.toLowerCase() == 'active' ||
              status.toLowerCase() == 'aktif' ||
              status == '1' ||
              status.toLowerCase() == 'true';

          return Container(
            margin: const EdgeInsets.only(bottom: 12),
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: _C.card,
              borderRadius: BorderRadius.circular(AppColors.cardRadius),
              border: Border.all(color: _C.border, width: AppColors.borderWidth),
              boxShadow: AppColors.softShadow,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    CircleAvatar(
                      backgroundColor: _C.primary.withOpacity(0.15),
                      child: Icon(Icons.person, color: _C.primary),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            uname,
                            style: TextStyle(
                              color: _C.text,
                              fontFamily: kFont,
                              fontWeight: FontWeight.bold,
                              fontSize: 14,
                            ),
                          ),
                          if (pass.isNotEmpty)
                            Text(
                              'Pass: $pass',
                              style: TextStyle(
                                color: _C.textSub,
                                fontFamily: kFont,
                                fontSize: 11,
                              ),
                            ),
                        ],
                      ),
                    ),
                    if (type.isNotEmpty)
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: _C.primary.withOpacity(0.12),
                          borderRadius: BorderRadius.circular(6),
                          border: Border.all(color: _C.primary.withOpacity(0.3), width: 1),
                        ),
                        child: Text(
                          type.toUpperCase(),
                          style: TextStyle(
                            color: _C.primary,
                            fontFamily: kFont,
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                  ],
                ),
                if (expired.isNotEmpty) ...[
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Icon(Icons.schedule, size: 14, color: _C.textSub),
                      const SizedBox(width: 6),
                      Expanded(
                        child: Text(
                          'Expired: $expired',
                          style: TextStyle(
                            color: _C.textSub,
                            fontFamily: kFont,
                            fontSize: 11,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
                const SizedBox(height: 4),
                Row(
                  children: [
                    Icon(
                      Icons.circle,
                      size: 8,
                      color: isActive ? _C.green : _C.red,
                    ),
                    const SizedBox(width: 6),
                    Text(
                      'Status: ${status.toUpperCase()}',
                      style: TextStyle(
                        color: isActive ? _C.green : _C.red,
                        fontFamily: kFont,
                        fontSize: 11,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════
//  DELETE USERS TAB (baca dari /reseller/deleteUsers)
// ═══════════════════════════════════════════════════════════════════════
class _DeleteUsersTab extends StatefulWidget {
  final String sessionKey;
  final ValueNotifier<int> refreshNotifier;

  const _DeleteUsersTab({
    required this.sessionKey,
    required this.refreshNotifier,
  });

  @override
  State<_DeleteUsersTab> createState() => _DeleteUsersTabState();
}

class _DeleteUsersTabState extends State<_DeleteUsersTab> {
  bool _loading = true;
  String? _error;
  List<Map<String, dynamic>> _users = [];
  final Set<String> _deleting = <String>{};

  @override
  void initState() {
    super.initState();
    widget.refreshNotifier.addListener(_fetch);
    _fetch();
  }

  @override
  void dispose() {
    widget.refreshNotifier.removeListener(_fetch);
    super.dispose();
  }

  Future<void> _fetch() async {
    if (!mounted) return;
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final r = await apiListUsers(widget.sessionKey);
      if (!mounted) return;
      setState(() {
        _users = r.users;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = e.toString().replaceFirst('Exception: ', '');
        _loading = false;
      });
    }
  }

  String _pick(Map<String, dynamic> u, List<String> keys, [String fallback = '']) {
    for (final k in keys) {
      final v = u[k];
      if (v != null && v.toString().isNotEmpty) return v.toString();
    }
    return fallback;
  }

  Future<void> _confirmDelete(String username) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: _C.card,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AppColors.cardRadius),
          side: BorderSide(color: _C.border, width: AppColors.borderWidth),
        ),
        title: Text(
          "Hapus akun?",
          style: TextStyle(
            fontFamily: kFont,
            fontWeight: FontWeight.bold,
            color: _C.text,
          ),
        ),
        content: Text(
          "Akun \"$username\" akan dihapus permanen dari server. Lanjutkan?",
          style: TextStyle(fontFamily: kFont, color: _C.textSub),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text("Batal",
                style: TextStyle(fontFamily: kFont, color: _C.textSub)),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: Text(
              "Hapus",
              style: TextStyle(
                fontFamily: kFont,
                fontWeight: FontWeight.bold,
                color: _C.red,
              ),
            ),
          ),
        ],
      ),
    );
    if (ok == true) await _doDelete(username);
  }

  Future<void> _doDelete(String username) async {
    setState(() => _deleting.add(username));
    try {
      await apiDeleteUser(widget.sessionKey, username);
      _toast('✅ Akun "$username" berhasil dihapus', _C.green);
      await _fetch();
    } catch (e) {
      _toast('❌ ${e.toString().replaceFirst('Exception: ', '')}', _C.red);
    } finally {
      if (mounted) setState(() => _deleting.remove(username));
    }
  }

  void _toast(String msg, Color bg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg, style: const TextStyle(fontFamily: kFont, color: Colors.white)),
        backgroundColor: bg,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return Center(child: CircularProgressIndicator(color: _C.primary));
    }

    if (_error != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.error_outline, color: _C.red, size: 48),
              const SizedBox(height: 12),
              Text(
                _error!,
                textAlign: TextAlign.center,
                style: TextStyle(color: _C.textSub, fontFamily: kFont),
              ),
              const SizedBox(height: 16),
              OutlinedButton(
                onPressed: _fetch,
                style: OutlinedButton.styleFrom(
                  side: BorderSide(color: _C.primary),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(AppColors.cardRadius),
                  ),
                ),
                child: Text("Coba lagi",
                    style: TextStyle(color: _C.primary, fontFamily: kFont, fontWeight: FontWeight.bold)),
              ),
            ],
          ),
        ),
      );
    }

    if (_users.isEmpty) {
      return RefreshIndicator(
        color: _C.primary,
        onRefresh: _fetch,
        child: ListView(
          physics: const AlwaysScrollableScrollPhysics(),
          children: [
            SizedBox(
              height: MediaQuery.of(context).size.height * 0.7,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.checklist_rounded, color: _C.textSub, size: 64),
                  const SizedBox(height: 12),
                  Text(
                    "Tidak ada user untuk dihapus",
                    style: TextStyle(color: _C.textSub, fontFamily: kFont, fontSize: 14),
                  ),
                ],
              ),
            ),
          ],
        ),
      );
    }

    return RefreshIndicator(
      color: _C.primary,
      onRefresh: _fetch,
      child: ListView.builder(
        padding: const EdgeInsets.all(16),
        physics: const AlwaysScrollableScrollPhysics(),
        itemCount: _users.length,
        itemBuilder: (ctx, i) {
          final raw = _users[i];
          final u = raw;
          final uname = _pick(u, ['username', 'user', 'name'], '-');
          final pass = _pick(u, ['password', 'pass']);
          final expired = _pick(u, ['expired', 'expiry', 'expiredAt', 'expired_at']);
          final type = _pick(u, ['type', 'plan', 'role']);
          final isDeleting = _deleting.contains(uname);

          return Container(
            margin: const EdgeInsets.only(bottom: 12),
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: _C.card,
              borderRadius: BorderRadius.circular(AppColors.cardRadius),
              border: Border.all(color: _C.border, width: AppColors.borderWidth),
              boxShadow: AppColors.softShadow,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    CircleAvatar(
                      backgroundColor: _C.red.withOpacity(0.12),
                      child: Icon(Icons.person, color: _C.red),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            uname,
                            style: TextStyle(
                              color: _C.text,
                              fontFamily: kFont,
                              fontWeight: FontWeight.bold,
                              fontSize: 14,
                            ),
                          ),
                          if (pass.isNotEmpty)
                            Text(
                              'Pass: $pass',
                              style: TextStyle(
                                color: _C.textSub,
                                fontFamily: kFont,
                                fontSize: 11,
                              ),
                            ),
                        ],
                      ),
                    ),
                    if (type.isNotEmpty)
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: _C.primary.withOpacity(0.12),
                          borderRadius: BorderRadius.circular(6),
                          border: Border.all(color: _C.primary.withOpacity(0.3), width: 1),
                        ),
                        child: Text(
                          type.toUpperCase(),
                          style: TextStyle(
                            color: _C.primary,
                            fontFamily: kFont,
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                  ],
                ),
                if (expired.isNotEmpty) ...[
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Icon(Icons.schedule, size: 14, color: _C.textSub),
                      const SizedBox(width: 6),
                      Expanded(
                        child: Text(
                          'Expired: $expired',
                          style: TextStyle(
                            color: _C.textSub,
                            fontFamily: kFont,
                            fontSize: 11,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
                const SizedBox(height: 12),
                SizedBox(
                  width: double.infinity,
                  height: 40,
                  child: ElevatedButton.icon(
                    onPressed: isDeleting ? null : () => _confirmDelete(uname),
                    icon: isDeleting
                        ? const SizedBox(
                            width: 16,
                            height: 16,
                            child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                          )
                        : const Icon(Icons.delete_outline, color: Colors.white, size: 18),
                    label: Text(
                      isDeleting ? "Menghapus..." : "Hapus akun",
                      style: const TextStyle(
                        fontFamily: kFont,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                        fontSize: 12,
                      ),
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _C.red,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                        side: BorderSide(color: _C.border, width: AppColors.borderWidth),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════
//  QRIS RESELLER SHEET
// ═══════════════════════════════════════════════════════════════════════
class _QrisResellerSheet extends StatefulWidget {
  final String sessionKey;
  final String depositId;
  final String qrUrl;
  final int totalPayment;
  final String username;
  final String password;
  final int days;
  final VoidCallback onSuccess;

  const _QrisResellerSheet({
    required this.sessionKey,
    required this.depositId,
    required this.qrUrl,
    required this.totalPayment,
    required this.username,
    required this.password,
    required this.days,
    required this.onSuccess,
  });

  @override
  State<_QrisResellerSheet> createState() => _QrisResellerSheetState();
}

class _QrisResellerSheetState extends State<_QrisResellerSheet> {
  Timer? _pollTimer;
  Timer? _countdownTimer;
  bool _success = false;
  bool _expired = false;
  int _sisaWaktu = 900;

  @override
  void initState() {
    super.initState();
    _startPolling();
    _startTimer();
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    _countdownTimer?.cancel();
    super.dispose();
  }

  void _startTimer() {
    _countdownTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted || _success || _expired) return;
      if (_sisaWaktu > 0) {
        setState(() => _sisaWaktu--);
      } else {
        _countdownTimer?.cancel();
      }
    });
  }

  void _startPolling() {
    _pollTimer = Timer.periodic(const Duration(seconds: 5), (_) async {
      if (!mounted || _success || _expired) return;
      try {
        final res = await http.get(
          Uri.parse("$_kBase/reseller/status?depositId=${widget.depositId}"),
        );
        final data = jsonDecode(res.body);
        final status = data['status'];

        if (status == 'success') {
          _pollTimer?.cancel();
          _countdownTimer?.cancel();
          if (mounted) {
            setState(() => _success = true);
            widget.onSuccess();
          }
        } else if (status == 'expired' || status == 'canceled') {
          _pollTimer?.cancel();
          _countdownTimer?.cancel();
          if (mounted) setState(() => _expired = true);
        }
      } catch (_) {}
    });
  }

  Future<void> _cancel() async {
    _pollTimer?.cancel();
    _countdownTimer?.cancel();
    try {
      await http.get(
        Uri.parse("$_kBase/reseller/cancel?depositId=${widget.depositId}"),
      );
    } catch (_) {}
    if (mounted) Navigator.pop(context);
  }

  String _formatTime(int total) {
    final m = total ~/ 60;
    final s = total % 60;
    return '${m.toString().padLeft(2, '0')}:${s.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: _C.card,
        borderRadius: BorderRadius.circular(AppColors.sheetRadius),
        border: Border.all(color: _C.border, width: AppColors.borderWidth),
        boxShadow: AppColors.glassShadow,
      ),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: _C.border,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(height: 16),
            Text(
              _success
                  ? 'AKUN BERHASIL DIBUAT!'
                  : _expired
                      ? 'INVOICE EXPIRED'
                      : 'MENUNGGU PEMBAYARAN',
              style: TextStyle(
                color: _success ? _C.green : _expired ? _C.red : _C.text,
                fontFamily: kFont,
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            if (_success)
              _successView()
            else if (_expired)
              _expiredView()
            else
              _qrView(),
          ],
        ),
      ),
    );
  }

  Widget _qrView() {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          decoration: BoxDecoration(
            color: _C.amber.withOpacity(0.1),
            borderRadius: BorderRadius.circular(20),
          ),
          child: Text(
            'Kedaluwarsa dalam ${_formatTime(_sisaWaktu)}',
            style: TextStyle(
              color: _C.amber,
              fontFamily: kFont,
              fontSize: 11,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        const SizedBox(height: 16),
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: _C.border, width: 2),
          ),
          child: Image.network(
            widget.qrUrl,
            width: 200,
            height: 200,
            fit: BoxFit.contain,
            loadingBuilder: (_, c, p) => p == null
                ? c
                : const SizedBox(
                    width: 200,
                    height: 200,
                    child: Center(child: CircularProgressIndicator()),
                  ),
            errorBuilder: (_, __, ___) => const SizedBox(
              width: 200,
              height: 200,
              child: Center(child: Icon(Icons.broken_image, size: 60)),
            ),
          ),
        ),
        const SizedBox(height: 16),
        Text(
          "TOTAL BAYAR",
          style: TextStyle(
            color: _C.textSub,
            fontFamily: kFont,
            fontSize: 10,
            letterSpacing: 1,
          ),
        ),
        Text(
          "Rp ${widget.totalPayment}",
          style: TextStyle(
            color: _C.primary,
            fontFamily: kFont,
            fontSize: 24,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 16),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(
              width: 14,
              height: 14,
              child: CircularProgressIndicator(strokeWidth: 2, color: _C.primary),
            ),
            const SizedBox(width: 10),
            Text(
              'Menunggu pembayaran...',
              style: TextStyle(
                color: _C.textSub,
                fontFamily: kFont,
                fontSize: 12,
              ),
            ),
          ],
        ),
        const SizedBox(height: 20),
        SizedBox(
          width: double.infinity,
          height: 44,
          child: OutlinedButton(
            onPressed: _cancel,
            style: OutlinedButton.styleFrom(
              side: BorderSide(color: _C.red),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
            child: Text(
              'BATAL',
              style: TextStyle(
                color: _C.red,
                fontFamily: kFont,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _successView() {
    return Column(
      children: [
        Container(
          width: 80,
          height: 80,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: _C.green,
          ),
          child: const Icon(Icons.check_rounded, color: Colors.white, size: 40),
        ),
        const SizedBox(height: 16),
        Text(
          'Akun: ${widget.username}\nPassword: ${widget.password}\nDurasi: ${widget.days} hari',
          textAlign: TextAlign.center,
          style: TextStyle(color: _C.textSub, fontFamily: kFont, fontSize: 13),
        ),
        const SizedBox(height: 20),
        SizedBox(
          width: double.infinity,
          height: 46,
          child: ElevatedButton(
            onPressed: () => Navigator.pop(context),
            style: ElevatedButton.styleFrom(
              backgroundColor: _C.green,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
                side: BorderSide(color: _C.border, width: AppColors.borderWidth),
              ),
            ),
            child: const Text(
              'SELESAI',
              style: TextStyle(
                fontFamily: kFont,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _expiredView() {
    return Column(
      children: [
        Container(
          width: 80,
          height: 80,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: _C.red.withOpacity(0.1),
            border: Border.all(color: _C.red, width: 2),
          ),
          child: Icon(Icons.cancel_rounded, color: _C.red, size: 40),
        ),
        const SizedBox(height: 16),
        Text(
          'Waktu pembayaran habis.\nSilakan buat ulang.',
          textAlign: TextAlign.center,
          style: TextStyle(color: _C.textSub, fontFamily: kFont, fontSize: 12),
        ),
        const SizedBox(height: 20),
        SizedBox(
          width: double.infinity,
          height: 46,
          child: ElevatedButton(
            onPressed: () => Navigator.pop(context),
            style: ElevatedButton.styleFrom(
              backgroundColor: _C.red,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
                side: BorderSide(color: _C.border, width: AppColors.borderWidth),
              ),
            ),
            child: const Text(
              'TUTUP',
              style: TextStyle(
                fontFamily: kFont,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
          ),
        ),
      ],
    );
  }
}