import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:flutter_tts/flutter_tts.dart';

// IMPORT FILE YANG DIBUTUHKAN
import 'splash.dart';
import 'main.dart';
import 'theme.dart';
import 'free_trial.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage>
    with TickerProviderStateMixin {
  final userController = TextEditingController();
  final passController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  bool isLoading = false;
  bool _obscurePassword = true;
  String? androidId;
  bool _isPowerOn = false;

  late AnimationController _controller;
  late Animation<double> _fadeAnim;
  late Animation<double> _slideAnim;

  late AnimationController _robotController;
  late Animation<double> _blinkAnim;
  late AnimationController _powerAnimController;
  late Animation<double> _powerAnim;

  final FlutterTts _flutterTts = FlutterTts();

  String appVersion = "6.3";

  // ── SHORTCUT KE AppColors ──
  static Color get _primary => AppColors.accent;
  static Color get _textPrimary => AppColors.text;
  static Color get _textSecondary => AppColors.textSub;
  static Color get _cardColor => AppColors.card;
  static Color get _fieldColor => AppColors.card2;
  static Color get _borderColor => AppColors.border;
  static Color get _bgColor => AppColors.bg;
  static bool get _isComic => ThemeModeManager.isComic3d;
  static bool get _isLight => ThemeModeManager.isMonochrome;

  String get _passwordStrength {
    final p = passController.text;
    if (p.isEmpty) return "WAITING FOR PASSWORD";
    if (p.length < 6) return "WEAK • TOO SHORT";
    final hasUpper = p.contains(RegExp(r'[A-Z]'));
    final hasLower = p.contains(RegExp(r'[a-z]'));
    final hasDigit = p.contains(RegExp(r'[0-9]'));
    final hasSymbol = p.contains(RegExp(r'[^A-Za-z0-9]'));
    final score = [hasUpper, hasLower, hasDigit, hasSymbol]
            .where((v) => v)
            .length +
        (p.length >= 10 ? 1 : 0);
    if (score <= 2) return "MEDIUM • ADD NUMBERS / SYMBOLS";
    if (score <= 4) return "STRONG • NICE PASSWORD";
    return "VERY STRONG • LOCKED IN";
  }

  Color get _passwordStrengthColor {
    final p = passController.text;
    if (p.isEmpty) return _textSecondary;
    if (p.length < 6) return AppColors.red;
    final hasUpper = p.contains(RegExp(r'[A-Z]'));
    final hasLower = p.contains(RegExp(r'[a-z]'));
    final hasDigit = p.contains(RegExp(r'[0-9]'));
    final hasSymbol = p.contains(RegExp(r'[^A-Za-z0-9]'));
    final score = [hasUpper, hasLower, hasDigit, hasSymbol]
            .where((v) => v)
            .length +
        (p.length >= 10 ? 1 : 0);
    return score <= 2 ? AppColors.batteryMid : AppColors.green;
  }

  @override
  void initState() {
    super.initState();
    _initAnim();

    _robotController = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 260));
    _blinkAnim = Tween<double>(begin: 1, end: 0.08).animate(
        CurvedAnimation(parent: _robotController, curve: Curves.easeInOut));

    _powerAnimController = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 600));
    _powerAnim = CurvedAnimation(
        parent: _powerAnimController, curve: Curves.easeOutCubic);

    passController.addListener(() {
      if (mounted) setState(() {});
    });

    _initTts();
    _initAndLoad();
  }

  Future<void> _initTts() async {
    try {
      await _flutterTts.setLanguage("id-ID");
      await _flutterTts.setSpeechRate(0.45);
      await _flutterTts.setVolume(0.7);
      await _flutterTts.setPitch(0.6);
      if (Theme.of(context).platform == TargetPlatform.android) {
        await _flutterTts.setEngine("com.google.android.tts");
      }
    } catch (_) {}
  }

  Future<void> _speakPowerOn() async {
    try {
      await _flutterTts.stop();
      await _flutterTts.setPitch(0.8);
      await _flutterTts.setSpeechRate(0.45);
      await _flutterTts.speak("System Online");
    } catch (_) {}
  }

  Future<void> _speakPowerOff() async {
    try {
      await _flutterTts.stop();
      await _flutterTts.setPitch(0.5);
      await _flutterTts.setSpeechRate(0.4);
      await _flutterTts.speak("System Offline");
    } catch (_) {}
  }

  Future<void> _initAndLoad() async {
    androidId = await getAndroidId();
    try {
      final info = await PackageInfo.fromPlatform();
      if (mounted) setState(() => appVersion = info.version);
    } catch (_) {}
    await initLogin();
  }

  void _initAnim() {
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    )..forward();

    _fadeAnim = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOut),
    );

    _slideAnim = Tween<double>(begin: 30, end: 0).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeOut),
    );
  }

  void _togglePower() {
    setState(() {
      _isPowerOn = !_isPowerOn;
    });

    if (_isPowerOn) {
      _powerAnimController.forward();
      _speakPowerOn();
      _robotController.forward().then((_) => _robotController.reverse());
    } else {
      _powerAnimController.reverse();
      _speakPowerOff();
    }
  }

  Future<void> initLogin() async {
    final prefs = await SharedPreferences.getInstance();
    final savedUser = prefs.getString("username");
    final savedPass = prefs.getString("password");
    final savedKey = prefs.getString("key");
    final savedUid = prefs.getString("uid") ?? '';

    if (savedUser != null && savedPass != null && savedKey != null) {
      final uri = Uri.parse(
          "http://cp.zyrostore.id:3448/myInfo?username=$savedUser&password=$savedPass&androidId=$androidId&key=$savedKey");

      try {
        final res = await http.get(uri);
        final data = jsonDecode(res.body);

        if (data['valid'] == true && data['expired'] != true) {
          if (!mounted) return;
          Navigator.pushReplacement(
            context,
            PageRouteBuilder(
              pageBuilder: (_, __, ___) => SplashScreen(
                username: savedUser,
                password: savedPass,
                role: data['role'],
                sessionKey: data['key'],
                expiredDate: data['expiredDate'],
                listBug: (data['listBug'] as List? ?? [])
                    .map((e) => Map<String, dynamic>.from(e as Map))
                    .toList(),
                listDoos: (data['listDDoS'] as List? ?? [])
                    .map((e) => Map<String, dynamic>.from(e as Map))
                    .toList(),
                news: (data['news'] as List? ?? [])
                    .map((e) => Map<String, dynamic>.from(e as Map))
                    .toList(),
                uid: ((data['uid'] ?? savedUid) ?? '').toString(),
              ),
              transitionDuration: const Duration(milliseconds: 400),
              transitionsBuilder: (_, animation, __, child) =>
                  FadeTransition(opacity: animation, child: child),
            ),
          );
        } else if (data['reason'] == 'device') {
          if (!mounted) return;
          _showPopup(
            title: "Device Mismatch",
            message: "Akun ini sudah digunakan di perangkat lain.",
            color: AppColors.red,
          );
        }
      } catch (_) {}
    }
  }

  Future<String> getAndroidId() async {
    final deviceInfo = DeviceInfoPlugin();
    final android = await deviceInfo.androidInfo;
    return android.id;
  }

  Future<void> login() async {
    if (!_isPowerOn) return;
    if (!_formKey.currentState!.validate()) return;

    final username = userController.text.trim();
    final password = passController.text.trim();

    setState(() => isLoading = true);

    try {
      androidId ??= await getAndroidId();

      if (username == "Cloude" && password == "syamanjing") {
        if (!mounted) return;
        final localUid = 'local_${androidId ?? 'device'}_$username';
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString("uid", localUid);
        if (!mounted) return;
        Navigator.pushReplacement(
          context,
          PageRouteBuilder(
            pageBuilder: (_, __, ___) => SplashScreen(
              username: username,
              password: password,
              role: "owner_utama",
              sessionKey: "local_key",
              expiredDate:
                  DateTime.now().add(const Duration(days: 365)).toString(),
              listBug: [],
              listDoos: [],
              news: [],
              uid: localUid,
            ),
            transitionDuration: const Duration(milliseconds: 400),
            transitionsBuilder: (_, animation, __, child) =>
                FadeTransition(opacity: animation, child: child),
          ),
        );
        setState(() => isLoading = false);
        return;
      }

      final validate = await http.post(
        Uri.parse("http://cp.zyrostore.id:3448/validate"),
        body: {
          "username": username,
          "password": password,
          "androidId": androidId!,
          "version": appVersion,
        },
      );

      final validData = jsonDecode(validate.body);

      if (!mounted) return;

      if (validData['expired'] == true) {
        _showPopup(
          title: "AKSES BERAKHIR",
          message: "Masa akses Anda telah habis.\nSilakan perpanjang.",
          color: AppColors.batteryMid,
          showContact: true,
        );
      } else if (validData['valid'] != true) {
        _showFailPopup(
          title: "MASUK GAGAL",
          message: "Username Atau Password Salah",
        );
      } else {
        final serverUid = (validData['uid'] ?? '').toString();
        final prefs = await SharedPreferences.getInstance();
        prefs.setString("username", username);
        prefs.setString("password", password);
        prefs.setString("key", validData['key']);
        prefs.setString("uid", serverUid);

        if (!mounted) return;
        Navigator.pushReplacement(
          context,
          PageRouteBuilder(
            pageBuilder: (_, __, ___) => SplashScreen(
              username: username,
              password: password,
              role: validData['role'],
              sessionKey: validData['key'],
              expiredDate: validData['expiredDate'],
              listBug: (validData['listBug'] as List? ?? [])
                  .map((e) => Map<String, dynamic>.from(e as Map))
                  .toList(),
              listDoos: (validData['listDDoS'] as List? ?? [])
                  .map((e) => Map<String, dynamic>.from(e as Map))
                  .toList(),
              news: (validData['news'] as List? ?? [])
                  .map((e) => Map<String, dynamic>.from(e as Map))
                  .toList(),
              uid: serverUid,
            ),
            transitionDuration: const Duration(milliseconds: 400),
            transitionsBuilder: (_, animation, __, child) =>
                FadeTransition(opacity: animation, child: child),
          ),
        );
      }
    } catch (e) {
      if (!mounted) return;
      _showFailPopup(
        title: "KONEKSI GAGAL",
        message: "Tidak dapat terhubung ke server.\nPeriksa koneksi internet Anda.",
      );
    }

    if (mounted) setState(() => isLoading = false);
  }

  // ═════════════════════════════════════════════════════════════════
  // POPUP GAGAL — DESAIN BARU (SESUAI FOTO)
  // ═════════════════════════════════════════════════════════════════
  void _showFailPopup({
    required String title,
    required String message,
  }) {
    showGeneralDialog(
      context: context,
      barrierDismissible: true,
      barrierLabel: 'Dismiss',
      barrierColor: Colors.black.withOpacity(0.85),
      transitionDuration: const Duration(milliseconds: 320),
      pageBuilder: (ctx, anim1, anim2) {
        return Center(
          child: Material(
            color: Colors.transparent,
            child: _FailPopupWidget(
              title: title,
              message: message,
              onClose: () => Navigator.of(ctx).pop(),
            ),
          ),
        );
      },
      transitionBuilder: (ctx, anim, _, child) {
        final curved = CurvedAnimation(parent: anim, curve: Curves.easeOutBack);
        return FadeTransition(
          opacity: anim,
          child: ScaleTransition(scale: Tween(begin: 0.85, end: 1.0).animate(curved), child: child),
        );
      },
    );
  }

  void _showPopup({
    required String title,
    required String message,
    Color? color,
    bool showContact = false,
  }) {
    final popColor = color ?? _primary;
    showDialog(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          decoration: BoxDecoration(
            color: _cardColor,
            borderRadius: BorderRadius.circular(AppColors.cardRadius),
            border: Border.all(
              color: _borderColor,
              width: AppColors.borderWidth,
            ),
            boxShadow: AppColors.glassShadow,
          ),
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 48,
                  height: 48,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: popColor.withOpacity(0.15),
                    border: Border.all(
                      color: popColor,
                      width: _isComic ? 2.5 : 1.5,
                    ),
                  ),
                  child: Icon(
                    popColor == AppColors.batteryMid
                        ? Icons.warning
                        : Icons.error,
                    color: popColor,
                    size: 24,
                  ),
                ),
                const SizedBox(height: 16),
                Text(title,
                    style: TextStyle(
                        color: _textPrimary,
                        fontSize: 18,
                        fontWeight: FontWeight.w900)),
                const SizedBox(height: 12),
                Text(message,
                    style: TextStyle(
                        color: _textSecondary, fontSize: 14, height: 1.5),
                    textAlign: TextAlign.center),
                const SizedBox(height: 24),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    if (showContact)
                      OutlinedButton(
                        onPressed: () async {
                          final uri = Uri.parse("https://t.me/Jentrick2");
                          await launchUrl(uri,
                              mode: LaunchMode.externalApplication);
                        },
                        style: OutlinedButton.styleFrom(
                          foregroundColor: _textSecondary,
                          side: BorderSide(
                              color: _borderColor,
                              width: _isComic ? 2 : 1),
                          padding: const EdgeInsets.symmetric(
                              horizontal: 16, vertical: 8),
                        ),
                        child: const Text("Contact Admin",
                            style: TextStyle(fontSize: 13)),
                      ),
                    const SizedBox(width: 8),
                    ElevatedButton(
                      onPressed: () => Navigator.pop(context),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: popColor,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(
                            horizontal: 20, vertical: 8),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                          side: _isComic
                              ? const BorderSide(
                                  color: Colors.black, width: 2.5)
                              : BorderSide.none,
                        ),
                      ),
                      child: const Text("Close",
                          style: TextStyle(fontWeight: FontWeight.w800)),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    _robotController.dispose();
    _powerAnimController.dispose();
    userController.dispose();
    passController.dispose();
    _flutterTts.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppThemeMode>(
      valueListenable: ThemeModeManager.current,
      builder: (context, _, __) {
        final width = MediaQuery.of(context).size.width;
        return Scaffold(
          backgroundColor: _bgColor,
          body: Stack(
            children: [
              Positioned.fill(
                  child: CustomPaint(painter: _SpaceBgPainter())),
              SafeArea(
                child: Center(
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 24, vertical: 20),
                    child: AnimatedBuilder(
                      animation: _controller,
                      builder: (context, child) => Transform.translate(
                        offset: Offset(0, _slideAnim.value),
                        child:
                            Opacity(opacity: _fadeAnim.value, child: child),
                      ),
                      child: ConstrainedBox(
                        constraints: const BoxConstraints(maxWidth: 430),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            // --- ROBOT & TITLE ---
                            AnimatedBuilder(
                              animation:
                                  Listenable.merge([_blinkAnim, _powerAnim]),
                              builder: (_, __) => GestureDetector(
                                onTap: () {
                                  if (_isPowerOn &&
                                      !_robotController.isAnimating) {
                                    _robotController
                                        .forward()
                                        .then((_) => _robotController.reverse());
                                  }
                                },
                                child: CustomPaint(
                                  size: const Size(200, 160),
                                  painter: _RobotPainter(
                                      eyeOpen: _isPowerOn
                                          ? _blinkAnim.value
                                          : 0.0,
                                      isLoading: isLoading,
                                      powerAnim: _powerAnim.value),
                                ),
                              ),
                            ),
                            const SizedBox(height: 10),
                            Text('Masuk ke Akun Anda',
                                style: TextStyle(
                                    color: _textPrimary,
                                    fontSize: 22,
                                    fontWeight: FontWeight.w900)),
                            const SizedBox(height: 5),
                            Text('Authorized access only',
                                style: TextStyle(
                                    color: _textSecondary,
                                    fontSize: 12,
                                    letterSpacing: 1.5)),
                            const SizedBox(height: 25),

                            // --- FORM CARD ---
                            AnimatedOpacity(
                              duration: const Duration(milliseconds: 400),
                              opacity: _isPowerOn ? 1.0 : 0.3,
                              child: IgnorePointer(
                                ignoring: !_isPowerOn,
                                child: Container(
                                  width: width,
                                  padding: const EdgeInsets.fromLTRB(
                                      22, 24, 22, 22),
                                  decoration: BoxDecoration(
                                    color: _cardColor,
                                    borderRadius: BorderRadius.circular(
                                        _isComic ? 8 : 28),
                                    border: Border.all(
                                      color: _borderColor,
                                      width: _isComic ? 3.5 : 1.5,
                                    ),
                                    boxShadow: _isComic
                                        ? const [
                                            BoxShadow(
                                                color: Colors.black,
                                                offset: Offset(8, 8),
                                                blurRadius: 0),
                                          ]
                                        : (_isLight
                                            ? AppColors.glassShadow
                                            : [
                                                BoxShadow(
                                                  color: Colors.black
                                                      .withOpacity(0.3),
                                                  blurRadius: 20,
                                                  offset:
                                                      const Offset(0, 10),
                                                )
                                              ]),
                                  ),
                                  child: Form(
                                    key: _formKey,
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        _fieldLabel('USERNAME'),
                                        const SizedBox(height: 8),
                                        _customField(
                                          controller: userController,
                                          hint: 'Masukkan username',
                                          icon: Icons.person_outline_rounded,
                                          obscure: false,
                                          onToggle: null,
                                          validator: (v) =>
                                              v == null ||
                                                      v.trim().isEmpty
                                                  ? 'Please enter username'
                                                  : null,
                                        ),
                                        const SizedBox(height: 16),
                                        _fieldLabel('PASSWORD'),
                                        const SizedBox(height: 8),
                                        _customField(
                                          controller: passController,
                                          hint: 'Masukkan kata sandi',
                                          icon: Icons.lock_outline_rounded,
                                          obscure: _obscurePassword,
                                          onToggle: () => setState(() =>
                                              _obscurePassword =
                                                  !_obscurePassword),
                                          validator: (v) =>
                                              v == null || v.isEmpty
                                                  ? 'Please enter password'
                                                  : null,
                                        ),
                                        const SizedBox(height: 10),
                                        Row(
                                          children: [
                                            Expanded(
                                              child: ClipRRect(
                                                borderRadius:
                                                    BorderRadius.circular(8),
                                                child:
                                                    LinearProgressIndicator(
                                                  value: passController
                                                          .text.isEmpty
                                                      ? 0
                                                      : (_passwordStrength
                                                              .startsWith(
                                                                  'WEAK')
                                                          ? .25
                                                          : _passwordStrength
                                                                  .startsWith(
                                                                      'MEDIUM')
                                                              ? .55
                                                              : _passwordStrength
                                                                      .startsWith(
                                                                          'STRONG')
                                                                  ? .8
                                                                  : 1),
                                                  minHeight: 4,
                                                  backgroundColor: _isLight
                                                      ? const Color(
                                                          0xFFE2E8F0)
                                                      : _fieldColor,
                                                  valueColor:
                                                      AlwaysStoppedAnimation(
                                                          _passwordStrengthColor),
                                                ),
                                              ),
                                            ),
                                            const SizedBox(width: 10),
                                            Text(_passwordStrength,
                                                style: TextStyle(
                                                    color:
                                                        _passwordStrengthColor,
                                                    fontSize: 8,
                                                    fontWeight:
                                                        FontWeight.w900,
                                                    letterSpacing: .5)),
                                          ],
                                        ),
                                        const SizedBox(height: 24),
                                        _buildLoginButton(isLoading),
                                        const SizedBox(height: 16),
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          children: [
                                            Icon(Icons.shield_outlined,
                                                size: 14,
                                                color: _textSecondary),
                                            const SizedBox(width: 6),
                                            Flexible(
                                              child: Text(
                                                  'Device binding active for account security.',
                                                  style: TextStyle(
                                                      color: _textSecondary,
                                                      fontSize: 10,
                                                      fontWeight:
                                                          FontWeight.w600)),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),

                            const SizedBox(height: 20),

                            // --- DIVIDER ---
                            Row(
                              children: [
                                Expanded(
                                    child: Divider(
                                        color: _borderColor, thickness: 1.5)),
                                Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 10),
                                  child: Text("OR",
                                      style: TextStyle(
                                          color: _textSecondary,
                                          fontSize: 10,
                                          fontWeight: FontWeight.bold)),
                                ),
                                Expanded(
                                    child: Divider(
                                        color: _borderColor, thickness: 1.5)),
                              ],
                            ),

                            const SizedBox(height: 20),

                            // --- FREE TRIAL BUTTON ---
                            AnimatedOpacity(
                              duration: const Duration(milliseconds: 400),
                              opacity: _isPowerOn ? 1.0 : 0.3,
                              child: IgnorePointer(
                                ignoring: !_isPowerOn,
                                child: _buildFreeTrialButton(),
                              ),
                            ),

                            const SizedBox(height: 24),

                            // --- POWER BUTTON ---
                            GestureDetector(
                              onTap: _togglePower,
                              child: AnimatedContainer(
                                duration: const Duration(milliseconds: 300),
                                width: 60,
                                height: 60,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: _isPowerOn
                                      ? (_isLight
                                          ? AppColors.accent
                                          : _primary.withOpacity(0.2))
                                      : (_isLight
                                          ? const Color(0xFFE2E8F0)
                                          : Colors.black45),
                                  border: Border.all(
                                    color: _isPowerOn
                                        ? (_isComic
                                            ? Colors.black
                                            : _primary)
                                        : (_isComic
                                            ? Colors.black
                                            : (_isLight
                                                ? const Color(0xFFCBD5E1)
                                                : Colors.white24)),
                                    width: _isComic ? 3 : 2.5,
                                  ),
                                  boxShadow: _isPowerOn && !_isComic
                                      ? [
                                          BoxShadow(
                                            color: _primary.withOpacity(0.6),
                                            blurRadius: 20,
                                            spreadRadius: 2,
                                          )
                                        ]
                                      : (_isComic
                                          ? const [
                                              BoxShadow(
                                                  color: Colors.black,
                                                  offset: Offset(4, 4),
                                                  blurRadius: 0),
                                            ]
                                          : []),
                                ),
                                child: Icon(
                                  Icons.power_settings_new_rounded,
                                  size: 30,
                                  color: _isPowerOn
                                      ? (_isLight
                                          ? Colors.white
                                          : _primary)
                                      : (_isLight
                                          ? const Color(0xFF94A3B8)
                                          : Colors.grey),
                                ),
                              ),
                            ),
                            const SizedBox(height: 10),
                            Text(
                              _isPowerOn ? "SYSTEM ONLINE" : "SYSTEM OFFLINE",
                              style: TextStyle(
                                color: _isPowerOn
                                    ? _primary
                                    : (_isLight
                                        ? const Color(0xFF94A3B8)
                                        : Colors.grey),
                                fontSize: 10,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 2,
                              ),
                            ),

                            const SizedBox(height: 20),

                            // --- BUY ACCESS ---
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text('No access yet? ',
                                    style: TextStyle(
                                        color: _textSecondary,
                                        fontSize: 12)),
                                GestureDetector(
                                  onTap: () {},
                                  child: Text('BUY ACCESS',
                                      style: TextStyle(
                                          color: AppColors.pink,
                                          fontSize: 12,
                                          fontWeight: FontWeight.w900,
                                          decoration:
                                              TextDecoration.underline,
                                          decorationColor:
                                              AppColors.pink)),
                                ),
                              ],
                            ),

                            const SizedBox(height: 16),

                            Text('© 2026 VOLY PROJECT  •  v$appVersion',
                                style: TextStyle(
                                    color: _textSecondary,
                                    fontSize: 10,
                                    letterSpacing: 1.4,
                                    fontWeight: FontWeight.w700)),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  // ── Helper Label ──
  Widget _fieldLabel(String text) => Text(text,
      style: TextStyle(
          color: _textSecondary,
          fontSize: 10,
          fontWeight: FontWeight.w900,
          letterSpacing: 1.5));

  // ── Helper Text Field ──
  Widget _customField({
    required TextEditingController controller,
    required String hint,
    required IconData icon,
    required bool obscure,
    required VoidCallback? onToggle,
    required String? Function(String?) validator,
  }) {
    return TextFormField(
      controller: controller,
      obscureText: obscure,
      validator: validator,
      style: TextStyle(
          color: _textPrimary, fontSize: 14, fontWeight: FontWeight.w600),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle:
            TextStyle(color: AppColors.textHint, fontSize: 13),
        prefixIcon: Icon(icon, color: _textSecondary, size: 22),
        suffixIcon: onToggle == null
            ? null
            : IconButton(
                onPressed: onToggle,
                icon: Icon(
                    obscure
                        ? Icons.visibility_off_outlined
                        : Icons.visibility_outlined,
                    color: _textSecondary)),
        filled: true,
        fillColor: _fieldColor,
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 16, vertical: 18),
        border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: BorderSide(
                color: _borderColor, width: _isComic ? 3 : 1.5)),
        enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: BorderSide(
                color: _borderColor, width: _isComic ? 3 : 1.5)),
        focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide:
                BorderSide(color: _primary, width: _isComic ? 3 : 2)),
        errorBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: BorderSide(color: AppColors.red, width: 2)),
      ),
    );
  }

  // ── Custom Login Button ──
  Widget _buildLoginButton(bool isLoading) {
    return GestureDetector(
      onTap: isLoading ? null : login,
      child: Container(
        height: 68,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          gradient: _isLight || !_isComic ? AppColors.btnGrad : null,
          color: _isComic ? AppColors.gold : null,
          border: _isComic
              ? Border.all(color: Colors.black, width: 3.5)
              : null,
          boxShadow: _isComic
              ? const [
                  BoxShadow(
                      color: Colors.black,
                      offset: Offset(0, 6),
                      blurRadius: 0),
                ]
              : [
                  BoxShadow(
                    color: _primary.withOpacity(0.5),
                    blurRadius: 20,
                    offset: const Offset(0, 8),
                  )
                ],
        ),
        child: Row(
          children: [
            Padding(
              padding: const EdgeInsets.only(left: 12.0),
              child: Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: _isComic
                      ? Colors.white
                      : Colors.white.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(12),
                  border: _isComic
                      ? Border.all(color: Colors.black, width: 2)
                      : null,
                ),
                child: Icon(
                  Icons.shield_rounded,
                  color: _isComic ? Colors.black : Colors.white,
                  size: 24,
                ),
              ),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'MASUK APLIKASI',
                      style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1,
                        color: _isComic ? Colors.black : Colors.white,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      'Voltax Premium Account Access',
                      style: TextStyle(
                        fontSize: 9,
                        fontWeight: FontWeight.w600,
                        color: _isComic
                            ? Colors.black54
                            : Colors.white70,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(right: 10.0),
              child: Container(
                height: 42,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                decoration: BoxDecoration(
                  color: _isComic
                      ? Colors.black
                      : (_isLight
                          ? const Color(0xFF1E40AF)
                          : const Color(0xFF150D1E)),
                  borderRadius: BorderRadius.circular(10),
                  border: _isComic
                      ? Border.all(color: Colors.white, width: 2)
                      : null,
                ),
                child: isLoading
                    ? const Center(
                        child: SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(
                                strokeWidth: 2, color: Colors.white)))
                    : Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Text(
                            'LOGIN',
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 1,
                              color: Colors.white,
                            ),
                          ),
                          const SizedBox(width: 6),
                          const Icon(Icons.arrow_forward_rounded,
                              size: 16, color: Colors.white),
                        ],
                      ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── Custom Free Trial Button ──
  Widget _buildFreeTrialButton() {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => const FreeTrialPage()),
        );
      },
      child: Container(
        height: 68,
        decoration: BoxDecoration(
          color: _isLight ? Colors.white : _cardColor,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: _isComic ? Colors.black : AppColors.gold,
            width: _isComic ? 3.5 : 1.5,
          ),
          boxShadow: _isComic
              ? const [
                  BoxShadow(
                      color: Colors.black,
                      offset: Offset(0, 6),
                      blurRadius: 0),
                ]
              : [],
        ),
        child: Row(
          children: [
            Padding(
              padding: const EdgeInsets.only(left: 12.0),
              child: Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: _isComic
                      ? Colors.white
                      : AppColors.gold.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: _isComic
                        ? Colors.black
                        : AppColors.gold.withOpacity(0.5),
                    width: 1.5,
                  ),
                ),
                child: Icon(
                  Icons.confirmation_number_outlined,
                  color: _isComic ? Colors.black : AppColors.gold,
                  size: 24,
                ),
              ),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'FREE TRIAL ACCESS',
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1,
                        color: _isComic
                            ? Colors.black
                            : (_isLight
                                ? const Color(0xFF92400E)
                                : AppColors.gold),
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      'Coba aplikasi secara gratis',
                      style: TextStyle(
                        fontSize: 9,
                        fontWeight: FontWeight.w600,
                        color: _isComic
                            ? Colors.black54
                            : _textSecondary,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(right: 10.0),
              child: Container(
                height: 42,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                decoration: BoxDecoration(
                  color: _isComic ? AppColors.gold : AppColors.gold,
                  borderRadius: BorderRadius.circular(10),
                  border: _isComic
                      ? Border.all(color: Colors.black, width: 2)
                      : null,
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      'START',
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1,
                        color: _isLight ? Colors.black : Colors.black,
                      ),
                    ),
                    const SizedBox(width: 6),
                    const Icon(Icons.arrow_forward_rounded,
                        size: 16, color: Colors.black),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ═════════════════════════════════════════════════════════════════════
// WIDGET POPUP GAGAL — BACKGROUND POPUP.PNG (SESUAI FOTO)
// ═════════════════════════════════════════════════════════════════════
class _FailPopupWidget extends StatelessWidget {
  final String title;
  final String message;
  final VoidCallback onClose;

  const _FailPopupWidget({
    required this.title,
    required this.message,
    required this.onClose,
  });

  @override
  Widget build(BuildContext context) {
    // Lebar popup disesuaikan dengan layar
    final width = MediaQuery.of(context).size.width * 0.85;
    // Menyesuaikan tinggi agar tidak terlalu tinggi dan pas dengan gambar (rasio mirip 1:1 atau 4:3)
    final height = width * 0.85;

    return SizedBox(
      width: width,
      height: height,
      child: Stack(
        alignment: Alignment.center,
        children: [
          // Background popup (cloud) dari assets
          Positioned.fill(
            child: Image.asset(
              'assets/images/popup.png',
              fit: BoxFit.fill,
              errorBuilder: (_, __, ___) => Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(40),
                ),
              ),
            ),
          ),

          // Tombol X (Close) di bagian atas
          Positioned(
            top: height * 0.08,
            child: GestureDetector(
              onTap: onClose,
              child: Container(
                width: width * 0.18,
                height: width * 0.18,
                decoration: const BoxDecoration(
                  color: Color(0xFFFF4D67),
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  Icons.close_rounded,
                  color: Colors.white,
                  size: width * 0.1,
                ),
              ),
            ),
          ),

          // Judul (Teks Utama)
          Positioned(
            top: height * 0.32,
            left: width * 0.1,
            right: width * 0.1,
            child: Text(
              title,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: width * 0.065,
                fontWeight: FontWeight.w900,
                letterSpacing: 2,
                color: const Color(0xFF2A2A2A),
                fontFamily: 'Pek',
              ),
            ),
          ),

          // Pesan (Teks Sub)
          Positioned(
            top: height * 0.45,
            left: width * 0.1,
            right: width * 0.1,
            child: Text(
              message,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: width * 0.038,
                fontWeight: FontWeight.w600,
                color: const Color(0xFF4A4A4A),
                height: 1.4,
                fontFamily: 'Pek',
              ),
            ),
          ),

          // Tombol MENGERTI
          Positioned(
            top: height * 0.62,
            child: GestureDetector(
              onTap: onClose,
              child: Container(
                width: width * 0.55,
                height: height * 0.13,
                decoration: BoxDecoration(
                  color: const Color(0xFFFF4D67),
                  borderRadius: BorderRadius.circular(30),
                ),
                alignment: Alignment.center,
                child: Text(
                  'MENGERTI',
                  style: TextStyle(
                    fontSize: width * 0.04,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 3,
                    color: Colors.white,
                    fontFamily: 'Pek',
                  ),
                ),
              ),
            ),
          ),

          // Gambar Chibi di kanan bawah (opsional, jika aset tersedia)
          Positioned(
            bottom: -10,
            right: -10,
            child: Image.asset(
              'assets/images/chibi.png',
              height: height * 0.35,
              errorBuilder: (_, __, ___) => const SizedBox(),
            ),
          ),
        ],
      ),
    );
  }
}

// ═════════════════════════════════════════════════════════════════════
// BACKGROUND PAINTER — otomatis mengikuti AppColors
// ═════════════════════════════════════════════════════════════════════
class _SpaceBgPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final isComic = ThemeModeManager.isComic3d;
    final isLight = ThemeModeManager.isMonochrome;

    final baseColor = AppColors.bg;
    final dotColor = isLight
        ? const Color(0xFFD0E1F9)
        : (isComic ? const Color(0xFFE0D0A0) : const Color(0xFF2A1B3D));
    final lineColor = isLight
        ? const Color(0xFFBFDBFE)
        : (isComic ? const Color(0xFFC084FC) : const Color(0xFF3D2459));
    final slashColor = isLight
        ? const Color(0xFF93C5FD)
        : (isComic ? const Color(0xFF7C3AED) : const Color(0xFF8B5CF6));
    final starColor = isLight
        ? const Color(0xFF60A5FA)
        : (isComic ? const Color(0xFF9333EA) : const Color(0xFFC4B5FD));

    canvas.drawRect(Offset.zero & size, Paint()..color = baseColor);

    final dots = Paint()..color = dotColor.withOpacity(isComic ? 0.5 : 1.0);
    for (double x = 10; x < size.width; x += 27) {
      for (double y = 10; y < size.height; y += 27) {
        canvas.drawCircle(Offset(x, y), 1.2, dots);
      }
    }

    final line = Paint()
      ..color = lineColor
      ..strokeWidth = 1.5;
    for (double y = 100; y < size.height; y += 180) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y + 35), line);
    }

    final slash = Paint()
      ..color = slashColor.withOpacity(.25)
      ..strokeWidth = 4
      ..strokeCap = StrokeCap.round;
    canvas.drawLine(Offset(size.width * .05, size.height * .35),
        Offset(size.width * .35, size.height * .18), slash);
    canvas.drawLine(Offset(size.width * .72, size.height * .75),
        Offset(size.width * .98, size.height * .62), slash);

    final star = Paint()..color = starColor.withOpacity(.4);
    canvas.drawCircle(Offset(size.width * .15, size.height * .12), 3, star);
    canvas.drawCircle(Offset(size.width * .88, size.height * .45), 2.5, star);
    canvas.drawCircle(Offset(size.width * .25, size.height * .88), 2, star);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

// ═════════════════════════════════════════════════════════════════════
// ROBOT PAINTER — otomatis mengikuti AppColors
// ═════════════════════════════════════════════════════════════════════
class _RobotPainter extends CustomPainter {
  final double eyeOpen;
  final bool isLoading;
  final double powerAnim;

  _RobotPainter({
    required this.eyeOpen,
    required this.isLoading,
    required this.powerAnim,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final isComic = ThemeModeManager.isComic3d;
    final isLight = ThemeModeManager.isMonochrome;
    final cx = size.width / 2;
    final p = Paint()..style = PaintingStyle.fill;
    final outline = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3.5
      ..strokeJoin = StrokeJoin.round;

    final onHead = isLight ? const Color(0xFF3B82F6) : AppColors.accent;
    final onFace = isLight
        ? Colors.white
        : (isComic ? const Color(0xFFFFF8E7) : const Color(0xFF15081F));
    final onEar = isLight
        ? const Color(0xFF60A5FA)
        : (isComic ? const Color(0xFFA78BFA) : const Color(0xFF7A001A));
    final onEarLight = isLight
        ? const Color(0xFF93C5FD)
        : (isComic ? const Color(0xFFC084FC) : const Color(0xFFFF4D4D));
    final onEye = isLight
        ? const Color(0xFF1E40AF)
        : (isComic ? const Color(0xFF9333EA) : AppColors.gold);
    final onMouth = isLight
        ? const Color(0xFF1E40AF)
        : (isComic ? const Color(0xFF9333EA) : AppColors.accent);
    final onBlush = isLight
        ? const Color(0xFFFDA4AF)
        : (isComic ? const Color(0xFFF472B6) : const Color(0xFFE879F9));
    final onAnt = isLoading
        ? AppColors.batteryMid
        : (isLight ? const Color(0xFF2563EB) : AppColors.gold);

    const offHead = Color(0xFF333333);
    const offFace = Color(0xFF111111);
    const offEar = Color(0xFF222222);
    const offEarLight = Color(0xFF333333);
    const offEye = Color(0xFF444444);
    const offMouth = Color(0xFF444444);
    const offAnt = Color(0xFF444444);
    final offOutline =
        isLight ? const Color(0xFF94A3B8) : const Color(0xFF555555);
    final onOutline = isLight ? const Color(0xFF1E293B) : Colors.black;

    final headColor = Color.lerp(offHead, onHead, powerAnim)!;
    final faceColor = Color.lerp(offFace, onFace, powerAnim)!;
    final earColor = Color.lerp(offEar, onEar, powerAnim)!;
    final earLight = Color.lerp(offEarLight, onEarLight, powerAnim)!;
    final eyeColor = Color.lerp(offEye, onEye, powerAnim)!;
    final mouthColor = Color.lerp(offMouth, onMouth, powerAnim)!;
    final blushColor = Color.lerp(Colors.transparent, onBlush, powerAnim)!;
    final antBallColor = Color.lerp(offAnt, onAnt, powerAnim)!;
    outline.color = Color.lerp(offOutline, onOutline, powerAnim)!;

    final headRect = RRect.fromRectAndRadius(
        Rect.fromLTWH(cx - 75, 35, 150, 112), const Radius.circular(32));
    p.color = headColor;
    canvas.drawRRect(headRect, p);
    canvas.drawRRect(headRect, outline);

    final faceRect = RRect.fromRectAndRadius(
        Rect.fromLTWH(cx - 58, 53, 116, 76), const Radius.circular(24));
    p.color = faceColor;
    canvas.drawRRect(faceRect, p);
    canvas.drawRRect(faceRect, outline);

    final earL = RRect.fromRectAndRadius(
        Rect.fromLTWH(cx - 88, 65, 15, 47), const Radius.circular(8));
    final earR = RRect.fromRectAndRadius(
        Rect.fromLTWH(cx + 73, 65, 15, 47), const Radius.circular(8));
    p.color = earColor;
    canvas.drawRRect(earL, p);
    canvas.drawRRect(earR, p);
    canvas.drawRRect(earL, outline);
    canvas.drawRRect(earR, outline);

    p.color = earLight;
    canvas.drawRRect(
        RRect.fromRectAndRadius(
            Rect.fromLTWH(cx - 82, 77, 5, 22), const Radius.circular(3)),
        p);
    canvas.drawRRect(
        RRect.fromRectAndRadius(
            Rect.fromLTWH(cx + 77, 77, 5, 22), const Radius.circular(3)),
        p);

    final eye = Paint()..color = eyeColor;
    final eyeHeight = 25.0 * eyeOpen * powerAnim;
    final eyeWidth = 25.0 * powerAnim;

    if (eyeWidth > 1) {
      final eyeRectL = Rect.fromCenter(
          center: Offset(cx - 27, 87), width: eyeWidth, height: eyeHeight);
      final eyeRectR = Rect.fromCenter(
          center: Offset(cx + 27, 87), width: eyeWidth, height: eyeHeight);
      canvas.drawOval(eyeRectL, eye);
      canvas.drawOval(eyeRectR, eye);
      canvas.drawOval(eyeRectL, outline);
      canvas.drawOval(eyeRectR, outline);

      if (powerAnim > 0.5) {
        p.color = Colors.white.withOpacity(powerAnim);
        canvas.drawCircle(Offset(cx - 23, 84), 4 * powerAnim, p);
        canvas.drawCircle(Offset(cx + 31, 84), 4 * powerAnim, p);
      }
    }

    final mouth = RRect.fromRectAndRadius(
        Rect.fromLTWH(cx - 9, 111, 18, 5), const Radius.circular(3));
    p.color = mouthColor;
    canvas.drawRRect(mouth, p);
    canvas.drawRRect(mouth, outline);

    if (powerAnim > 0.1) {
      p.color = blushColor;
      canvas.drawCircle(Offset(cx - 43, 117), 5 * powerAnim, p);
      canvas.drawCircle(Offset(cx + 43, 117), 5 * powerAnim, p);
    }

    final antenna = Paint()
      ..color = outline.color!
      ..strokeWidth = 5
      ..strokeCap = StrokeCap.round;
    canvas.drawLine(Offset(cx, 35), Offset(cx, 18), antenna);

    final antBall = Paint()..color = antBallColor;
    canvas.drawCircle(Offset(cx, 12), 8 * powerAnim + 2, antBall);
    final antOutline = Paint()
      ..style = PaintingStyle.stroke
      ..color = outline.color!
      ..strokeWidth = 3;
    canvas.drawCircle(Offset(cx, 12), 8 * powerAnim + 2, antOutline);

    if (powerAnim > 0.5 && !isComic && !isLight) {
      final glowPaint = Paint()
        ..color = AppColors.gold.withOpacity(0.3 * powerAnim)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 15);
      canvas.drawCircle(Offset(cx, 12), 12 * powerAnim, glowPaint);
    }
  }

  @override
  bool shouldRepaint(covariant _RobotPainter oldDelegate) =>
      oldDelegate.eyeOpen != eyeOpen ||
      oldDelegate.isLoading != isLoading ||
      oldDelegate.powerAnim != powerAnim;
}