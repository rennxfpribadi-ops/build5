package com.nvrch.pes;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
