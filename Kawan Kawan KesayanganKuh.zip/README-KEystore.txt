NOVARCH ANDROID RELEASE KEYSTORE PACKAGE

Included:
- android/upload-keystore.jks : release signing keystore
- android/key.properties : local Gradle signing configuration
- android/app/build.gradle.kts : release signing integration
- .github/workflows/build-flutter.yml : GitHub Actions APK/AAB workflow
- private-keystore-info/ : Base64 and GitHub Secret values (CONFIDENTIAL)

IMPORTANT:
1. Keep this ZIP and private-keystore-info folder private.
2. Do not commit android/key.properties, android/upload-keystore.jks,
   or private-keystore-info to a public repository.
3. Add the four GitHub Secrets listed in private-keystore-info/GITHUB_SECRETS.txt.
4. Keep an offline backup of upload-keystore.jks and its passwords.
5. This is a newly generated key. If an app was already published using a
   different signing/upload key, do not use this key for its update unless
   the Play Console upload-key reset process has been completed.
